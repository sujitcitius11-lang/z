"""Auth, users, departments, doctors, patients, chatbot."""
import pytest

from tests.conftest import PW

API = "/api/v1"


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_register_login_me(client):
    r = client.post(f"{API}/auth/register", json={"name": "Neo", "email": "neo@t.io", "password": PW})
    assert r.status_code == 201
    assert client.post(f"{API}/auth/register", json={"name": "Neo", "email": "neo@t.io", "password": PW}).status_code == 409
    t = client.post(f"{API}/auth/login", json={"email": "neo@t.io", "password": PW}).json()["access_token"]
    me = client.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {t}"})
    assert me.json()["role"] == "patient"


def test_login_bad_and_422(client, world):
    assert client.post(f"{API}/auth/login", json={"email": "admin@t.io", "password": "nope"}).status_code == 401
    assert client.post(f"{API}/auth/register", json={"name": "x", "email": "bad", "password": "short"}).status_code == 422


def test_no_token_401(client):
    assert client.get(f"{API}/users").status_code == 401


@pytest.mark.parametrize("role,code", [("admin", 200), ("super_admin", 200), ("doctor", 403), ("patient", 403),
                                       ("receptionist", 403), ("pharmacist", 403), ("lab_technician", 403)])
def test_users_rbac(client, world, auth, role, code):
    assert client.get(f"{API}/users", headers=auth(role)).status_code == code


def test_user_crud(client, world, auth):
    h = auth("admin")
    r = client.post(f"{API}/users", headers=h, json={"name": "Pat", "email": "p@t.io", "password": PW, "role": "pharmacist"})
    assert r.status_code == 201
    uid = r.json()["user_id"]
    assert client.put(f"{API}/users/{uid}", headers=h, json={"name": "Pat2"}).json()["name"] == "Pat2"
    assert client.delete(f"{API}/users/{uid}", headers=h).status_code == 204
    assert client.put(f"{API}/users/00000000-0000-0000-0000-000000000000", headers=h, json={}).status_code == 404


def test_departments(client, world, auth):
    h = auth("admin")
    assert client.post(f"{API}/departments", headers=h, json={"name": "Neuro"}).status_code == 201
    assert client.post(f"{API}/departments", headers=h, json={"name": "Neuro"}).status_code == 409
    assert client.post(f"{API}/departments", headers=auth("doctor"), json={"name": "X1"}).status_code == 403
    assert len(client.get(f"{API}/departments", headers=auth("patient")).json()) == 2
    did = str(world["dept"].department_id)
    assert client.delete(f"{API}/departments/{did}", headers=h).status_code == 409


def test_doctors(client, world, auth):
    h = auth("admin")
    body = {"name": "Dr X", "email": "dx@t.io", "password": PW, "department_id": str(world["dept"].department_id),
            "availability": {"Mon": "10-2"}}
    assert client.post(f"{API}/doctors", headers=h, json=body).status_code == 201
    assert client.post(f"{API}/doctors", headers=auth("patient"), json=body).status_code == 403
    did = str(world["doctor"].doctor_id)
    r = client.get(f"{API}/doctors/{did}/availability?day=2026-10-12T00:00:00", headers=auth("patient"))
    assert r.status_code == 200 and len(r.json()["free_slots"]) == 3


def test_patients_scope(client, world, auth):
    r = client.get(f"{API}/patients", headers=auth("patient"))
    assert len(r.json()) == 1
    pid = str(world["patient"].patient_id)
    assert client.get(f"{API}/patients/{pid}", headers=auth("patient")).status_code == 200
    assert client.get(f"{API}/patients", headers=auth("receptionist")).status_code == 200
    assert client.get(f"{API}/patients", headers=auth("lab_technician")).status_code == 200
    new = {"name": "Walk In", "email": "w@t.io", "password": PW, "gender": "Female", "dob": "2000-02-02"}
    assert client.post(f"{API}/patients", headers=auth("receptionist"), json=new).status_code == 201
    assert client.post(f"{API}/patients", headers=auth("patient"), json=new).status_code == 403
    other = client.get(f"{API}/patients", headers=auth("receptionist")).json()
    oid = next(p["patient_id"] for p in other if p["email"] == "w@t.io")
    assert client.get(f"{API}/patients/{oid}", headers=auth("patient")).status_code == 403
    assert client.get(f"{API}/patients/00000000-0000-0000-0000-000000000000", headers=auth("admin")).status_code == 404


def test_chat_offline(client, world, auth):
    r = client.post(f"{API}/chat", headers=auth("patient"), json={"message": "how do I book an appointment?"})
    assert r.status_code == 200 and r.json()["source"] == "offline" and "Appointments" in r.json()["reply"]
    med = client.post(f"{API}/chat", headers=auth("patient"), json={"message": "what dose should I take?"})
    assert "consult your doctor" in med.json()["reply"].lower()
    assert client.post(f"{API}/chat", json={"message": "hi"}).status_code == 401
    assert client.get(f"{API}/chat/status", headers=auth("patient")).json() == {"azure_configured": False}


def test_chat_azure_mock(client, world, auth, monkeypatch):
    import httpx

    from app.core import config

    monkeypatch.setattr(config.get_settings(), "azure_openai_endpoint", "https://x.openai.azure.com")
    monkeypatch.setattr(config.get_settings(), "azure_openai_api_key", "k")
    monkeypatch.setattr(config.get_settings(), "azure_openai_deployment", "gpt")

    class R:
        def raise_for_status(self): ...
        def json(self): return {"choices": [{"message": {"content": " Hello from Azure "}}]}

    seen = {}
    def fake(url, headers, timeout, json):
        seen.update(url=url, key=headers["api-key"], n=len(json["messages"]))
        return R()
    monkeypatch.setattr(httpx, "post", fake)
    r = client.post(f"{API}/chat", headers=auth("doctor"), json={"message": "hi", "history": []})
    assert r.json() == {"reply": "Hello from Azure", "source": "azure"}
    assert "/openai/deployments/gpt/chat/completions" in seen["url"] and seen["key"] == "k"
    monkeypatch.setattr(httpx, "post", lambda *a, **k: (_ for _ in ()).throw(httpx.ConnectError("x")))
    assert client.post(f"{API}/chat", headers=auth("doctor"), json={"message": "hi"}).json()["source"] == "offline"
