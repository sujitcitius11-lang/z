"""Appointments, prescriptions, lab, billing, pharmacy, reports + integration flow."""
from datetime import date, timedelta

import pytest

from tests.conftest import PW

API = "/api/v1"


def _next_weekday_dt(hour=9):
    d = date.today() + timedelta(days=1)
    return f"{d.isoformat()}T{hour:02d}:00:00"


def _book(client, world, auth, hour=9, role="patient"):
    body = {"doctor_id": str(world["doctor"].doctor_id), "appointment_date": _next_weekday_dt(hour)}
    if role == "receptionist":
        body["patient_id"] = str(world["patient"].patient_id)
    return client.post(f"{API}/appointments", headers=auth(role), json=body)


def test_booking_rules(client, world, auth):
    r = _book(client, world, auth)
    assert r.status_code == 201
    assert _book(client, world, auth, role="receptionist").status_code == 409
    assert _book(client, world, auth, hour=20).status_code == 422
    assert client.post(f"{API}/appointments", headers=auth("pharmacist"), json={}).status_code == 403
    aid = r.json()["appointment_id"]
    assert client.patch(f"{API}/appointments/{aid}/cancel", headers=auth("patient")).json()["status"] == "Cancelled"
    assert _book(client, world, auth, role="receptionist").status_code == 201
    assert client.get(f"{API}/notifications", headers=auth("doctor")).json()


def test_appointment_scoping(client, world, auth):
    _book(client, world, auth)
    assert len(client.get(f"{API}/appointments", headers=auth("doctor")).json()) == 1
    assert len(client.get(f"{API}/appointments", headers=auth("patient")).json()) == 1
    assert client.get(f"{API}/appointments", headers=auth("lab_technician")).status_code == 403
    aid = client.get(f"{API}/appointments", headers=auth("doctor")).json()[0]["appointment_id"]
    assert client.put(f"{API}/appointments/{aid}", headers=auth("patient"), json={"status": "Completed"}).status_code == 403
    assert client.put(f"{API}/appointments/{aid}", headers=auth("doctor"), json={"status": "Completed"}).status_code == 200
    assert client.patch(f"{API}/appointments/00000000-0000-0000-0000-000000000000/cancel", headers=auth("doctor")).status_code == 404


def _full_flow(client, world, auth):
    aid = _book(client, world, auth).json()["appointment_id"]
    rx = client.post(f"{API}/prescriptions", headers=auth("doctor"),
                     json={"appointment_id": aid, "diagnosis": "Flu", "medicines": [{"name": "Paracetamol", "dosage": "1-0-1"}]})
    assert rx.status_code == 201
    return aid, rx.json()["prescription_id"]


def test_prescriptions(client, world, auth):
    aid, rid = _full_flow(client, world, auth)
    assert client.get(f"{API}/appointments", headers=auth("doctor")).json()[0]["status"] == "Completed"
    assert client.get(f"{API}/prescriptions/{rid}", headers=auth("patient")).status_code == 200
    assert client.get(f"{API}/prescriptions/{rid}", headers=auth("pharmacist")).status_code == 200
    assert client.get(f"{API}/prescriptions/{rid}", headers=auth("receptionist")).status_code == 403
    assert client.post(f"{API}/prescriptions", headers=auth("patient"), json={}).status_code == 403
    assert client.post(f"{API}/prescriptions", headers=auth("doctor"), json={"appointment_id": aid}).status_code == 422
    pid = str(world["patient"].patient_id)
    assert len(client.get(f"{API}/patients/{pid}/prescriptions", headers=auth("patient")).json()) == 1


def test_lab(client, world, auth):
    pid = str(world["patient"].patient_id)
    f = {"file": ("r.pdf", b"%PDF-1.4 x", "application/pdf")}
    r = client.post(f"{API}/lab-reports", headers=auth("lab_technician"), data={"patient_id": pid, "test_name": "CBC"}, files=f)
    assert r.status_code == 201
    rid = r.json()["report_id"]
    bad = client.post(f"{API}/lab-reports", headers=auth("lab_technician"), data={"patient_id": pid, "test_name": "X"},
                      files={"file": ("m.exe", b"x", "application/octet-stream")})
    assert bad.status_code == 422
    assert client.post(f"{API}/lab-reports", headers=auth("doctor"), data={"patient_id": pid, "test_name": "X"}).status_code == 403
    assert len(client.get(f"{API}/lab-reports", headers=auth("patient")).json()) == 1
    assert client.get(f"{API}/lab-reports/{rid}/download", headers=auth("patient")).content.startswith(b"%PDF")
    assert client.get(f"{API}/lab-reports/{rid}/download", headers=auth("pharmacist")).status_code == 403


def test_billing_flow(client, world, auth):
    pid = str(world["patient"].patient_id)
    body = {"patient_id": pid, "services": [{"name": "Consult", "amount": "500"}, {"name": "CBC", "amount": "250.50"}]}
    r = client.post(f"{API}/billing", headers=auth("receptionist"), json=body)
    assert r.status_code == 201 and float(r.json()["total_amount"]) == 750.50
    bid = r.json()["bill_id"]
    assert client.post(f"{API}/billing", headers=auth("patient"), json=body).status_code == 403
    assert client.post(f"{API}/billing", headers=auth("receptionist"), json={"patient_id": pid, "services": []}).status_code == 422
    p = client.patch(f"{API}/billing/{bid}/payment", headers=auth("receptionist"), json={"payment_status": "Paid", "payment_mode": "Card"})
    assert p.json()["payment_status"] == "Paid"
    pdf = client.get(f"{API}/billing/{bid}/invoice.pdf", headers=auth("patient"))
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF")
    assert client.get(f"{API}/billing/{bid}", headers=auth("doctor")).status_code == 403
    assert len(client.get(f"{API}/billing", headers=auth("patient")).json()) == 1


@pytest.mark.parametrize("role,code", [("pharmacist", 200), ("admin", 200), ("patient", 403), ("doctor", 403)])
def test_pharmacy_rbac(client, world, auth, role, code):
    assert client.get(f"{API}/medicines", headers=auth(role)).status_code == code


def test_pharmacy_dispense(client, world, auth):
    h = auth("pharmacist")
    m = {"name": "Paracetamol", "quantity_available": 5, "expiry_date": (date.today() + timedelta(days=10)).isoformat(), "unit_price": "2"}
    assert client.post(f"{API}/medicines", headers=h, json=m).status_code == 201
    assert client.post(f"{API}/medicines", headers=h, json=m).status_code == 409
    _, rid = _full_flow(client, world, auth)
    ok = client.post(f"{API}/pharmacy/dispense", headers=h, json={"prescription_id": rid, "items": [{"name": "Paracetamol", "quantity": 2}]})
    assert ok.json()["dispensed"][0]["remaining"] == 3
    assert client.post(f"{API}/pharmacy/dispense", headers=h, json={"prescription_id": rid, "items": [{"name": "Paracetamol", "quantity": 9}]}).status_code == 409
    assert client.post(f"{API}/pharmacy/dispense", headers=h, json={"prescription_id": rid, "items": [{"name": "Aspirin", "quantity": 1}]}).status_code == 422
    a = client.get(f"{API}/medicines/alerts", headers=h).json()
    assert len(a["low_stock"]) == 1 and len(a["near_expiry"]) == 1


@pytest.mark.parametrize("role,code", [("admin", 200), ("super_admin", 200), ("doctor", 403), ("receptionist", 403)])
def test_reports_rbac(client, world, auth, role, code):
    assert client.get(f"{API}/reports/revenue", headers=auth(role)).status_code == code


def test_reports_and_export(client, world, auth):
    pid = str(world["patient"].patient_id)
    b = client.post(f"{API}/billing", headers=auth("receptionist"), json={"patient_id": pid, "services": [{"name": "C", "amount": "100"}]}).json()
    client.patch(f"{API}/billing/{b['bill_id']}/payment", headers=auth("receptionist"), json={"payment_status": "Paid"})
    _full_flow(client, world, auth)
    h = auth("admin")
    assert client.get(f"{API}/reports/revenue", headers=h).json()[0]["revenue"] == 100.0
    assert client.get(f"{API}/reports/patients-seen", headers=h).json()[0]["patients"] == 1
    assert client.get(f"{API}/reports/top-departments", headers=h).json()[0]["department"] == "Cardio"
    assert b"revenue" in client.get(f"{API}/reports/export?format=csv", headers=h).content
    assert client.get(f"{API}/reports/export?format=pdf&report=top-departments", headers=h).content.startswith(b"%PDF")
    assert client.get(f"{API}/reports/export?format=xml", headers=h).status_code == 422


def test_audit_written(client, world, auth, db):
    from app.models import AuditLog

    _book(client, world, auth)
    actions = {a.action for a in db.query(AuditLog).all()}
    assert {"LOGIN", "CREATE"} <= actions


def test_seed_super_admin(db, monkeypatch):
    from app.core import config
    from app.models import Role, User
    from app.services.seed import seed_demo, seed_super_admin

    monkeypatch.setattr(config.get_settings(), "admin_email", "Root@T.io")
    monkeypatch.setattr(config.get_settings(), "admin_password", PW)
    seed_super_admin(db)
    assert db.query(User).filter(User.role == Role.super_admin).count() == 1
    seed_demo(db)
    seed_demo(db)
    assert db.query(User).filter(User.email == "doctor@hms-demo.com").count() == 1
