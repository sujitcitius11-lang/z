"""Test fixtures: SQLite DB, client, role-based auth helpers."""
import os
import sys
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_hms.db"
os.environ["SECRET_KEY"] = "test-secret-key-that-is-at-least-32-bytes-long"
os.environ["UPLOAD_DIR"] = "./test_uploads"
os.environ["AZURE_OPENAI_API_KEY"] = ""
os.environ["AZURE_OPENAI_ENDPOINT"] = ""
os.environ["AZURE_OPENAI_DEPLOYMENT"] = ""
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.core.security import hash_password  # noqa: E402
from app.db.base import Base  # noqa: E402
from app.db.session import SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Department, Doctor, Patient, Role, User  # noqa: E402

PW = "Passw0rd!"

from passlib.context import CryptContext  # noqa: E402

import app.core.security as _sec  # noqa: E402

_sec._pwd = CryptContext(schemes=["bcrypt"], bcrypt__rounds=4)


@pytest.fixture()
def db():
    """Fresh schema per test."""
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    from app.routers import auth as _auth

    _auth._attempts.clear()
    s = SessionLocal()
    yield s
    s.close()


@pytest.fixture()
def client(db):
    """HTTP client."""
    with TestClient(app) as c:
        yield c


def _mk(db, role, email, name=None):
    u = User(name=name or role.value, email=email, password_hash=hash_password(PW), role=role)
    db.add(u)
    db.commit()
    return u


@pytest.fixture()
def world(db):
    """One user of each role + dept, doctor, patient profile."""
    d = {r.value: _mk(db, r, f"{r.value}@t.io") for r in Role}
    dep = Department(name="Cardio")
    db.add(dep)
    db.commit()
    doc = Doctor(user_id=d["doctor"].user_id, department_id=dep.department_id,
                 availability={k: "9-12" for k in ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")})
    pat = Patient(user_id=d["patient"].user_id, gender="Male", dob="1990-01-01")
    import datetime
    pat.dob = datetime.date(1990, 1, 1)
    db.add_all([doc, pat])
    db.commit()
    return {"users": d, "dept": dep, "doctor": doc, "patient": pat}


@pytest.fixture()
def auth(client):
    """Return headers for a role."""
    def _h(role: str):
        r = client.post("/api/v1/auth/login", json={"email": f"{role}@t.io", "password": PW})
        assert r.status_code == 200, r.text
        return {"Authorization": f"Bearer {r.json()['access_token']}"}
    return _h
