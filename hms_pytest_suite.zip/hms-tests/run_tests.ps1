# Run from the folder that contains this file after copying it into <project>\backend
python -m pip install -q -r requirements-test.txt
python -m pytest
