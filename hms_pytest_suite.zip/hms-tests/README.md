# HMS pytest suite (34 tests, SQLite, no Azure needed)
Copy the contents of this zip INTO `hms/backend/` (so `tests/`, `pytest.ini` sit next to `app/`), then:
    Windows:  .\run_tests.ps1        Linux/macOS: ./run_tests.sh
Covers: auth/register/login, RBAC matrix per role (parametrized), users, departments, doctors, patients scoping,
appointments (availability, double-booking 409), prescriptions, lab upload validation, billing + invoice PDF,
pharmacy dispense/stock/alerts, reports + CSV/PDF export, audit rows, seeding, chatbot (offline + mocked Azure).
Tests use a throwaway `test_hms.db` and clear AZURE_* keys, so no real keys or network are used. Coverage gate: 80%.
