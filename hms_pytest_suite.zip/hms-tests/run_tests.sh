#!/usr/bin/env bash
pip install -q -r requirements-test.txt && python -m pytest
