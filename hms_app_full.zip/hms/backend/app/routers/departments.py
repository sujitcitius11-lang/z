"""Department endpoints."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_roles
from app.db.session import get_db
from app.models import Department, Doctor, Role, User
from app.schemas.clinical import DepartmentIn, DepartmentOut
from app.services import audit_service
from app.services.common import get_or_404, page

router = APIRouter(prefix="/departments", tags=["departments"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[DepartmentOut])
def list_departments(skip: int = 0, limit: int = 50, db: Session = Depends(get_db),
                     _: User = Depends(get_current_user)):
    """List departments."""
    return page(db.query(Department).order_by(Department.name), skip, limit)


@router.post("", response_model=DepartmentOut, status_code=201)
def create(body: DepartmentIn, request: Request, db: Session = Depends(get_db), me: User = Depends(admin)):
    """Create department."""
    if db.query(Department).filter(Department.name == body.name).first():
        raise HTTPException(409, "Department exists")
    d = Department(**body.model_dump())
    db.add(d)
    db.commit()
    audit_service.log(db, me, "CREATE", "department", d.department_id, request)
    return d


@router.put("/{department_id}", response_model=DepartmentOut)
def update(department_id: uuid.UUID, body: DepartmentIn, request: Request, db: Session = Depends(get_db),
           me: User = Depends(admin)):
    """Update department."""
    d = get_or_404(db, Department, department_id, "Department")
    d.name, d.description = body.name, body.description
    db.commit()
    audit_service.log(db, me, "UPDATE", "department", department_id, request)
    return d


@router.delete("/{department_id}", status_code=204)
def delete(department_id: uuid.UUID, request: Request, db: Session = Depends(get_db), me: User = Depends(admin)):
    """Delete department (409 if doctors assigned)."""
    d = get_or_404(db, Department, department_id, "Department")
    if db.query(Doctor).filter(Doctor.department_id == department_id).first():
        raise HTTPException(409, "Department has doctors")
    db.delete(d)
    db.commit()
    audit_service.log(db, me, "DELETE", "department", department_id, request)
