"""Pharmacy endpoints."""
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Medicine, Prescription, Role, User
from app.schemas.ops import DispenseIn, MedicineIn, MedicineOut, MedicineUpdate
from app.services import audit_service
from app.services.common import get_or_404, page

router = APIRouter(tags=["pharmacy"])
staff = require_roles(Role.pharmacist, Role.admin)


@router.get("/medicines", response_model=list[MedicineOut])
def list_medicines(skip: int = 0, limit: int = 50, search: str | None = None, db: Session = Depends(get_db),
                   _: User = Depends(staff)):
    """List medicines."""
    q = db.query(Medicine)
    if search:
        q = q.filter(Medicine.name.ilike(f"%{search}%"))
    return page(q.order_by(Medicine.name), skip, limit)


@router.get("/medicines/alerts")
def alerts(db: Session = Depends(get_db), _: User = Depends(staff)):
    """Low-stock and near-expiry lists."""
    s = get_settings()
    soon = date.today() + timedelta(days=s.near_expiry_days)
    low = db.query(Medicine).filter(Medicine.quantity_available <= s.low_stock_threshold).all()
    exp = db.query(Medicine).filter(Medicine.expiry_date <= soon).all()
    return {"low_stock": [MedicineOut.model_validate(m).model_dump(mode="json") for m in low],
            "near_expiry": [MedicineOut.model_validate(m).model_dump(mode="json") for m in exp]}


@router.post("/medicines", response_model=MedicineOut, status_code=201)
def create(body: MedicineIn, request: Request, db: Session = Depends(get_db), me: User = Depends(staff)):
    """Add medicine."""
    if db.query(Medicine).filter(Medicine.name == body.name).first():
        raise HTTPException(409, "Medicine exists")
    m = Medicine(**body.model_dump())
    db.add(m)
    db.commit()
    audit_service.log(db, me, "CREATE", "medicine", m.medicine_id, request)
    return m


@router.put("/medicines/{medicine_id}", response_model=MedicineOut)
def update(medicine_id: uuid.UUID, body: MedicineUpdate, request: Request, db: Session = Depends(get_db),
           me: User = Depends(staff)):
    """Update medicine."""
    m = get_or_404(db, Medicine, medicine_id, "Medicine")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(m, k, v)
    db.commit()
    audit_service.log(db, me, "UPDATE", "medicine", medicine_id, request)
    return m


@router.post("/pharmacy/dispense")
def dispense(body: DispenseIn, request: Request, db: Session = Depends(get_db), me: User = Depends(staff)):
    """Dispense only prescribed items; decrement stock or 409."""
    rx = get_or_404(db, Prescription, body.prescription_id, "Prescription")
    prescribed = {m["name"].lower() for m in rx.medicines}
    done = []
    for it in body.items:
        name, qty = str(it.get("name", "")), int(it.get("quantity", 0))
        if name.lower() not in prescribed:
            raise HTTPException(422, f"{name} is not on the prescription")
        m = db.query(Medicine).filter(Medicine.name.ilike(name)).first()
        if m is None:
            raise HTTPException(404, f"{name} not in stock list")
        if qty < 1 or m.quantity_available < qty:
            raise HTTPException(409, f"Insufficient stock for {name}")
        m.quantity_available -= qty
        done.append({"name": m.name, "dispensed": qty, "remaining": m.quantity_available})
    db.commit()
    audit_service.log(db, me, "UPDATE", "pharmacy_dispense", rx.prescription_id, request)
    return {"dispensed": done}
