"""Prescription endpoints."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Appointment, Prescription, Role, User
from app.schemas.clinical import PrescriptionCreate, PrescriptionOut
from app.services import audit_service
from app.services.common import assert_patient_access, doctor_of, get_or_404

router = APIRouter(prefix="/prescriptions", tags=["prescriptions"])


@router.post("", response_model=PrescriptionOut, status_code=201)
def create(body: PrescriptionCreate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(require_roles(Role.doctor))):
    """Doctor writes a prescription and completes the visit."""
    a = get_or_404(db, Appointment, body.appointment_id, "Appointment")
    d = doctor_of(db, user)
    if not d or d.doctor_id != a.doctor_id:
        raise HTTPException(403, "Insufficient permissions")
    rx = Prescription(appointment_id=a.appointment_id, diagnosis=body.diagnosis,
                      medicines=[m.model_dump() for m in body.medicines], created_by=d.doctor_id)
    a.status = "Completed"
    db.add(rx)
    db.commit()
    audit_service.log(db, user, "CREATE", "prescription", rx.prescription_id, request)
    return rx


@router.get("/{prescription_id}", response_model=PrescriptionOut)
def get(prescription_id: uuid.UUID, db: Session = Depends(get_db),
        user: User = Depends(require_roles(Role.patient, Role.pharmacist, Role.doctor))):
    """Get prescription."""
    rx = get_or_404(db, Prescription, prescription_id, "Prescription")
    a = db.get(Appointment, rx.appointment_id)
    assert_patient_access(db, user, a.patient_id)
    return rx
