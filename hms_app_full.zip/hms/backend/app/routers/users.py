"""User admin endpoints."""
import uuid

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.core.security import hash_password
from app.db.session import get_db
from app.models import Role, User
from app.schemas.auth import UserCreate, UserOut, UserUpdate
from app.services import audit_service, user_service
from app.services.common import get_or_404, page

router = APIRouter(prefix="/users", tags=["users"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[UserOut])
def list_users(skip: int = 0, limit: int = 50, role: Role | None = None, sort: str = "created_at",
               db: Session = Depends(get_db), _: User = Depends(admin)):
    """List users."""
    q = db.query(User)
    if role:
        q = q.filter(User.role == role)
    col = getattr(User, sort, User.created_at)
    return page(q.order_by(col), skip, limit)


@router.post("", response_model=UserOut, status_code=201)
def create(body: UserCreate, request: Request, db: Session = Depends(get_db), me: User = Depends(admin)):
    """Create user."""
    u = user_service.create_user(db, body)
    db.commit()
    audit_service.log(db, me, "CREATE", "user", u.user_id, request)
    return u


@router.put("/{user_id}", response_model=UserOut)
def update(user_id: uuid.UUID, body: UserUpdate, request: Request, db: Session = Depends(get_db),
           me: User = Depends(admin)):
    """Update user."""
    u = get_or_404(db, User, user_id, "User")
    data = body.model_dump(exclude_unset=True)
    if "password" in data:
        u.password_hash = hash_password(data.pop("password"))
    for k, v in data.items():
        setattr(u, k, v)
    db.commit()
    audit_service.log(db, me, "UPDATE", "user", user_id, request)
    return u


@router.delete("/{user_id}", status_code=204)
def delete(user_id: uuid.UUID, request: Request, db: Session = Depends(get_db), me: User = Depends(admin)):
    """Deactivate user (soft delete keeps history)."""
    u = get_or_404(db, User, user_id, "User")
    u.status = False
    db.commit()
    audit_service.log(db, me, "DELETE", "user", user_id, request)
