"""Lab report endpoints."""
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.deps import require_roles
from app.db.session import get_db
from app.models import LabReport, Patient, Role, User
from app.schemas.clinical import LabReportOut
from app.services import audit_service
from app.services.common import assert_patient_access, get_or_404, page, patient_of

router = APIRouter(tags=["lab"])
ALLOWED = {".pdf", ".png", ".jpg", ".jpeg"}


@router.post("/lab-reports", response_model=LabReportOut, status_code=201)
async def upload(request: Request, patient_id: uuid.UUID = Form(...), test_name: str = Form(...),
                 result_summary: str | None = Form(None), file: UploadFile | None = File(None),
                 db: Session = Depends(get_db), user: User = Depends(require_roles(Role.lab_technician))):
    """Upload lab report (pdf/png/jpg, size limited)."""
    get_or_404(db, Patient, patient_id, "Patient")
    s = get_settings()
    path = None
    if file is not None and file.filename:
        ext = Path(file.filename).suffix.lower()
        if ext not in ALLOWED:
            raise HTTPException(422, "Only pdf, png, jpg files are allowed")
        data = await file.read()
        if len(data) > s.max_upload_mb * 1024 * 1024:
            raise HTTPException(422, f"File exceeds {s.max_upload_mb} MB")
        Path(s.upload_dir).mkdir(parents=True, exist_ok=True)
        path = str(Path(s.upload_dir) / f"{uuid.uuid4()}{ext}")
        Path(path).write_bytes(data)
    r = LabReport(patient_id=patient_id, test_name=test_name, result_summary=result_summary,
                  report_file=path, created_by=user.user_id)
    db.add(r)
    db.commit()
    audit_service.log(db, user, "CREATE", "lab_report", r.report_id, request)
    return r


@router.get("/lab-reports", response_model=list[LabReportOut])
def list_reports(skip: int = 0, limit: int = 50, patient_id: uuid.UUID | None = None, db: Session = Depends(get_db),
                 user: User = Depends(require_roles(Role.doctor, Role.patient, Role.lab_technician))):
    """List reports (patient sees own)."""
    q = db.query(LabReport)
    if user.role == Role.patient:
        p = patient_of(db, user)
        q = q.filter(LabReport.patient_id == (p.patient_id if p else None))
    elif patient_id:
        q = q.filter(LabReport.patient_id == patient_id)
    return page(q.order_by(LabReport.created_at.desc()), skip, limit)


@router.get("/lab-reports/{report_id}/download")
def download(report_id: uuid.UUID, request: Request, db: Session = Depends(get_db),
             user: User = Depends(require_roles(Role.doctor, Role.patient, Role.lab_technician))):
    """Download report file."""
    r = get_or_404(db, LabReport, report_id, "Report")
    assert_patient_access(db, user, r.patient_id)
    if not r.report_file or not Path(r.report_file).exists():
        raise HTTPException(404, "No file attached")
    audit_service.log(db, user, "VIEW", "lab_report", report_id, request)
    return FileResponse(r.report_file)
