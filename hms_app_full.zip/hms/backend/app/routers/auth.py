"""Auth endpoints."""
import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.deps import get_current_user
from app.core.security import create_access_token, verify_password
from app.db.session import get_db
from app.models import Role, User
from app.schemas.auth import LoginIn, RegisterIn, TokenOut, UserOut
from app.services import audit_service, user_service

router = APIRouter(prefix="/auth", tags=["auth"])
_attempts: dict[str, deque] = defaultdict(deque)


def _rate_limit(key: str) -> None:
    s = get_settings()
    now = time.monotonic()
    q = _attempts[key]
    while q and now - q[0] > s.login_rate_window_s:
        q.popleft()
    if len(q) >= s.login_rate_limit:
        raise HTTPException(429, "Too many login attempts. Try again later.")
    q.append(now)


@router.post("/register", response_model=UserOut, status_code=201)
def register(body: RegisterIn, request: Request, db: Session = Depends(get_db)):
    """Self-register as a patient account."""
    u = user_service.create_user(db, name=body.name, email=body.email, password=body.password,
                                 role=Role.patient, contact_number=body.contact_number)
    db.commit()
    audit_service.log(db, u, "CREATE", "user", u.user_id, request)
    return u


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    """Authenticate and issue JWT (rate limited)."""
    _rate_limit(f"{request.client.host if request.client else 'x'}:{body.email.lower()}")
    u = db.query(User).filter(User.email == body.email.lower()).first()
    if not u or not u.status or not verify_password(body.password, u.password_hash):
        raise HTTPException(401, "Invalid credentials")
    audit_service.log(db, u, "LOGIN", "user", u.user_id, request)
    return TokenOut(access_token=create_access_token(str(u.user_id), u.role.value), role=u.role, name=u.name)


@router.post("/logout", status_code=204)
def logout(user: User = Depends(get_current_user)):
    """Stateless logout; client discards token."""
    return None


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    """Current user."""
    return user
