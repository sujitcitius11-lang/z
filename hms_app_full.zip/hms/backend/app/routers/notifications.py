"""In-app notification endpoints."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import Notification, User

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("")
def mine(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Latest notifications of the caller."""
    rows = db.query(Notification).filter(Notification.user_id == user.user_id).order_by(
        Notification.created_at.desc()).limit(20).all()
    return [{"message": n.message, "created_at": n.created_at.isoformat()} for n in rows]
