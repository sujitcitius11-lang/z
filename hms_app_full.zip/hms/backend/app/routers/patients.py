"""Patient endpoints."""
import uuid

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Appointment, Patient, Prescription, Role, User
from app.schemas.clinical import PatientCreate, PatientOut, PatientUpdate, PrescriptionOut
from app.services import audit_service, user_service
from app.services.common import assert_patient_access, get_or_404, page, patient_of

router = APIRouter(tags=["patients"])
staff = require_roles(Role.admin, Role.receptionist)

@router.get("/patients", response_model=list[PatientOut])
def list_patients(skip: int = 0, limit: int = 50, search: str | None = None, db: Session = Depends(get_db),
                  user: User = Depends(require_roles(Role.admin, Role.receptionist, Role.patient, Role.doctor,
                                                     Role.lab_technician, Role.pharmacist))):
    """List patients (patient sees only self)."""
    q = db.query(Patient).join(User, Patient.user_id == User.user_id)
    if user.role == Role.patient:
        q = q.filter(Patient.user_id == user.user_id)
    if search:
        q = q.filter(User.name.ilike(f"%{search}%"))
    return [user_service.patient_out(p) for p in page(q.order_by(User.name), skip, limit)]

@router.post("/patients", response_model=PatientOut, status_code=201)
def create(body: PatientCreate, request: Request, db: Session = Depends(get_db), me: User = Depends(staff)):
    """Create patient."""
    p = user_service.create_patient(db, body)
    audit_service.log(db, me, "CREATE", "patient", p.patient_id, request)
    return user_service.patient_out(p)

@router.post("/patients/me", response_model=PatientOut, status_code=201)
def create_my_profile(body: PatientUpdate, request: Request, db: Session = Depends(get_db),
                      me: User = Depends(require_roles(Role.patient))):
    """Patient completes own profile after self-registration."""
    from fastapi import HTTPException

    if patient_of(db, me):
        raise HTTPException(409, "Profile already exists")
    d = body.model_dump(exclude_unset=True)
    if not d.get("gender") or not d.get("dob"):
        raise HTTPException(422, "gender and dob are required")
    c = d.pop("contact_number", None)
    if c:
        me.contact_number = c
    p = Patient(user_id=me.user_id, **d)
    db.add(p)
    db.commit()
    db.refresh(p)
    audit_service.log(db, me, "CREATE", "patient", p.patient_id, request)
    return user_service.patient_out(p)

@router.get("/patients/{patient_id}", response_model=PatientOut)
def get_patient(patient_id: uuid.UUID, db: Session = Depends(get_db),
                user: User = Depends(require_roles(Role.admin, Role.receptionist, Role.patient, Role.doctor))):
    """Get patient."""
    assert_patient_access(db, user, patient_id)
    return user_service.patient_out(get_or_404(db, Patient, patient_id, "Patient"))

@router.put("/patients/{patient_id}", response_model=PatientOut)
def update(patient_id: uuid.UUID, body: PatientUpdate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(require_roles(Role.admin, Role.receptionist, Role.patient))):
    """Update patient."""
    assert_patient_access(db, user, patient_id)
    p = get_or_404(db, Patient, patient_id, "Patient")
    d = body.model_dump(exclude_unset=True)
    if "contact_number" in d:
        p.user.contact_number = d.pop("contact_number")
    for k, v in d.items():
        setattr(p, k, v)
    db.commit()
    db.refresh(p)
    audit_service.log(db, user, "UPDATE", "patient", patient_id, request)
    return user_service.patient_out(p)

@router.get("/patients/{patient_id}/prescriptions", response_model=list[PrescriptionOut])
def patient_prescriptions(patient_id: uuid.UUID, db: Session = Depends(get_db),
                          user: User = Depends(require_roles(Role.patient, Role.pharmacist, Role.doctor))):
    """Prescriptions of a patient."""
    assert_patient_access(db, user, patient_id)
    ids = [a.appointment_id for a in db.query(Appointment).filter(Appointment.patient_id == patient_id)]
    return db.query(Prescription).filter(Prescription.appointment_id.in_(ids)).all() if ids else []

