"""Doctor endpoints."""
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_roles
from app.db.session import get_db
from app.models import Doctor, Role, User
from app.schemas.clinical import DoctorCreate, DoctorOut, DoctorUpdate
from app.services import appointment_service, audit_service, user_service
from app.services.common import get_or_404, page

router = APIRouter(prefix="/doctors", tags=["doctors"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[DoctorOut])
def list_doctors(skip: int = 0, limit: int = 50, department_id: uuid.UUID | None = None,
                 db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    """List doctors."""
    q = db.query(Doctor)
    if department_id:
        q = q.filter(Doctor.department_id == department_id)
    return [user_service.doctor_out(d) for d in page(q, skip, limit)]


@router.post("", response_model=DoctorOut, status_code=201)
def create(body: DoctorCreate, request: Request, db: Session = Depends(get_db), me: User = Depends(admin)):
    """Create doctor."""
    d = user_service.create_doctor(db, body)
    audit_service.log(db, me, "CREATE", "doctor", d.doctor_id, request)
    return user_service.doctor_out(d)


@router.put("/{doctor_id}", response_model=DoctorOut)
def update(doctor_id: uuid.UUID, body: DoctorUpdate, request: Request, db: Session = Depends(get_db),
           me: User = Depends(admin)):
    """Update doctor."""
    d = get_or_404(db, Doctor, doctor_id, "Doctor")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(d, k, v)
    db.commit()
    db.refresh(d)
    audit_service.log(db, me, "UPDATE", "doctor", doctor_id, request)
    return user_service.doctor_out(d)


@router.get("/{doctor_id}/availability")
def availability(doctor_id: uuid.UUID, day: datetime | None = None, db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    """Weekly availability, plus free slots for `day` when given."""
    d = get_or_404(db, Doctor, doctor_id, "Doctor")
    out = {"availability": d.availability or {}}
    if day:
        out["free_slots"] = appointment_service.free_slots(db, d, day)
    return out
