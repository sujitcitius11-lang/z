"""Chatbot endpoint."""
from fastapi import APIRouter, Depends

from app.core.deps import get_current_user
from app.models import User
from app.schemas.ops import ChatIn, ChatOut
from app.services import chat_service

router = APIRouter(prefix="/chat", tags=["chatbot"])


@router.post("", response_model=ChatOut)
def chat(body: ChatIn, user: User = Depends(get_current_user)):
    """Ask the HMS help assistant (Azure Foundry/OpenAI, offline fallback)."""
    return chat_service.ask(user, body)


@router.get("/status")
def status(user: User = Depends(get_current_user)):
    """Whether Azure keys are configured (never returns the keys)."""
    return {"azure_configured": chat_service.azure_configured()}
