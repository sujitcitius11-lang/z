"""Report endpoints."""
from typing import Literal

from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Role, User
from app.services import report_service
from app.utils.csv_export import to_csv
from app.utils.pdf import simple_pdf

router = APIRouter(prefix="/reports", tags=["reports"])
admin = require_roles(Role.admin)


@router.get("/revenue")
def revenue(db: Session = Depends(get_db), _: User = Depends(admin)):
    """Daily revenue."""
    return report_service.revenue(db)


@router.get("/patients-seen")
def patients_seen(db: Session = Depends(get_db), _: User = Depends(admin)):
    """Patients seen per day."""
    return report_service.patients_seen(db)


@router.get("/top-departments")
def top_departments(db: Session = Depends(get_db), _: User = Depends(admin)):
    """Departments by load."""
    return report_service.top_departments(db)


@router.get("/export")
def export(format: Literal["csv", "pdf"] = "csv", report: Literal["revenue", "patients-seen", "top-departments"] = "revenue",
           db: Session = Depends(get_db), _: User = Depends(admin)):
    """Export a report as CSV or PDF."""
    rows = {"revenue": report_service.revenue, "patients-seen": report_service.patients_seen,
            "top-departments": report_service.top_departments}[report](db)
    if format == "csv":
        return Response(to_csv(rows), media_type="text/csv",
                        headers={"Content-Disposition": f"attachment; filename={report}.csv"})
    header = list(rows[0].keys()) if rows else ["(no data)"]
    body = [tuple(r.values()) for r in rows]
    pdf = simple_pdf(f"HMS Report: {report}", [], header, body)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename={report}.pdf"})
