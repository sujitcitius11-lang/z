"""Appointment endpoints."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Appointment, Doctor, Patient, Role, User
from app.schemas.clinical import AppointmentCreate, AppointmentOut, AppointmentUpdate
from app.services import appointment_service, audit_service
from app.services.common import doctor_of, get_or_404, page, patient_of
from app.services.notify_service import notify

router = APIRouter(prefix="/appointments", tags=["appointments"])
who = require_roles(Role.patient, Role.receptionist, Role.doctor, Role.admin)


def _check_access(db: Session, user: User, a: Appointment) -> None:
    if user.role == Role.patient:
        p = patient_of(db, user)
        if not p or p.patient_id != a.patient_id:
            raise HTTPException(403, "Insufficient permissions")
    if user.role == Role.doctor:
        d = doctor_of(db, user)
        if not d or d.doctor_id != a.doctor_id:
            raise HTTPException(403, "Insufficient permissions")


@router.get("", response_model=list[AppointmentOut])
def list_appointments(skip: int = 0, limit: int = 50, status: str | None = None, doctor_id: uuid.UUID | None = None,
                      db: Session = Depends(get_db), user: User = Depends(who)):
    """List appointments scoped to the caller."""
    q = db.query(Appointment)
    if user.role == Role.patient:
        p = patient_of(db, user)
        q = q.filter(Appointment.patient_id == (p.patient_id if p else None))
    elif user.role == Role.doctor:
        d = doctor_of(db, user)
        q = q.filter(Appointment.doctor_id == (d.doctor_id if d else None))
    if status:
        q = q.filter(Appointment.status == status)
    if doctor_id:
        q = q.filter(Appointment.doctor_id == doctor_id)
    return page(q.order_by(Appointment.appointment_date.desc()), skip, limit)


@router.post("", response_model=AppointmentOut, status_code=201)
def book(body: AppointmentCreate, request: Request, db: Session = Depends(get_db),
         user: User = Depends(require_roles(Role.patient, Role.receptionist))):
    """Book appointment; slot must be free and within availability."""
    if user.role == Role.patient:
        p = patient_of(db, user)
        if not p:
            raise HTTPException(422, "Complete your patient profile first")
        pid = p.patient_id
    else:
        if not body.patient_id:
            raise HTTPException(422, "patient_id required")
        pid = get_or_404(db, Patient, body.patient_id, "Patient").patient_id
    doc = get_or_404(db, Doctor, body.doctor_id, "Doctor")
    appointment_service.validate_slot(db, doc, body.appointment_date)
    a = Appointment(patient_id=pid, doctor_id=doc.doctor_id, appointment_date=body.appointment_date.replace(tzinfo=None),
                    notes=body.notes)
    db.add(a)
    db.commit()
    pat = db.get(Patient, pid)
    msg = f"Appointment booked for {a.appointment_date:%Y-%m-%d %H:%M}"
    notify(db, doc.user_id, msg)
    notify(db, pat.user_id, msg)
    audit_service.log(db, user, "CREATE", "appointment", a.appointment_id, request)
    return a


@router.put("/{appointment_id}", response_model=AppointmentOut)
def update(appointment_id: uuid.UUID, body: AppointmentUpdate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(who)):
    """Reschedule or complete (doctor)."""
    a = get_or_404(db, Appointment, appointment_id, "Appointment")
    _check_access(db, user, a)
    data = body.model_dump(exclude_unset=True)
    if data.get("status") == "Completed" and user.role not in (Role.doctor, Role.admin, Role.super_admin):
        raise HTTPException(403, "Only a doctor can complete a visit")
    if "appointment_date" in data and data["appointment_date"]:
        doc = db.get(Doctor, a.doctor_id)
        appointment_service.validate_slot(db, doc, data["appointment_date"], a.appointment_id)
        data["appointment_date"] = data["appointment_date"].replace(tzinfo=None)
    for k, v in data.items():
        setattr(a, k, v)
    db.commit()
    audit_service.log(db, user, "UPDATE", "appointment", appointment_id, request)
    return a


@router.patch("/{appointment_id}/cancel", response_model=AppointmentOut)
def cancel(appointment_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(who)):
    """Cancel appointment."""
    a = get_or_404(db, Appointment, appointment_id, "Appointment")
    _check_access(db, user, a)
    a.status = "Cancelled"
    db.commit()
    audit_service.log(db, user, "UPDATE", "appointment", appointment_id, request)
    return a
