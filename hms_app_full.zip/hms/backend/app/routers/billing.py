"""Billing endpoints."""
import uuid

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from app.core.deps import require_roles
from app.db.session import get_db
from app.models import Bill, Patient, Role, User
from app.schemas.ops import BillCreate, BillOut, PaymentUpdate
from app.services import audit_service, billing_service
from app.services.common import assert_patient_access, get_or_404, page, patient_of

router = APIRouter(prefix="/billing", tags=["billing"])


@router.get("", response_model=list[BillOut])
def list_bills(skip: int = 0, limit: int = 50, patient_id: uuid.UUID | None = None, db: Session = Depends(get_db),
               user: User = Depends(require_roles(Role.receptionist, Role.patient))):
    """List bills (patient sees own)."""
    q = db.query(Bill)
    if user.role == Role.patient:
        p = patient_of(db, user)
        q = q.filter(Bill.patient_id == (p.patient_id if p else None))
    elif patient_id:
        q = q.filter(Bill.patient_id == patient_id)
    return page(q.order_by(Bill.created_at.desc()), skip, limit)


@router.post("", response_model=BillOut, status_code=201)
def create(body: BillCreate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(require_roles(Role.receptionist))):
    """Create bill; total is the sum of services."""
    get_or_404(db, Patient, body.patient_id, "Patient")
    b = Bill(patient_id=body.patient_id, services=[{"name": s.name, "amount": str(s.amount)} for s in body.services],
             total_amount=billing_service.total_of(body.services), payment_mode=body.payment_mode)
    db.add(b)
    db.commit()
    audit_service.log(db, user, "CREATE", "bill", b.bill_id, request)
    return b


@router.get("/{bill_id}", response_model=BillOut)
def get(bill_id: uuid.UUID, db: Session = Depends(get_db),
        user: User = Depends(require_roles(Role.receptionist, Role.patient))):
    """Get bill."""
    b = get_or_404(db, Bill, bill_id, "Bill")
    assert_patient_access(db, user, b.patient_id)
    return b


@router.patch("/{bill_id}/payment", response_model=BillOut)
def pay(bill_id: uuid.UUID, body: PaymentUpdate, request: Request, db: Session = Depends(get_db),
        user: User = Depends(require_roles(Role.receptionist))):
    """Record payment."""
    b = get_or_404(db, Bill, bill_id, "Bill")
    b.payment_status = body.payment_status
    if body.payment_mode:
        b.payment_mode = body.payment_mode
    db.commit()
    audit_service.log(db, user, "UPDATE", "bill", bill_id, request)
    return b


@router.get("/{bill_id}/invoice.pdf")
def invoice(bill_id: uuid.UUID, db: Session = Depends(get_db),
            user: User = Depends(require_roles(Role.receptionist, Role.patient))):
    """Invoice PDF."""
    b = get_or_404(db, Bill, bill_id, "Bill")
    assert_patient_access(db, user, b.patient_id)
    name = db.get(Patient, b.patient_id).user.name
    return Response(billing_service.invoice_pdf(b, name), media_type="application/pdf")
