"""Shared schema types."""
from pydantic import BaseModel, ConfigDict


class ORMModel(BaseModel):
    """Base for response schemas."""

    model_config = ConfigDict(from_attributes=True)
