"""Billing, pharmacy, reports, chat schemas."""
import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

from app.schemas.common import ORMModel


class ServiceLine(BaseModel):
    """Billable line."""

    name: str
    amount: Decimal = Field(ge=0)


class BillCreate(BaseModel):
    """Create bill."""

    patient_id: uuid.UUID
    services: list[ServiceLine] = Field(min_length=1)
    payment_mode: Literal["Cash", "Card", "Online"] | None = None


class PaymentUpdate(BaseModel):
    """Record payment."""

    payment_status: Literal["Paid", "Unpaid", "Partially Paid"]
    payment_mode: Literal["Cash", "Card", "Online"] | None = None


class BillOut(ORMModel):
    """Bill response."""

    bill_id: uuid.UUID
    patient_id: uuid.UUID
    services: list[ServiceLine]
    total_amount: Decimal
    payment_status: str
    payment_mode: str | None
    created_at: datetime


class MedicineIn(BaseModel):
    """Medicine body."""

    name: str = Field(min_length=1)
    quantity_available: int = Field(ge=0)
    expiry_date: date
    unit_price: Decimal = Field(ge=0)


class MedicineUpdate(BaseModel):
    """Medicine partial update."""

    quantity_available: int | None = Field(default=None, ge=0)
    expiry_date: date | None = None
    unit_price: Decimal | None = Field(default=None, ge=0)


class MedicineOut(ORMModel, MedicineIn):
    """Medicine response."""

    medicine_id: uuid.UUID


class DispenseIn(BaseModel):
    """Dispense against prescription."""

    prescription_id: uuid.UUID
    items: list[dict] = Field(min_length=1, description="[{'name': str, 'quantity': int}]")


class ChatMessage(BaseModel):
    """One chat turn."""

    role: Literal["user", "assistant"]
    content: str = Field(max_length=4000)


class ChatIn(BaseModel):
    """Chat request."""

    message: str = Field(min_length=1, max_length=2000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=20)


class ChatOut(BaseModel):
    """Chat reply."""

    reply: str
    source: Literal["azure", "offline"]
