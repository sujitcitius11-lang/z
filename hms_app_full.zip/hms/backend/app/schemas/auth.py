"""Auth and user schemas."""
import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field

from app.models import Role
from app.schemas.common import ORMModel


class RegisterIn(BaseModel):
    """Patient self-registration."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = None


class LoginIn(BaseModel):
    """Login body."""

    email: EmailStr
    password: str


class TokenOut(BaseModel):
    """JWT response."""

    access_token: str
    token_type: str = "bearer"
    role: Role
    name: str


class UserCreate(BaseModel):
    """Admin creates user."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: Role
    contact_number: str | None = None


class UserUpdate(BaseModel):
    """Admin updates user."""

    name: str | None = None
    role: Role | None = None
    contact_number: str | None = None
    status: bool | None = None
    password: str | None = Field(default=None, min_length=8, max_length=72)


class UserOut(ORMModel):
    """User response."""

    user_id: uuid.UUID
    name: str
    email: str
    role: Role
    contact_number: str | None
    status: bool
    created_at: datetime
