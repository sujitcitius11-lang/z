"""Patients, doctors, departments, appointments, prescriptions, lab."""
import uuid
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field

from app.schemas.common import ORMModel


class DepartmentIn(BaseModel):
    """Department body."""

    name: str = Field(min_length=2, max_length=120)
    description: str | None = None


class DepartmentOut(ORMModel, DepartmentIn):
    """Department response."""

    department_id: uuid.UUID


class PatientCreate(BaseModel):
    """Receptionist/admin creates patient + account."""

    name: str = Field(min_length=2)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = None
    gender: Literal["Male", "Female", "Other"]
    dob: date
    blood_group: str | None = None
    address: str | None = None
    emergency_contact: str | None = None
    allergies: str | None = None


class PatientUpdate(BaseModel):
    """Patient update."""

    gender: Literal["Male", "Female", "Other"] | None = None
    dob: date | None = None
    blood_group: str | None = None
    address: str | None = None
    emergency_contact: str | None = None
    allergies: str | None = None
    contact_number: str | None = None


class PatientOut(BaseModel):
    """Patient response (flattened with user name/email)."""

    patient_id: uuid.UUID
    user_id: uuid.UUID
    name: str
    email: str
    contact_number: str | None
    gender: str
    dob: date
    blood_group: str | None
    address: str | None
    emergency_contact: str | None
    allergies: str | None


class DoctorCreate(BaseModel):
    """Admin creates doctor + account."""

    name: str = Field(min_length=2)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = None
    department_id: uuid.UUID
    qualification: str | None = None
    availability: dict[str, str] = Field(default_factory=dict)


class DoctorUpdate(BaseModel):
    """Doctor update."""

    department_id: uuid.UUID | None = None
    qualification: str | None = None
    availability: dict[str, str] | None = None


class DoctorOut(BaseModel):
    """Doctor response."""

    doctor_id: uuid.UUID
    user_id: uuid.UUID
    name: str
    email: str
    department_id: uuid.UUID
    department: str
    qualification: str | None
    availability: dict[str, str]


class AppointmentCreate(BaseModel):
    """Book appointment."""

    patient_id: uuid.UUID | None = None
    doctor_id: uuid.UUID
    appointment_date: datetime
    notes: str | None = None


class AppointmentUpdate(BaseModel):
    """Update appointment."""

    appointment_date: datetime | None = None
    status: Literal["Scheduled", "Completed", "Cancelled"] | None = None
    notes: str | None = None


class AppointmentOut(ORMModel):
    """Appointment response."""

    appointment_id: uuid.UUID
    patient_id: uuid.UUID
    doctor_id: uuid.UUID
    appointment_date: datetime
    status: str
    notes: str | None


class MedicineLine(BaseModel):
    """Prescribed medicine."""

    name: str
    dosage: str


class PrescriptionCreate(BaseModel):
    """Doctor writes prescription."""

    appointment_id: uuid.UUID
    diagnosis: str = Field(min_length=2)
    medicines: list[MedicineLine] = Field(default_factory=list)


class PrescriptionOut(ORMModel):
    """Prescription response."""

    prescription_id: uuid.UUID
    appointment_id: uuid.UUID
    diagnosis: str
    medicines: list[MedicineLine]
    created_by: uuid.UUID


class LabReportOut(ORMModel):
    """Lab report response."""

    report_id: uuid.UUID
    patient_id: uuid.UUID
    test_name: str
    result_summary: str | None
    report_file: str | None
    created_by: uuid.UUID
    created_at: datetime
