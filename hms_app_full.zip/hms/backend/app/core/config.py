"""Application settings loaded from environment / .env."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed settings; secrets come from env only."""

    model_config = SettingsConfigDict(env_file=(".env", "../.env"), extra="ignore")

    database_url: str = "sqlite:///./hms.db"
    secret_key: str = "change-me-in-env"
    algorithm: str = "HS256"
    access_token_minutes: int = 60
    frontend_origin: str = "http://localhost:8501"
    upload_dir: str = "./uploads"
    max_upload_mb: int = 5
    login_rate_limit: int = 10
    login_rate_window_s: int = 60
    low_stock_threshold: int = 10
    near_expiry_days: int = 30
    seed_demo_data: bool = False
    admin_email: str = ""
    admin_password: str = ""

    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_deployment: str = ""
    azure_openai_api_version: str = "2024-10-21"
    chatbot_timeout_s: int = 30


@lru_cache
def get_settings() -> Settings:
    """Return cached settings."""
    return Settings()
