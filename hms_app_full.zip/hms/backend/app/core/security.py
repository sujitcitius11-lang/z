"""Password hashing and JWT helpers."""
from datetime import datetime, timedelta, timezone

import jwt
from passlib.context import CryptContext

from app.core.config import get_settings

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Return bcrypt hash."""
    return _pwd.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """Check password against hash."""
    return _pwd.verify(password, hashed)


def create_access_token(subject: str, role: str) -> str:
    """Create signed JWT."""
    s = get_settings()
    exp = datetime.now(timezone.utc) + timedelta(minutes=s.access_token_minutes)
    return jwt.encode({"sub": subject, "role": role, "exp": exp}, s.secret_key, algorithm=s.algorithm)


def decode_token(token: str) -> dict:
    """Decode JWT or raise jwt.PyJWTError."""
    s = get_settings()
    return jwt.decode(token, s.secret_key, algorithms=[s.algorithm])
