"""ORM models."""
import enum
from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import JSON, Boolean, Date, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, new_id


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Role(str, enum.Enum):
    """User roles."""

    admin = "admin"
    doctor = "doctor"
    receptionist = "receptionist"
    patient = "patient"
    lab_technician = "lab_technician"
    pharmacist = "pharmacist"
    super_admin = "super_admin"


class User(Base):
    """Login account."""

    __tablename__ = "users"
    user_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(Enum(Role))
    contact_number: Mapped[str | None] = mapped_column(String(30), nullable=True)
    status: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Department(Base):
    """Hospital department."""

    __tablename__ = "departments"
    department_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)


class Patient(Base):
    """Patient profile."""

    __tablename__ = "patients"
    patient_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    user_id: Mapped[object] = mapped_column(ForeignKey("users.user_id"), unique=True)
    gender: Mapped[str] = mapped_column(String(10))
    dob: Mapped[date] = mapped_column(Date)
    blood_group: Mapped[str | None] = mapped_column(String(5), nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    emergency_contact: Mapped[str | None] = mapped_column(String(60), nullable=True)
    allergies: Mapped[str | None] = mapped_column(Text, nullable=True)
    user: Mapped[User] = relationship()


class Doctor(Base):
    """Doctor profile."""

    __tablename__ = "doctors"
    doctor_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    user_id: Mapped[object] = mapped_column(ForeignKey("users.user_id"), unique=True)
    department_id: Mapped[object] = mapped_column(ForeignKey("departments.department_id"))
    qualification: Mapped[str | None] = mapped_column(String(255), nullable=True)
    availability: Mapped[dict] = mapped_column(JSON, default=dict)
    user: Mapped[User] = relationship()
    department: Mapped[Department] = relationship()


class Appointment(Base):
    """Booked visit."""

    __tablename__ = "appointments"
    appointment_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    patient_id: Mapped[object] = mapped_column(ForeignKey("patients.patient_id"))
    doctor_id: Mapped[object] = mapped_column(ForeignKey("doctors.doctor_id"))
    appointment_date: Mapped[datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(15), default="Scheduled")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Prescription(Base):
    """Prescription issued after a visit."""

    __tablename__ = "prescriptions"
    prescription_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    appointment_id: Mapped[object] = mapped_column(ForeignKey("appointments.appointment_id"))
    diagnosis: Mapped[str] = mapped_column(Text)
    medicines: Mapped[list] = mapped_column(JSON, default=list)
    created_by: Mapped[object] = mapped_column(ForeignKey("doctors.doctor_id"))


class LabReport(Base):
    """Uploaded lab report."""

    __tablename__ = "lab_reports"
    report_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    patient_id: Mapped[object] = mapped_column(ForeignKey("patients.patient_id"))
    test_name: Mapped[str] = mapped_column(String(120))
    result_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    report_file: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[object] = mapped_column(ForeignKey("users.user_id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Bill(Base):
    """Invoice."""

    __tablename__ = "billing"
    bill_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    patient_id: Mapped[object] = mapped_column(ForeignKey("patients.patient_id"))
    services: Mapped[list] = mapped_column(JSON, default=list)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    payment_status: Mapped[str] = mapped_column(String(20), default="Unpaid")
    payment_mode: Mapped[str | None] = mapped_column(String(10), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Medicine(Base):
    """Pharmacy stock item."""

    __tablename__ = "medicines"
    medicine_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    quantity_available: Mapped[int] = mapped_column(Integer, default=0)
    expiry_date: Mapped[date] = mapped_column(Date)
    unit_price: Mapped[Decimal] = mapped_column(Numeric(10, 2))


class AuditLog(Base):
    """Audit trail row."""

    __tablename__ = "audit_logs"
    log_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    user_id: Mapped[object | None] = mapped_column(ForeignKey("users.user_id"), nullable=True)
    action: Mapped[str] = mapped_column(String(10))
    entity: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str | None] = mapped_column(String(60), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)


class Notification(Base):
    """In-app notification."""

    __tablename__ = "notifications"
    notification_id: Mapped[object] = mapped_column(Uuid, primary_key=True, default=new_id)
    user_id: Mapped[object] = mapped_column(ForeignKey("users.user_id"))
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    read: Mapped[bool] = mapped_column(Boolean, default=False)
