"""Declarative base and portable column helpers."""
import uuid

from sqlalchemy import JSON, Uuid
from sqlalchemy.orm import DeclarativeBase

JsonType = JSON
UuidType = Uuid


def new_id() -> uuid.UUID:
    """Generate UUID primary key."""
    return uuid.uuid4()


class Base(DeclarativeBase):
    """Base class for all models."""
