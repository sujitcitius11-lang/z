"""Appointment rules: availability, double booking."""
from datetime import datetime

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models import Appointment, Doctor

_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _window(spec: str) -> tuple[int, int] | None:
    """Parse '10-2' or '14-18' to 24h hours; hours below 8 are treated as PM."""
    try:
        a, b = (int(x) for x in spec.split("-"))
    except ValueError:
        return None
    if a < 8:
        a += 12
    if b <= a:
        b += 12
    return a, b


def slots_for(doctor: Doctor, day: datetime) -> list[int]:
    """Bookable hour slots for a doctor on a date."""
    w = _window((doctor.availability or {}).get(_DAYS[day.weekday()], ""))
    return list(range(w[0], w[1])) if w else []


def validate_slot(db: Session, doctor: Doctor, when: datetime, exclude_id=None) -> None:
    """Raise 422 if outside availability, 409 if taken."""
    if when.minute or when.second or when.hour not in slots_for(doctor, when):
        raise HTTPException(422, "Time is outside the doctor's availability (use whole-hour slots)")
    q = db.query(Appointment).filter(Appointment.doctor_id == doctor.doctor_id,
                                     Appointment.appointment_date == when.replace(tzinfo=None),
                                     Appointment.status != "Cancelled")
    if exclude_id:
        q = q.filter(Appointment.appointment_id != exclude_id)
    if q.first():
        raise HTTPException(409, "Slot already booked")


def free_slots(db: Session, doctor: Doctor, day: datetime) -> list[str]:
    """Free ISO slots for a day."""
    out = []
    for h in slots_for(doctor, day):
        t = day.replace(hour=h, minute=0, second=0, microsecond=0, tzinfo=None)
        taken = db.query(Appointment).filter(Appointment.doctor_id == doctor.doctor_id,
                                             Appointment.appointment_date == t,
                                             Appointment.status != "Cancelled").first()
        if not taken:
            out.append(t.isoformat())
    return out
