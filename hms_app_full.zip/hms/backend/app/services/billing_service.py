"""Billing totals and invoice PDF."""
from decimal import Decimal

from app.models import Bill
from app.schemas.ops import ServiceLine
from app.utils.pdf import simple_pdf


def total_of(lines: list[ServiceLine]) -> Decimal:
    """Sum service amounts."""
    return sum((Decimal(s.amount) for s in lines), Decimal("0.00"))


def invoice_pdf(bill: Bill, patient_name: str) -> bytes:
    """Render invoice PDF bytes."""
    rows = [(s["name"], f"{Decimal(str(s['amount'])):.2f}") for s in bill.services]
    rows.append(("TOTAL", f"{bill.total_amount:.2f}"))
    head = f"Invoice {bill.bill_id} | Patient: {patient_name} | Status: {bill.payment_status}"
    return simple_pdf("HMS Invoice", [head], ["Service", "Amount"], rows)
