"""Shared lookup helpers."""
import uuid

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models import Doctor, Patient, Role, User


def get_or_404(db: Session, model, pk, label: str):
    """Fetch by PK or raise 404."""
    obj = db.get(model, pk)
    if obj is None:
        raise HTTPException(404, f"{label} not found")
    return obj


def patient_of(db: Session, user: User) -> Patient | None:
    """Patient profile of a user."""
    return db.query(Patient).filter(Patient.user_id == user.user_id).first()


def doctor_of(db: Session, user: User) -> Doctor | None:
    """Doctor profile of a user."""
    return db.query(Doctor).filter(Doctor.user_id == user.user_id).first()


def assert_patient_access(db: Session, user: User, patient_id: uuid.UUID) -> None:
    """Patients may only touch their own record."""
    if user.role == Role.patient:
        p = patient_of(db, user)
        if p is None or p.patient_id != patient_id:
            raise HTTPException(403, "Insufficient permissions")


def page(q, skip: int, limit: int):
    """Apply skip/limit with caps."""
    return q.offset(max(skip, 0)).limit(min(max(limit, 1), 200)).all()
