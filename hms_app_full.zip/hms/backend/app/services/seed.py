"""Startup seeding: bootstrap admin and optional synthetic demo data."""
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import hash_password
from app.models import Department, Doctor, Medicine, Patient, Role, User


def _user(db: Session, name, email, role, pw="Passw0rd!"):
    u = db.query(User).filter(User.email == email).first()
    if u:
        return u
    u = User(name=name, email=email, password_hash=hash_password(pw), role=role)
    db.add(u)
    db.flush()
    return u


def seed_super_admin(db: Session) -> None:
    """Create the first super admin from env (no hard-coded password)."""
    st = get_settings()
    email, pw = st.admin_email, st.admin_password
    if email and pw and not db.query(User).filter(User.role == Role.super_admin).first():
        _user(db, "Super Admin", email.lower(), Role.super_admin, pw)
        db.commit()


def seed_demo(db: Session) -> None:
    """Synthetic demo users, department, doctor, patient, medicines (dev only)."""
    if db.query(Department).first():
        return
    dep = Department(name="General Medicine", description="Primary care")
    db.add(dep)
    db.flush()
    _user(db, "Demo Admin", "admin@hms-demo.com", Role.admin)
    _user(db, "Demo Reception", "reception@hms-demo.com", Role.receptionist)
    _user(db, "Demo Lab", "lab@hms-demo.com", Role.lab_technician)
    _user(db, "Demo Pharmacist", "pharmacy@hms-demo.com", Role.pharmacist)
    du = _user(db, "Dr. Demo", "doctor@hms-demo.com", Role.doctor)
    pu = _user(db, "Demo Patient", "patient@hms-demo.com", Role.patient)
    db.add(Doctor(user_id=du.user_id, department_id=dep.department_id, qualification="MBBS",
                  availability={d: "9-5" for d in ("Mon", "Tue", "Wed", "Thu", "Fri")}))
    db.add(Patient(user_id=pu.user_id, gender="Other", dob=date(1990, 1, 1), blood_group="O+", allergies=""))
    for n, q in (("Paracetamol", 100), ("Amoxicillin", 5), ("Cetirizine", 50)):
        db.add(Medicine(name=n, quantity_available=q, expiry_date=date.today() + timedelta(days=400),
                        unit_price=Decimal("2.50")))
    db.commit()
