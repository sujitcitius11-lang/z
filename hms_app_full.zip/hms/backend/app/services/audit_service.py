"""Audit log writer."""
from fastapi import Request
from sqlalchemy.orm import Session

from app.models import AuditLog, User


def log(db: Session, user: User | None, action: str, entity: str, entity_id=None, request: Request | None = None) -> None:
    """Persist one audit row."""
    ip = request.client.host if request is not None and request.client else None
    db.add(AuditLog(user_id=user.user_id if user else None, action=action, entity=entity,
                    entity_id=str(entity_id) if entity_id else None, ip_address=ip))
    db.commit()
