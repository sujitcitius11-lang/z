"""In-app notifications."""
from sqlalchemy.orm import Session

from app.models import Notification


def notify(db: Session, user_id, message: str) -> None:
    """Create an in-app notification."""
    db.add(Notification(user_id=user_id, message=message))
    db.commit()
