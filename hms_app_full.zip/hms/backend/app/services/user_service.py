"""User, patient, doctor business logic."""
from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import Doctor, Patient, Role, User
from app.schemas.auth import UserCreate
from app.schemas.clinical import DoctorCreate, DoctorOut, PatientCreate, PatientOut


def create_user(db: Session, data: UserCreate | None = None, **kw) -> User:
    """Create a user; 409 on duplicate email."""
    d = data.model_dump() if data else kw
    email = d["email"].lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(409, "Email already registered")
    u = User(name=d["name"], email=email, password_hash=hash_password(d["password"]),
             role=d["role"], contact_number=d.get("contact_number"))
    db.add(u)
    db.flush()
    return u


def patient_out(p: Patient) -> PatientOut:
    """Flatten patient + user."""
    return PatientOut(patient_id=p.patient_id, user_id=p.user_id, name=p.user.name, email=p.user.email,
                      contact_number=p.user.contact_number, gender=p.gender, dob=p.dob,
                      blood_group=p.blood_group, address=p.address,
                      emergency_contact=p.emergency_contact, allergies=p.allergies)


def create_patient(db: Session, d: PatientCreate) -> Patient:
    """Create patient account + profile."""
    u = create_user(db, name=d.name, email=d.email, password=d.password, role=Role.patient,
                    contact_number=d.contact_number)
    p = Patient(user_id=u.user_id, gender=d.gender, dob=d.dob, blood_group=d.blood_group, address=d.address,
                emergency_contact=d.emergency_contact, allergies=d.allergies)
    db.add(p)
    db.commit()
    db.refresh(p)
    return p


def doctor_out(d: Doctor) -> DoctorOut:
    """Flatten doctor."""
    return DoctorOut(doctor_id=d.doctor_id, user_id=d.user_id, name=d.user.name, email=d.user.email,
                     department_id=d.department_id, department=d.department.name,
                     qualification=d.qualification, availability=d.availability or {})


def create_doctor(db: Session, d: DoctorCreate) -> Doctor:
    """Create doctor account + profile."""
    from app.models import Department

    if db.get(Department, d.department_id) is None:
        raise HTTPException(404, "Department not found")
    u = create_user(db, name=d.name, email=d.email, password=d.password, role=Role.doctor,
                    contact_number=d.contact_number)
    doc = Doctor(user_id=u.user_id, department_id=d.department_id, qualification=d.qualification,
                 availability=d.availability)
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc
