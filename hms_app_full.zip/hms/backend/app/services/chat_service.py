"""HMS help chatbot: Azure AI Foundry / Azure OpenAI with offline fallback."""
import httpx

from app.core.config import get_settings
from app.models import User
from app.schemas.ops import ChatIn, ChatOut

PAGES = {
    "admin": "Patients, Doctors, Appointments(view), Pharmacy, Reports, Admin (users, departments)",
    "super_admin": "Patients, Doctors, Pharmacy, Reports, Admin (users, departments)",
    "doctor": "Doctors, Appointments, Consultation (complete visit + prescription), Lab Reports",
    "receptionist": "Patients, Doctors, Appointments (book), Billing (create bill, record payment, invoice PDF)",
    "patient": "Patients (own profile), Doctors, Appointments (book/cancel), Lab Reports (own), Billing (own)",
    "lab_technician": "Doctors, Lab Reports (upload pdf/png/jpg up to the size limit)",
    "pharmacist": "Doctors, Pharmacy (stock, dispense against prescription, low-stock and near-expiry alerts)",
}

SYSTEM = (
    "You are the HMS help assistant for a hospital management web app. Only explain how to use the app "
    "(pages, buttons, workflows, roles). Never diagnose, never give medical advice, never suggest or change "
    "medicines or doses, and never reveal other people's data. For medical questions reply: 'Please consult "
    "your doctor.' Keep answers under 6 short lines. The user's role is {role}; pages they can use: {pages}."
)

_OFFLINE = [
    (("book", "appointment"), "Open Appointments, pick a doctor, a date, then a free slot and press Book. Double-booked slots are rejected."),
    (("bill", "invoice", "payment"), "Receptionists create bills in Billing, record payment (Cash/Card/Online) and download the invoice PDF."),
    (("lab", "report", "upload"), "Lab technicians upload pdf/png/jpg files in Lab Reports. Doctors and the patient can view and download them."),
    (("medicine", "pharmacy", "stock", "dispense"), "Pharmacists use Pharmacy to manage stock and dispense against a prescription. Low-stock and near-expiry lists are shown there."),
    (("prescription", "consult"), "Doctors open Consultation, choose an appointment, add diagnosis and medicines, then complete the visit."),
    (("password", "login"), "Log in from the first page with your email and password. If your session expires you are sent back to login."),
    (("report", "revenue"), "Admins see revenue, patients seen and top departments in Reports and can export CSV or PDF."),
]
_MEDICAL = ("diagnos", "symptom", "dose", "dosage", "treatment", "cure", "pain", "should i take", "medicine for")


def _offline(msg: str, role: str) -> str:
    m = msg.lower()
    if any(k in m for k in _MEDICAL):
        return "Please consult your doctor. I can only help with using this application."
    for keys, ans in _OFFLINE:
        if any(k in m for k in keys):
            return ans
    return f"I can help you use the app. As {role} you can use: {PAGES.get(role, 'the pages in the sidebar')}."


def azure_configured() -> bool:
    """True when endpoint, key and deployment are all set."""
    s = get_settings()
    return bool(s.azure_openai_endpoint and s.azure_openai_api_key and s.azure_openai_deployment)


def ask(user: User, body: ChatIn) -> ChatOut:
    """Answer via Azure; fall back to offline FAQ on missing keys or any error."""
    role = user.role.value
    if not azure_configured():
        return ChatOut(reply=_offline(body.message, role), source="offline")
    s = get_settings()
    url = (f"{s.azure_openai_endpoint.rstrip('/')}/openai/deployments/{s.azure_openai_deployment}"
           f"/chat/completions?api-version={s.azure_openai_api_version}")
    msgs = [{"role": "system", "content": SYSTEM.format(role=role, pages=PAGES.get(role, ""))}]
    msgs += [m.model_dump() for m in body.history[-10:]]
    msgs.append({"role": "user", "content": body.message})
    try:
        r = httpx.post(url, headers={"api-key": s.azure_openai_api_key}, timeout=s.chatbot_timeout_s,
                       json={"messages": msgs, "temperature": 0.2, "max_tokens": 300})
        r.raise_for_status()
        return ChatOut(reply=r.json()["choices"][0]["message"]["content"].strip(), source="azure")
    except (httpx.HTTPError, KeyError, IndexError, ValueError):
        return ChatOut(reply=_offline(body.message, role), source="offline")
