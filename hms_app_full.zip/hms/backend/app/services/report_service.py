"""Report aggregations."""
from collections import Counter, defaultdict
from decimal import Decimal

from sqlalchemy.orm import Session

from app.models import Appointment, Bill, Doctor


def revenue(db: Session) -> list[dict]:
    """Daily revenue from paid bills."""
    d: dict[str, Decimal] = defaultdict(Decimal)
    for b in db.query(Bill).filter(Bill.payment_status == "Paid").all():
        d[b.created_at.date().isoformat()] += b.total_amount
    return [{"date": k, "revenue": float(v)} for k, v in sorted(d.items())]


def patients_seen(db: Session) -> list[dict]:
    """Distinct patients per day from completed visits."""
    d: dict[str, set] = defaultdict(set)
    for a in db.query(Appointment).filter(Appointment.status == "Completed").all():
        d[a.appointment_date.date().isoformat()].add(a.patient_id)
    return [{"date": k, "patients": len(v)} for k, v in sorted(d.items())]


def top_departments(db: Session) -> list[dict]:
    """Departments ranked by appointment count."""
    c: Counter = Counter()
    for a in db.query(Appointment).filter(Appointment.status != "Cancelled").all():
        doc = db.get(Doctor, a.doctor_id)
        c[doc.department.name] += 1
    return [{"department": k, "appointments": v} for k, v in c.most_common()]
