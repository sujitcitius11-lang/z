"""CSV export helper (pandas)."""
import pandas as pd


def to_csv(rows: list[dict]) -> bytes:
    """Rows to CSV bytes."""
    return pd.DataFrame(rows).to_csv(index=False).encode()
