"""PDF helper (ReportLab)."""
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def simple_pdf(title: str, lines: list[str], header: list[str], rows: list[tuple]) -> bytes:
    """Build a one-table PDF."""
    buf = BytesIO()
    st = getSampleStyleSheet()
    els = [Paragraph(title, st["Title"])] + [Paragraph(x, st["Normal"]) for x in lines] + [Spacer(1, 12)]
    t = Table([header, *[[str(c) for c in r] for r in rows]])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.lightblue), ("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    els.append(t)
    SimpleDocTemplate(buf, pagesize=A4).build(els)
    return buf.getvalue()
