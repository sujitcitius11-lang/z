"""Optional email/SMS hooks (no-op in dev)."""


def send_email(to: str, subject: str, body: str) -> None:
    """Placeholder email sender; wire SMTP here."""
    return None
