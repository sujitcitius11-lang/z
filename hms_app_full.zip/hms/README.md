# HMS – Hospital Management System (FastAPI + Streamlit)

Synthetic/demo data only. Backend: FastAPI + SQLAlchemy 2 + Alembic. Frontend: Streamlit (talks to the API only via `frontend/api_client.py`).

## Quick start (Windows PowerShell)
```powershell
.\scripts\run_backend.ps1     # terminal 1 -> http://localhost:8000/docs
.\scripts\run_frontend.ps1    # terminal 2 -> http://localhost:8501
# or both:  .\scripts\run_all.ps1
```
Linux/macOS/Git Bash: `./scripts/run_backend.sh` and `./scripts/run_frontend.sh`.
First run copies `.env.example` to `.env`. With `SEED_DEMO_DATA=true` these demo logins exist (password `Passw0rd!`):
`admin@hms-demo.com`, `doctor@hms-demo.com`, `reception@hms-demo.com`, `patient@hms-demo.com`, `lab@hms-demo.com`, `pharmacy@hms-demo.com`.
Set `SEED_DEMO_DATA=false` for anything real, and set `ADMIN_EMAIL` / `ADMIN_PASSWORD` for the first super admin.

## Chatbot – where to put the API keys
Click **💬 Chat assistant** in the sidebar (every page). Keys live ONLY in the root `.env` (read by the backend; the browser never sees them):
```
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com     # or ...services.ai.azure.com
AZURE_OPENAI_API_KEY=<key from Foundry portal -> Keys and Endpoint>
AZURE_OPENAI_DEPLOYMENT=<your chat deployment name, e.g. gpt-4o-mini>
AZURE_OPENAI_API_VERSION=2024-10-21
```
Restart the backend after editing. If any of the three is empty, or Azure errors, the bot falls back to a built-in offline FAQ. The bot only explains how to use the app; it never gives medical advice.
Code: `backend/app/services/chat_service.py`, `backend/app/routers/chat.py`, `frontend/auth_utils.py` (`chatbot()`).

## Docker
`docker compose up --build` (needs `.env` with `POSTGRES_PASSWORD`). Backend runs `alembic upgrade head` on start.

## Tests
`cd backend && pytest -q --cov=app` (34 tests, ~92% coverage) · `ruff check backend frontend`.

## Notes
- Roles: admin, doctor, receptionist, patient, lab_technician, pharmacist, super_admin. Backend `require_roles` is authoritative.
- Lab technicians and pharmacists can list patients (names are needed to pick a patient); tighten if required.
- Schema is managed by Alembic (`backend/alembic`). Rate limit on login is in-memory (single process).
