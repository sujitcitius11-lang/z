#!/usr/bin/env bash
# Run FastAPI backend (Linux/macOS/Git Bash).
set -e
root="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$root/.env" ] || { cp "$root/.env.example" "$root/.env"; echo "Created .env - edit it (AZURE_OPENAI_* for the chatbot)."; }
cd "$root/backend"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate 2>/dev/null || . .venv/Scripts/activate
pip install -q -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
