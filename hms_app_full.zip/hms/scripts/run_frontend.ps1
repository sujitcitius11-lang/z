# Run Streamlit frontend (Windows PowerShell). Usage: .\scripts\run_frontend.ps1
$root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path "$root\.env")) { Copy-Item "$root\.env.example" "$root\.env" }
Get-Content "$root\.env" | ForEach-Object { if ($_ -match '^\s*([A-Z_]+)=(.*)$') { Set-Item -Path "Env:$($Matches[1])" -Value $Matches[2] } }
Set-Location "$root\frontend"
if (-not (Test-Path ".venv")) { python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install -q -r requirements.txt
& .\.venv\Scripts\python.exe -m streamlit run app.py --server.port 8501
