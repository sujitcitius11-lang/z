# Start backend and frontend in two windows (Windows PowerShell).
$here = $PSScriptRoot
Start-Process powershell -ArgumentList "-NoExit","-File","$here\run_backend.ps1"
Start-Sleep -Seconds 8
Start-Process powershell -ArgumentList "-NoExit","-File","$here\run_frontend.ps1"
Write-Host "API: http://localhost:8000/docs   UI: http://localhost:8501"
