# Run FastAPI backend (Windows PowerShell). Usage: .\scripts\run_backend.ps1
$root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path "$root\.env")) { Copy-Item "$root\.env.example" "$root\.env"; Write-Host "Created .env - edit it (see AZURE_OPENAI_* for the chatbot)." }
Set-Location "$root\backend"
if (-not (Test-Path ".venv")) { python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install -q -r requirements.txt
& .\.venv\Scripts\python.exe -m alembic upgrade head
& .\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
