#!/usr/bin/env bash
# Run Streamlit frontend (Linux/macOS/Git Bash).
set -e
root="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$root/.env" ] || cp "$root/.env.example" "$root/.env"
set -a; . "$root/.env"; set +a
cd "$root/frontend"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate 2>/dev/null || . .venv/Scripts/activate
pip install -q -r requirements.txt
streamlit run app.py --server.port 8501
