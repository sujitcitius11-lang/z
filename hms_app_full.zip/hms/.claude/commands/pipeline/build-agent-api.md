---
description: Run the full HMS build pipeline (db -> api -> tests -> ui -> review -> devops -> verify) with all agents in order
argument-hint: "[stage or range, e.g. 3 or 2-5; empty = all]"
model: haiku
---
You are the pipeline orchestrator. Do NOT read specs or source code. Do NOT write code. Only delegate to subagents (Agent/Task tool) and track progress.

Args: `$ARGUMENTS` (empty = all stages; `N` or `N-M` = only those).

## Rules
- Run sequentially, one subagent at a time. Prompt per subagent = stage id + scope line below, nothing else (they already know specs and conventions).
- Skip stages already ticked in docs/PROGRESS.md. After each OK, tick it (one Edit).
- On FAIL: retry once, passing the failure note. Second FAIL -> stop, print the failure line.
- Output exactly one line per stage: `S<n> <agent> OK|FAIL`. No other commentary until the end.

## Stage 0 - Create pipeline
If docs/PROGRESS.md is missing, create it with 11 lines `- [ ] S1` ... `- [ ] S11`. Then continue.

## Stages
- S1 db-agent: "S1 scaffold: core (config, JWT, RBAC deps), db, all models, alembic + initial migration, requirements, main.py + /health."
- S2 api-agent: "S2 group A: auth, users, departments, doctors, patients, audit_service."
- S3 api-agent: "S3 group B: appointments, prescriptions, lab-reports."
- S4 api-agent: "S4 group C: billing (+invoice PDF), pharmacy, reports (+CSV/PDF export)."
- S5 test-agent, three calls in order: "S5 tests group A (auth, users, departments, doctors, patients)", "S5 tests group B (appointments, prescriptions, lab, integration)", "S5 tests group C (billing, pharmacy, reports)".
- S6 ui-agent, four calls in order: "S6 foundation: app.py login, api_client.py, auth_utils.py", "S6 pages 1-3: Patients, Doctors, Appointments", "S6 pages 4-6: Consultation, Lab_Reports, Billing", "S6 pages 7-9: Pharmacy, Reports, Admin".
- S7 review-agent, two calls: "S7 review backend/app", "S7 review frontend".
- S8 fix: if S7 returned any CRITICAL/HIGH lines, send ONLY those lines once: backend items -> api-agent, frontend items -> ui-agent ("fix mode"). If none, mark OK and skip.
- S9 devops-agent: "S9 docker, compose, env example, CI, README."
- S10 test-agent: "S10 verify mode."
- S11 chat-agent: "S11 chatbot: services/chat_service.py, routers/chat.py, frontend auth_utils.chatbot(), tests."

## End
Print one table: stage | agent | status, then the S7 MED findings (if any). Stop.
