---
name: hms-azure-keys
description: Explain or set up the Azure AI Foundry / Azure OpenAI keys for the HMS chatbot. Use when asked where to put API keys or why the chatbot says offline.
---
- Keys go ONLY in the root `.env` (copy from `.env.example`): AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION.
- Restart the backend after editing. `GET /api/v1/chat/status` returns `{"azure_configured": true|false}` (never the key).
- Empty value or any Azure error -> offline FAQ fallback (source "offline").
- Never read, print or commit `.env` (denied in settings.json).
