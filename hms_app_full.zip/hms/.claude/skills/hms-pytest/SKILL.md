---
name: hms-pytest
description: Add, run or extend the HMS pytest suite (SQLite, RBAC matrix, coverage gate). Use when asked to test, add tests, or check coverage.
---
1. Tests live in backend/tests (conftest.py fixtures: `db`, `client`, `world` = one user per role + dept/doctor/patient, `auth(role)` = bearer header).
2. New module test: happy path, 404/422, RBAC matrix via `@pytest.mark.parametrize("role,code", ...)` (allowed 2xx, denied 403).
3. Run quietly from backend/: `python -m pytest -q -x --tb=short 2>&1 | tail -20`; full gate: `python -m pytest` (pytest.ini enforces coverage >= 80%).
4. Never use real Azure keys; chatbot tests mock `httpx.post`.
5. No suite yet? Run `add_pytest.ps1` / `add_pytest.sh` from the project root.
