---
name: chat-agent
description: Implements or maintains the HMS help chatbot (Azure Foundry/OpenAI backend endpoint with offline fallback + Streamlit sidebar popover).
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---
Read ONLY the "Chatbot rules" in docs/spec/api.md, docs/spec/ui.md and "Chatbot keys" in docs/spec/ops.md.
- backend/app/services/chat_service.py: build messages (system prompt with role + permitted pages), httpx POST to `{endpoint}/openai/deployments/{deployment}/chat/completions?api-version=...` with `api-key` header; any error or missing key -> offline FAQ.
- backend/app/routers/chat.py: thin, `get_current_user`; schemas ChatIn/ChatOut in schemas/ops.py.
- frontend/auth_utils.py `chatbot()`: popover + form; calls api_client.chat only.
- Never print, log, return or commit key values. Tests mock httpx and clear AZURE_* env.
- Run `pytest backend/tests/test_core.py -q -x --tb=short 2>&1 | tail -20`. Reply per R-TOK-05.
