"""Session guard, role-aware sidebar and the chatbot button."""
import api_client as api
import streamlit as st

PAGES = [
    ("pages/1_Patients.py", "Patients", "🧑", {"admin", "super_admin", "receptionist", "patient", "doctor"}),
    ("pages/2_Doctors.py", "Doctors", "🩺", None),
    ("pages/3_Appointments.py", "Appointments", "📅", {"patient", "receptionist", "doctor"}),
    ("pages/4_Consultation.py", "Consultation", "📝", {"doctor"}),
    ("pages/5_Lab_Reports.py", "Lab Reports", "🧪", {"lab_technician", "doctor", "patient"}),
    ("pages/6_Billing.py", "Billing", "💳", {"receptionist", "patient"}),
    ("pages/7_Pharmacy.py", "Pharmacy", "💊", {"pharmacist", "admin", "super_admin"}),
    ("pages/8_Reports.py", "Reports", "📊", {"admin", "super_admin"}),
    ("pages/9_Admin.py", "Admin", "⚙️", {"admin", "super_admin"}),
]


def allowed(role: str, roles: set | None) -> bool:
    """Role check for UX (backend is authoritative)."""
    return roles is None or role in roles


def require_login(roles: set | None = None) -> str:
    """Stop the page unless logged in with a permitted role; render sidebar; return role."""
    if not st.session_state.get("token"):
        st.switch_page("app.py")
    role = st.session_state["role"]
    sidebar()
    if not allowed(role, roles):
        st.error("You do not have access to this page.")
        st.stop()
    return role


def sidebar() -> None:
    """Permitted page links, logout and the chatbot."""
    role = st.session_state.get("role", "")
    with st.sidebar:
        st.markdown(f"**{st.session_state.get('name', '')}**  \n`{role}`")
        st.page_link("app.py", label="Home", icon="🏠")
        for path, label, icon, roles in PAGES:
            if allowed(role, roles):
                st.page_link(path, label=label, icon=icon)
        if st.button("Log out", use_container_width=True):
            for k in list(st.session_state.keys()):
                del st.session_state[k]
            st.switch_page("app.py")
        st.divider()
        chatbot()


def chatbot() -> None:
    """Sidebar chat button: popover with a chat window backed by /chat."""
    hist = st.session_state.setdefault("chat_history", [])
    with st.popover("💬 Chat assistant", use_container_width=True):
        st.caption("Ask how to use HMS. No medical advice.")
        box = st.container(height=320)
        with box:
            if not hist:
                st.info("Hi! Ask me e.g. “How do I book an appointment?”")
            for m in hist:
                st.chat_message(m["role"]).write(m["content"])
        with st.form("chat_form", clear_on_submit=True, border=False):
            q = st.text_input("Type your question", label_visibility="collapsed", placeholder="Type your question")
            sent = st.form_submit_button("Send", use_container_width=True)
        if sent and q.strip():
            try:
                out = api.chat(q.strip(), hist)
                hist += [{"role": "user", "content": q.strip()}, {"role": "assistant", "content": out["reply"]}]
            except api.ApiError as e:
                hist += [{"role": "user", "content": q.strip()}, {"role": "assistant", "content": f"Chat error: {e.detail}"}]
            st.rerun()
        if hist and st.button("Clear chat", key="chat_clear"):
            hist.clear()
            st.rerun()


def show_error(e: Exception) -> None:
    """Uniform error toast."""
    st.error(e.detail if isinstance(e, api.ApiError) else str(e))
