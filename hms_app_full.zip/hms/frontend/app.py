"""HMS Streamlit entrypoint: login, registration and home."""
import api_client as api
import auth_utils as au
import streamlit as st

st.set_page_config(page_title="HMS", page_icon="🏥", layout="wide")

if st.session_state.get("token"):
    au.sidebar()
    st.title(f"Welcome, {st.session_state['name']}")
    role = st.session_state["role"]
    st.write(f"Signed in as **{role}**. Use the sidebar to open a page, or the 💬 button to ask the assistant.")
    try:
        notes = api.get("/notifications")
        if notes:
            st.subheader("Notifications")
            for n in notes[:5]:
                st.info(f"{n['created_at'][:16].replace('T', ' ')} — {n['message']}")
    except api.ApiError as e:
        au.show_error(e)
    st.stop()

st.title("🏥 Hospital Management System")
if st.session_state.pop("expired", False):
    st.warning("Session expired. Please log in again.")
tab_login, tab_reg = st.tabs(["Login", "Register (patient)"])
with tab_login, st.form("login"):
    email = st.text_input("Email")
    pw = st.text_input("Password", type="password")
    if st.form_submit_button("Log in", type="primary"):
        try:
            d = api.login(email, pw)
            st.session_state.update(token=d["access_token"], role=d["role"], name=d["name"])
            st.rerun()
        except api.ApiError as e:
            au.show_error(e)
with tab_reg, st.form("register"):
    n = st.text_input("Full name")
    e = st.text_input("Email ")
    c = st.text_input("Contact number")
    p = st.text_input("Password (8+ characters)", type="password")
    if st.form_submit_button("Create account"):
        try:
            api.register(n, e, p, c or None)
            st.success("Account created. Please log in, then complete your profile under Patients.")
        except api.ApiError as ex:
            au.show_error(ex)
