"""Single gateway from Streamlit to the FastAPI backend (no DB access here)."""
import os

import requests
import streamlit as st

BASE = os.getenv("API_BASE_URL", "http://localhost:8000").rstrip("/") + "/api/v1"
TIMEOUT = 30


class ApiError(Exception):
    """Raised for non-2xx API replies."""

    def __init__(self, status: int, detail):
        super().__init__(str(detail))
        self.status, self.detail = status, detail


def _headers() -> dict:
    t = st.session_state.get("token")
    return {"Authorization": f"Bearer {t}"} if t else {}


def _handle(r: requests.Response):
    if r.status_code == 401 and st.session_state.get("token"):
        for k in ("token", "role", "name"):
            st.session_state.pop(k, None)
        st.session_state["expired"] = True
        st.rerun()
    if not r.ok:
        try:
            d = r.json().get("detail", r.text)
        except ValueError:
            d = r.text
        if isinstance(d, list):
            d = "; ".join(f"{'.'.join(map(str, e.get('loc', [])[1:]))}: {e.get('msg')}" for e in d)
        raise ApiError(r.status_code, d)
    return r


def request(method: str, path: str, **kw) -> requests.Response:
    """Authenticated request."""
    try:
        r = requests.request(method, BASE + path, headers=_headers(), timeout=TIMEOUT, **kw)
    except requests.RequestException as e:
        raise ApiError(0, f"Cannot reach API at {BASE}: {e.__class__.__name__}") from e
    return _handle(r)


def get(path: str, **params):
    """GET JSON."""
    return request("GET", path, params={k: v for k, v in params.items() if v not in (None, "")}).json()


def post(path: str, json=None, **kw):
    """POST JSON."""
    r = request("POST", path, json=json, **kw)
    return r.json() if r.content else None


def put(path: str, json=None):
    """PUT JSON."""
    return request("PUT", path, json=json).json()


def patch(path: str, json=None):
    """PATCH JSON."""
    return request("PATCH", path, json=json).json()


def delete(path: str) -> None:
    """DELETE."""
    request("DELETE", path)


def download(path: str, **params) -> bytes:
    """GET raw bytes."""
    return request("GET", path, params=params).content


def login(email: str, password: str) -> dict:
    """Login (no auth header)."""
    try:
        r = requests.post(f"{BASE}/auth/login", json={"email": email, "password": password}, timeout=TIMEOUT)
    except requests.RequestException as e:
        raise ApiError(0, f"Cannot reach API at {BASE}: {e.__class__.__name__}") from e
    if not r.ok:
        raise ApiError(r.status_code, r.json().get("detail", "Login failed"))
    return r.json()


def register(name: str, email: str, password: str, contact: str | None) -> dict:
    """Patient self-registration."""
    r = requests.post(f"{BASE}/auth/register", timeout=TIMEOUT,
                      json={"name": name, "email": email, "password": password, "contact_number": contact})
    if not r.ok:
        d = r.json().get("detail", "Registration failed")
        raise ApiError(r.status_code, d if isinstance(d, str) else "Invalid input (password needs 8+ characters)")
    return r.json()


def chat(message: str, history: list[dict]) -> dict:
    """Ask the chatbot."""
    return post("/chat", {"message": message, "history": history[-10:]})


@st.cache_data(ttl=60, show_spinner=False)
def _cached(path: str, token: str):
    return requests.get(BASE + path, headers={"Authorization": f"Bearer {token}"}, timeout=TIMEOUT).json()


def cached_list(path: str) -> list:
    """TTL-cached list for departments/doctors."""
    out = _cached(path, st.session_state.get("token", ""))
    return out if isinstance(out, list) else []
