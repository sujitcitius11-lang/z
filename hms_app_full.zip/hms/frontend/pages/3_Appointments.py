"""Appointments page."""
from datetime import date, datetime

import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Appointments", layout="wide")
role = au.require_login({"patient", "receptionist", "doctor"})
st.title("📅 Appointments")
docs = api.cached_list("/doctors?limit=200")
dname = {d["doctor_id"]: d["name"] for d in docs}

try:
    appts = api.get("/appointments", limit=200)
except api.ApiError as e:
    au.show_error(e)
    appts = []
if appts:
    df = pd.DataFrame(appts)
    df["doctor"] = df["doctor_id"].map(dname)
    st.dataframe(df[["appointment_date", "doctor", "status", "notes"]], use_container_width=True, hide_index=True)
    open_ = [a for a in appts if a["status"] == "Scheduled"]
    if open_:
        pick = st.selectbox("Cancel an appointment", open_, index=None,
                            format_func=lambda a: f"{a['appointment_date'][:16]} · {dname.get(a['doctor_id'], '')}")
        if pick and st.button("Cancel selected"):
            try:
                api.patch(f"/appointments/{pick['appointment_id']}/cancel")
                st.toast("Cancelled")
                st.rerun()
            except api.ApiError as e:
                au.show_error(e)
else:
    st.info("No appointments.")

if role in ("patient", "receptionist"):
    st.subheader("Book appointment")
    pid = None
    if role == "receptionist":
        pts = api.get("/patients", limit=200)
        sel = st.selectbox("Patient", pts, format_func=lambda p: f"{p['name']} ({p['email']})") if pts else None
        pid = sel["patient_id"] if sel else None
    doc = st.selectbox("Doctor", docs, format_func=lambda d: f"{d['name']} — {d['department']}") if docs else None
    day = st.date_input("Date", min_value=date.today())
    slots = []
    if doc:
        try:
            slots = api.get(f"/doctors/{doc['doctor_id']}/availability", day=f"{day}T00:00:00").get("free_slots", [])
        except api.ApiError as e:
            au.show_error(e)
    slot = st.selectbox("Available slot", slots, format_func=lambda s: datetime.fromisoformat(s).strftime("%H:%M")) if slots else None
    if doc and not slots:
        st.warning("No free slots that day.")
    with st.form("book"):
        notes = st.text_input("Reason / notes")
        if st.form_submit_button("Book", type="primary", disabled=not slot):
            try:
                api.post("/appointments", {"patient_id": pid, "doctor_id": doc["doctor_id"], "appointment_date": slot,
                                           "notes": notes or None})
                st.success("Booked")
                st.rerun()
            except api.ApiError as e:
                au.show_error(e)
