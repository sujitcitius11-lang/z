"""Reports page."""
import api_client as api
import auth_utils as au
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Reports", layout="wide")
au.require_login({"admin", "super_admin"})
st.title("📊 Reports")
try:
    rev, seen, top = api.get("/reports/revenue"), api.get("/reports/patients-seen"), api.get("/reports/top-departments")
except api.ApiError as e:
    au.show_error(e)
    st.stop()
c1, c2, c3 = st.columns(3)
if rev:
    c1.plotly_chart(px.bar(pd.DataFrame(rev), x="date", y="revenue", title="Daily revenue"), use_container_width=True)
else:
    c1.info("No paid bills yet.")
if seen:
    c2.plotly_chart(px.line(pd.DataFrame(seen), x="date", y="patients", markers=True, title="Patients seen"), use_container_width=True)
else:
    c2.info("No completed visits yet.")
if top:
    c3.plotly_chart(px.pie(pd.DataFrame(top), names="department", values="appointments", title="Department load"), use_container_width=True)
else:
    c3.info("No appointments yet.")
st.subheader("Export")
rep = st.selectbox("Report", ["revenue", "patients-seen", "top-departments"])
for fmt, mime in (("csv", "text/csv"), ("pdf", "application/pdf")):
    try:
        st.download_button(f"Download {fmt.upper()}", api.download("/reports/export", format=fmt, report=rep),
                           file_name=f"{rep}.{fmt}", mime=mime, key=f"dl_{fmt}")
    except api.ApiError as e:
        au.show_error(e)
