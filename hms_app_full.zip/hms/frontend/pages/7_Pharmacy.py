"""Pharmacy page."""
from datetime import date, timedelta

import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Pharmacy", layout="wide")
role = au.require_login({"pharmacist", "admin", "super_admin"})
st.title("💊 Pharmacy")
tab_stock, tab_alert, tab_disp = st.tabs(["Stock", "Alerts", "Dispense"])

with tab_stock:
    try:
        meds = api.get("/medicines", search=st.text_input("Search medicine"), limit=200)
    except api.ApiError as e:
        au.show_error(e)
        meds = []
    if meds:
        st.dataframe(pd.DataFrame(meds).drop(columns=["medicine_id"]), use_container_width=True, hide_index=True)
    with st.expander("➕ Add medicine"), st.form("addmed", clear_on_submit=True):
        n = st.text_input("Name")
        q = st.number_input("Quantity", 0, 100000, 0)
        e = st.date_input("Expiry", value=date.today() + timedelta(days=365))
        p = st.number_input("Unit price", 0.0, 100000.0, 0.0)
        if st.form_submit_button("Add", type="primary"):
            try:
                api.post("/medicines", {"name": n, "quantity_available": int(q), "expiry_date": str(e), "unit_price": p})
                st.success("Added")
            except api.ApiError as ex:
                au.show_error(ex)
    if meds:
        with st.form("restock"):
            m = st.selectbox("Restock", meds, format_func=lambda x: f"{x['name']} (qty {x['quantity_available']})")
            q2 = st.number_input("New quantity", 0, 100000, int(m["quantity_available"]))
            if st.form_submit_button("Update stock"):
                try:
                    api.put(f"/medicines/{m['medicine_id']}", {"quantity_available": int(q2)})
                    st.toast("Updated")
                    st.rerun()
                except api.ApiError as ex:
                    au.show_error(ex)

with tab_alert:
    try:
        a = api.get("/medicines/alerts")
        c1, c2 = st.columns(2)
        c1.subheader("Low stock")
        c1.dataframe(pd.DataFrame(a["low_stock"]), use_container_width=True, hide_index=True)
        c2.subheader("Near expiry")
        c2.dataframe(pd.DataFrame(a["near_expiry"]), use_container_width=True, hide_index=True)
    except api.ApiError as e:
        au.show_error(e)

with tab_disp:
    try:
        pts = api.get("/patients", limit=200)
    except api.ApiError:
        pts = []
    if role == "pharmacist" and pts:
        pat = st.selectbox("Patient", pts, format_func=lambda p: p["name"])
        rxs = api.get(f"/patients/{pat['patient_id']}/prescriptions")
        if not rxs:
            st.info("No prescriptions.")
        else:
            rx = st.selectbox("Prescription", rxs, format_func=lambda r: f"{r['diagnosis'][:30]} · {r['prescription_id'][:8]}")
            st.table(pd.DataFrame(rx["medicines"]))
            with st.form("dispense"):
                qty = {m["name"]: st.number_input(f"{m['name']} qty", 0, 1000, 1) for m in rx["medicines"]}
                if st.form_submit_button("Dispense", type="primary"):
                    try:
                        out = api.post("/pharmacy/dispense", {"prescription_id": rx["prescription_id"],
                                                              "items": [{"name": k, "quantity": v} for k, v in qty.items() if v]})
                        st.success(f"Dispensed: {out['dispensed']}")
                    except api.ApiError as e:
                        au.show_error(e)
    else:
        st.info("Dispensing is available to the pharmacist role.")
