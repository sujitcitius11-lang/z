"""Lab reports page."""
import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Lab Reports", layout="wide")
role = au.require_login({"lab_technician", "doctor", "patient"})
st.title("🧪 Lab Reports")

try:
    rows = api.get("/lab-reports", limit=200)
except api.ApiError as e:
    au.show_error(e)
    rows = []
if rows:
    st.dataframe(pd.DataFrame(rows)[["test_name", "result_summary", "created_at", "report_id"]], use_container_width=True, hide_index=True)
    pick = st.selectbox("Download report", [r for r in rows if r["report_file"]], index=None, format_func=lambda r: f"{r['test_name']} · {r['created_at'][:10]}")
    if pick:
        try:
            st.download_button("Download file", api.download(f"/lab-reports/{pick['report_id']}/download"),
                               file_name=f"{pick['test_name']}.{pick['report_file'].rsplit('.', 1)[-1]}")
        except api.ApiError as e:
            au.show_error(e)
else:
    st.info("No reports.")

if role == "lab_technician":
    st.subheader("Upload report")
    try:
        pts = api.get("/patients", limit=200)
    except api.ApiError:
        pts = []
    with st.form("up", clear_on_submit=True):
        pat = st.selectbox("Patient", pts, format_func=lambda p: f"{p['name']} ({p['email']})") if pts else None
        name = st.text_input("Test name")
        summ = st.text_area("Result summary")
        f = st.file_uploader("Report file (pdf/png/jpg)", type=["pdf", "png", "jpg", "jpeg"])
        if st.form_submit_button("Upload", type="primary"):
            try:
                files = {"file": (f.name, f.getvalue(), f.type)} if f else None
                api.post("/lab-reports", None, data={"patient_id": pat["patient_id"] if pat else "", "test_name": name, "result_summary": summ}, files=files)
                st.success("Uploaded")
            except api.ApiError as e:
                au.show_error(e)
