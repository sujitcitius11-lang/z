"""Doctors page."""
import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Doctors", layout="wide")
role = au.require_login()
st.title("🩺 Doctors")
docs = api.cached_list("/doctors?limit=200")
deps = api.cached_list("/departments?limit=200")
if docs:
    st.dataframe(pd.DataFrame([{**d, "availability": ", ".join(f"{k} {v}" for k, v in d["availability"].items())} for d in docs])
                 .drop(columns=["doctor_id", "user_id", "department_id"]), use_container_width=True, hide_index=True)
else:
    st.info("No doctors yet.")

if role in ("admin", "super_admin"):
    with st.expander("➕ Add doctor"), st.form("new_doc", clear_on_submit=True):
        c1, c2 = st.columns(2)
        name, email = c1.text_input("Name"), c2.text_input("Email")
        pw, q = c1.text_input("Temporary password", type="password"), c2.text_input("Qualification")
        dep = st.selectbox("Department", deps, format_func=lambda d: d["name"]) if deps else None
        days = st.multiselect("Available days", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
        hours = st.text_input("Hours (e.g. 10-2 or 2-6)", value="10-2")
        if st.form_submit_button("Create", type="primary"):
            if not dep:
                st.error("Create a department first (Admin page).")
            else:
                try:
                    api.post("/doctors", {"name": name, "email": email, "password": pw, "qualification": q or None,
                                          "department_id": dep["department_id"], "availability": {d: hours for d in days}})
                    api._cached.clear()
                    st.success("Doctor created")
                except api.ApiError as e:
                    au.show_error(e)
