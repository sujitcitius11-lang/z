"""Consultation page (doctor)."""
import api_client as api
import auth_utils as au
import streamlit as st

st.set_page_config(page_title="Consultation", layout="wide")
au.require_login({"doctor"})
st.title("📝 Consultation")
try:
    todo = api.get("/appointments", status="Scheduled", limit=200)
    pats = {p["patient_id"]: p for p in api.get("/patients", limit=200)}
except api.ApiError as e:
    au.show_error(e)
    st.stop()
if not todo:
    st.info("No scheduled visits.")
    st.stop()
a = st.selectbox("Visit", todo, format_func=lambda x: f"{x['appointment_date'][:16]} · {pats.get(x['patient_id'], {}).get('name', '?')}")
p = pats.get(a["patient_id"], {})
st.caption(f"Allergies: {p.get('allergies') or 'none recorded'} · Blood group: {p.get('blood_group') or '-'}")
n = st.session_state.setdefault("rx_rows", 1)
with st.form("rx"):
    dx = st.text_area("Diagnosis / notes")
    meds = [(st.columns(2)[0].text_input(f"Medicine {i + 1}", key=f"m{i}"), st.text_input(f"Dosage {i + 1}", key=f"d{i}"))
            for i in range(n)]
    if st.form_submit_button("Save prescription & complete visit", type="primary"):
        try:
            api.post("/prescriptions", {"appointment_id": a["appointment_id"], "diagnosis": dx,
                                        "medicines": [{"name": m, "dosage": d} for m, d in meds if m]})
            st.success("Visit completed")
            st.session_state["rx_rows"] = 1
            st.rerun()
        except api.ApiError as e:
            au.show_error(e)
if st.button("＋ Add medicine row"):
    st.session_state["rx_rows"] = n + 1
    st.rerun()
