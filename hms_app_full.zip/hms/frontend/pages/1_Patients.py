"""Patients page."""
import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Patients", layout="wide")
role = au.require_login({"admin", "super_admin", "receptionist", "patient", "doctor"})
st.title("🧑 Patients")

try:
    rows = api.get("/patients", search=st.text_input("Search by name") if role != "patient" else None, limit=200)
except api.ApiError as e:
    au.show_error(e)
    rows = []

if role == "patient" and not rows:
    st.info("Complete your patient profile.")
    with st.form("profile"):
        g = st.selectbox("Gender", ["Male", "Female", "Other"])
        dob = st.date_input("Date of birth", value=None, min_value=pd.Timestamp("1900-01-01").date())
        bg = st.text_input("Blood group")
        addr = st.text_area("Address")
        ec = st.text_input("Emergency contact")
        al = st.text_input("Allergies (comma separated)")
        if st.form_submit_button("Save profile", type="primary"):
            try:
                api.post("/patients/me", {"gender": g, "dob": str(dob), "blood_group": bg or None, "address": addr or None,
                                          "emergency_contact": ec or None, "allergies": al or None})
                st.toast("Profile saved")
                st.rerun()
            except api.ApiError as e:
                au.show_error(e)
elif rows:
    df = pd.DataFrame(rows)
    st.dataframe(df.drop(columns=["user_id"]), use_container_width=True, hide_index=True)

if role in ("admin", "super_admin", "receptionist"):
    with st.expander("➕ Register new patient"), st.form("new_patient", clear_on_submit=True):
        c1, c2 = st.columns(2)
        name, email = c1.text_input("Name"), c2.text_input("Email")
        pw, contact = c1.text_input("Temporary password", type="password"), c2.text_input("Contact number")
        g = c1.selectbox("Gender", ["Male", "Female", "Other"])
        dob = c2.date_input("Date of birth", value=None, min_value=pd.Timestamp("1900-01-01").date())
        bg, ec = c1.text_input("Blood group"), c2.text_input("Emergency contact")
        addr, al = st.text_area("Address"), st.text_input("Allergies")
        if st.form_submit_button("Create", type="primary"):
            try:
                api.post("/patients", {"name": name, "email": email, "password": pw, "contact_number": contact or None,
                                       "gender": g, "dob": str(dob), "blood_group": bg or None, "address": addr or None,
                                       "emergency_contact": ec or None, "allergies": al or None})
                st.success("Patient created")
            except api.ApiError as e:
                au.show_error(e)
