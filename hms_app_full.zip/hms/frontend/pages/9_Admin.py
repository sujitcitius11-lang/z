"""Admin page: users and departments."""
import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Admin", layout="wide")
au.require_login({"admin", "super_admin"})
st.title("⚙️ Admin")
tab_u, tab_d = st.tabs(["Users", "Departments"])

with tab_u:
    try:
        users = api.get("/users", limit=200)
    except api.ApiError as e:
        au.show_error(e)
        users = []
    if users:
        st.dataframe(pd.DataFrame(users).drop(columns=["user_id"]), use_container_width=True, hide_index=True)
        u = st.selectbox("Select user", users, format_func=lambda x: f"{x['name']} ({x['role']})")
        c1, c2 = st.columns(2)
        if c1.button("Toggle active"):
            try:
                api.put(f"/users/{u['user_id']}", {"status": not u["status"]})
                st.rerun()
            except api.ApiError as e:
                au.show_error(e)
        if c2.button("Deactivate (delete)"):
            try:
                api.delete(f"/users/{u['user_id']}")
                st.rerun()
            except api.ApiError as e:
                au.show_error(e)
    with st.expander("➕ Create user"), st.form("nu", clear_on_submit=True):
        n, e = st.text_input("Name"), st.text_input("Email")
        pw = st.text_input("Password", type="password")
        r = st.selectbox("Role", ["admin", "doctor", "receptionist", "patient", "lab_technician", "pharmacist", "super_admin"])
        if st.form_submit_button("Create", type="primary"):
            try:
                api.post("/users", {"name": n, "email": e, "password": pw, "role": r})
                st.success("Created")
            except api.ApiError as ex:
                au.show_error(ex)

with tab_d:
    deps = api.get("/departments", limit=200)
    if deps:
        st.dataframe(pd.DataFrame(deps).drop(columns=["department_id"]), use_container_width=True, hide_index=True)
        d = st.selectbox("Department", deps, format_func=lambda x: x["name"])
        if st.button("Delete department"):
            try:
                api.delete(f"/departments/{d['department_id']}")
                api._cached.clear()
                st.rerun()
            except api.ApiError as ex:
                au.show_error(ex)
    with st.form("nd", clear_on_submit=True):
        n, ds = st.text_input("Name"), st.text_input("Description")
        if st.form_submit_button("Add department", type="primary"):
            try:
                api.post("/departments", {"name": n, "description": ds or None})
                api._cached.clear()
                st.rerun()
            except api.ApiError as ex:
                au.show_error(ex)
