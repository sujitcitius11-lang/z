"""Billing page."""
import api_client as api
import auth_utils as au
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Billing", layout="wide")
role = au.require_login({"receptionist", "patient"})
st.title("💳 Billing")

try:
    bills = api.get("/billing", limit=200)
except api.ApiError as e:
    au.show_error(e)
    bills = []
if bills:
    df = pd.DataFrame(bills)
    st.dataframe(df[["created_at", "total_amount", "payment_status", "payment_mode", "bill_id"]], use_container_width=True, hide_index=True)
    b = st.selectbox("Bill", bills, format_func=lambda x: f"{x['created_at'][:10]} · {x['total_amount']} · {x['payment_status']}")
    try:
        st.download_button("Download invoice PDF", api.download(f"/billing/{b['bill_id']}/invoice.pdf"),
                           file_name="invoice.pdf", mime="application/pdf")
    except api.ApiError as e:
        au.show_error(e)
    if role == "receptionist":
        with st.form("pay"):
            s = st.selectbox("Payment status", ["Paid", "Partially Paid", "Unpaid"])
            m = st.selectbox("Mode", ["Cash", "Card", "Online"])
            if st.form_submit_button("Record payment"):
                try:
                    api.patch(f"/billing/{b['bill_id']}/payment", {"payment_status": s, "payment_mode": m})
                    st.toast("Updated")
                    st.rerun()
                except api.ApiError as e:
                    au.show_error(e)
else:
    st.info("No bills.")

if role == "receptionist":
    st.subheader("Create bill")
    pts = api.get("/patients", limit=200)
    pat = st.selectbox("Patient", pts, format_func=lambda p: f"{p['name']} ({p['email']})") if pts else None
    seed = pd.DataFrame([{"name": "Consultation", "amount": 0.0}])
    lines = st.data_editor(seed, num_rows="dynamic", use_container_width=True, key="lines")
    mode = st.selectbox("Payment mode", ["Cash", "Card", "Online"])
    clean = [{"name": str(r["name"]), "amount": float(r["amount"])} for _, r in lines.iterrows() if r["name"]]
    st.metric("Total", f"{sum(x['amount'] for x in clean):.2f}")
    if st.button("Create bill", type="primary", disabled=not (pat and clean)):
        try:
            api.post("/billing", {"patient_id": pat["patient_id"], "services": clean, "payment_mode": mode})
            st.success("Bill created")
            st.rerun()
        except api.ApiError as e:
            au.show_error(e)
