import json

import config
from src.pipeline import batch, events
from src.pipeline.operations import retry_dead_letter
from src.pipeline.processor import DocumentProcessor, doc_id_for
from src.storage.blob_store import get_blob
from src.storage.cosmos_store import get_cosmos


def test_every_file_was_ingested(pipeline):
    assert pipeline["result"]["errors"] == []
    n = pipeline["sql"].scalar("SELECT COUNT(*) FROM Documents")
    assert n == len(pipeline["files"])


def test_status_mix_is_sensible(pipeline):
    rows = {r["status"]: r["n"] for r in pipeline["sql"].query("SELECT status, COUNT(*) AS n FROM Documents GROUP BY status")}
    assert rows.get("PASSED", 0) > 0 and rows.get("NEEDS_REVIEW", 0) > 0 and rows.get("FAILED", 0) >= 3
    assert rows.get("DUPLICATE", 0) >= 1
    assert "PROCESSING" not in rows                                  # nothing left half-done


def test_corrupt_pdfs_are_dead_lettered_and_quarantined(pipeline):
    sql = pipeline["sql"]
    failed = sql.query("SELECT * FROM Documents WHERE status='FAILED'")
    assert len(failed) >= 3 and all(f["route_id"] == "W-DLQ" for f in failed)
    dl = sql.query("SELECT * FROM DeadLetter WHERE stage='processing'")
    assert len(dl) >= 3
    assert get_blob().count(config.BLOB_CONTAINERS["quarantine"]) >= 3


def test_unclassified_documents_go_to_triage(pipeline):
    rows = pipeline["sql"].query("SELECT * FROM Documents WHERE file_name LIKE 'fax_cover%' OR file_name LIKE 'memo%'")
    assert rows and all(r["doc_type"] == "unknown" and r["route_id"] == "W-TRIAGE" and r["status"] == "NEEDS_REVIEW" for r in rows)


def test_exact_duplicates_are_detected_not_reprocessed(pipeline):
    sql = pipeline["sql"]
    dups = sql.query("SELECT * FROM Documents WHERE status='DUPLICATE'")
    assert dups and all(d["duplicate_of"] and d["route_id"] == "W-DUP" for d in dups)
    orig = sql.get_document(dups[0]["duplicate_of"])
    assert orig["status"] in ("PASSED", "NEEDS_REVIEW")


def test_redelivered_event_is_ignored(pipeline):
    sql = pipeline["sql"]
    doc = sql.one("SELECT * FROM Documents WHERE status='PASSED' LIMIT 1")
    before = sql.scalar("SELECT COUNT(*) FROM Documents")
    ev = events.blob_created_event("incoming", doc["blob_name"], 1, "application/pdf")
    out = DocumentProcessor().handle_event(ev)                        # Event Grid delivers at least once -> same event twice
    assert out["status"] == "IGNORED" and sql.scalar("SELECT COUNT(*) FROM Documents") == before


def test_events_in_other_containers_are_ignored():
    out = DocumentProcessor().handle_event(events.blob_created_event("processed", "x.pdf", 1, "application/pdf"))
    assert out["status"] == "IGNORED"


def test_all_tables_filled(pipeline):
    sql = pipeline["sql"]
    for t in ("ExtractedFields", "ValidationIssues", "Routing", "ReviewTasks", "AuditLog", "Events", "WorkflowActions", "ProcessingStages", "CosmosItems"):
        assert sql.scalar(f"SELECT COUNT(*) FROM {t}") > 0, t


def test_raw_json_in_cosmos_store(pipeline):
    doc = pipeline["sql"].one("SELECT doc_id, doc_type FROM Documents WHERE status='PASSED' LIMIT 1")
    item = get_cosmos().get(doc["doc_id"], doc["doc_type"])
    assert item and "ocr" in item and "fields" in item and item["doc_type"] == doc["doc_type"]


def test_blobs_moved_out_of_incoming(pipeline):
    b = get_blob()
    assert b.count("incoming") == 0 and b.count("processed") > 0 and b.count("review") > 0


def test_audit_trail_has_no_phi(pipeline):
    sql = pipeline["sql"]
    names = {r["value_json"].strip('"') for r in sql.query("SELECT value_json FROM ExtractedFields WHERE field_name='patient_name' LIMIT 40")}
    blob = " ".join(r["detail_json"] or "" for r in sql.query("SELECT detail_json FROM AuditLog")) + (config.LOG_DIR / "audit.jsonl").read_text(encoding="utf-8")
    leaked = [n for n in names if n and n != "null" and n in blob]
    assert leaked == []


def test_every_document_has_complete_audit_chain(pipeline):
    sql = pipeline["sql"]
    doc = sql.one("SELECT doc_id FROM Documents WHERE status='PASSED' LIMIT 1")
    actions = [r["action"] for r in sql.query("SELECT action FROM AuditLog WHERE doc_id=? ORDER BY audit_id", [doc["doc_id"]])]
    assert actions[:1] == ["received"] and {"ocr_done", "classified", "validated", "routed"} <= set(actions)


def test_stage_timings_recorded(pipeline):
    stages = {r["stage"] for r in pipeline["sql"].query("SELECT DISTINCT stage FROM ProcessingStages")}
    assert {"download", "ocr", "classify_extract", "validate", "route", "store"} <= stages


def test_dead_letter_retry_requeues_blob(pipeline):
    sql = pipeline["sql"]
    dl = sql.one("SELECT * FROM DeadLetter WHERE stage='processing' LIMIT 1")
    out = retry_dead_letter(dl["dl_id"])
    assert out["status"] in ("delivered", "dead_lettered")
    assert sql.one("SELECT status FROM DeadLetter WHERE dl_id=?", [dl["dl_id"]])["status"] == "retried"


def test_ingest_rejects_bad_files():
    import pytest
    with pytest.raises(ValueError):
        batch.ingest("virus.exe", b"x")
    with pytest.raises(ValueError):
        batch.ingest("big.pdf", b"x" * (config.UPLOAD_LIMIT_MB * 1024 * 1024 + 1))


def test_same_bytes_uploaded_twice_is_flagged_duplicate(dataset):
    a = next(a for a in dataset["key"].values() if a["meta"]["format"] == "pdf_digital" and not a["meta"]["defects"])
    data = (config.SYNTH_DIR / "documents" / a["doc_type"] / a["file"]).read_bytes()
    r1 = batch.ingest("ui_copy_a.pdf", data)
    r2 = batch.ingest("ui_copy_b.pdf", data)
    from src.storage.sql_store import get_sql
    s = get_sql()
    assert s.get_document(r1["doc_id"])["status"] in ("PASSED", "NEEDS_REVIEW", "DUPLICATE")
    assert s.get_document(r2["doc_id"])["status"] == "DUPLICATE"


def test_event_schema_matches_event_grid():
    e = events.blob_created_event("incoming", "2026/01/01/a.pdf", 10, "application/pdf")
    assert e["eventType"] == "Microsoft.Storage.BlobCreated" and e["subject"].endswith("/blobs/2026/01/01/a.pdf")
    assert events.parse_subject(e["subject"]) == ("incoming", "2026/01/01/a.pdf")


def test_failing_handler_is_retried_then_dead_lettered():
    grid = events.LocalEventGrid()
    calls = {"n": 0}

    def boom(ev):
        calls["n"] += 1
        raise RuntimeError("function down")
    grid.subscribe(boom)
    status = grid.publish(events.blob_created_event("incoming", "x/y.pdf", 1, "application/pdf"))
    assert status == "dead_lettered" and calls["n"] == events.EVENT_MAX_ATTEMPTS


def test_doc_id_is_deterministic():
    assert doc_id_for("a/b.pdf") == doc_id_for("a/b.pdf") != doc_id_for("a/c.pdf")
