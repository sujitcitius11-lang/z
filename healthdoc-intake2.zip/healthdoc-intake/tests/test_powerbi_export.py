import json
import re
from pathlib import Path

import pandas as pd

import config
from src.analytics import export_powerbi as X
from src.analytics import metrics

PHI_COLUMNS = {"patient_name", "dob", "member_id", "address", "phone", "email", "applicant_name", "group_number"}


def _export(pipeline, tmp_path):
    from src.datagen.generate import load_answer_key
    return X.export_all(tmp_path, sql=pipeline["sql"], answer_key=load_answer_key()), tmp_path


def test_all_tables_exported(pipeline, tmp_path):
    counts, out = _export(pipeline, tmp_path)
    expected = {"FactDocuments", "FactValidationIssues", "FactStageTimings", "FactWorkflowActions", "FactFieldConfidence", "FactFieldAccuracy",
                "DimDate", "DimDocType", "DimWorkflow", "DimStatus", "DimProvider", "DimInsurer", "DimRule", "DimFileFormat"}
    assert expected <= set(counts) and all((out / f"{t}.csv").exists() for t in expected)
    assert counts["FactDocuments"] == pipeline["sql"].scalar("SELECT COUNT(*) FROM Documents")


def test_relationships_have_no_orphans(pipeline, tmp_path):
    _, out = _export(pipeline, tmp_path)
    for many, mc, one, oc in X.RELATIONSHIPS:
        if not (out / f"{many}.csv").exists() or not (out / f"{one}.csv").exists():
            continue
        a = pd.read_csv(out / f"{many}.csv", keep_default_na=False)[mc].astype(str)
        b = set(pd.read_csv(out / f"{one}.csv", keep_default_na=False)[oc].astype(str))
        orphans = set(a) - b
        assert not orphans, f"{many}.{mc} -> {one}.{oc}: {list(orphans)[:5]}"
        if one.startswith("Dim") or one == "FactDocuments":
            assert pd.read_csv(out / f"{one}.csv", keep_default_na=False)[oc].is_unique, f"{one}.{oc} must be unique (one side)"


def test_no_phi_columns_anywhere(pipeline, tmp_path):
    _, out = _export(pipeline, tmp_path)
    for f in out.glob("*.csv"):
        cols = set(pd.read_csv(f, nrows=1).columns)
        assert not (cols & PHI_COLUMNS), f"{f.name} leaks {cols & PHI_COLUMNS}"


def test_kpi_parity_between_csv_and_app(pipeline, tmp_path):
    """The DAX measures are defined to equal these pandas formulas; the app uses metrics.kpis()."""
    _, out = _export(pipeline, tmp_path)
    f = pd.read_csv(out / "FactDocuments.csv")
    k = metrics.kpis(pipeline["sql"])
    unique = f[~f.status.isin(["DUPLICATE", "SPLIT"])]
    assert len(f) == k["total"] and len(unique) == k["unique"]
    assert round(100 * f.auto_processed.sum() / len(unique), 1) == k["stp_rate"]
    assert round(100 * f.sent_to_review.sum() / len(unique), 1) == k["review_rate"]
    assert round(100 * (f.status == "FAILED").sum() / len(f), 1) == k["failure_rate"]
    ms = unique[unique.processing_ms.notna()].processing_seconds
    assert round(ms.mean(), 2) == k["avg_processing_s"]
    assert round(f.est_cost_usd.fillna(0).sum(), 2) == k["est_cost_usd"]


def test_date_dimension_covers_all_facts(pipeline, tmp_path):
    _, out = _export(pipeline, tmp_path)
    f, d = pd.read_csv(out / "FactDocuments.csv"), pd.read_csv(out / "DimDate.csv")
    assert set(f.date_key) <= set(d.date_key) and d.date_key.is_unique


def test_dax_references_existing_columns(pipeline, tmp_path):
    counts, out = _export(pipeline, tmp_path)
    schema = json.loads((out / "schema.json").read_text(encoding="utf-8"))
    cols = {t: {c["name"] for c in v["columns"]} for t, v in schema["tables"].items()}
    dax = (config.POWERBI_DIR / "measures.dax").read_text(encoding="utf-8")
    dax = re.sub(r"//.*", "", dax)
    refs = re.findall(r"\b(Fact\w+|Dim\w+)\[(\w+)\]", dax)
    assert refs
    bad = [(t, c) for t, c in refs if t not in cols or c not in cols[t]]
    assert not bad, bad
    measures = set(re.findall(r"^\s*([A-Za-z][\w \-%]*?)\s*=", dax, re.M))
    for m in re.findall(r"\[([A-Z][\w \-%]+)\]", dax):
        if m in {c for cs in cols.values() for c in cs}:
            continue
        assert m in measures, f"measure [{m}] is used but not defined"


def test_theme_is_valid_json_with_required_keys():
    t = json.loads((config.POWERBI_DIR / "theme.json").read_text(encoding="utf-8"))
    assert t["name"] and len(t["dataColors"]) >= 6 and "visualStyles" in t and "textClasses" in t


def test_generated_m_and_sql_cover_every_exported_table(pipeline, tmp_path):
    _, out = _export(pipeline, tmp_path)
    schema = json.loads((out / "schema.json").read_text(encoding="utf-8"))
    qdir = config.POWERBI_DIR / "queries"
    if not (qdir / "csv").exists():
        return
    for t in schema["tables"]:
        assert (qdir / "csv" / f"{t}.m").exists(), t
    views = (config.ROOT / "sql" / "powerbi_views.sql").read_text(encoding="utf-8")
    assert "patient_name" not in views and "member_id" not in views.replace("patient_key", "")
    for t in schema["tables"]:
        if t != "FactFieldAccuracy":
            assert f"vw_{t}" in views
