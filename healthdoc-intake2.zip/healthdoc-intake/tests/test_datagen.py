import json
from collections import Counter

import config
from src import common
from src import schemas as S
from src.datagen.generate import generate_all


def test_counts_and_types(dataset):
    m = dataset["manifest"]
    assert m["total_documents"] == 50 and set(m["by_type"]) == set(S.DOC_TYPES) and all(v == 10 for v in m["by_type"].values())


def test_full_requirement_constants():
    assert config.DOCS_PER_TYPE * len(S.DOC_TYPES) == 2500          # the brief: 2,500 documents, 5 types


def test_files_exist_and_are_supported(dataset):
    for fname, a in dataset["key"].items():
        p = config.SYNTH_DIR / "documents" / a["doc_type"] / fname
        assert p.exists() and p.stat().st_size > 500
        assert fname.lower().endswith(config.ALLOWED_EXTENSIONS)


def test_clean_documents_have_valid_npis(dataset):
    for a in dataset["key"].values():
        if a["meta"]["defects"]:
            continue
        npi_f = S.PROVIDER_FIELDS.get(a["doc_type"], (None, None))[1]
        if npi_f:
            assert common.is_valid_npi(a["fields"][npi_f])


def test_defects_and_duplicates_present(dataset):
    c = Counter(d for a in dataset["key"].values() for d in a["meta"]["defects"])
    assert c["duplicate_exact"] >= 1 and len(c) >= 4


def test_formats_include_scans_or_images(dataset):
    fmts = {a["meta"]["format"] for a in dataset["key"].values()}
    assert "pdf_digital" in fmts


def test_deterministic_with_same_seed(tmp_path):
    a = generate_all(tmp_path / "a", per_type=3, seed=11, use_azure_narrative=False, dup_per_type=0)
    b = generate_all(tmp_path / "b", per_type=3, seed=11, use_azure_narrative=False, dup_per_type=0)
    ka, kb = json.loads((tmp_path / "a" / "answer_key.json").read_text(encoding="utf-8")), json.loads((tmp_path / "b" / "answer_key.json").read_text(encoding="utf-8"))
    assert [x["fields"] for x in ka] == [x["fields"] for x in kb]
    assert a["total_documents"] == b["total_documents"] == 15


def test_edge_case_pack(dataset):
    assert (config.SYNTH_DIR / "edge_cases" / "edge_cases.json").exists()
    assert len(list((config.SYNTH_DIR / "edge_cases").glob("*.pdf"))) >= 10


def test_no_real_looking_phi_markers(dataset):
    """Every PDF carries the synthetic-data footer."""
    import pdfplumber
    a = next(a for a in dataset["key"].values() if a["meta"]["format"] == "pdf_digital")
    with pdfplumber.open(config.SYNTH_DIR / "documents" / a["doc_type"] / a["file"]) as pdf:
        assert "SYNTHETIC" in (pdf.pages[0].extract_text() or "")
