import pytest

from src.validation import rules


def F(**kw):
    return {k: {"value": v, "confidence": 0.99} for k, v in kw.items()}


def ids(issues):
    return {i.rule_id for i in issues}


GOOD_CLAIM = dict(claim_number="CLM251234567", patient_name="A B", dob="1980-01-01", member_id="ABC123456789", insurer="X",
                  provider_name="D", provider_npi="1234567893", service_date="2026-01-05", place_of_service="11",
                  diagnosis_codes=["E11.9"], line_items=[{"cpt": "99213", "description": "x", "units": 1, "charge": 130.0}], billed_amount=130.0)


def test_clean_claim_has_no_issues():
    assert rules.validate("claim", F(**GOOD_CLAIM)) == []


@pytest.mark.parametrize("change,rule", [
    ({"provider_npi": "1234567890"}, "R006"), ({"member_id": "ABC123456"}, "R007"), ({"diagnosis_codes": ["ZZ9.99"]}, "R008"),
    ({"service_date": "2031-01-01"}, "R003"), ({"service_date": "1970-01-01"}, "R005"), ({"billed_amount": 999.0}, "R011"),
    ({"billed_amount": -5.0}, "R012"), ({"dob": "2999-01-01"}, "R004"), ({"service_date": "not a date"}, "R002"),
    ({"place_of_service": "99"}, "R023"), ({"diagnosis_codes": ["A99.99"]}, "R009"),
])
def test_claim_rules_fire(change, rule):
    assert rule in ids(rules.validate("claim", F(**{**GOOD_CLAIM, **change})))


def test_missing_required_field():
    g = {**GOOD_CLAIM}
    g["member_id"] = None
    assert "R001" in ids(rules.validate("claim", F(**g)))


def test_duplicate_claim_number_uses_callback():
    assert "R022" in ids(rules.validate("claim", F(**GOOD_CLAIM), claim_exists=lambda cn: True))
    assert "R022" not in ids(rules.validate("claim", F(**GOOD_CLAIM), claim_exists=lambda cn: False))


def test_lab_flag_and_range_rules():
    rows = [{"test": "Glucose", "value": 150.0, "unit": "mg/dL", "ref_low": 70.0, "ref_high": 99.0, "flag": ""}]
    base = dict(accession_number="ACC123456789", lab_name="L", patient_name="A B", dob="1980-01-01", ordering_provider="D",
                ordering_npi="1234567893", collected_date="2026-01-01", reported_date="2026-01-02", panel_name="Basic Metabolic Panel", results=rows)
    got = ids(rules.validate("lab_report", F(**base)))
    assert "R013" in got and "R015" in got                       # wrong flag + incomplete panel
    base["reported_date"] = "2025-12-30"
    assert "R019" in ids(rules.validate("lab_report", F(**base)))


def test_prescription_rules():
    base = dict(rx_number="RX12345678", date_written="2026-01-01", patient_name="A B", dob="1980-01-01", prescriber_name="D",
                prescriber_npi="1234567893", drug_name="Metformin", strength="500 mg", dosage_form="Tablet", quantity=60, refills=15, directions="x")
    assert "R016" in ids(rules.validate("prescription", F(**base)))
    base.update(refills=2, quantity=0, drug_name="Unobtainium")
    got = ids(rules.validate("prescription", F(**base)))
    assert "R017" in got and "R024" in got


def test_low_confidence_warning():
    f = F(**GOOD_CLAIM)
    f["patient_name"]["confidence"] = 0.4
    assert "R021" in ids(rules.validate("claim", f))


def test_decide_status():
    assert rules.decide_status([], 0.99, 0.97, "claim") == ("PASSED", [])
    err = [rules.Issue("R006", "error", "x", "m")]
    assert rules.decide_status(err, 0.99, 0.97, "claim")[0] == "NEEDS_REVIEW"
    one_warn = [rules.Issue("R009", "warning", "x", "m")]
    assert rules.decide_status(one_warn, 0.99, 0.97, "claim")[0] == "PASSED"
    two_warn = one_warn * 2
    assert rules.decide_status(two_warn, 0.99, 0.97, "claim")[0] == "NEEDS_REVIEW"
    assert rules.decide_status([], 0.3, 0.97, "claim")[0] == "NEEDS_REVIEW"
    assert rules.decide_status([], 0.99, 0.5, "claim")[0] == "NEEDS_REVIEW"
    assert rules.decide_status([], 0.99, 0.99, "unknown")[0] == "NEEDS_REVIEW"


def test_every_rule_in_catalogue_is_documented():
    assert all(v[0] in ("error", "warning") and v[1] for v in rules.CATALOGUE.values())
