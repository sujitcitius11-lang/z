"""Azure code paths exercised with FAKE clients (no network). This proves our request/response handling, retry mapping and
mode switching; it does NOT prove the real Azure services accept our calls (see docs/KNOWN_LIMITATIONS.md)."""
import importlib
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

import config
from src.providers import llm, ocr

ROOT = Path(__file__).resolve().parents[1]


def test_service_modes_switch_on_configuration(monkeypatch):
    monkeypatch.setattr(config, "FORCE_LOCAL", False)
    for k in ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT_NAME", "DOCUMENT_INTELLIGENCE_ENDPOINT", "COSMOS_ENDPOINT", "KEY_VAULT_URI"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setattr(config, "env", lambda n, d=None: __import__("os").getenv(n) or d)
    assert set(config.service_modes().values()) == {"local"}
    monkeypatch.setenv("DOCUMENT_INTELLIGENCE_ENDPOINT", "https://x")
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://y")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt")
    m = config.service_modes()
    assert m["doc_intelligence"] == "azure" and m["openai"] == "azure" and m["sql"] == "local"
    monkeypatch.setattr(config, "FORCE_LOCAL", True)
    assert set(config.service_modes().values()) == {"local"}


def test_document_intelligence_response_is_converted(monkeypatch):
    page = NS(page_number=1, words=[NS(content="Patient", confidence=0.99), NS(content="Nme", confidence=0.50)])
    result = NS(content="Patient Nme", pages=[page])
    client = NS(begin_analyze_document=lambda *a, **k: NS(result=lambda: result))
    import src.providers.azure_clients as ac
    monkeypatch.setattr(ac, "document_intelligence_client", lambda: client)
    r = ocr.AzureDocIntelOcr().analyze(b"%PDF-1.4 fake", "a.pdf")
    assert r.text == "Patient Nme" and r.pages == 1 and r.words[1]["conf"] == 0.5 and abs(r.avg_confidence - 0.745) < 1e-6


def test_document_intelligence_503_is_transient_and_400_is_unreadable(monkeypatch):
    from azure.core.exceptions import HttpResponseError
    from src import common
    import src.providers.azure_clients as ac

    def boom(code):
        e = HttpResponseError(message="x"); e.status_code = code
        def f(*a, **k): raise e
        return NS(begin_analyze_document=f)
    monkeypatch.setattr(ac, "document_intelligence_client", lambda: boom(503))
    with pytest.raises(common.TransientError):
        ocr.AzureDocIntelOcr().analyze(b"x")
    monkeypatch.setattr(ac, "document_intelligence_client", lambda: boom(400))
    with pytest.raises(ocr.UnreadableDocument):
        ocr.AzureDocIntelOcr().analyze(b"x")


class FakeOpenAI:
    def __init__(self, classify, extract):
        self.replies = [classify, extract]
        self.calls = []
        self.chat = NS(completions=NS(create=self._create))

    def _create(self, **kw):
        self.calls.append(kw)
        body = self.replies.pop(0)
        return NS(usage=NS(prompt_tokens=100, completion_tokens=20), choices=[NS(message=NS(content=json.dumps(body)))])


def _engine(fake, monkeypatch):
    import src.providers.azure_clients as ac
    monkeypatch.setattr(ac, "openai_client", lambda: fake)
    monkeypatch.setattr(ac, "openai_deployment", lambda: "gpt-test")
    return llm.AzureOpenAIEngine()


def test_openai_two_calls_strict_schema_and_hallucination_penalty(monkeypatch):
    from src import schemas as S
    fake = FakeOpenAI({"doc_type": "prescription", "confidence": 0.97},
                      {f.name: None for f in S.SCHEMAS["prescription"]} | {"drug_name": "Zzyzx Mystery Pill", "patient_name": "April Finley"})
    text = "Prescription\nPatient Name: April Finley\nDrug: Lisinopril"
    words = [{"text": w, "conf": 0.98, "page": 1} for w in text.split()]
    out = _engine(fake, monkeypatch).classify_and_extract(text, words, 0.98)
    assert out.doc_type == "prescription" and len(fake.calls) == 2
    assert fake.calls[1]["response_format"]["json_schema"]["strict"] is True and fake.calls[0]["temperature"] == 0
    assert out.fields["patient_name"]["confidence"] > 0.8
    assert out.fields["drug_name"]["confidence"] < 0.6 and "hallucination" in (out.fields["drug_name"]["note"] or "")
    assert out.tokens_in == 200 and out.tokens_out == 40


def test_openai_unknown_type_skips_extraction(monkeypatch):
    fake = FakeOpenAI({"doc_type": "menu", "confidence": 0.9}, {})
    out = _engine(fake, monkeypatch).classify_and_extract("pizza", [], 0.9)
    assert out.doc_type == "unknown" and len(fake.calls) == 1


def test_openai_rate_limit_is_retried(monkeypatch):
    from openai import RateLimitError
    calls = {"n": 0}

    def create(**kw):
        calls["n"] += 1
        if calls["n"] < 3:
            raise RateLimitError("slow down", response=NS(status_code=429, headers={}, request=NS()), body=None)
        return NS(usage=NS(prompt_tokens=1, completion_tokens=1), choices=[NS(message=NS(content="{}"))])
    fake = NS(chat=NS(completions=NS(create=create)))
    r = _engine(fake, monkeypatch)._chat(messages=[])
    assert calls["n"] == 3 and r is not None


def test_fallback_engine_uses_local_when_azure_fails():
    class Bad:
        name = "bad"
        def classify_and_extract(self, *a): raise RuntimeError("down")
    class Good:
        name = "good"
        def classify_and_extract(self, *a): return "ok"
    class Out: fallback_used = False
    class Good2:
        def classify_and_extract(self, *a): return Out()
    out = llm.FallbackEngine(Bad(), Good2()).classify_and_extract("t", [], 0.9)
    assert out.fallback_used is True


def test_logic_app_dispatch_posts_and_records_failures(monkeypatch, pipeline):
    from src.routing import logic_app
    sent = []
    monkeypatch.setattr(config, "mode", lambda s: "azure" if s == "logic_apps" else "local")
    monkeypatch.setattr(config, "env", lambda n, d=None: "https://logic.example/run")
    monkeypatch.setattr(logic_app, "_post", lambda url, p: sent.append((url, p)) or 202)
    route = {"workflow_id": "W-CLAIM", "workflow_name": "Claims", "team": "Claims", "priority": "normal", "sla_due_at": "2026-10-23T00:00:00Z",
             "reason": "r", "actions": ["notify_team_email", "create_work_item"]}
    rows = logic_app.dispatch("DOC-T1", route, {"doc_type": "claim"}, store=pipeline["sql"])
    assert len(sent) == 1 and sent[0][1]["workflow_id"] == "W-CLAIM" and {r["status"] for r in rows} == {"sent"}

    def fail(url, p): raise RuntimeError("500")
    monkeypatch.setattr(logic_app, "_post", fail)
    rows = logic_app.dispatch("DOC-T2", route, {}, store=pipeline["sql"])
    assert {r["status"] for r in rows} == {"failed"}
    pipeline["sql"].delete("WorkflowActions", "doc_id IN (?,?)", ["DOC-T1", "DOC-T2"])   # keep the shared test DB clean


def test_workflow_json_covers_every_routing_workflow():
    wf = json.loads((ROOT / "logic_apps" / "routing_workflow.json").read_text(encoding="utf-8"))
    text = json.dumps(wf)
    from src.routing import router
    ids = set(re.findall(r"W-[A-Z0-9-]+", Path(router.__file__).read_text(encoding="utf-8")))
    assert ids, "no workflow ids found in router"
    missing = [i for i in ids if i not in text]
    assert not missing, missing


def test_function_helpers_call_pipeline_and_raise_on_transient(monkeypatch):
    sys.path.insert(0, str(ROOT / "functions"))
    try:
        fa = importlib.import_module("function_app")
    except ModuleNotFoundError:
        pytest.skip("azure-functions package not installed")
    import src.pipeline.processor as P
    monkeypatch.setattr(P.DocumentProcessor, "handle_event", lambda self, e: {"status": "PASSED", "doc_id": "D1"})
    assert fa.handle_blob_created({"id": "1", "subject": "x"})["status"] == "PASSED"
    monkeypatch.setattr(P.DocumentProcessor, "handle_event", lambda self, e: {"status": "FAILED", "transient": True, "reason": "503"})
    with pytest.raises(RuntimeError):
        fa.handle_blob_created({"id": "2", "subject": "x"})


def test_schema_azure_sql_is_in_sync_with_python_table_spec(tmp_path):
    import subprocess
    out = tmp_path / "s.sql"
    subprocess.run([sys.executable, str(ROOT / "scripts" / "export_sql_schema.py"), "--out", str(out)], check=True, capture_output=True)
    assert out.read_text(encoding="utf-8") == (ROOT / "sql" / "schema_azure.sql").read_text(encoding="utf-8")


def test_env_example_lists_every_setting_the_code_reads():
    sample = (ROOT / ".env.example").read_text(encoding="utf-8")
    skip = {"tests", ".git", ".venv", "venv", "site-packages", "node_modules", "__pycache__"}
    src = "".join(p.read_text(encoding="utf-8", errors="ignore") for p in ROOT.rglob("*.py") if not skip & set(p.relative_to(ROOT).parts))
    used = set(re.findall(r'(?:env|getenv)\(\s*"([A-Z][A-Z_]{3,})"', src))
    assert not [u for u in used if f"{u}=" not in sample]
