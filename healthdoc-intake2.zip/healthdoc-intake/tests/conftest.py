"""Tests run in a THROWAWAY data folder and in local mode, so they never touch your real data or any Azure resource."""
import os
import sys
import tempfile
from pathlib import Path

_TMP = tempfile.mkdtemp(prefix="docintake_tests_")
os.environ["DOCINTAKE_DATA_DIR"] = _TMP
os.environ["DOCINTAKE_LOG_DIR"] = str(Path(_TMP) / "logs")
os.environ["FORCE_LOCAL"] = "1"
os.environ["RETRY_BASE_SECONDS"] = "0.01"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

import config  # noqa: E402


@pytest.fixture(scope="session")
def dataset():
    """A small synthetic dataset (6 per type, a few scans) + the edge-case pack."""
    from src.datagen.generate import generate_all, load_answer_key
    m = generate_all(config.SYNTH_DIR, per_type=10, seed=7, scanned_ratio=0.1, defect_ratio=0.25, dup_per_type=1, use_azure_narrative=False)
    return {"manifest": m, "key": load_answer_key()}


@pytest.fixture(scope="session")
def pipeline(dataset):
    """Push the dataset + edge cases through the real pipeline once; tests then inspect the database."""
    from src.pipeline.batch import run_batch
    from src.pipeline.operations import reset_all
    reset_all()
    files, received = [], {}
    for fname, a in dataset["key"].items():
        files.append(config.SYNTH_DIR / "documents" / a["doc_type"] / fname)
        received[fname] = a["meta"]["received_at"]
    files += sorted((config.SYNTH_DIR / "edge_cases").glob("*.pdf"))
    res = run_batch(files, received, workers=1)
    from src.storage.sql_store import get_sql
    return {"result": res, "sql": get_sql(), "files": files}
