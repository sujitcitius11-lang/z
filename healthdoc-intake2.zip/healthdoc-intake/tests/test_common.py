import random

import pytest

from src import common


def test_npi_check_digit_known_values():
    assert common.is_valid_npi("1234567893")          # the textbook example
    assert not common.is_valid_npi("1234567890")
    assert not common.is_valid_npi("123")
    assert not common.is_valid_npi("")


def test_generated_npis_are_valid():
    rng = random.Random(1)
    assert all(common.is_valid_npi(common.make_npi(rng)) for _ in range(200))


@pytest.mark.parametrize("text,iso", [("03/04/1980", "1980-03-04"), ("1980-03-04", "1980-03-04"), ("Mar 4, 1980", "1980-03-04"),
                                      ("March 4, 1980", "1980-03-04"), ("04-Mar-1980", "1980-03-04"), ("garbage", None), (None, None)])
def test_parse_date(text, iso):
    assert common.to_iso_date(text) == iso


def test_money_and_phone():
    assert common.parse_money("$1,234.50") == 1234.5
    assert common.parse_money("abc") is None
    assert common.normalise_phone("555.123.4567") == "(555) 123-4567"
    assert common.normalise_phone("123") is None


def test_masking_hides_phi():
    m = common.mask_fields({"patient_name": "Jane Doe", "dob": "1980-01-01", "member_id": "ABC123456789", "amount": 5})
    assert "Jane" not in m["patient_name"] and m["dob"].startswith("****") and m["member_id"].endswith("*" * 9) and m["amount"] == 5


def test_retry_retries_transient_then_succeeds():
    calls = {"n": 0}

    @common.retry(max_attempts=3, base=0.001)
    def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise common.TransientError("429")
        return "ok"
    assert flaky() == "ok" and calls["n"] == 3


def test_retry_gives_up_and_raises():
    @common.retry(max_attempts=2, base=0.001)
    def bad():
        raise common.TransientError("503")
    with pytest.raises(common.TransientError):
        bad()


def test_retry_does_not_retry_permanent_errors():
    calls = {"n": 0}

    @common.retry(max_attempts=3, base=0.001)
    def perm():
        calls["n"] += 1
        raise ValueError("bad")
    with pytest.raises(ValueError):
        perm()
    assert calls["n"] == 1
