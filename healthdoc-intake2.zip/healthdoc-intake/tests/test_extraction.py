import pytest
import config
from src.analytics.evaluation import evaluate
from src.providers import heuristic
from src.providers.llm import HeuristicEngine
from src.providers.ocr import LocalOcr, tesseract_available


def _run(dataset, only_digital=True):
    ocr, eng, res = LocalOcr(), HeuristicEngine(), []
    for fname, a in dataset["key"].items():
        if only_digital and a["meta"]["format"] != "pdf_digital":
            continue
        data = (config.SYNTH_DIR / "documents" / a["doc_type"] / fname).read_bytes()
        o = ocr.analyze(data, fname)
        e = eng.classify_and_extract(o.text, o.words, o.avg_confidence)
        res.append({"file": fname, "doc_type": e.doc_type, "type_confidence": e.type_confidence, "fields": e.fields, "status": "X"})
    return evaluate(dataset["key"], res)


def test_digital_documents_are_classified_and_read_accurately(dataset):
    ev = _run(dataset)
    assert ev["classification_accuracy"] == 100.0
    assert ev["field_accuracy_overall"] >= 97.0
    assert ev["spurious_fields"] == 0


def test_label_matching_does_not_confuse_titles_with_labels():
    text = "Patient Referral\nSpecialist Referral Form\nPatient Name:\nJane Roe\nSpecialty: Cardiology"
    out = heuristic.extract("referral", heuristic.fuzzy_label_pass("referral", text), [], 0.99)
    assert out["patient_name"]["value"] == "Jane Roe" and out["referred_to_specialty"]["value"] == "Cardiology"


def test_fuzzy_label_repairs_damaged_label_line():
    fixed = heuristic.fuzzy_label_pass("enrollment", "Applicant Nane\nApril Finley")
    assert fixed.splitlines()[0].endswith(":")


def test_ocr_repair_of_ids_and_digits():
    assert heuristic.repair_id("member_id", "ABC12345G789")[0] == "ABC123456789"
    assert heuristic.repair_id("claim_number", "CLM2S6417843")[0] == "CLM256417843"
    assert heuristic.repair_digits("2O35374407") == "2035374407"


def test_lab_row_parser_tolerates_ocr_damage():
    rows = heuristic.extract_lab_rows("TSH 2°55 mIU/L 0.40 - 4.00\nGlucose 91 mg/dL 70 - 99 H")
    assert rows[0]["value"] == 2.55 and rows[1]["flag"] == "H"


def test_classifier_unknown_for_memo():
    assert heuristic.classify("INTERNAL MEMO\nSubject: Staff meeting moved to Thursday\nPlease bring your reports.")[0] == "unknown"
    assert heuristic.classify("")[0] == "unknown"


@pytest.mark.skipif(not tesseract_available(), reason="Tesseract OCR not installed on this machine")
def test_scanned_documents_are_still_mostly_readable(dataset):
    ev = _run(dataset, only_digital=False)
    assert ev["classification_accuracy"] >= 95.0 and ev["field_accuracy_overall"] >= 85.0
