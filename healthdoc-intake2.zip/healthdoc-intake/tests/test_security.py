import os

from src.security import auth, keyvault


def test_roles_from_entra_claims():
    assert auth.roles_from_claims({"roles": ["Intake.Reviewer", "Other.Role"]}) == ["Intake.Reviewer"]
    assert auth.roles_from_claims({"roles": "Intake.Admin"}) == ["Intake.Admin"]
    assert auth.roles_from_claims(None) == [] and auth.roles_from_claims({}) == []


def test_page_access_is_least_privilege():
    assert "Azure Services" not in auth.allowed_pages(["Intake.Analyst"])
    assert "Review Queue" in auth.allowed_pages(["Intake.Reviewer"]) and "Upload & Process" not in auth.allowed_pages(["Intake.Reviewer"])
    assert set(auth.allowed_pages(["Intake.Admin"])) == set(auth.PAGE_ACCESS)
    assert not auth.can_access("Review Queue", [])


def test_phi_visibility():
    assert auth.can_see_phi(["Intake.Reviewer"]) and not auth.can_see_phi(["Intake.Analyst"])


def test_key_vault_returns_none_without_vault_and_never_for_unlisted_names(monkeypatch):
    monkeypatch.delenv("KEY_VAULT_URI", raising=False)
    keyvault.get_secret.cache_clear()
    assert keyvault.get_secret("AZURE_OPENAI_API_KEY") is None
    monkeypatch.setenv("KEY_VAULT_URI", "https://example.vault.azure.net")
    assert keyvault.get_secret("SOME_RANDOM_NAME") is None


def test_key_vault_lookup_maps_underscores_and_caches(monkeypatch):
    monkeypatch.setenv("KEY_VAULT_URI", "https://example.vault.azure.net")
    asked = []

    class Secret:
        value = "s3cret"

    class FakeClient:
        def get_secret(self, name):
            asked.append(name)
            return Secret()
    monkeypatch.setattr(keyvault, "_client", lambda: FakeClient())
    keyvault.get_secret.cache_clear()
    assert keyvault.get_secret("COSMOS_KEY") == "s3cret" and keyvault.get_secret("COSMOS_KEY") == "s3cret"
    assert asked == ["COSMOS-KEY"]
    keyvault.get_secret.cache_clear()


def test_no_secrets_in_source():
    import re
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    pat = re.compile(r"(AccountKey=[A-Za-z0-9+/=]{20,}|sk-[A-Za-z0-9]{20,}|Password=[^;\s\"']{6,})")
    skip = {"tests", ".git", ".venv", "venv", "site-packages", "node_modules", "__pycache__"}
    hits = [str(p) for p in root.rglob("*.py") if not skip & set(p.relative_to(root).parts) and pat.search(p.read_text(encoding="utf-8", errors="ignore"))]
    assert hits == []
