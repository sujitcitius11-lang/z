"""Evaluation harness, packet splitting, feedback loop, PHI masking, cross-document rules, FHIR, telemetry."""
import io
import json
import sqlite3
from types import SimpleNamespace as NS

import pytest

import config
from src import schemas as S
from src.analytics import evaluation as E
from src.pipeline import feedback, splitter
from src.security import deid
from src.validation import rules


# ------------------------------------------------------------------ precision / recall / F1
def _key(truth):
    return {"a.pdf": {"doc_type": "prescription", "fields": truth, "meta": {"defects": [], "format": "pdf_digital", "noise": 0}}}


def test_prf_counts_wrong_value_as_fp_and_fn():
    truth = {"drug_name": "Lisinopril", "strength": "10 mg", "quantity": 30}
    res = [{"file": "a.pdf", "doc_type": "prescription", "status": "PASSED",
            "fields": {"drug_name": {"value": "Lisinopril"}, "strength": {"value": "20 mg"}, "quantity": {"value": None}}}]
    r = E.prf(_key(truth), res)["per_field"]
    assert r["prescription.drug_name"]["tp"] == 1
    assert (r["prescription.strength"]["tp"], r["prescription.strength"]["fp"], r["prescription.strength"]["fn"]) == (0, 1, 1)
    assert (r["prescription.quantity"]["fp"], r["prescription.quantity"]["fn"]) == (0, 1)


def test_prf_wrong_document_type_is_all_misses():
    res = [{"file": "a.pdf", "doc_type": "claim", "status": "PASSED", "fields": {"drug_name": {"value": "Lisinopril"}}}]
    r = E.prf(_key({"drug_name": "Lisinopril"}), res)
    assert r["per_field"]["prescription.drug_name"]["fn"] == 1 and r["per_type"]["prescription"]["doc_exact_match"] == 0


def test_threshold_sweep_is_monotonic():
    key = {f"{i}.pdf": {"doc_type": "prescription", "fields": {"drug_name": "X"}, "meta": {"defects": []}} for i in range(20)}
    res = [{"file": f"{i}.pdf", "doc_type": "prescription", "status": "PASSED", "doc_confidence": 0.5 + i / 40, "error_count": 0,
            "fields": {"drug_name": {"value": "X" if i % 2 else "Y", "confidence": 0.5 + i / 40}}} for i in range(20)]
    sw = E.threshold_sweep(key, res)["doc_sweep"]
    st = [d["straight_through"] for d in sw]
    assert st == sorted(st, reverse=True)


# ------------------------------------------------------------------ packet splitting
def _pdf_text_pages(pages):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    for lines in pages:
        y = 740
        for ln in lines:
            c.drawString(50, y, ln)
            y -= 16
        c.showPage()
    c.save()
    return buf.getvalue()


HEAD = ["Org Name", "Synthetic training document - fictional organisation"]


def test_splitter_uses_titles_and_page_numbers():
    pages = [HEAD + ["HEALTH INSURANCE CLAIM FORM", "Claim Number: CLM250000001", "Page 1"],
             HEAD + ["Claim Number: CLM250000001", "Line Items:", "Page 2"],
             HEAD + ["HEALTH INSURANCE CLAIM FORM", "Claim Number: CLM250000002", "Page 1"],
             HEAD + ["LABORATORY REPORT", "Accession Number: ACC123456789", "Page 1"]]
    segs = splitter.real_segments(splitter.split_pages(["\n".join(p) for p in pages]))
    assert [(s.start, s.end) for s in segs] == [(0, 1), (2, 2), (3, 3)]


def test_splitter_drops_blank_pages_and_keeps_cover_sheet():
    pages = ["FAX COVER SHEET\nTo: Records\nFrom: Desk\nPlease process", "", "\n".join(HEAD + ["PRESCRIPTION", "Rx Number: RX12345678", "Page 1"])]
    segs = splitter.split_pages(pages)
    assert [s.kind for s in segs] == ["document", "blank", "document"]


def test_splitter_slice_bytes_roundtrip():
    from pypdf import PdfReader
    data = _pdf_text_pages([["a"], ["b"], ["c"]])
    assert len(PdfReader(io.BytesIO(splitter.slice_bytes(data, "x.pdf", 1, 2))).pages) == 2


def test_pipeline_splits_packet_into_documents(dataset, pipeline):
    from pypdf import PdfReader, PdfWriter
    from src.pipeline.batch import ingest, make_pipeline
    picks = []
    for t in ("claim", "lab_report"):
        f = next(k for k, v in dataset["key"].items() if v["doc_type"] == t and v["meta"]["format"] == "pdf_digital" and v["meta"]["pages"] == 1
                 and not v["meta"]["defects"])
        picks.append(config.SYNTH_DIR / "documents" / t / f)
    w = PdfWriter()
    for p in picks:
        for pg in PdfReader(str(p)).pages:
            w.add_page(pg)
    buf = io.BytesIO()
    w.write(buf)
    r = ingest("packet_test_1.pdf", buf.getvalue(), grid=make_pipeline())
    sql = pipeline["sql"]
    parent = sql.get_document(r["doc_id"])
    assert parent["status"] == "SPLIT" and parent["split_count"] == 2
    kids = sql.query("SELECT doc_type, page_range FROM Documents WHERE parent_doc_id=? ORDER BY file_name", [r["doc_id"]])
    assert [k["doc_type"] for k in kids] == ["claim", "lab_report"] and [k["page_range"] for k in kids] == ["p1", "p2"]
    # replaying the same event does not split twice
    for row in sql.query("SELECT doc_id FROM Documents WHERE doc_id=? OR parent_doc_id=?", [r["doc_id"], r["doc_id"]]):   # keep the shared test DB clean
        for t in ("Documents", "ExtractedFields", "ValidationIssues", "Routing", "ReviewTasks", "WorkflowActions", "ProcessingStages", "AuditLog"):
            sql.delete(t, "doc_id=?", [row["doc_id"]])
        sql.delete("CosmosItems", "id=?", [row["doc_id"]])


# ------------------------------------------------------------------ feedback loop
def test_correction_memory_learns_after_two_identical_fixes(pipeline):
    sql = pipeline["sql"]
    sql.delete("Corrections", "doc_id LIKE ?", ["FB-%"])
    for i in (1, 2):
        sql.insert("Corrections", {"ts": "2026-10-23T00:00:00Z", "doc_id": f"FB-{i}", "doc_type": "claim", "field_name": "insurer",
                                   "read_value": json.dumps("Lakeshore Benelits"), "corrected_value": json.dumps("Lakeshore Benefits"), "confidence": .7,
                                   "reviewer": "t", "rule_ids": "R021"})
    sql.insert("Corrections", {"ts": "x", "doc_id": "FB-3", "doc_type": "claim", "field_name": "member_id", "read_value": json.dumps("ABC1"),
                               "corrected_value": json.dumps("ABC2"), "reviewer": "t"})
    sql.insert("Corrections", {"ts": "x", "doc_id": "FB-4", "doc_type": "claim", "field_name": "member_id", "read_value": json.dumps("ABC1"),
                               "corrected_value": json.dumps("ABC2"), "reviewer": "t"})
    rl = feedback.learned_rules(sql)
    assert any(r["field"] == "insurer" and r["corrected"] == "Lakeshore Benefits" for r in rl)
    assert not any(r["field"] == "member_id" for r in rl), "ids must never be learned"
    fields = {"insurer": {"value": "lakeshore  benelits", "confidence": .6}, "member_id": {"value": "ABC1", "confidence": .6}}
    n = feedback.apply_memory("claim", fields, sql)
    assert n == 1 and fields["insurer"]["value"] == "Lakeshore Benefits" and fields["insurer"]["source"] == "memory" and fields["member_id"]["value"] == "ABC1"
    sql.delete("Corrections", "doc_id LIKE ?", ["FB-%"])


def test_contradicted_correction_is_not_learned(pipeline):
    sql = pipeline["sql"]
    for i, new in enumerate(["A", "B"]):
        sql.insert("Corrections", {"ts": "x", "doc_id": f"FC-{i}", "doc_type": "claim", "field_name": "facility", "read_value": json.dumps("Oak"),
                                   "corrected_value": json.dumps(new), "reviewer": "t"})
    assert not [r for r in feedback.learned_rules(sql) if r["field"] == "facility"]
    sql.delete("Corrections", "doc_id LIKE ?", ["FC-%"])


def test_review_correction_is_recorded_and_exported(pipeline):
    from src.pipeline import operations as ops
    sql = pipeline["sql"]
    row = sql.one("SELECT doc_id FROM ReviewTasks WHERE status='open' LIMIT 1")
    if not row:
        pytest.skip("no open review task in the test dataset")
    doc = sql.get_document(row["doc_id"])
    field = next(f for f in S.SCHEMAS[doc["doc_type"]] if f.kind == "text" and not f.multiline)
    ops.resolve_review(row["doc_id"], "tester", "correct", {field.name: "Corrected Text Value"}, "x", sql)
    c = sql.one("SELECT * FROM Corrections WHERE doc_id=? AND field_name=?", [row["doc_id"], field.name])
    assert c and json.loads(c["corrected_value"]) == "Corrected Text Value"
    ex = feedback.export_training(sql, mask=True)
    assert ex["documents"] >= 1 and "messages" in ex["jsonl"].splitlines()[0]


# ------------------------------------------------------------------ PHI masking before the model
TEXT = ("Claim Form\nClaim Number: CLM250667191\nPatient: Sheila Walker\nPatient DOB: 03-Jan-2015\nSubscriber ID: BPR569193350\n"
        "Phone: (604) 307-2096\nEmail: sheila.walker@example.com\nBilling Provider: Kenneth Martin, DO\nProvider NPI: 1144046236\n"
        "Service Date: 12-Jun-2025\nDiagnosis: I25.10\nAmount Billed: $120.00\n")


def test_pseudonymise_hides_identifiers_and_keeps_the_rest():
    masked, mp = deid.pseudonymise(TEXT, "claim")
    for secret in ("Sheila Walker", "03-Jan-2015", "BPR569193350", "307-2096", "sheila.walker@example.com", "12-Jun-2025"):
        assert secret not in masked, secret
    for keep in ("Kenneth Martin", "1144046236", "I25.10", "CLM250667191", "$120.00"):
        assert keep in masked, keep
    assert deid.restore({"patient_name": "[NAME_1]", "x": ["[DATE_2]"]}, mp)["patient_name"] == "Sheila Walker"


def test_model_only_sees_placeholders_and_result_is_restored(monkeypatch):
    from src.providers import llm
    import src.providers.azure_clients as ac
    seen = []

    def create(**kw):
        seen.append(json.dumps(kw["messages"]))
        if len(seen) == 1:
            body = {"doc_type": "claim", "confidence": .95}
        else:
            masked = kw["messages"][1]["content"]
            name_tok = next(l for l in masked.splitlines() if l.startswith("Patient:")).split(": ")[1]
            body = {f.name: None for f in S.SCHEMAS["claim"]} | {"patient_name": name_tok}
        return NS(usage=NS(prompt_tokens=10, completion_tokens=5), choices=[NS(message=NS(content=json.dumps(body)))])
    monkeypatch.setattr(ac, "openai_client", lambda: NS(chat=NS(completions=NS(create=create))))
    monkeypatch.setattr(ac, "openai_deployment", lambda: "d")
    words = [{"text": w, "conf": .98, "page": 1} for w in TEXT.split()]
    out = llm.AzureOpenAIEngine().classify_and_extract(TEXT, words, .98)
    assert "Sheila Walker" not in " ".join(seen) and "BPR569193350" not in " ".join(seen)
    assert out.fields["patient_name"]["value"] == "Sheila Walker" and out.masked_spans >= 4


# ------------------------------------------------------------------ cross-document rules
def test_member_id_with_different_name_is_an_error():
    f = {"member_id": {"value": "ABC123456789"}, "patient_name": {"value": "April Finley"}, "dob": {"value": "1990-01-01"}}
    iss = rules.validate("prescription", f, identity_lookup=lambda m: [{"name": "Robert Stone", "dob": "1975-05-05"}])
    assert [i.rule_id for i in iss if i.rule_id in rules.CROSS_RULES] == ["R027"]


def test_same_member_ocr_slip_in_name_is_tolerated_but_dob_conflict_warns():
    f = {"member_id": {"value": "ABC123456789"}, "patient_name": {"value": "Apri1 Finley"}, "dob": {"value": "1990-01-01"}}
    same = rules.validate("prescription", f, identity_lookup=lambda m: [{"name": "April Finley", "dob": "1990-01-01"}])
    assert not [i for i in same if i.rule_id in rules.CROSS_RULES]
    dob = rules.validate("prescription", f, identity_lookup=lambda m: [{"name": "April Finley", "dob": "1991-02-02"}])
    assert [i.rule_id for i in dob if i.rule_id in rules.CROSS_RULES] == ["R028"]


def test_npi_with_different_provider_name_warns():
    f = {"prescriber_name": {"value": "Kenneth Martin, DO"}, "prescriber_npi": {"value": "1144046236"}}
    iss = rules.validate("prescription", f, provider_lookup=lambda n: ["Dana Whitfield, MD"])
    assert "R029" in [i.rule_id for i in iss]
    assert "R029" not in [i.rule_id for i in rules.validate("prescription", f, provider_lookup=lambda n: ["Kenneth Martin DO"])]


# ------------------------------------------------------------------ FHIR
def test_every_document_type_exports_valid_fhir(pipeline):
    from src.exports import fhir
    pytest.importorskip("fhir.resources")
    sql = pipeline["sql"]
    seen = set()
    for t in S.DOC_TYPES:
        for d in sql.query("SELECT doc_id FROM Documents WHERE doc_type=? AND status IN ('PASSED','NEEDS_REVIEW') LIMIT 5", [t]):
            b = fhir.to_bundle(d["doc_id"], t, sql.fields_of(d["doc_id"]))
            assert fhir.validate_bundle(b) == [], (t, fhir.validate_bundle(b))
            seen.add(t)
    assert seen == set(S.DOC_TYPES)


# ------------------------------------------------------------------ telemetry + migration
def test_processing_writes_telemetry(pipeline):
    assert pipeline["sql"].scalar("SELECT COUNT(*) FROM Telemetry WHERE name='document_processed'", default=0) > 0


def test_old_database_is_migrated(tmp_path, monkeypatch):
    db = tmp_path / "old.sqlite"
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE Documents (doc_id TEXT PRIMARY KEY, file_name TEXT)")
    c.commit(); c.close()
    monkeypatch.setattr(config, "SQLITE_PATH", db)
    from src.storage.sql_store import SqlStore
    s = SqlStore("local")
    cols = {r["name"] for r in s.query("PRAGMA table_info(Documents)")}
    assert {"parent_doc_id", "phi_masked_spans", "cross_doc_flags", "page_range"} <= cols
