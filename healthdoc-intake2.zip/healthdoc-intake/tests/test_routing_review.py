import pytest

import config
from src.pipeline.operations import effective_fields, resolve_review
from src.routing import router


def F(**kw):
    return {k: {"value": v, "confidence": 0.99} for k, v in kw.items()}


def test_standard_routes():
    for t, w in {"enrollment": "W-ENR", "claim": "W-CLM", "referral": "W-REF", "prescription": "W-RX", "lab_report": "W-LAB"}.items():
        assert router.route(t, F(), "PASSED").workflow_id == w


def test_high_value_claim_goes_to_senior_review():
    assert router.route("claim", F(billed_amount=config.HIGH_VALUE_CLAIM), "PASSED").workflow_id == "W-CLM-HV"
    assert router.route("claim", F(billed_amount=config.HIGH_VALUE_CLAIM - 1), "PASSED").workflow_id == "W-CLM"


def test_urgent_referral_has_short_sla():
    r = router.route("referral", F(urgency="Urgent"), "PASSED", received_at="2026-01-01T08:00:00Z")
    assert r.workflow_id == "W-REF-URG" and r.sla_hours == 4 and r.sla_due_at.startswith("2026-01-01T12:00")
    assert r.priority == "Critical" and "page_on_call" in r.actions


def test_critical_lab_alert():
    rows = [{"test": "Glucose", "value": 400.0, "unit": "mg/dL", "ref_low": 70.0, "ref_high": 99.0, "flag": "H"}]
    assert router.route("lab_report", F(results=rows), "PASSED").workflow_id == "W-LAB-CRIT"
    rows[0]["value"] = 105.0
    assert router.route("lab_report", F(results=rows), "PASSED").workflow_id == "W-LAB"


def test_review_and_failure_routes_remember_intended_workflow():
    r = router.route("claim", F(billed_amount=50000.0), "NEEDS_REVIEW", ["bad npi"])
    assert r.workflow_id == "W-REVIEW" and r.intended_workflow_id == "W-CLM-HV"
    assert router.route("unknown", {}, "NEEDS_REVIEW").workflow_id == "W-TRIAGE"
    assert router.route("claim", {}, "FAILED").workflow_id == "W-DLQ"


def test_all_workflows_have_sla():
    assert all(w["sla_hours"] >= 0 and w["team"] for w in router.WORKFLOWS.values())


# ------------------------------------------------------------------ human review
def _review_doc(sql, with_rule=None):
    q = "SELECT d.doc_id FROM Documents d JOIN ValidationIssues v ON v.doc_id=d.doc_id WHERE d.status='NEEDS_REVIEW' AND d.doc_type<>'unknown' "
    if with_rule:
        q += f"AND v.rule_id='{with_rule}' "
    return sql.one(q + "LIMIT 1")


def test_correcting_a_bad_npi_releases_the_document(pipeline):
    sql = pipeline["sql"]
    row = _review_doc(sql, "R006")
    if not row:
        pytest.skip("no R006 document in this small sample")
    doc_id = row["doc_id"]
    npi_field = next(i["field_name"] for i in sql.query("SELECT field_name FROM ValidationIssues WHERE doc_id=? AND rule_id='R006'", [doc_id]))
    out = resolve_review(doc_id, "tester@x", "correct", {npi_field: "1234567893"}, "fixed from the paper copy")
    assert effective_fields(sql, doc_id)[npi_field]["value"] == "1234567893"
    assert out["status"] in ("PASSED", "NEEDS_REVIEW")
    assert sql.one("SELECT COUNT(*) AS n FROM AuditLog WHERE doc_id=? AND action='review_correct'", [doc_id])["n"] == 1


def test_wrong_correction_keeps_document_in_queue(pipeline):
    sql = pipeline["sql"]
    row = _review_doc(sql, "R006")
    if not row:
        pytest.skip("no R006 document in this small sample")
    npi_field = next(i["field_name"] for i in sql.query("SELECT field_name FROM ValidationIssues WHERE doc_id=? AND rule_id='R006'", [row["doc_id"]]))
    out = resolve_review(row["doc_id"], "tester@x", "correct", {npi_field: "1234567890"}, "")
    assert out["status"] == "NEEDS_REVIEW" and out["remaining_errors"]


def test_approve_with_errors_requires_note(pipeline):
    sql = pipeline["sql"]
    row = sql.one("SELECT d.doc_id FROM Documents d WHERE d.status='NEEDS_REVIEW' AND d.doc_type<>'unknown' AND d.error_count>0 LIMIT 1")
    if not row:
        pytest.skip("no review doc with errors")
    with pytest.raises(ValueError):
        resolve_review(row["doc_id"], "tester@x", "approve", {}, "")
    out = resolve_review(row["doc_id"], "tester@x", "approve", {}, "Verified against the original paper form")
    assert out["status"] == "PASSED" and sql.get_document(row["doc_id"])["review_status"] == "approved_override"


def test_reject_closes_document(pipeline):
    sql = pipeline["sql"]
    row = sql.one("SELECT doc_id FROM Documents WHERE status='NEEDS_REVIEW' LIMIT 1")
    if not row:
        pytest.skip("no review doc left")
    out = resolve_review(row["doc_id"], "tester@x", "reject", {}, "illegible")
    assert out["status"] == "REJECTED"
    assert sql.one("SELECT status FROM ReviewTasks WHERE doc_id=?", [row["doc_id"]])["status"] == "rejected"
