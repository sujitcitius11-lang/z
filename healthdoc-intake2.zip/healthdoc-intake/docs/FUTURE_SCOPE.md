# Future scope: what to add next, and what each step needs

Everything below is **not built**: it needs a live Azure account, licences or a design decision. It is listed so the capstone can end with a credible roadmap.

| Idea | What it is | Why it matters | What is needed | Effort |
|---|---|---|---|---|
| **Azure Content Understanding** | Microsoft's newer analyzer platform (Document Intelligence is now positioned inside it). Check the current docs before committing: it changes quickly. | Benchmark against Document Intelligence on the same hard pack | Azure resource + the hard pack; add a `ContentUnderstandingOcr` class with the same interface as `AzureDocIntelOcr`, then the ablation harness compares them (V5/V6 slots exist) | 2-3 days |
| **Vision LLM extraction** | Send page images straight to a multimodal model with a JSON schema | Might beat OCR + text on boxed forms and photos (our weakest case) | Multimodal deployment; a new engine class; compare cost and accuracy on the hard pack | 2-3 days |
| **Model routing** | Cheap model first, stronger model only for low-confidence documents | Cost control | Two deployments; routing rule on `doc_confidence`; measure the cost/accuracy curve with the existing threshold sweep | 2 days |
| **Chat with documents** | Index processed documents in Azure AI Search (hybrid search) and answer questions with citations | Staff find information without opening files | AI Search + embeddings deployment; index only masked or access-controlled content | 4-5 days |
| **Agentic follow-up** | An agent notices a missing mandatory field and drafts a request to the provider (human approves before sending) | Closes the loop on rejected documents | Agent framework, e-mail connector, strict approval step | 3-4 days |
| **Learning from corrections, stage 2** | Use `corrections_finetune.jsonl` to fine-tune a small model or train a Document Intelligence custom model | Fewer reviews over time | Labelled data volume (hundreds+ per type), de-identified; custom models need bounding-box labels | 1-2 weeks |
| **Fabric + Purview** | Lakehouse analytics (Power BI Direct Lake) and data lineage / classification | Governance story for the client | Fabric capacity, Purview account | 1 week |
| **Real healthcare standards** | FHIR is built (export, structurally validated). Next: post to Azure Health Data Services; X12 837/835 for real claims files; LOINC / RxNorm coding | Interoperability | AHDS workspace; code-set licences/lookups | 1-2 weeks |
| **Source highlighting** | Draw the box on the page where each value was read | Faster, more trustworthy review | Keep word bounding boxes from OCR (Document Intelligence returns polygons) and store them with each field | 2-3 days |
| **Private networking** | Private endpoints, VNet integration, no public access | Required for real PHI | Network design, DNS, Bicep changes | 3-5 days |

Already done in this project from the original list: accuracy harness with precision/recall/F1 and ablation, messy-document pack, packet splitting, review feedback loop, cross-document validation,
reliability (retries, dead-letter, idempotency), telemetry hooks, PHI masking before the LLM, FHIR output, infrastructure as code, cost and latency estimate.
