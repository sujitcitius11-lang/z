# Monitoring with Application Insights

`src/pipeline/telemetry.py` sends **custom events** and **metrics** (never PHI: ids, status, type, timings only).
Set `APPLICATIONINSIGHTS_CONNECTION_STRING` (the Bicep template creates the resource and the Function App already has the setting) and install `azure-monitor-opentelemetry`.
Without it the same calls fill the local `Telemetry` table, shown at the bottom of the Pipeline Monitor page.

| Event | Meaning |
|---|---|
| `document_processed` (value = ms) | one document finished; props: status, doc_type, workflow |
| `document_failed` | pipeline error, document dead-lettered |
| `packet_split` (value = parts) | one file was cut into several documents |
| metric `ocr_confidence` | average OCR word confidence per document |

## KQL to paste into Logs
```kusto
// documents per hour by outcome
customEvents | where name == "document_processed"
| summarize n = count() by bin(timestamp, 1h), status = tostring(customDimensions.status) | render columnchart

// slowest 5% (p95 latency, ms) per day
customEvents | where name == "document_processed"
| summarize p95 = percentile(todouble(customDimensions.value), 95) by bin(timestamp, 1d)

// failure rate, last 24 h
customEvents | where timestamp > ago(24h)
| summarize failed = countif(name == "document_failed"), ok = countif(name == "document_processed") | extend failure_pct = 100.0 * failed / (failed + ok)

// Function exceptions
exceptions | where cloud_RoleName has "func" | summarize count() by type, outerMessage | top 10 by count_
```
## Alerts to create (Azure Monitor)
* Failure rate > 2 % over 15 minutes (query above, log alert, severity 2).
* No `document_processed` event for 30 minutes during business hours (pipeline stalled).
* Dead-letter blobs > 0 (Event Grid dead-letter container metric).
* p95 latency above the SLA you promised.
Status: the code path was written to Microsoft's documented pattern but not run against a real Application Insights resource.
