# Architecture
```mermaid
flowchart LR
  U[Upload / batch / fax] --> B[(Blob: incoming)]
  B -->|BlobCreated| EG[Event Grid]
  EG --> F[Azure Function]
  F --> DI[Document Intelligence OCR]
  F --> AO[Azure OpenAI classify + extract]
  F --> V[Validation rules in code]
  V --> R[Routing + SLA]
  R --> SQL[(Azure SQL)]
  R --> CO[(Cosmos DB raw JSON)]
  R --> LA[Logic App: email / Teams / work item]
  R --> B2[(Blob: processed / review / quarantine)]
  SQL --> PBI[Power BI]
  SQL --> UI[Streamlit UI + review queue]
  KV[Key Vault] -.secrets.-> F
  ENT[Entra ID] -.roles.-> UI
```
**Design rule:** code decides, the model only reads. Confidence comes from OCR word confidence plus a grounding check, not from the model's own claim.
**Reliability:** deterministic document id (idempotent), sha256 duplicate detection, retries with exponential back-off, dead-letter queue, Event Grid dead-lettering, local fallback engine.
**Local mode:** every box has a same-interface stand-in (folder, SQLite, pdfplumber/Tesseract, heuristic extractor, outbox table).
