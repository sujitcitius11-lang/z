# Project outline
**Phase 1 Foundation** (week 1): environment, Azure resources (Bicep), repo + Boards, security baseline.
**Phase 2 Data** (week 1-2): schemas, generator (2,500 documents, scans, defects, answer key).
**Phase 3 Read** (week 2-3): OCR, classification, extraction, confidence.
**Phase 4 Check and route** (week 3-4): validation rules, routing, Logic Apps, human review.
**Phase 5 Store and show** (week 4-5): SQL/Cosmos, Streamlit UI, Power BI.
**Phase 6 Harden** (week 5-6): idempotency, retries, dead-letter, audit, tests, CI/CD, evaluation, cost.
**Phase 7 Deliver**: demo, documentation, hand-over. Hardest parts: reliable extraction from poor scans, validation rule design, tuning the review threshold, Azure permissions/networking, Power BI modelling.
