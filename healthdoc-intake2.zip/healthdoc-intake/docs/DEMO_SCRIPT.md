# Demo script (15 minutes)
1. **Overview** (2 min): 2,517 documents, 83.6% straight-through, cost tile, weekly volume. Say the numbers are synthetic and assumptions are labelled.
2. **Upload & Process** (3 min): drop a PDF and a phone photo; watch the stage belt (upload > OCR > classify > validate > route). Upload the same file again: DUPLICATE, nothing double counted.
3. **Document Explorer** (2 min): open a claim; original beside extracted fields, per-field confidence, validation results, history.
4. **Review Queue** (3 min): open a flagged claim (service date before DOB); correct a field; release; show re-validation, audit entry and new route.
5. **Workflows & Rules** (1 min): 11 workflows, SLA, rule catalogue. **Pipeline Monitor**: events, retries, dead letters; reprocess one.
6. **Accuracy & Evaluation** (2 min): accuracy by type/quality, calibration table, defect detection. Be frank about the limits.
7. **Power BI** (1 min): live preview, data model, kit. **Azure Services**: what is local vs Azure; Key Vault and roles.
8. Close with `docs/KNOWN_LIMITATIONS.md` and the next steps (real samples, live Azure run).
Switch role (Analyst vs Reviewer) to show access control and PHI masking.
