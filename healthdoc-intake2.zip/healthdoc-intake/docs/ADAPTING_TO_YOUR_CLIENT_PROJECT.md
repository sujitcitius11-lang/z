# Adapting this to the real client project
1. Put 50+ de-identified real samples per type into a folder; run `scripts/run_pipeline.py` on them and read the Review Queue to see what breaks.
2. Edit `src/schemas.py` (fields, label synonyms) and `src/reference_data.py` (code lists); add rules to `src/validation/rules.py` (+ a test each).
3. Change routes, teams, SLAs in `src/routing/router.py`; mirror them in `logic_apps/build_workflow.py` and regenerate the JSON.
4. Switch on Azure one service at a time via `.env` (Azure Services page shows each mode and a connection check). Start with Document Intelligence, then OpenAI.
5. Replace the answer-key evaluation with a hand-labelled sample of real documents; re-set thresholds in `.env` using the calibration table.
6. Replace SQLite with Azure SQL (`sql/schema_azure.sql`), publish Power BI from the views, set up Entra app roles, deploy with `infra/deploy.sh` and `devops/azure-pipelines.yml`.
