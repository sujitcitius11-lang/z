# Questions to ask the client
1. Which document types and layouts, how many per day, peaks? Real samples (de-identified) for 50+ of each type?
2. Languages, handwriting, faxes, stamps, multi-page packets?
3. Who receives each document type; what are the real SLAs and priorities? Escalation rules?
4. Which fields are mandatory; which code sets (ICD-10 / CPT versions, payer list, NPI registry lookup)?
5. Target systems (EHR, claims system): API, file drop, HL7/FHIR? Do we write back?
6. Compliance: HIPAA/BAA, data residency, retention period, who may see PHI, audit needs?
7. Azure landing zone: subscription, region, network (private endpoints), identity, naming, budgets?
8. Acceptable error rate and review capacity; what is the cost of a wrong extraction?
9. Success measures and baseline: minutes per document today, staff count?
10. Power BI: licences, workspace, refresh needs, audiences, RLS rules?
