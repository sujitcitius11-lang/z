# Known limitations (read before presenting)

*Hard-pack findings, PHI-masking scope and the other additions are covered in items 11-17 at the end.*

1. **No live Azure run.** Azure code paths are tested with fake clients only. Expect small fixes on first contact (SDK versions, permissions, quotas).
2. **Bicep and Logic App JSON are uncompiled / untested** in a subscription. Run `az bicep build` and `what-if` first.
3. **No `.pbix`.** Power BI Desktop is Windows-only; the kit (CSV/SQL, M, DAX, theme, guide) was validated by code, not opened in Desktop. A Streamlit page mirrors the report.
4. **Accuracy is measured on our own generated forms** (labelled layouts). The local extractor relies on printed labels; a real client's layouts, handwriting and stamps will score lower. With Azure OpenAI the model handles layout variety; re-measure on real samples.
5. **Synthetic data only.** No real PHI; HIPAA-style safeguards (masking, RBAC, audit, Key Vault) are demonstrated, not certified. Real PHI needs a BAA, a compliance review and a private network design.
6. **Prices are placeholders** and the "hours saved" figure rests on two editable assumptions (6 min manual, 2 min review).
7. **Demo auth** (role picker) has no password; use `AUTH_MODE=entra` with a real app registration for anything shared.
8. **Handwriting and non-English documents** are out of scope. Multi-page documents are read but tested mostly with 1-2 pages.
9. SQLite stands in for Azure SQL / Cosmos; concurrency and scale behave differently (the pipeline runs ~7 docs/s on one laptop core set).
10. A few UI cosmetics (e.g. the sidebar role dropdown is low-contrast) were not polished.
11. **The main dataset is easy.** Clean, labelled forms. The separate hard pack (photos, faxes, low-res scans, boxed forms without colons) shows the real weak spot: scanned boxed forms fall to roughly 20-65% field accuracy with the local reader (`docs/HARD_PACK_REPORT.md`). The review queue catches most of these, but some wrong documents still pass ("silent errors", measured). A layout-aware reader (Document Intelligence) is expected to do much better; it was not measured here.
12. **Ablation variants V5/V6 (Document Intelligence alone / plus Azure OpenAI) were not run**: they need a live account. The harness runs them automatically when Azure is configured.
13. **Packet splitting** relies on page numbers, titles and document numbers. It was measured on our own generated packets (fax covers, blank pages, same-type neighbours, 2-page claims). Packets with no titles, no page numbers and the same document type back to back would be split wrongly. TIFF/PDF only; other image formats are processed whole.
14. **PHI masking is data minimisation, not legal de-identification.** Patient names, all dates, addresses, phones, e-mails and member/group numbers are replaced by placeholders before text reaches Azure OpenAI; provider names, codes and amounts are not. Names that appear only in free text, with no label, are masked only if the same string occurs at a labelled place. Recall was measured on labelled synthetic forms only.
15. **Correction memory** only repairs repeated, identical misreadings of text-like fields. It does not retrain a model; the JSONL export is the first step towards that. The export is masked by default.
16. **Cross-document rules (R027-R029)** compare against documents already processed, so with parallel workers the order decides which of two conflicting documents is flagged. They need identifiers (member ID, NPI) to have been read correctly.
17. **FHIR output** is a faithful mapping, structurally checked against the R4B model, never posted to a FHIR server; drugs, labs and procedures are not coded with RxNorm / LOINC.
