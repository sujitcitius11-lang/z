# Healthcare glossary
**PHI** protected health information. **HIPAA** US privacy law. **NPI** 10-digit provider ID with a Luhn check digit. **ICD-10** diagnosis codes. **CPT** procedure codes.
**Claim** request for payment. **Enrollment** signing up for a health plan. **Referral** a doctor sends a patient to a specialist. **Prescription (Rx)** medicine order; refills = repeat fills.
**Lab report** test results with reference ranges and flags (H high, L low, critical). **Member ID** insurance ID. **Payer / insurer** the plan. **Prior authorization** insurer approval before care.
**SLA** promised response time. **STP** straight-through processing (no human touch). **OCR** reading text from images. **HITL** human in the loop.
