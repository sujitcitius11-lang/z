# Concepts and run guide
**Event-driven**: a new file raises an event; the function reacts. Event Grid delivers at least once, so processing must be **idempotent** (same file twice = one result).
**OCR + confidence**: OCR returns text and a per-word confidence. A field's confidence is the confidence of the words it came from, reduced if the value is not found in the text. Below 0.80 field / 0.85 document goes to a person.
**LLM extraction**: two calls (classify, extract) with a strict JSON schema, temperature 0. The model never decides status.
**Validation**: 26 plain rules (R001-R026), unit-tested. **Routing**: document type + content + status select a workflow, team, priority and deadline.
**Human in the loop**: reviewer sees the image, edits fields, approves/rejects; the system re-validates and audits. **Dead-letter**: items that fail after retries are parked for an operator.
**Security**: secrets in Key Vault, managed identity, Entra app roles (Admin, Operator, Reviewer, Analyst), PHI masked for roles that may not see it, audit log.
**Cost**: Document Intelligence per page + OpenAI per token (placeholder rates in `config.py`).
**Run modes**: local (default) / Azure (fill `.env`, see Azure Services page). `FORCE_LOCAL=1` forces local.
**Entra sign-in**: set `AUTH_MODE=entra` and add an `[auth]` block to `.streamlit/secrets.toml` (client_id, client_secret, redirect_uri, cookie_secret, server_metadata_url); define app roles `Intake.*` and assign users. Not tested live.
**Troubleshooting**: no text from images = Tesseract not installed; `pyodbc` errors = install ODBC Driver 18; empty dashboards = run `run_pipeline.py`.
