# Risks and mitigations
| Risk | Mitigation in this project |
|---|---|
| OCR misreads a scan | image pre-processing; word confidence; low confidence > review; accuracy reported per image quality |
| Model invents a value (hallucination) | strict JSON schema; value must appear in OCR text or confidence is cut and flagged; code validates |
| Wrong data silently accepted | 26 rules; false negatives measured (defect detection) |
| Same file arrives twice (Event Grid is at-least-once) | deterministic doc id + hash duplicate check |
| Azure service outage / throttling | retries with back-off, dead-letter, local fallback engine, reprocess action |
| PHI leaks into logs / dashboards | masking helper everywhere, de-identified Power BI model, role-based unmasking |
| Secrets in code | environment / Key Vault only, `.env` git-ignored, managed identity |
| Cost surprise | cost estimator per batch; use smaller model; cache; real prices to be confirmed |
| Client layouts differ from ours | adapting guide, evaluation script, review queue as safety net |
| Scope creep | traceability matrix, limitations list |
