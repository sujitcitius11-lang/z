# Requirements traceability (brief > where it is met > how it is checked)

| # | Requirement from the brief | Where | Check |
|---|---|---|---|
| 1 | Ingest PDF / image documents | `src/pipeline/events.py`, Upload page, Blob `incoming` (PDF, PNG, JPG, TIF) | `tests/test_pipeline.py` |
| 2 | Event-driven trigger (Blob + Event Grid) | `functions/function_app.py`, `infra/main.bicep`, local event emulator | `test_azure_mock.py`, Pipeline Monitor |
| 3 | OCR | `src/providers/ocr.py` (Document Intelligence prebuilt-layout / local Tesseract) | Evaluation: accuracy by image quality |
| 4 | Extract patient, provider, insurance info | `src/schemas.py`, `src/providers/llm.py`, `heuristic.py` | Evaluation: field accuracy per type/field |
| 5 | Classify the 5 document types | same; unknown type goes to manual triage | 100% on the synthetic set |
| 6 | Validate (formats, dates, codes, totals, lab flags) | `src/validation/rules.py` R001-R026 | `tests/test_validation.py`; defect detection 98.8% |
| 7 | Route to workflows with SLA | `src/routing/router.py`, `logic_app.py`, `logic_apps/routing_workflow.json` | `tests/test_routing_review.py` |
| 8 | Store structured + raw data (SQL + Cosmos) | `src/storage/*`, `sql/schema_azure.sql` | schema sync test |
| 9 | Dashboards (UI) | Streamlit Overview, Monitor, Evaluation | AppTest of all pages |
| 10 | Power BI | `powerbi/*`, `sql/powerbi_views.sql` | export tests (keys, no PHI, KPI parity); no .pbix |
| 11 | 2,500 synthetic documents, 5 types | `src/datagen/*` (500 per type, Faker, optional Azure OpenAI, ReportLab) | `tests/test_datagen.py` |
| 12 | Confidence scores | OCR word confidence grounds each field; doc confidence | calibration table in evaluation |
| 13 | Human in the loop | Review Queue: approve / correct / reject, re-validation, audit | `test_routing_review.py` |
| 14 | Idempotency, duplicates | deterministic `doc_id`, sha256 duplicate check | `test_pipeline.py` |
| 15 | Retries, dead-letter queue | `common.retry`, DeadLetter table, reprocess action | `test_pipeline.py`, `test_azure_mock.py` |
| 16 | Audit log | `src/pipeline/audit.py` (PHI-masked), Audit Log page | tests + UI |
| 17 | Security: Key Vault, Entra ID, RBAC, PHI masking | `src/security/*`, UI role gating | `tests/test_security.py` |
| 18 | Logic Apps notifications | `logic_apps/` + local outbox | dispatch test |
| 19 | DevOps CI/CD | `devops/azure-pipelines.yml` | not run (needs your organisation) |
| 20 | AKS (optional) | `Dockerfile`, `infra/k8s/` | not run |
| 21 | Measured accuracy, cost estimate | `docs/EVALUATION_REPORT.md`, Overview cost tile (placeholder prices) | script |
| 22 | (Hardening) Accuracy harness: precision / recall / F1 per field and type, ablation, threshold sweep | `src/analytics/evaluation.py`, `ablation.py`, `scripts/ablation.py` | `tests/test_new_features.py`; Accuracy page |
| 23 | (Hardening) Messy documents: photos, faxes, low-res, boxed layout, multi-page | `src/datagen/hardpack.py`, `noise.py`, `scripts/run_hardpack.py` | `docs/HARD_PACK_REPORT.md` |
| 24 | (Hardening) Packet splitting | `src/pipeline/splitter.py`, processor `_split_packet` | pipeline test + packet metrics |
| 25 | (Hardening) Review loop that learns | `src/pipeline/feedback.py`, Review > Learning tab | feedback tests |
| 26 | (Hardening) Cross-document validation | rules R027-R029, `SqlStore.identities_for_member` | rule tests |
| 27 | (Hardening) PHI masking before the LLM | `src/security/deid.py`, `scripts/phi_leak_test.py` | fake-OpenAI test, leak test |
| 28 | (Hardening) Monitoring in App Insights | `src/pipeline/telemetry.py`, `docs/MONITORING.md` | local telemetry test |
| 29 | (Hardening) FHIR output | `src/exports/fhir.py`, Explorer > FHIR tab | R4B structural validation test |
