"""Run the ablation study and save data/ablation.json (evaluate.py then adds it to the report).
   python scripts/ablation.py [--n 300]"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from src.analytics.ablation import run  # noqa: E402
from src.datagen.generate import load_answer_key  # noqa: E402

if __name__ == "__main__":
    from src.providers.ocr import require_tesseract_or_skip
    require_tesseract_or_skip('the ablation study')
    n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 300
    res = run(load_answer_key(), n)
    (config.DATA_DIR / "ablation.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    for v in res["variants"]:
        print(f"{v['name']:<52} acc {v['field_accuracy']}%  all-correct {v['doc_exact']}%  review {v['review_rate']}%  silent {v['silent_error_rate']}% ({v['silent_errors']}/{v['auto_passed']})")
