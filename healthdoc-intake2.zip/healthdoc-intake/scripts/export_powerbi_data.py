"""Rebuild the Power BI star-schema CSV files in powerbi/data/ from the database.   python scripts/export_powerbi_data.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.analytics.export_powerbi import export_all  # noqa: E402

for name, n in export_all().items():
    print(f"{name:24s}{n:>8,} rows")
