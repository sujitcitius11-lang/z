"""Generate the synthetic dataset.   python scripts/generate_data.py            -> 2,500 documents
                                    python scripts/generate_data.py --per-type 20   (quick test)"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from src.datagen.generate import generate_all  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--per-type", type=int, default=config.DOCS_PER_TYPE)
ap.add_argument("--seed", type=int, default=config.DATASET_SEED)
ap.add_argument("--out", default=str(config.SYNTH_DIR))
ap.add_argument("--no-azure-narrative", action="store_true", help="never call Azure OpenAI for narrative text")
a = ap.parse_args()
m = generate_all(Path(a.out), a.per_type, a.seed, use_azure_narrative=not a.no_azure_narrative,
                 progress=lambda d, t, s: print(f"\r{d}/{t} {s}      ", end="", flush=True))
print()
for k, v in m.items():
    print(f"{k}: {v}")
