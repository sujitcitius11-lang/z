"""Push the synthetic documents through the pipeline (upload -> Event Grid -> process).
   python scripts/run_pipeline.py                 all documents
   python scripts/run_pipeline.py --limit 50      first 50 per type
   python scripts/run_pipeline.py --reset         wipe DB + blobs first
   python scripts/run_pipeline.py --edge          also push the edge-case pack (fax cover sheets, blank pages, corrupt PDFs)"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from src.pipeline.batch import run_batch  # noqa: E402
from src.pipeline.operations import reset_all  # noqa: E402

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0, help="documents per type (0 = all)")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--edge", action="store_true")
    ap.add_argument("--src", default=str(config.SYNTH_DIR))
    a = ap.parse_args()

    src = Path(a.src)
    key = json.loads((src / "answer_key.json").read_text(encoding="utf-8"))
    if a.reset:
        reset_all()
    files, received = [], {}
    counts: dict = {}
    for e in key:
        counts[e["doc_type"]] = counts.get(e["doc_type"], 0) + 1
        if a.limit and counts[e["doc_type"]] > a.limit:
            continue
        files.append(src / "documents" / e["doc_type"] / e["file"])
        received[e["file"]] = e["meta"]["received_at"]
    if a.edge:
        for f in sorted((src / "edge_cases").glob("*.pdf")):
            files.append(f)
    print(f"processing {len(files)} documents with {a.workers} workers ...")
    res = run_batch(files, received, a.workers, progress=lambda d, t: print(f"\r{d}/{t}", end="", flush=True))
    print("\n", res["seconds"], "s;", len(res["errors"]), "ingest errors")
    for e in res["errors"][:10]:
        print(e)


if __name__ == "__main__":
    main()
