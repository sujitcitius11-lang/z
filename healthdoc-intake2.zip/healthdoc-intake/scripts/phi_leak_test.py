"""How well does the PHI masker work?  For a sample of synthetic documents, run the real OCR text through deid.pseudonymise and count how many of the
KNOWN patient identifiers (from the answer key) still appear in the masked text.   python scripts/phi_leak_test.py [--n 300]
Writes data/phi_masking.json"""
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from src.datagen.generate import load_answer_key  # noqa: E402
from src.providers.ocr import get_ocr  # noqa: E402
from src.security import deid  # noqa: E402
from src import reference_data  # noqa: E402,F401

PHI = ["patient_name", "dob", "address", "phone", "email", "member_id", "group_number"]


def fmt_variants(field, v):
    return [str(v)]


def main():
    from src.providers.ocr import require_tesseract_or_skip
    require_tesseract_or_skip('the PHI leak test')
    n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 300
    key = load_answer_key()
    rng = random.Random(5)
    files = rng.sample([k for k, v in key.items() if "duplicate_exact" not in v["meta"]["defects"]], n)
    ocr = get_ocr()
    tot, leaks, docs_leaking, per = 0, 0, 0, defaultdict(lambda: [0, 0])
    by_fmt = defaultdict(lambda: [0, 0])
    examples = []
    for f in files:
        a = key[f]
        p = config.SYNTH_DIR / "documents" / a["doc_type"] / f
        r = ocr.analyze(p.read_bytes(), f)
        masked, mp = deid.pseudonymise(r.text, a["doc_type"])
        any_leak = False
        for fld in PHI:
            v = a["fields"].get(fld)
            if not v:
                continue
            # dates are printed in many styles, so check the ISO value AND every printed style the generator may have used
            if fld == "dob":
                from datetime import date
                from src import common
                d = date.fromisoformat(v)
                cands = [common.format_date(d, s) for s in ("us", "iso", "long", "short", "dmy")]
            else:
                cands = [str(v)]
            printed = [c for c in cands if c.lower() in r.text.lower().replace("\n", " ")]
            if not printed:
                continue                     # OCR did not even read it: nothing to leak
            tot += 1
            per[fld][1] += 1
            by_fmt[a["meta"]["format"]][1] += 1
            leak = deid.leaked(masked, printed)
            if leak:
                leaks += 1
                per[fld][0] += 1
                by_fmt[a["meta"]["format"]][0] += 1
                any_leak = True
                if len(examples) < 8:
                    examples.append({"file": f, "field": fld, "format": a["meta"]["format"]})
        docs_leaking += int(any_leak)
    pct = lambda a, b: round(100 * a / b, 2) if b else None
    out = {"documents": n, "phi_values_checked": tot, "leaked": leaks, "leak_rate": pct(leaks, tot), "recall": pct(tot - leaks, tot),
           "documents_with_any_leak": docs_leaking, "by_field": {k: {"leaked": v[0], "checked": v[1], "recall": pct(v[1] - v[0], v[1])} for k, v in per.items()},
           "by_format": {k: {"leaked": v[0], "checked": v[1], "recall": pct(v[1] - v[0], v[1])} for k, v in by_fmt.items()}, "examples": examples}
    (config.DATA_DIR / "phi_masking.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print(json.dumps({k: v for k, v in out.items() if k != "examples"}, indent=1))


if __name__ == "__main__":
    main()
