// All CSV queries for the Document Intake model. In Power BI Desktop: Home > Transform data > New Source > Blank Query,
// Advanced Editor, paste ONE section per query and name the query exactly as in the heading.

// ====================  Query name: FactDocuments  ====================
// FactDocuments: loads FactDocuments.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactDocuments.csv"), [Delimiter = ",", Columns = 30, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"date_key", Int64.Type},
        {"doc_type_key", type text},
        {"workflow_id", type text},
        {"status", type text},
        {"file_format", type text},
        {"patient_key", type text},
        {"provider_npi", type text},
        {"insurer", type text},
        {"is_scanned", type number},
        {"page_count", type number},
        {"ocr_confidence", type number},
        {"doc_confidence", type number},
        {"type_confidence", type number},
        {"processing_ms", Int64.Type},
        {"processing_seconds", type number},
        {"issue_count", Int64.Type},
        {"error_count", Int64.Type},
        {"warning_count", Int64.Type},
        {"billed_amount", type number},
        {"est_cost_usd", type number},
        {"sla_hours", Int64.Type},
        {"sla_due_at", type datetime},
        {"received_at", type datetime},
        {"processed_at", type datetime},
        {"auto_processed", Int64.Type},
        {"sent_to_review", Int64.Type},
        {"fallback_used", type number},
        {"duplicate_of", type text},
        {"workflow_status", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: FactValidationIssues  ====================
// FactValidationIssues: loads FactValidationIssues.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactValidationIssues.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"issue_id", Int64.Type},
        {"doc_id", type text},
        {"rule_id", type text},
        {"severity", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"date_key", Int64.Type}
    }, "en-US")
in
    Typed


// ====================  Query name: FactStageTimings  ====================
// FactStageTimings: loads FactStageTimings.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactStageTimings.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"stage", type text},
        {"ms", Int64.Type}
    }, "en-US")
in
    Typed


// ====================  Query name: FactWorkflowActions  ====================
// FactWorkflowActions: loads FactWorkflowActions.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactWorkflowActions.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"action_id", type text},
        {"doc_id", type text},
        {"workflow_id", type text},
        {"action_type", type text},
        {"channel", type text},
        {"status", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: FactFieldConfidence  ====================
// FactFieldConfidence: loads FactFieldConfidence.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactFieldConfidence.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"field_name", type text},
        {"confidence", type number},
        {"has_value", Int64.Type},
        {"was_corrected", Int64.Type},
        {"doc_type_key", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: FactFieldAccuracy  ====================
// FactFieldAccuracy: loads FactFieldAccuracy.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactFieldAccuracy.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"correct", Int64.Type},
        {"confidence", type number},
        {"source_format", type text},
        {"noise_band", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: DimDate  ====================
// DimDate: loads DimDate.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimDate.csv"), [Delimiter = ",", Columns = 9, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"date_key", Int64.Type},
        {"date", type date},
        {"year", Int64.Type},
        {"month_number", Int64.Type},
        {"month", type text},
        {"year_month", type text},
        {"quarter", type text},
        {"weekday", type text},
        {"is_weekend", Int64.Type}
    }, "en-US")
in
    Typed


// ====================  Query name: DimDocType  ====================
// DimDocType: loads DimDocType.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimDocType.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_type_key", type text},
        {"doc_type", type text},
        {"sort_order", Int64.Type}
    }, "en-US")
in
    Typed


// ====================  Query name: DimWorkflow  ====================
// DimWorkflow: loads DimWorkflow.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimWorkflow.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"workflow_id", type text},
        {"workflow_name", type text},
        {"team", type text},
        {"sla_target_hours", Int64.Type},
        {"priority", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: DimStatus  ====================
// DimStatus: loads DimStatus.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimStatus.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"status", type text},
        {"is_final", Int64.Type},
        {"sort_order", Int64.Type},
        {"group", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: DimProvider  ====================
// DimProvider: loads DimProvider.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimProvider.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"provider_npi", type text},
        {"provider_name", type text},
        {"npi_check_digit_ok", Int64.Type}
    }, "en-US")
in
    Typed


// ====================  Query name: DimInsurer  ====================
// DimInsurer: loads DimInsurer.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimInsurer.csv"), [Delimiter = ",", Columns = 1, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"insurer", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: DimRule  ====================
// DimRule: loads DimRule.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimRule.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"rule_id", type text},
        {"severity", type text},
        {"description", type text}
    }, "en-US")
in
    Typed


// ====================  Query name: DimFileFormat  ====================
// DimFileFormat: loads DimFileFormat.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimFileFormat.csv"), [Delimiter = ",", Columns = 1, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"file_format", type text}
    }, "en-US")
in
    Typed

