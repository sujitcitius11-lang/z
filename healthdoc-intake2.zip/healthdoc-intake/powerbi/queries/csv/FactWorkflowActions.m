// FactWorkflowActions: loads FactWorkflowActions.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactWorkflowActions.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"action_id", type text},
        {"doc_id", type text},
        {"workflow_id", type text},
        {"action_type", type text},
        {"channel", type text},
        {"status", type text}
    }, "en-US")
in
    Typed
