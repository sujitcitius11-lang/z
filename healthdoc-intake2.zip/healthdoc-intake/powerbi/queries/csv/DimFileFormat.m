// DimFileFormat: loads DimFileFormat.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimFileFormat.csv"), [Delimiter = ",", Columns = 1, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"file_format", type text}
    }, "en-US")
in
    Typed
