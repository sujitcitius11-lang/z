// FactFieldConfidence: loads FactFieldConfidence.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactFieldConfidence.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"field_name", type text},
        {"confidence", type number},
        {"has_value", Int64.Type},
        {"was_corrected", Int64.Type},
        {"doc_type_key", type text}
    }, "en-US")
in
    Typed
