// DimDate: loads DimDate.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimDate.csv"), [Delimiter = ",", Columns = 9, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"date_key", Int64.Type},
        {"date", type date},
        {"year", Int64.Type},
        {"month_number", Int64.Type},
        {"month", type text},
        {"year_month", type text},
        {"quarter", type text},
        {"weekday", type text},
        {"is_weekend", Int64.Type}
    }, "en-US")
in
    Typed
