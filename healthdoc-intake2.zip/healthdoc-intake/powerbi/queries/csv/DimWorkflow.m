// DimWorkflow: loads DimWorkflow.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimWorkflow.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"workflow_id", type text},
        {"workflow_name", type text},
        {"team", type text},
        {"sla_target_hours", Int64.Type},
        {"priority", type text}
    }, "en-US")
in
    Typed
