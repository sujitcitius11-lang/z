// FactValidationIssues: loads FactValidationIssues.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactValidationIssues.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"issue_id", Int64.Type},
        {"doc_id", type text},
        {"rule_id", type text},
        {"severity", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"date_key", Int64.Type}
    }, "en-US")
in
    Typed
