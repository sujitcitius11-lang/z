// DimProvider: loads DimProvider.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimProvider.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"provider_npi", type text},
        {"provider_name", type text},
        {"npi_check_digit_ok", Int64.Type}
    }, "en-US")
in
    Typed
