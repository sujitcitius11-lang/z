// FactFieldAccuracy: loads FactFieldAccuracy.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactFieldAccuracy.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"correct", Int64.Type},
        {"confidence", type number},
        {"source_format", type text},
        {"noise_band", type text}
    }, "en-US")
in
    Typed
