// FactDocuments: loads FactDocuments.csv from the folder held in the DataFolder parameter (Text, e.g. C:\docintake\powerbi\data\)
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactDocuments.csv"), [Delimiter = ",", Columns = 30, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
        {"doc_id", type text},
        {"date_key", Int64.Type},
        {"doc_type_key", type text},
        {"workflow_id", type text},
        {"status", type text},
        {"file_format", type text},
        {"patient_key", type text},
        {"provider_npi", type text},
        {"insurer", type text},
        {"is_scanned", type number},
        {"page_count", type number},
        {"ocr_confidence", type number},
        {"doc_confidence", type number},
        {"type_confidence", type number},
        {"processing_ms", Int64.Type},
        {"processing_seconds", type number},
        {"issue_count", Int64.Type},
        {"error_count", Int64.Type},
        {"warning_count", Int64.Type},
        {"billed_amount", type number},
        {"est_cost_usd", type number},
        {"sla_hours", Int64.Type},
        {"sla_due_at", type datetime},
        {"received_at", type datetime},
        {"processed_at", type datetime},
        {"auto_processed", Int64.Type},
        {"sent_to_review", Int64.Type},
        {"fallback_used", type number},
        {"duplicate_of", type text},
        {"workflow_status", type text}
    }, "en-US")
in
    Typed
