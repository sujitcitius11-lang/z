// All SQL queries for the Document Intake model. In Power BI Desktop: Home > Transform data > New Source > Blank Query,
// Advanced Editor, paste ONE section per query and name the query exactly as in the heading.

// ====================  Query name: FactDocuments  ====================
// FactDocuments: reads the de-identified view dbo.vw_FactDocuments from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactDocuments"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"date_key", Int64.Type},
        {"doc_type_key", type text},
        {"workflow_id", type text},
        {"status", type text},
        {"file_format", type text},
        {"patient_key", type text},
        {"provider_npi", type text},
        {"insurer", type text},
        {"is_scanned", type number},
        {"page_count", type number},
        {"ocr_confidence", type number},
        {"doc_confidence", type number},
        {"type_confidence", type number},
        {"processing_ms", Int64.Type},
        {"processing_seconds", type number},
        {"issue_count", Int64.Type},
        {"error_count", Int64.Type},
        {"warning_count", Int64.Type},
        {"billed_amount", type number},
        {"est_cost_usd", type number},
        {"sla_hours", Int64.Type},
        {"sla_due_at", type datetime},
        {"received_at", type datetime},
        {"processed_at", type datetime},
        {"auto_processed", Int64.Type},
        {"sent_to_review", Int64.Type},
        {"fallback_used", type number},
        {"duplicate_of", type text},
        {"workflow_status", type text}
    })
in
    Typed


// ====================  Query name: FactValidationIssues  ====================
// FactValidationIssues: reads the de-identified view dbo.vw_FactValidationIssues from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactValidationIssues"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"issue_id", Int64.Type},
        {"doc_id", type text},
        {"rule_id", type text},
        {"severity", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"date_key", Int64.Type}
    })
in
    Typed


// ====================  Query name: FactStageTimings  ====================
// FactStageTimings: reads the de-identified view dbo.vw_FactStageTimings from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactStageTimings"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"stage", type text},
        {"ms", Int64.Type}
    })
in
    Typed


// ====================  Query name: FactWorkflowActions  ====================
// FactWorkflowActions: reads the de-identified view dbo.vw_FactWorkflowActions from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactWorkflowActions"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"action_id", type text},
        {"doc_id", type text},
        {"workflow_id", type text},
        {"action_type", type text},
        {"channel", type text},
        {"status", type text}
    })
in
    Typed


// ====================  Query name: FactFieldConfidence  ====================
// FactFieldConfidence: reads the de-identified view dbo.vw_FactFieldConfidence from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactFieldConfidence"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"field_name", type text},
        {"confidence", type number},
        {"has_value", Int64.Type},
        {"was_corrected", Int64.Type},
        {"doc_type_key", type text}
    })
in
    Typed


// ====================  Query name: DimDate  ====================
// DimDate: reads the de-identified view dbo.vw_DimDate from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimDate"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"date_key", Int64.Type},
        {"date", type date},
        {"year", Int64.Type},
        {"month_number", Int64.Type},
        {"month", type text},
        {"year_month", type text},
        {"quarter", type text},
        {"weekday", type text},
        {"is_weekend", Int64.Type}
    })
in
    Typed


// ====================  Query name: DimDocType  ====================
// DimDocType: reads the de-identified view dbo.vw_DimDocType from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimDocType"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_type_key", type text},
        {"doc_type", type text},
        {"sort_order", Int64.Type}
    })
in
    Typed


// ====================  Query name: DimWorkflow  ====================
// DimWorkflow: reads the de-identified view dbo.vw_DimWorkflow from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimWorkflow"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"workflow_id", type text},
        {"workflow_name", type text},
        {"team", type text},
        {"sla_target_hours", Int64.Type},
        {"priority", type text}
    })
in
    Typed


// ====================  Query name: DimStatus  ====================
// DimStatus: reads the de-identified view dbo.vw_DimStatus from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimStatus"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"status", type text},
        {"is_final", Int64.Type},
        {"sort_order", Int64.Type},
        {"group", type text}
    })
in
    Typed


// ====================  Query name: DimProvider  ====================
// DimProvider: reads the de-identified view dbo.vw_DimProvider from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimProvider"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"provider_npi", type text},
        {"provider_name", type text},
        {"npi_check_digit_ok", Int64.Type}
    })
in
    Typed


// ====================  Query name: DimInsurer  ====================
// DimInsurer: reads the de-identified view dbo.vw_DimInsurer from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimInsurer"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"insurer", type text}
    })
in
    Typed


// ====================  Query name: DimRule  ====================
// DimRule: reads the de-identified view dbo.vw_DimRule from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimRule"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"rule_id", type text},
        {"severity", type text},
        {"description", type text}
    })
in
    Typed


// ====================  Query name: DimFileFormat  ====================
// DimFileFormat: reads the de-identified view dbo.vw_DimFileFormat from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimFileFormat"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"file_format", type text}
    })
in
    Typed

