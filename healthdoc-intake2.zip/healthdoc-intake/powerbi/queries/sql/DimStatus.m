// DimStatus: reads the de-identified view dbo.vw_DimStatus from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimStatus"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"status", type text},
        {"is_final", Int64.Type},
        {"sort_order", Int64.Type},
        {"group", type text}
    })
in
    Typed
