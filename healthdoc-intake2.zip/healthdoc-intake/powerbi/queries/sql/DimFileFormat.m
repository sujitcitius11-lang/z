// DimFileFormat: reads the de-identified view dbo.vw_DimFileFormat from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimFileFormat"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"file_format", type text}
    })
in
    Typed
