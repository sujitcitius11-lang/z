// FactWorkflowActions: reads the de-identified view dbo.vw_FactWorkflowActions from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactWorkflowActions"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"action_id", type text},
        {"doc_id", type text},
        {"workflow_id", type text},
        {"action_type", type text},
        {"channel", type text},
        {"status", type text}
    })
in
    Typed
