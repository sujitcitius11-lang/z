// FactDocuments: reads the de-identified view dbo.vw_FactDocuments from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactDocuments"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"date_key", Int64.Type},
        {"doc_type_key", type text},
        {"workflow_id", type text},
        {"status", type text},
        {"file_format", type text},
        {"patient_key", type text},
        {"provider_npi", type text},
        {"insurer", type text},
        {"is_scanned", type number},
        {"page_count", type number},
        {"ocr_confidence", type number},
        {"doc_confidence", type number},
        {"type_confidence", type number},
        {"processing_ms", Int64.Type},
        {"processing_seconds", type number},
        {"issue_count", Int64.Type},
        {"error_count", Int64.Type},
        {"warning_count", Int64.Type},
        {"billed_amount", type number},
        {"est_cost_usd", type number},
        {"sla_hours", Int64.Type},
        {"sla_due_at", type datetime},
        {"received_at", type datetime},
        {"processed_at", type datetime},
        {"auto_processed", Int64.Type},
        {"sent_to_review", Int64.Type},
        {"fallback_used", type number},
        {"duplicate_of", type text},
        {"workflow_status", type text}
    })
in
    Typed
