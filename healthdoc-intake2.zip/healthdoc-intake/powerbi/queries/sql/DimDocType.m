// DimDocType: reads the de-identified view dbo.vw_DimDocType from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimDocType"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_type_key", type text},
        {"doc_type", type text},
        {"sort_order", Int64.Type}
    })
in
    Typed
