// DimDate: reads the de-identified view dbo.vw_DimDate from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimDate"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"date_key", Int64.Type},
        {"date", type date},
        {"year", Int64.Type},
        {"month_number", Int64.Type},
        {"month", type text},
        {"year_month", type text},
        {"quarter", type text},
        {"weekday", type text},
        {"is_weekend", Int64.Type}
    })
in
    Typed
