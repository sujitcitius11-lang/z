// DimInsurer: reads the de-identified view dbo.vw_DimInsurer from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimInsurer"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"insurer", type text}
    })
in
    Typed
