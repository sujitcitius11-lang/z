// FactFieldConfidence: reads the de-identified view dbo.vw_FactFieldConfidence from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactFieldConfidence"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"field_name", type text},
        {"confidence", type number},
        {"has_value", Int64.Type},
        {"was_corrected", Int64.Type},
        {"doc_type_key", type text}
    })
in
    Typed
