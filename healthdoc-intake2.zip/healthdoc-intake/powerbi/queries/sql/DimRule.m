// DimRule: reads the de-identified view dbo.vw_DimRule from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimRule"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"rule_id", type text},
        {"severity", type text},
        {"description", type text}
    })
in
    Typed
