// FactValidationIssues: reads the de-identified view dbo.vw_FactValidationIssues from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactValidationIssues"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"issue_id", Int64.Type},
        {"doc_id", type text},
        {"rule_id", type text},
        {"severity", type text},
        {"field_name", type text},
        {"doc_type_key", type text},
        {"date_key", Int64.Type}
    })
in
    Typed
