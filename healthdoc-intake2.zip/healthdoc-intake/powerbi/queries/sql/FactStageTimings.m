// FactStageTimings: reads the de-identified view dbo.vw_FactStageTimings from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_FactStageTimings"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"doc_id", type text},
        {"stage", type text},
        {"ms", Int64.Type}
    })
in
    Typed
