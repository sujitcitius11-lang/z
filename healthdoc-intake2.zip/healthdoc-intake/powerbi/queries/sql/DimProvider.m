// DimProvider: reads the de-identified view dbo.vw_DimProvider from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimProvider"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"provider_npi", type text},
        {"provider_name", type text},
        {"npi_check_digit_ok", Int64.Type}
    })
in
    Typed
