// DimWorkflow: reads the de-identified view dbo.vw_DimWorkflow from Azure SQL (parameters SqlServer and SqlDatabase, Text)
let
    Source = Sql.Database(SqlServer, SqlDatabase),
    View   = Source{[Schema = "dbo", Item = "vw_DimWorkflow"]}[Data],
    Typed  = Table.TransformColumnTypes(View, {
        {"workflow_id", type text},
        {"workflow_name", type text},
        {"team", type text},
        {"sla_target_hours", Int64.Type},
        {"priority", type text}
    })
in
    Typed
