# Power BI report: build guide (about 45 minutes)

**Honest status.** The model files (CSV or Azure SQL views), Power Query (M), DAX measures and the theme in this folder were generated
and checked with code (row counts, keys, no-PHI, KPI parity with the app). They were **not opened in Power BI Desktop** because Desktop is
a Windows program that is not available where this project was built, so there is no `.pbix` file. Follow this guide once; Desktop does the rest.
If a DAX line shows a red underline, fix the table or column name (they come from `powerbi/data/schema.json`).

## 0. What you need
Power BI Desktop (free, Windows). A copy of this project folder. Optional: a Power BI Pro / Premium-per-user licence to publish and share.

## 1. Load the data (choose ONE route)

### Route A: CSV files (laptop demo, 5 minutes)
1. Run `python scripts/export_powerbi_data.py` (or press **Rebuild the CSV files** on the app's *Power BI* page). Files appear in `powerbi/data/`.
2. Power BI Desktop > **Home > Transform data**. In Power Query: **Manage parameters > New parameter**: name `DataFolder`, type *Text*,
   current value = full path **ending in a backslash**, e.g. `C:\docintake\powerbi\data\`.
3. **New Source > Blank query > Advanced editor.** Open `powerbi/queries/all_queries_csv.m`. For each section (`Query name: ...`) paste the code and rename the query to
   exactly that name. (Or paste each file from `powerbi/queries/csv/`.) There are 14 queries.
4. **Close & Apply.** Types are already set (dates, whole numbers, decimals).

### Route B: Azure SQL (the real deployment)
1. Run `sql/powerbi_views.sql` once on the database (it creates `vw_*` views that contain **no patient name, DOB, member ID, address, phone or e-mail**).
2. Grant Power BI users `db_datareader` on those views only.
3. Power Query parameters `SqlServer` (e.g. `myserver.database.windows.net`) and `SqlDatabase`. Paste `powerbi/queries/all_queries_sql.m` the same way.
4. Choose **Import** (default; refresh on a schedule) or **DirectQuery** (live; slower visuals). For millions of rows enable incremental refresh on
   `received_at` (RangeStart / RangeEnd parameters, store 2 years, refresh 3 days).
   `FactFieldAccuracy` exists only as a CSV (it needs the synthetic answer key): load it from Route A even in Route B, or skip page 4.

## 2. Model (Model view)
Mark **DimDate** as the date table (*Table tools > Mark as date table > `date`*). Create these relationships
(*many* side is the table named first; *single* direction, filter flows from the one side). Desktop usually auto-detects them; check each.

| Many side (Fact) | Column | One side (Dimension) | Column |
|---|---|---|---|
| FactDocuments | date_key | DimDate | date_key |
| FactDocuments | doc_type_key | DimDocType | doc_type_key |
| FactDocuments | workflow_id | DimWorkflow | workflow_id |
| FactDocuments | status | DimStatus | status |
| FactDocuments | provider_npi | DimProvider | provider_npi |
| FactDocuments | insurer | DimInsurer | insurer |
| FactDocuments | file_format | DimFileFormat | file_format |
| FactValidationIssues | doc_id | FactDocuments | doc_id |
| FactValidationIssues | rule_id | DimRule | rule_id |
| FactStageTimings, FactWorkflowActions, FactFieldConfidence, FactFieldAccuracy | doc_id | FactDocuments | doc_id |

(The last row is five relationships. `powerbi/data/schema.json` lists all 13 exactly.) Sort **DimDate[month]** by `month_number`, **DimDocType[doc_type]** by `sort_order`, **DimStatus[status]** by `sort_order`.
Hide the key columns from Report view. Format: `doc_confidence`, `ocr_confidence`, `confidence` as 0.00; `billed_amount`, `est_cost_usd` as currency.

## 3. Measures
Create a measure table (*Home > Enter data*, name `_Measures`, delete the dummy column) or use FactDocuments as the home table. Paste each measure from
`powerbi/measures.dax` (**New measure**, one at a time). Set formats: rates and shares *Percentage 1 decimal*; seconds *0.00*; hours *#,0.0*; cost *$#,0.00*.
Optional: replace the two constants `Manual Minutes Per Doc` and `Review Minutes Per Doc` with **What-if parameters** so a manager can try other assumptions live.

## 4. Theme
*View > Themes > Browse for themes* > `powerbi/theme.json`.

## 5. Pages and visuals
Canvas 16:9, page background from the theme. Every page: title text box, a one-line subtitle (`[KPI Subtitle]` on page 1), and slicers **Date range** (DimDate[date], between), **Document type** (DimDocType[doc_type], tile slicer).

### Page 1: Executive overview
| Visual | Fields |
|---|---|
| Card x5 | `[Total Documents]`, `[STP Rate]`, `[Review Rate]`, `[Avg Processing Seconds]`, `[Hours Saved]` (conditional colour: STP Rate green >= 80 %, amber 60 to 80, red below) |
| Stacked column | X: DimDate[year_month]; Y: `[Total Documents]`; Legend: DimDocType[doc_type] (monthly volume) |
| Donut | Legend: DimStatus[status]; Values: `[Total Documents]` (colours: PASSED teal, NEEDS_REVIEW amber, FAILED red, DUPLICATE grey) |
| Line | X: DimDate[year_month]; Y: `[STP Rate]` (trend) |
| Table | DimWorkflow[workflow_name], `[Total Documents]`, `[Avg Processing Seconds]` with data bars |
Tooltip page: card `[MoM Growth]` + `[Documents Prior Month]`. Bookmark "Last 90 days" = date slicer preset.

### Page 2: Operations and SLA
| Visual | Fields |
|---|---|
| Card | `[Open SLA Breaches]` (red if > 0), `[Failed Documents]`, `[Sent To Review]` |
| Clustered bar | Axis: DimWorkflow[team]; Values: `[Total Documents]`; Legend: DimWorkflow[priority] |
| Column | Axis: FactStageTimings[stage]; Values: `[Avg Stage ms]` (where is time spent?) |
| Matrix | Rows: DimWorkflow[workflow_name]; Columns: DimStatus[status]; Values: `[Total Documents]`; background colour scale |
| Table | FactWorkflowActions[channel], action_type, count of rows (what the Logic App did) |
Drill-through page "Workflow detail": drill-through field DimWorkflow[workflow_name]; shows documents by type and the issue list.

### Page 3: Quality and validation
| Visual | Fields |
|---|---|
| Card | `[Validation Issues]`, `[Validation Errors]`, `[Issues per Document]`, `[Low Confidence Field Share]` |
| Bar (top 10) | Axis: DimRule[description]; Values: `[Validation Issues]`; Legend: DimRule[severity]; Top N filter 10 by value |
| Column | Axis: FactValidationIssues[field_name]; Values: `[Validation Issues]` |
| Heat matrix | Rows: DimDocType[doc_type]; Columns: DimRule[rule_id]; Values: `[Validation Issues]` |
| Scatter | X: FactDocuments[ocr_confidence]; Y: FactDocuments[error_count]; Legend: FactDocuments[file_format] (do bad scans make errors?) |
Slicer: DimRule[severity].

### Page 4: Accuracy and model performance (synthetic data only)
| Visual | Fields |
|---|---|
| Card | `[Field Accuracy]`, `[High Confidence Accuracy]`, `[Fields Evaluated]` |
| Column | Axis: FactFieldAccuracy[noise_band] (sort digital, light, medium, heavy); Values: `[Field Accuracy]` |
| Bar | Axis: FactFieldAccuracy[field_name]; Values: `[Field Accuracy]`; sorted ascending, Top N 15 (the weakest fields) |
| Line | X: FactFieldAccuracy[confidence] binned (Group by 0.1); Y: `[Field Accuracy]` (calibration: should rise left to right) |
Add a text box "Measured against the generator's answer key; real documents will differ."

## 6. Publish and share
*Home > Publish* to a workspace. In the service: dataset **Settings > Scheduled refresh** (Route A needs a gateway with a file path; Route B uses an Azure SQL credential,
preferably a service principal or the organisation account). Share the report or build an app. **Row-level security** idea: roles per team
(`DimWorkflow[team] = "Claims Processing"`), then *Manage roles*; add members in the service. Never publish the base tables or any data with patient identifiers.

## 7. Embed in the Streamlit app
Publish > in the service **File > Embed report > Website or portal**, copy the link into `.env` as `POWERBI_EMBED_URL=...`. The app's *Power BI* page shows it in an iframe.

## Acceptance checklist
- [ ] 14 tables load without errors; 13 relationships present; DimDate is the date table
- [ ] `Total Documents` equals the row count shown on the app's Overview page
- [ ] `STP Rate`, `Review Rate`, `Avg Processing Seconds` match the app's Overview tiles (to rounding)
- [ ] No column in the model contains a patient name, date of birth, member ID, address, phone or e-mail
