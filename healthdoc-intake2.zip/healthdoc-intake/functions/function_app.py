"""Azure Functions (Python v2 programming model): the thin Azure front door of the pipeline.

All business logic lives in ../src (shared with the laptop version). These functions only translate an Azure trigger
into a call:
    process_document  Event Grid  (Microsoft.Storage.BlobCreated on container `incoming`)  -> DocumentProcessor.handle_event
    health            HTTP GET    /api/health                                                  -> config.service_modes + connectivity
    reprocess         HTTP POST   /api/reprocess/{dl_id}  (function key)                       -> operations.retry_dead_letter
    sla_watch         Timer       every 15 minutes                                              -> SLA breach actions via Logic App

Packaging: the deployment package root must contain function_app.py, host.json, requirements.txt AND the folders `src/`
and the file `config.py`. `devops/azure-pipelines.yml` copies them next to function_app.py (see functions/README.md).
When run from the repository (local `func start`) the project root is added to sys.path below.
"""
from __future__ import annotations

import json
import logging
import sys
import uuid
from pathlib import Path

import azure.functions as func

_HERE = Path(__file__).resolve().parent
for _p in (_HERE, _HERE.parent):                    # packaged: ./src ; repository: ../src
    if (_p / "src").is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)
log = logging.getLogger("docintake.functions")


# ---------------------------------------------------------------------------------------------- plain python helpers
# (kept separate from the decorators so unit tests can call them without the Functions host)

def handle_blob_created(event: dict) -> dict:
    """Process one BlobCreated event. Raises on failure so Event Grid retries (then dead-letters to the `deadletter` blob container).
    Idempotent: DocumentProcessor ignores a re-delivered event for a document it has already processed."""
    from src.pipeline.processor import DocumentProcessor
    cid = event.get("id") or str(uuid.uuid4())
    log.info("event received id=%s subject=%s", cid, event.get("subject"))
    result = DocumentProcessor().handle_event(event)
    log.info("event done id=%s status=%s doc=%s", cid, result.get("status"), result.get("doc_id"))
    if result.get("status") == "FAILED" and result.get("transient"):
        raise RuntimeError(f"transient failure for {event.get('subject')}: {result.get('reason')}")
    return result


def health_report() -> dict:
    """Which service is in which mode, plus a cheap connectivity probe for each service that is in Azure mode."""
    import config
    modes = config.service_modes()
    checks: dict[str, str] = {}
    probes = {
        "sql": lambda: __import__("src.storage.sql_store", fromlist=["get_sql"]).get_sql().scalar("SELECT 1 AS ok"),
        "blob": lambda: __import__("src.storage.blob_store", fromlist=["get_blob"]).get_blob().count("incoming"),
        "cosmos": lambda: __import__("src.storage.cosmos_store", fromlist=["get_cosmos"]).get_cosmos().count(),
    }
    for name, probe in probes.items():
        try:
            probe()
            checks[name] = "ok"
        except Exception as exc:                    # never leak secrets: only the exception type
            checks[name] = f"error: {type(exc).__name__}"
    for name in ("doc_intelligence", "openai", "logic_apps", "key_vault"):
        checks[name] = "configured" if modes.get(name) == "azure" else "local fallback"
    healthy = all(v in ("ok", "configured", "local fallback") for v in checks.values())
    return {"status": "healthy" if healthy else "degraded", "modes": modes, "checks": checks}


def reprocess_dead_letter(dl_id: str) -> dict:
    from src.pipeline.operations import retry_dead_letter
    return retry_dead_letter(dl_id, actor="function:reprocess")


def sla_breaches(as_of: str | None = None) -> list[dict]:
    """Open work items whose SLA clock has run out; dispatch a breach notification once per item."""
    from src import common
    from src.routing import logic_app
    from src.storage.sql_store import get_sql
    sql = get_sql()
    now = as_of or common.iso_now()
    rows = sql.query("SELECT r.doc_id, r.workflow_id, r.workflow_name, r.team, r.priority, r.sla_due_at, r.reason FROM Routing r "
                     "WHERE r.status='open' AND r.sla_due_at < ?", [now])
    done = {r["doc_id"] for r in sql.query("SELECT doc_id FROM WorkflowActions WHERE action_type='sla_breach_alert'")}
    sent = []
    for r in rows:
        if r["doc_id"] in done:
            continue
        route = {"workflow_id": r["workflow_id"], "workflow_name": r["workflow_name"], "team": r["team"], "priority": "Critical",
                 "sla_due_at": r["sla_due_at"], "reason": f"SLA breached (due {r['sla_due_at']})", "actions": ["sla_breach_alert"]}
        logic_app.dispatch(r["doc_id"], route, {"status": "SLA_BREACH", "workflow": r["workflow_id"]}, sql)
        sent.append(r)
    return sent


# ---------------------------------------------------------------------------------------------- triggers
@app.function_name("process_document")
@app.event_grid_trigger(arg_name="event")
def process_document(event: func.EventGridEvent) -> None:
    handle_blob_created({"id": event.id, "subject": event.subject, "eventType": event.event_type,
                         "eventTime": event.event_time.isoformat() if event.event_time else None, "data": event.get_json()})


@app.function_name("health")
@app.route(route="health", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def health(req: func.HttpRequest) -> func.HttpResponse:
    rep = health_report()
    return func.HttpResponse(json.dumps(rep), mimetype="application/json", status_code=200 if rep["status"] == "healthy" else 503)


@app.function_name("reprocess")
@app.route(route="reprocess/{dl_id}", methods=["POST"], auth_level=func.AuthLevel.FUNCTION)
def reprocess(req: func.HttpRequest) -> func.HttpResponse:
    dl_id = req.route_params.get("dl_id", "")
    try:
        return func.HttpResponse(json.dumps(reprocess_dead_letter(dl_id)), mimetype="application/json")
    except KeyError:
        return func.HttpResponse(json.dumps({"error": "unknown dead-letter id"}), status_code=404, mimetype="application/json")


@app.function_name("sla_watch")
@app.timer_trigger(schedule="0 */15 * * * *", arg_name="timer", run_on_startup=False, use_monitor=True)
def sla_watch(timer: func.TimerRequest) -> None:
    sent = sla_breaches()
    log.info("sla_watch: %d breach alert(s) sent", len(sent))
