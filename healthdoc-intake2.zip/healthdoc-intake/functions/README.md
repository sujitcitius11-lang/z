# Azure Functions (Python v2 model)
* `process_document`: Event Grid trigger on BlobCreated for the `incoming` container, which runs the same pipeline as the local app (`src/pipeline/processor.py`).
* `health` (GET /api/health), `reprocess` (POST, replays dead-lettered documents), `sla_watch` (timer, flags work items past SLA).
* Local run: copy `local.settings.json.example` to `local.settings.json`, `pip install -r requirements.txt`, `func start`. Needs Azure Functions Core Tools.
* The Function package must contain `src/` and `config.py`; the pipeline zips the whole repo (see devops/azure-pipelines.yml).
* Status: handler helpers are unit tested with fakes; the Azure-hosted trigger itself was not run here.
