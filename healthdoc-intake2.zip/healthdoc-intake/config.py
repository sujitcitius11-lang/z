"""Central configuration.

Rules of this project
---------------------
* Secrets are NEVER hard-coded. They come from environment variables, the `.env` file,
  or Azure Key Vault (see src/security/keyvault.py).
* Every Azure service has a LOCAL FALLBACK so the whole system runs on a laptop with no
  Azure account. A service switches to Azure automatically when it is configured, unless
  FORCE_LOCAL=1.  The UI "Azure Services" page shows which mode each service is in.
"""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env")
except ImportError:  # python-dotenv is optional
    pass

ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DOCINTAKE_DATA_DIR") or (ROOT / "data"))   # override for tests / sandboxes
SYNTH_DIR = DATA_DIR / "synthetic"            # generated documents + answer key
BLOB_DIR = DATA_DIR / "blob"                  # local stand-in for Azure Blob Storage
DB_DIR = DATA_DIR / "db"                      # local stand-in for Azure SQL + Cosmos DB
LOG_DIR = Path(os.getenv("DOCINTAKE_LOG_DIR") or (ROOT / "logs"))
DOCS_DIR = ROOT / "docs"
POWERBI_DIR = ROOT / "powerbi"
POWERBI_DATA_DIR = POWERBI_DIR / "data"
for _d in (DATA_DIR, SYNTH_DIR, BLOB_DIR, DB_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# "Today" is fixed so demos and tests are repeatable (same idea as the reference projects).
REFERENCE_DATE = date.fromisoformat(os.getenv("REFERENCE_DATE", "2026-10-22"))

# ----------------------------------------------------------------------------------------
# Azure settings. Names follow the trainer's demos (AZURE_OPENAI_*, DOCUMENT_INTELLIGENCE_*).
# Values are read lazily through env() so Key Vault can supply them.
# ----------------------------------------------------------------------------------------


def env(name: str, default: str | None = None) -> str | None:
    """Read a setting: environment first, then Azure Key Vault (if KEY_VAULT_URI is set)."""
    val = os.getenv(name)
    if val:
        return val
    try:
        from src.security.keyvault import get_secret
        return get_secret(name) or default
    except Exception:
        return default


FORCE_LOCAL = os.getenv("FORCE_LOCAL", "0").lower() in ("1", "true", "yes")

BLOB_CONTAINERS = {
    "incoming": "incoming",      # new uploads land here (Event Grid watches this container)
    "processed": "processed",    # passed automatically
    "review": "review",          # waiting for a human
    "quarantine": "quarantine",  # failed / unreadable / dead-lettered
}

# SQL / Cosmos names
COSMOS_DATABASE = os.getenv("COSMOS_DATABASE", "docintake")
COSMOS_CONTAINER = os.getenv("COSMOS_CONTAINER", "extractions")   # partition key: /doc_type
SQLITE_PATH = DB_DIR / "intake.sqlite"

# ----------------------------------------------------------------------------------------
# Business thresholds (all editable here, all unit-tested)
# ----------------------------------------------------------------------------------------
FIELD_CONF_MIN = float(os.getenv("FIELD_CONF_MIN", "0.80"))   # below this a field needs a human
DOC_CONF_MIN = float(os.getenv("DOC_CONF_MIN", "0.85"))       # below this the document needs a human
CLASSIFY_CONF_MIN = float(os.getenv("CLASSIFY_CONF_MIN", "0.60"))
HIGH_VALUE_CLAIM = float(os.getenv("HIGH_VALUE_CLAIM", "10000"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
RETRY_BASE_SECONDS = float(os.getenv("RETRY_BASE_SECONDS", "0.2"))   # keep tiny for local runs
PACKET_SPLITTING = os.getenv("PACKET_SPLITTING", "1").lower() in ("1", "true", "yes")   # cut multi-document files into documents
PHI_MASK_BEFORE_LLM = os.getenv("PHI_MASK_BEFORE_LLM", "1").lower() in ("1", "true", "yes")  # pseudonymise PHI in the text sent to Azure OpenAI
FEEDBACK_MEMORY = os.getenv("FEEDBACK_MEMORY", "1").lower() in ("1", "true", "yes")             # apply reviewer-taught fixes to new documents
UPLOAD_LIMIT_MB = 20
ALLOWED_EXTENSIONS = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff")

# Cost estimator. PLACEHOLDER RATES in USD: check the Azure pricing page before quoting to a client.
COST_PER_1000_PAGES_LAYOUT = float(os.getenv("COST_PER_1000_PAGES_LAYOUT", "10.0"))
COST_PER_1M_INPUT_TOKENS = float(os.getenv("COST_PER_1M_INPUT_TOKENS", "0.40"))
COST_PER_1M_OUTPUT_TOKENS = float(os.getenv("COST_PER_1M_OUTPUT_TOKENS", "1.60"))

# Authentication: demo = role picker (like the reference projects); entra = Microsoft Entra ID sign-in
AUTH_MODE = os.getenv("AUTH_MODE", "demo").lower()

# Synthetic-data defaults
DATASET_SEED = int(os.getenv("DATASET_SEED", "2026"))
DOCS_PER_TYPE = 500                # 5 types x 500 = 2,500 documents (project requirement)


# ----------------------------------------------------------------------------------------
# Which backend is each service using? "azure" when configured, otherwise "local".
# ----------------------------------------------------------------------------------------
def _configured(*names: str) -> bool:
    return all(bool(env(n)) for n in names)


def service_modes() -> dict[str, str]:
    """Return {service: 'azure'|'local'} for the Azure Services page and for the factories."""
    if FORCE_LOCAL:
        return {k: "local" for k in ("blob", "event_grid", "doc_intelligence", "openai", "sql", "cosmos",
                                      "key_vault", "logic_apps", "entra")}
    return {
        "blob": "azure" if (_configured("AZURE_STORAGE_CONNECTION_STRING") or _configured("AZURE_STORAGE_ACCOUNT_URL")) else "local",
        # Real Event Grid delivers BlobCreated events to the Function. Locally we emulate the same event schema.
        "event_grid": "azure" if (_configured("AZURE_STORAGE_CONNECTION_STRING") or _configured("AZURE_STORAGE_ACCOUNT_URL")) and os.getenv("EVENT_GRID_MODE", "").lower() == "azure" else "local",
        "doc_intelligence": "azure" if _configured("DOCUMENT_INTELLIGENCE_ENDPOINT") else "local",
        "openai": "azure" if _configured("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT_NAME") else "local",
        "sql": "azure" if _configured("AZURE_SQL_CONNECTION_STRING") else "local",
        "cosmos": "azure" if _configured("COSMOS_ENDPOINT") else "local",
        "key_vault": "azure" if bool(os.getenv("KEY_VAULT_URI")) else "local",
        "logic_apps": "azure" if _configured("LOGIC_APP_ROUTING_URL") else "local",
        "entra": "azure" if AUTH_MODE == "entra" else "local",
    }


def mode(service: str) -> str:
    return service_modes().get(service, "local")


# Business-case assumptions (labelled as assumptions everywhere they are shown; change them to the client's real numbers)
MANUAL_MINUTES_PER_DOC = float(os.getenv("MANUAL_MINUTES_PER_DOC", "6"))     # minutes a person needs to key in + route one document by hand
REVIEW_MINUTES_PER_DOC = float(os.getenv("REVIEW_MINUTES_PER_DOC", "2"))     # minutes a person needs to check one flagged document
