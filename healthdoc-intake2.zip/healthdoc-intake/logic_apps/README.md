# Routing Logic App

`routing_workflow.json` is a **Consumption Logic App workflow definition**. `infra/main.bicep` loads it
(`loadJsonContent`) and deploys it. `build_workflow.py` regenerates it from `src/routing/router.WORKFLOWS`, so the cloud
decision table and the Python one cannot drift (a test checks that every workflow id is present).

## Division of labour
Python (`src/routing/router.py`) **decides** the workflow, priority and SLA. The Logic App only **acts** on that decision
(notify, create a task, page someone). The Python side posts the decision to the Logic App's HTTP trigger
(`LOGIC_APP_ROUTING_URL`, stored in Key Vault); see `src/routing/logic_app.py`.

## Trigger
HTTP request (POST). JSON schema = the payload built by `logic_app.dispatch`:
`doc_id, workflow_id, workflow_name, team, priority, sla_due_at, reason, actions[], summary{}`. The payload deliberately has **no PHI**
(no patient names, DOB, IDs): only document id, type, counts and amounts.

## Switch on `workflow_id` (12 cases)
| Case | Team | Priority | Actions |
|---|---|---|---|
| W-ENR, W-CLM, W-REF, W-RX, W-LAB, W-REVIEW, W-TRIAGE | per router | Normal | Outlook e-mail to team, Azure DevOps Task, HTTP callback |
| W-CLM-HV, W-DLQ | Senior Claims / IT Ops | High | + Microsoft Teams channel post |
| W-REF-URG, W-LAB-CRIT | Urgent Referral Desk / Clinical Alert | Critical | + Teams post + HTTP page-on-call call |
| W-DUP | - | Low | no-op (`Compose`) |
| default | - | - | `Terminate` as Failed (unknown id) |

Every external call has `runAfter` = Succeeded **or** Failed, so a failing Teams connector cannot block the e-mail or the
work item. HTTP actions retry 3 times with exponential back-off. The **Response** action always returns 200 with
`{run_id, doc_id, workflow_id, routed}`. An SLA-breach call (from the `sla_watch` function) uses the same workflow with
`actions` containing `sla_breach_alert`; the e-mail subject is then prefixed `SLA BREACH`.

## Connections and parameters
API connections (`office365`, `teams`, `visualstudioteamservices`) are created by Bicep but must be **authorised once** in the portal
(Logic App > API connections > Authorize) because they use OAuth. Parameters: `teamEmailDomain, teamsGroupId, teamsChannelId,
adoOrganization, adoProject, callbackUrl, pagerUrl`.

## Test with curl
Get the trigger URL (it contains a SAS key: treat it as a secret):
```bash
az logic workflow show -g rg-docintake -n <logic-app> --query accessEndpoint -o tsv      # base, then list callback:
az rest --method post --uri "https://management.azure.com/subscriptions/<sub>/resourceGroups/rg-docintake/providers/Microsoft.Logic/workflows/<logic-app>/triggers/manual/listCallbackUrl?api-version=2016-06-01" --query value -o tsv
curl -X POST "<callback-url>" -H "Content-Type: application/json" -d '{
  "doc_id":"DOC-TEST000001","workflow_id":"W-REF-URG","workflow_name":"Urgent Referral Desk","team":"Urgent Referral Desk",
  "priority":"Critical","sla_due_at":"2026-10-23T12:00:00Z","reason":"Referral urgency is Urgent",
  "actions":["notify_team_email","create_work_item","page_on_call","teams_message"],"summary":{"doc_type":"referral"}}'
```
Expected: `200 {"run_id":"0858...","routed":true}`; check the run history in the portal. In the local simulation the same actions are
written to the `WorkflowActions` table with status `simulated`.
