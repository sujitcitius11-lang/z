import json, sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from src.routing.router import WORKFLOWS

def sid(w): return w.replace("-", "_")

def email(w, subj_prefix):
    return {"type": "ApiConnection", "runAfter": {},
            "inputs": {"host": {"connection": {"name": "@parameters('$connections')['office365']['connectionId']"}}, "method": "post", "path": "/v2/Mail",
                       "body": {"To": "@{concat(replace(toLower(triggerBody()?['team']),' ','-'),'@',parameters('teamEmailDomain'))}",
                                "Subject": f"@{{if(contains(triggerBody()?['actions'],'sla_breach_alert'),'SLA BREACH ','')}}[{subj_prefix}] @{{triggerBody()?['workflow_name']}} - doc @{{triggerBody()?['doc_id']}} (SLA @{{triggerBody()?['sla_due_at']}})",
                                "Body": "<p><b>Workflow:</b> @{triggerBody()?['workflow_name']}<br/><b>Priority:</b> @{triggerBody()?['priority']}<br/><b>Why:</b> @{triggerBody()?['reason']}<br/><b>Summary:</b> @{string(triggerBody()?['summary'])}<br/><i>No patient data is included in this message; open the document in the intake app.</i></p>",
                                "Importance": "@if(or(equals(triggerBody()?['priority'],'Critical'),equals(triggerBody()?['priority'],'High')),'High','Normal')"}}}

def teams(prev):
    return {"type": "ApiConnection", "runAfter": {prev: ["Succeeded", "Failed"]},
            "inputs": {"host": {"connection": {"name": "@parameters('$connections')['teams']['connectionId']"}}, "method": "post",
                       "path": "/flowbot/actions/notification/recipienttype/channel",
                       "body": {"messageBody": "<b>@{triggerBody()?['priority']}</b>: @{triggerBody()?['workflow_name']} - doc @{triggerBody()?['doc_id']} - @{triggerBody()?['reason']}",
                                "recipient": {"groupId": "@parameters('teamsGroupId')", "channelId": "@parameters('teamsChannelId')"}}}}

def workitem(prev, w):
    return {"type": "ApiConnection", "runAfter": {prev: ["Succeeded", "Failed"]},
            "inputs": {"host": {"connection": {"name": "@parameters('$connections')['visualstudioteamservices']['connectionId']"}}, "method": "patch",
                       "path": "/@{encodeURIComponent(parameters('adoProject'))}/_apis/wit/workitems/$@{encodeURIComponent('Task')}",
                       "queries": {"account": "@parameters('adoOrganization')", "api-version": "7.1"},
                       "headers": {"Content-Type": "application/json-patch+json"},
                       "body": [{"op": "add", "path": "/fields/System.Title", "value": f"{w}: process document @{{triggerBody()?['doc_id']}}"},
                                {"op": "add", "path": "/fields/System.Description", "value": "@{triggerBody()?['reason']}"},
                                {"op": "add", "path": "/fields/Microsoft.VSTS.Common.Priority", "value": "@if(equals(triggerBody()?['priority'],'Critical'),1,if(equals(triggerBody()?['priority'],'High'),2,3))"},
                                {"op": "add", "path": "/fields/System.Tags", "value": f"docintake;{w}"}]}}

def http(name, url_param, prev):
    return {"type": "Http", "runAfter": {prev: ["Succeeded", "Failed"]},
            "inputs": {"method": "POST", "uri": f"@parameters('{url_param}')", "headers": {"Content-Type": "application/json"},
                       "body": {"doc_id": "@triggerBody()?['doc_id']", "workflow_id": "@triggerBody()?['workflow_id']", "priority": "@triggerBody()?['priority']",
                                "logic_app_run": "@workflow().run.name"}},
            "retryPolicy": {"type": "exponential", "count": 3, "interval": "PT10S"}}

cases = {}
for w, spec in WORKFLOWS.items():
    if w == "W-DUP":
        cases[f"Case_{sid(w)}"] = {"case": w, "actions": {f"Noop_{sid(w)}": {"type": "Compose", "inputs": "Duplicate archived - no action required", "runAfter": {}}}}
        continue
    a = {f"Email_{sid(w)}": email(w, spec["priority"].upper())}
    last = f"Email_{sid(w)}"
    a[f"WorkItem_{sid(w)}"] = workitem(last, w); last = f"WorkItem_{sid(w)}"
    if spec["priority"] in ("High", "Critical"):
        a[f"Teams_{sid(w)}"] = teams(last); last = f"Teams_{sid(w)}"
    if spec["priority"] == "Critical":
        a[f"PageOnCall_{sid(w)}"] = http("page", "pagerUrl", last); last = f"PageOnCall_{sid(w)}"
    a[f"Callback_{sid(w)}"] = http("cb", "callbackUrl", last)
    cases[f"Case_{sid(w)}"] = {"case": w, "actions": a}

definition = {
    "$schema": "https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#",
    "contentVersion": "1.0.0.0",
    "parameters": {
        "$connections": {"defaultValue": {}, "type": "Object"},
        "teamEmailDomain": {"defaultValue": "example.org", "type": "String"},
        "teamsGroupId": {"defaultValue": "00000000-0000-0000-0000-000000000000", "type": "String"},
        "teamsChannelId": {"defaultValue": "19:placeholder@thread.tacv2", "type": "String"},
        "adoOrganization": {"defaultValue": "your-org", "type": "String"},
        "adoProject": {"defaultValue": "DocIntake", "type": "String"},
        "callbackUrl": {"defaultValue": "https://example.org/docintake/callback", "type": "String"},
        "pagerUrl": {"defaultValue": "https://example.org/pager", "type": "String"}},
    "triggers": {"manual": {"type": "Request", "kind": "Http", "inputs": {"schema": {
        "type": "object",
        "properties": {
            "doc_id": {"type": "string"}, "workflow_id": {"type": "string", "enum": list(WORKFLOWS)}, "workflow_name": {"type": "string"},
            "team": {"type": "string"}, "priority": {"type": "string", "enum": ["Low", "Normal", "High", "Critical"]},
            "sla_due_at": {"type": ["string", "null"]}, "reason": {"type": "string"},
            "actions": {"type": "array", "items": {"type": "string"}}, "summary": {"type": "object"}, "error": {"type": "string"}},
        "required": ["doc_id", "workflow_id", "team", "priority", "actions"]}}}},
    "actions": {
        "Route_by_workflow": {"type": "Switch", "expression": "@triggerBody()?['workflow_id']", "cases": cases,
                              "default": {"actions": {"Unknown_workflow": {"type": "Terminate", "inputs": {"runStatus": "Failed", "runError": {"code": "UnknownWorkflow", "message": "@concat('Unknown workflow_id: ', triggerBody()?['workflow_id'])"}}}}},
                              "runAfter": {}},
        "Response": {"type": "Response", "kind": "Http", "runAfter": {"Route_by_workflow": ["Succeeded", "Failed", "TimedOut"]},
                     "inputs": {"statusCode": 200, "headers": {"Content-Type": "application/json"},
                                "body": {"run_id": "@workflow().run.name", "doc_id": "@triggerBody()?['doc_id']", "workflow_id": "@triggerBody()?['workflow_id']",
                                         "routed": "@equals(result('Route_by_workflow')[0]['status'],'Succeeded')"}}}},
    "outputs": {}}
json.dump(definition, open("" + str(__import__("pathlib").Path(__file__).with_name("routing_workflow.json")) + "", "w"), indent=2)
print(len(cases), "cases")
