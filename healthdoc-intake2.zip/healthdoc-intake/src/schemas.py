"""Single source of truth for the five document types.

The generator draws forms from these specs, the extractor reads them, the validator checks them,
the router uses them and the Power BI export is built from them. One change here flows everywhere.

kind values: text, name, date, money, int, phone, email, npi, id, icd_list, cpt_lines, lab_rows, choice
labels : every wording the forms may use for the field (the generator picks one; the extractor knows all)
"""
from __future__ import annotations

from dataclasses import dataclass, field

DOC_TYPES = ["enrollment", "claim", "referral", "prescription", "lab_report"]
DOC_TYPE_LABELS = {
    "enrollment": "Enrollment Form", "claim": "Claim", "referral": "Referral",
    "prescription": "Prescription", "lab_report": "Lab Report", "unknown": "Unclassified",
}

# Words that appear in the title block of each type (classification evidence for the local engine).
CLASSIFY_KEYWORDS = {
    "enrollment": {"enrollment": 3, "enroll": 2, "application": 2, "plan selection": 2, "effective date": 1, "dependents": 1, "member application": 3, "subscriber": 1, "coverage": 1},
    "claim": {"claim": 3, "billed": 2, "cpt": 3, "icd-10": 2, "place of service": 2, "procedure": 1, "billing": 2, "charges": 1, "diagnosis": 1},
    "referral": {"referral": 3, "referred to": 3, "refer": 1, "specialist": 2, "referring": 2, "urgency": 2, "consultation": 1, "authorization": 1},
    "prescription": {"prescription": 3, "rx": 3, "refills": 3, "dispense": 2, "sig": 2, "pharmacy": 2, "prescriber": 2, "drug": 1, "strength": 2},
    "lab_report": {"laboratory": 3, "lab report": 3, "specimen": 3, "accession": 3, "reference range": 3, "collected": 2, "result": 1, "flag": 1, "panel": 1},
}


@dataclass(frozen=True)
class FieldSpec:
    name: str
    display: str
    kind: str
    labels: tuple[str, ...]
    required: bool = True
    multiline: bool = False


def _f(name, display, kind, labels, required=True, multiline=False):
    return FieldSpec(name, display, kind, tuple(labels), required, multiline)


SCHEMAS: dict[str, list[FieldSpec]] = {
    "enrollment": [
        _f("application_date", "Application date", "date", ["Application Date", "Date of Application", "Date Submitted"], False),
        _f("patient_name", "Applicant name", "name", ["Applicant Name", "Member Name", "Full Name"]),
        _f("dob", "Date of birth", "date", ["Date of Birth", "DOB", "Birth Date"]),
        _f("gender", "Gender", "choice", ["Gender", "Sex"]),
        _f("address", "Address", "text", ["Home Address", "Address", "Mailing Address"]),
        _f("phone", "Phone", "phone", ["Phone", "Telephone", "Contact Number"]),
        _f("email", "Email", "email", ["Email", "E-mail", "Email Address"], False),
        _f("insurer", "Insurer", "text", ["Insurance Carrier", "Insurer", "Health Plan"]),
        _f("plan_name", "Plan name", "text", ["Plan Name", "Selected Plan", "Plan"]),
        _f("plan_type", "Plan type", "choice", ["Plan Type", "Coverage Type", "Network Type"]),
        _f("group_number", "Group number", "id", ["Group Number", "Group No", "Employer Group #"], False),
        _f("member_id", "Member ID", "id", ["Member ID", "Subscriber ID", "Member Number"]),
        _f("employer", "Employer", "text", ["Employer", "Employer Name", "Company"], False),
        _f("dependents", "Dependents", "int", ["Dependents", "Number of Dependents", "Covered Dependents"], False),
        _f("effective_date", "Effective date", "date", ["Effective Date", "Coverage Start Date", "Coverage Effective"]),
    ],
    "claim": [
        _f("claim_number", "Claim number", "id", ["Claim Number", "Claim No", "Claim #", "Claim ID"]),
        _f("patient_name", "Patient name", "name", ["Patient Name", "Name of Patient", "Patient"]),
        _f("dob", "Date of birth", "date", ["Date of Birth", "DOB", "Patient DOB"]),
        _f("member_id", "Member ID", "id", ["Member ID", "Insured ID", "Subscriber ID"]),
        _f("insurer", "Insurer", "text", ["Insurance Carrier", "Payer", "Insurer"]),
        _f("provider_name", "Billing provider", "name", ["Billing Provider", "Rendering Provider", "Provider Name"]),
        _f("provider_npi", "Provider NPI", "npi", ["Provider NPI", "NPI", "Billing NPI"]),
        _f("facility", "Facility", "text", ["Facility", "Service Facility", "Place of Treatment"], False),
        _f("service_date", "Date of service", "date", ["Date of Service", "Service Date", "DOS"]),
        _f("place_of_service", "Place of service", "id", ["Place of Service", "POS", "POS Code"]),
        _f("diagnosis_codes", "Diagnosis codes", "icd_list", ["Diagnosis Codes", "ICD-10 Codes", "Diagnosis"]),
        _f("line_items", "Service lines", "cpt_lines", ["Service Lines", "Procedures", "Line Items"]),
        _f("billed_amount", "Total billed", "money", ["Total Billed", "Total Charges", "Amount Billed"]),
    ],
    "referral": [
        _f("referral_id", "Referral ID", "id", ["Referral ID", "Referral Number", "Referral #"]),
        _f("referral_date", "Referral date", "date", ["Referral Date", "Date of Referral", "Date Issued"]),
        _f("patient_name", "Patient name", "name", ["Patient Name", "Name of Patient", "Patient"]),
        _f("dob", "Date of birth", "date", ["Date of Birth", "DOB", "Patient DOB"]),
        _f("member_id", "Member ID", "id", ["Member ID", "Insured ID", "Subscriber ID"]),
        _f("insurer", "Insurer", "text", ["Insurance Carrier", "Payer", "Insurer"]),
        _f("referring_provider", "Referring provider", "name", ["Referring Provider", "Referred By", "From Provider"]),
        _f("referring_npi", "Referring NPI", "npi", ["Referring NPI", "Referrer NPI", "NPI"]),
        _f("referred_to_provider", "Referred to", "name", ["Referred To", "Specialist Name", "To Provider"]),
        _f("referred_to_specialty", "Specialty", "choice", ["Specialty", "Specialty Requested", "Service Requested"]),
        _f("urgency", "Urgency", "choice", ["Urgency", "Priority", "Urgency Level"]),
        _f("diagnosis_codes", "Diagnosis codes", "icd_list", ["Diagnosis Codes", "ICD-10 Codes", "Diagnosis"]),
        _f("reason", "Reason for referral", "text", ["Reason for Referral", "Clinical Reason", "Referral Reason"], True, True),
        _f("authorization_number", "Authorization #", "id", ["Authorization Number", "Auth No", "Prior Auth #"], False),
    ],
    "prescription": [
        _f("rx_number", "Rx number", "id", ["Rx Number", "Prescription No", "Rx #"]),
        _f("date_written", "Date written", "date", ["Date Written", "Date Prescribed", "Prescription Date"]),
        _f("patient_name", "Patient name", "name", ["Patient Name", "Name of Patient", "Patient"]),
        _f("dob", "Date of birth", "date", ["Date of Birth", "DOB", "Patient DOB"]),
        _f("member_id", "Member ID", "id", ["Member ID", "Insured ID", "Subscriber ID"], False),
        _f("prescriber_name", "Prescriber", "name", ["Prescriber", "Prescribing Provider", "Physician"]),
        _f("prescriber_npi", "Prescriber NPI", "npi", ["Prescriber NPI", "NPI", "Physician NPI"]),
        _f("drug_name", "Drug", "text", ["Drug", "Medication", "Drug Name"]),
        _f("strength", "Strength", "text", ["Strength", "Dose Strength", "Dosage"]),
        _f("dosage_form", "Form", "choice", ["Dosage Form", "Form"]),
        _f("quantity", "Quantity", "int", ["Quantity", "Qty", "Quantity Dispensed"]),
        _f("refills", "Refills", "int", ["Refills", "Number of Refills", "Refills Allowed"]),
        _f("directions", "Directions (Sig)", "text", ["Directions", "Sig", "Directions for Use"], True, True),
        _f("pharmacy_name", "Pharmacy", "text", ["Pharmacy", "Dispensing Pharmacy", "Send To"], False),
    ],
    "lab_report": [
        _f("accession_number", "Accession number", "id", ["Accession Number", "Accession No", "Accession #"]),
        _f("lab_name", "Laboratory", "text", ["Laboratory", "Performing Lab", "Lab Name"]),
        _f("patient_name", "Patient name", "name", ["Patient Name", "Name of Patient", "Patient"]),
        _f("dob", "Date of birth", "date", ["Date of Birth", "DOB", "Patient DOB"]),
        _f("ordering_provider", "Ordering provider", "name", ["Ordering Provider", "Ordered By", "Requesting Physician"]),
        _f("ordering_npi", "Ordering NPI", "npi", ["Ordering NPI", "Provider NPI", "NPI"]),
        _f("specimen_type", "Specimen", "choice", ["Specimen Type", "Specimen", "Sample Type"], False),
        _f("collected_date", "Collected", "date", ["Collected", "Date Collected", "Collection Date"]),
        _f("reported_date", "Reported", "date", ["Reported", "Date Reported", "Report Date"]),
        _f("panel_name", "Panel", "text", ["Panel", "Test Panel", "Panel Name"]),
        _f("results", "Results", "lab_rows", ["Results", "Test Results"]),
    ],
}

# Which fields carry the provider / main date / amount (used by routing, KPIs and Power BI)
PROVIDER_FIELDS = {  # type -> (name field, npi field)
    "claim": ("provider_name", "provider_npi"), "referral": ("referring_provider", "referring_npi"),
    "prescription": ("prescriber_name", "prescriber_npi"), "lab_report": ("ordering_provider", "ordering_npi"),
}
PRIMARY_DATE = {
    "enrollment": "effective_date", "claim": "service_date", "referral": "referral_date",
    "prescription": "date_written", "lab_report": "reported_date",
}
# Layout wording of the table columns (claim lines, lab rows)
CLAIM_COLUMNS = ["CPT", "Description", "Units", "Charge"]
LAB_COLUMNS = ["Test", "Result", "Unit", "Reference Range", "Flag"]


def spec(doc_type: str) -> list[FieldSpec]:
    return SCHEMAS.get(doc_type, [])


def field_names(doc_type: str) -> list[str]:
    return [f.name for f in SCHEMAS.get(doc_type, [])]


def required_fields(doc_type: str) -> list[str]:
    return [f.name for f in SCHEMAS.get(doc_type, []) if f.required]


def field_spec(doc_type: str, name: str) -> FieldSpec | None:
    return next((f for f in SCHEMAS.get(doc_type, []) if f.name == name), None)


def all_labels(doc_type: str) -> dict[str, str]:
    """label (lower-case) -> canonical field name, longest labels first handled by the caller."""
    out = {}
    for f in SCHEMAS[doc_type]:
        for lab in f.labels:
            out[lab.lower()] = f.name
    return out


def json_schema_for_llm(doc_type: str | None = None) -> dict:
    """JSON Schema handed to Azure OpenAI structured output (response_format=json_schema)."""
    def one(f: FieldSpec):
        base = {"type": ["string", "null"], "description": f"{f.display}. Return exactly as printed. null if absent."}
        if f.kind == "icd_list":
            return {"type": ["array", "null"], "items": {"type": "string"}, "description": "ICD-10 codes"}
        if f.kind == "cpt_lines":
            return {"type": ["array", "null"], "items": {"type": "object", "properties": {
                "cpt": {"type": "string"}, "description": {"type": "string"}, "units": {"type": "string"}, "charge": {"type": "string"}},
                "required": ["cpt", "description", "units", "charge"], "additionalProperties": False}}
        if f.kind == "lab_rows":
            return {"type": ["array", "null"], "items": {"type": "object", "properties": {
                "test": {"type": "string"}, "value": {"type": "string"}, "unit": {"type": "string"},
                "ref_range": {"type": "string"}, "flag": {"type": "string"}},
                "required": ["test", "value", "unit", "ref_range", "flag"], "additionalProperties": False}}
        return base

    types = [doc_type] if doc_type else DOC_TYPES
    per_type = {t: {"type": "object", "properties": {f.name: one(f) for f in SCHEMAS[t]},
                    "required": [f.name for f in SCHEMAS[t]], "additionalProperties": False} for t in types}
    return {"per_type": per_type}


# ---------------------------------------------------------------------------------------------
# Format rules shared by the extractor (OCR repair) and the validator
# ---------------------------------------------------------------------------------------------
# field name -> (alphabetic prefix length, digit count, regex)
ID_PATTERNS: dict[str, tuple[int, int, str]] = {
    "member_id": (3, 9, r"^[A-Z]{3}\d{9}$"),
    "claim_number": (3, 9, r"^CLM\d{9}$"),
    "referral_id": (3, 8, r"^REF\d{8}$"),
    "rx_number": (2, 8, r"^RX\d{8}$"),
    "accession_number": (3, 9, r"^ACC\d{9}$"),
    "authorization_number": (4, 8, r"^AUTH\d{8}$"),
    "group_number": (3, 5, r"^GRP\d{5}$"),
    "place_of_service": (0, 2, r"^\d{2}$"),
}
ICD_REGEX = r"^[A-TV-Z]\d{2}(\.[0-9A-TV-Z]{1,4})?$"
CPT_REGEX = r"^\d{5}$"
EMAIL_REGEX = r"^[\w.+-]+@[\w-]+\.[\w.-]+$"
PHONE_REGEX = r"^\(\d{3}\) \d{3}-\d{4}$"
