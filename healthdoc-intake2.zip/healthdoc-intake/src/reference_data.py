"""Small reference tables used by the data generator AND by the validators.

All organisations, plans and people are fictional. Code lists are a SMALL SUBSET of the real
ICD-10-CM / CPT / place-of-service code sets, enough to demonstrate validation. In production
the validators would call the licensed full code sets (a typical client requirement).
"""
from __future__ import annotations

INSURERS = [
    "BlueHarbor Health Plan", "Evergreen Mutual", "NorthStar Health", "Pinecrest Assurance",
    "Summit Care Alliance", "Harborview Insurance", "Meridian Health Partners", "Lakeshore Benefits",
]
PLAN_TYPES = ["HMO", "PPO", "EPO", "HDHP", "POS"]
PLAN_NAMES = ["Silver Choice", "Gold Advantage", "Bronze Basic", "Platinum Select", "Family Care", "Essential Care"]
EMPLOYERS = ["Brightwave Logistics", "Cedar Ridge Schools", "Northgate Foods", "Orion Software", "Valley Steel Works",
             "Harbor City Transit", "Maple Leaf Bakery", "Quantum Retail", "Redwood Construction", "Self-employed"]
FACILITIES = [
    "Riverside Community Hospital", "St. Aurelia Medical Center", "Lakeside Family Clinic", "Northgate Specialty Center",
    "Willow Creek Health Center", "Summit Outpatient Surgery", "Harborview General Hospital", "Oakmont Urgent Care",
]
LABS = ["Precision Diagnostics Lab", "ClearPath Laboratories", "Meridian Pathology Services", "BrightLine Clinical Lab"]
PHARMACIES = ["Corner Health Pharmacy", "Greenleaf Pharmacy", "Main Street Rx", "CarePoint Pharmacy", "Sunrise Drugstore"]
SPECIALTIES = ["Cardiology", "Endocrinology", "Orthopedics", "Neurology", "Dermatology", "Gastroenterology",
               "Pulmonology", "Nephrology", "Oncology", "Psychiatry", "Ophthalmology", "Urology"]
URGENCY = ["Routine", "Urgent", "Emergent"]
GENDERS = ["Male", "Female", "Other"]

# ICD-10-CM subset: code -> description
ICD10 = {
    "E11.9": "Type 2 diabetes mellitus without complications", "E11.65": "Type 2 diabetes with hyperglycemia",
    "I10": "Essential (primary) hypertension", "I25.10": "Atherosclerotic heart disease of native coronary artery",
    "I50.9": "Heart failure, unspecified", "J45.909": "Unspecified asthma, uncomplicated",
    "J44.9": "Chronic obstructive pulmonary disease, unspecified", "J06.9": "Acute upper respiratory infection",
    "M54.5": "Low back pain", "M17.9": "Osteoarthritis of knee, unspecified", "M25.511": "Pain in right shoulder",
    "K21.9": "Gastro-esophageal reflux disease without esophagitis", "K29.70": "Gastritis, unspecified",
    "N39.0": "Urinary tract infection, site not specified", "N18.3": "Chronic kidney disease, stage 3",
    "F32.9": "Major depressive disorder, single episode", "F41.1": "Generalized anxiety disorder",
    "G43.909": "Migraine, unspecified", "G47.33": "Obstructive sleep apnea", "E78.5": "Hyperlipidemia, unspecified",
    "E03.9": "Hypothyroidism, unspecified", "D64.9": "Anemia, unspecified", "R07.9": "Chest pain, unspecified",
    "R51.9": "Headache, unspecified", "L30.9": "Dermatitis, unspecified", "H40.9": "Unspecified glaucoma",
    "C50.911": "Malignant neoplasm of unspecified site of right female breast", "Z00.00": "General adult medical examination",
    "Z23": "Encounter for immunization", "S93.401A": "Sprain of unspecified ligament of right ankle, initial encounter",
}

# CPT subset: code -> (description, typical charge USD)
CPT = {
    "99202": ("Office visit, new patient, 15-29 min", 120.0), "99203": ("Office visit, new patient, 30-44 min", 180.0),
    "99213": ("Office visit, established patient, 20-29 min", 130.0), "99214": ("Office visit, established patient, 30-39 min", 190.0),
    "99285": ("Emergency department visit, high severity", 950.0), "99223": ("Initial hospital care, high complexity", 520.0),
    "93000": ("Electrocardiogram, 12-lead with report", 75.0), "71046": ("Chest X-ray, 2 views", 110.0),
    "73721": ("MRI knee without contrast", 1250.0), "70553": ("MRI brain with and without contrast", 2400.0),
    "74177": ("CT abdomen and pelvis with contrast", 1800.0), "80053": ("Comprehensive metabolic panel", 45.0),
    "85025": ("Complete blood count with differential", 30.0), "83036": ("Hemoglobin A1c", 40.0),
    "36415": ("Venipuncture", 12.0), "90471": ("Immunization administration", 28.0), "96372": ("Therapeutic injection", 60.0),
    "45378": ("Colonoscopy, diagnostic", 2100.0), "43239": ("Upper GI endoscopy with biopsy", 1900.0),
    "27447": ("Total knee arthroplasty", 32000.0), "47562": ("Laparoscopic cholecystectomy", 9800.0),
    "29881": ("Knee arthroscopy with meniscectomy", 7400.0), "92014": ("Eye exam, established patient", 150.0),
    "97110": ("Therapeutic exercise, 15 min", 70.0), "99396": ("Preventive visit, established, 40-64 yrs", 210.0),
}

PLACE_OF_SERVICE = {"11": "Office", "21": "Inpatient Hospital", "22": "Outpatient Hospital", "23": "Emergency Room", "81": "Independent Laboratory"}

# Drugs: name, strengths, form, directions, typical quantity
DRUGS = [
    ("Metformin", ["500 mg", "850 mg", "1000 mg"], "Tablet", "Take 1 tablet by mouth twice daily with meals", 60),
    ("Lisinopril", ["5 mg", "10 mg", "20 mg", "40 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Atorvastatin", ["10 mg", "20 mg", "40 mg", "80 mg"], "Tablet", "Take 1 tablet by mouth once daily in the evening", 30),
    ("Amlodipine", ["2.5 mg", "5 mg", "10 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Levothyroxine", ["25 mcg", "50 mcg", "75 mcg", "100 mcg"], "Tablet", "Take 1 tablet by mouth every morning on an empty stomach", 30),
    ("Omeprazole", ["20 mg", "40 mg"], "Capsule", "Take 1 capsule by mouth once daily before breakfast", 30),
    ("Sertraline", ["25 mg", "50 mg", "100 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Albuterol", ["90 mcg/actuation"], "Inhaler", "Inhale 2 puffs every 4 to 6 hours as needed", 1),
    ("Amoxicillin", ["250 mg", "500 mg"], "Capsule", "Take 1 capsule by mouth three times daily for 10 days", 30),
    ("Ibuprofen", ["400 mg", "600 mg", "800 mg"], "Tablet", "Take 1 tablet by mouth every 8 hours as needed with food", 30),
    ("Losartan", ["25 mg", "50 mg", "100 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Gabapentin", ["100 mg", "300 mg", "600 mg"], "Capsule", "Take 1 capsule by mouth three times daily", 90),
    ("Hydrochlorothiazide", ["12.5 mg", "25 mg"], "Tablet", "Take 1 tablet by mouth once daily in the morning", 30),
    ("Montelukast", ["10 mg"], "Tablet", "Take 1 tablet by mouth once daily in the evening", 30),
    ("Pantoprazole", ["20 mg", "40 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Metoprolol", ["25 mg", "50 mg", "100 mg"], "Tablet", "Take 1 tablet by mouth twice daily", 60),
    ("Escitalopram", ["5 mg", "10 mg", "20 mg"], "Tablet", "Take 1 tablet by mouth once daily", 30),
    ("Cetirizine", ["10 mg"], "Tablet", "Take 1 tablet by mouth once daily as needed", 30),
    ("Prednisone", ["5 mg", "10 mg", "20 mg"], "Tablet", "Take as directed, taper over 7 days", 28),
    ("Insulin glargine", ["100 units/mL"], "Pen", "Inject 20 units under the skin once daily at bedtime", 1),
]

# Lab tests: name, unit, low, high, decimals.   Panels group them.
LAB_TESTS = {
    "WBC": ("x10^3/uL", 4.0, 11.0, 1), "RBC": ("x10^6/uL", 4.2, 5.9, 2), "Hemoglobin": ("g/dL", 12.0, 17.5, 1),
    "Hematocrit": ("%", 36.0, 52.0, 1), "Platelets": ("x10^3/uL", 150.0, 400.0, 0),
    "Glucose": ("mg/dL", 70.0, 99.0, 0), "BUN": ("mg/dL", 7.0, 20.0, 0), "Creatinine": ("mg/dL", 0.6, 1.3, 2),
    "Sodium": ("mmol/L", 136.0, 145.0, 0), "Potassium": ("mmol/L", 3.5, 5.1, 1), "Chloride": ("mmol/L", 98.0, 107.0, 0),
    "Calcium": ("mg/dL", 8.6, 10.2, 1), "ALT": ("U/L", 7.0, 56.0, 0), "AST": ("U/L", 10.0, 40.0, 0),
    "Total Cholesterol": ("mg/dL", 100.0, 199.0, 0), "LDL Cholesterol": ("mg/dL", 50.0, 129.0, 0),
    "HDL Cholesterol": ("mg/dL", 40.0, 90.0, 0), "Triglycerides": ("mg/dL", 40.0, 149.0, 0),
    "HbA1c": ("%", 4.0, 5.6, 1), "TSH": ("mIU/L", 0.4, 4.0, 2), "Free T4": ("ng/dL", 0.8, 1.8, 2),
    "Vitamin D": ("ng/mL", 30.0, 100.0, 0), "Ferritin": ("ng/mL", 20.0, 250.0, 0),
}
LAB_PANELS = {
    "Complete Blood Count": ["WBC", "RBC", "Hemoglobin", "Hematocrit", "Platelets"],
    "Basic Metabolic Panel": ["Glucose", "BUN", "Creatinine", "Sodium", "Potassium", "Chloride", "Calcium"],
    "Lipid Panel": ["Total Cholesterol", "LDL Cholesterol", "HDL Cholesterol", "Triglycerides"],
    "Liver Function Panel": ["ALT", "AST", "Calcium", "Glucose"],
    "Diabetes Monitoring": ["HbA1c", "Glucose", "Creatinine"],
    "Thyroid Panel": ["TSH", "Free T4"],
    "Anemia Work-up": ["Hemoglobin", "Hematocrit", "Ferritin", "Vitamin D"],
}
SPECIMEN_TYPES = ["Blood", "Serum", "Plasma", "Urine"]

# "Critical" thresholds (multiples of the reference range) for the clinical-alert route
CRITICAL_FACTOR = 1.5

# Referral reasons by diagnosis (fallback narrative if Azure OpenAI is not available)
REFERRAL_REASON_TEMPLATES = [
    "Patient with {dx} not adequately controlled on current therapy. Requesting specialist evaluation and management recommendations.",
    "Persistent symptoms related to {dx} despite 3 months of conservative treatment. Please evaluate and advise on next steps.",
    "Newly identified {dx}. Requesting consultation to confirm diagnosis and plan further testing.",
    "Worsening {dx} with functional impact on daily activities. Needs specialist review and possible procedure.",
    "Follow-up of {dx} after abnormal screening. Requesting expert opinion and co-management.",
]
LAB_COMMENTS = [
    "Specimen received in good condition.", "Results reviewed by laboratory director.",
    "Fasting specimen, 12 hours.", "Repeat testing recommended if clinically indicated.",
    "No hemolysis detected.", "Slightly lipemic specimen; interpret with caution.",
]
