"""Draw a document as a PDF with ReportLab. Three layouts, three fonts, varied titles and wording,
so the extractor cannot rely on one fixed template (that is what makes the data realistic).

Layout A  "lines"   Label: value on one line
Layout B  "grid"    two Label: value pairs per row (short fields), long fields full width
Layout C  "stacked" small grey label, value on the next line
"""
from __future__ import annotations

import random
from datetime import date

from reportlab.lib.colors import Color, HexColor
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

from src import common
from src import schemas as S

W, H = letter
M = 45
FONTS = {"sans": ("Helvetica", "Helvetica-Bold"), "serif": ("Times-Roman", "Times-Bold"), "mono": ("Courier", "Courier-Bold")}
TITLES = {
    "enrollment": ["MEMBER ENROLLMENT FORM", "Health Plan Enrollment Application", "Plan Enrollment Application"],
    "claim": ["HEALTH INSURANCE CLAIM FORM", "Medical Claim Submission", "Claim for Reimbursement"],
    "referral": ["REFERRAL AUTHORIZATION REQUEST", "Specialist Referral Form", "Patient Referral"],
    "prescription": ["PRESCRIPTION", "Rx - Prescription Order", "Prescription Record"],
    "lab_report": ["LABORATORY REPORT", "Clinical Lab Report", "Laboratory Test Results"],
}
BAND = ["#0E5C8A", "#1B7F5C", "#7A3E9D", "#B03A2E", "#33475B", "#0B7285"]
DATE_STYLES = ["us", "iso", "long", "short", "dmy"]


def _wrap(text: str, font: str, size: float, width: float) -> list[str]:
    words, lines, cur = str(text).split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if stringWidth(trial, font, size) <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


def display_value(f: S.FieldSpec, value, date_style: str) -> str:
    if value is None:
        return ""
    if f.kind == "date":
        return common.format_date(date.fromisoformat(value), date_style)
    if f.kind == "money":
        return f"${value:,.2f}"
    if f.kind == "icd_list":
        return ", ".join(value)
    return str(value)


def org_name(doc_type: str, fields: dict, world_org: str) -> str:
    if doc_type == "enrollment":
        return fields.get("insurer") or world_org
    if doc_type == "lab_report":
        return fields.get("lab_name") or world_org
    return world_org


def render(doc_type: str, fields: dict, path, rng: random.Random, org: str, layout: str | None = None) -> dict:
    """Write the PDF. Returns render metadata {layout, font, date_style, title, pages}."""
    layout = layout or rng.choice(["A", "B", "C"])           # "D" (boxed table, NO colons) is used only by the hard pack
    fontkey = rng.choice(list(FONTS))
    reg, bold = FONTS[fontkey]
    date_style = rng.choice(DATE_STYLES)
    title = rng.choice(TITLES[doc_type])
    band = HexColor(rng.choice(BAND))
    size = 9.5 if fontkey != "mono" else 8.6

    c = canvas.Canvas(str(path), pagesize=letter)
    c.setTitle(title)
    page = [1]

    def header():
        c.setFillColor(band)
        c.rect(0, H - 70, W, 70, stroke=0, fill=1)
        c.setFillColor(Color(1, 1, 1))
        c.circle(M + 14, H - 35, 14, stroke=0, fill=1)
        c.setFillColor(band)
        c.rect(M + 11, H - 43, 6, 16, stroke=0, fill=1)
        c.rect(M + 6, H - 38, 16, 6, stroke=0, fill=1)
        c.setFillColor(Color(1, 1, 1))
        c.setFont(bold, 14)
        c.drawString(M + 40, H - 33, org)
        c.setFont(reg, 8.5)
        c.drawString(M + 40, H - 48, "Synthetic training document - fictional organisation")

    def footer():
        c.setFillColor(Color(.4, .4, .4))
        c.setFont(reg, 7.5)
        c.drawString(M, 28, "SYNTHETIC DOCUMENT - generated for software training - contains no real patient information")
        c.drawRightString(W - M, 28, f"Page {page[0]}")
        c.setFillColor(Color(0, 0, 0))

    def new_page():
        footer()
        c.showPage()
        page[0] += 1
        header()
        return H - 100

    header()
    y = H - 100
    c.setFillColor(Color(0, 0, 0))
    c.setFont(bold, 15)
    c.drawString(M, y, title)
    y -= 8
    c.setStrokeColor(band)
    c.setLineWidth(1.2)
    c.line(M, y, W - M, y)
    y -= 22

    specs = [f for f in S.SCHEMAS[doc_type] if f.kind not in ("cpt_lines", "lab_rows")]
    tables = [f for f in S.SCHEMAS[doc_type] if f.kind in ("cpt_lines", "lab_rows")]
    labels = {f.name: rng.choice(f.labels) for f in S.SCHEMAS[doc_type]}
    rendered_labels = {}

    def put(label_text, value_text, x_label, x_value, y_, width):
        c.setFont(bold, size)
        c.drawString(x_label, y_, f"{label_text}:")
        c.setFont(reg, size)
        lines = _wrap(value_text, reg, size, width)
        for i, ln in enumerate(lines):
            c.drawString(x_value, y_ - i * (size + 3), ln)
        return len(lines)

    items = [(f, display_value(f, fields.get(f.name), date_style)) for f in specs]
    items = [(f, v) for f, v in items if v != ""]     # a missing field is simply not printed

    if layout == "A":
        for f, v in items:
            if y < 90:
                y = new_page()
            n = put(labels[f.name], v, M, M + 175, y, W - 2 * M - 175)
            rendered_labels[f.name] = labels[f.name]
            y -= (size + 3) * n + 6
    elif layout == "D":                                                  # boxed two-column form, labels have no colon
        c.setLineWidth(.6)
        for f, v in items:
            lines = _wrap(v, reg, size, W - 2 * M - 185)
            hgt = (size + 3) * len(lines) + 8
            if y - hgt < 90:
                y = new_page()
            c.setFillColor(Color(.93, .94, .96))
            c.rect(M, y - hgt + 8, 165, hgt, stroke=1, fill=1)
            c.setFillColor(Color(1, 1, 1))
            c.rect(M + 165, y - hgt + 8, W - 2 * M - 165, hgt, stroke=1, fill=1)
            c.setFillColor(Color(0, 0, 0))
            c.setFont(bold, size)
            c.drawString(M + 5, y - 3, labels[f.name])
            c.setFont(reg, size)
            for i, ln in enumerate(lines):
                c.drawString(M + 172, y - 3 - i * (size + 3), ln)
            rendered_labels[f.name] = labels[f.name]
            y -= hgt
        y -= 6
    elif layout == "C":
        for f, v in items:
            if y < 100:
                y = new_page()
            c.setFillColor(Color(.3, .3, .3))
            c.setFont(reg, 8.6)
            c.drawString(M, y, f"{labels[f.name]}:")
            c.setFillColor(Color(0, 0, 0))
            c.setFont(reg if rng.random() < .5 else bold, size + 0.5)
            y -= 11
            lines = _wrap(v, reg, size + .5, W - 2 * M)
            for ln in lines:
                c.drawString(M, y, ln)
                y -= size + 3
            rendered_labels[f.name] = labels[f.name]
            y -= 5
    else:  # B grid
        pending = None
        for f, v in items:
            wide = len(v) > 24 or f.multiline or f.kind in ("icd_list", "text")
            if y < 90:
                y = new_page()
            if wide:
                if pending:
                    n = put(labels[pending[0].name], pending[1], M, M + 120, y, 150)
                    rendered_labels[pending[0].name] = labels[pending[0].name]
                    y -= (size + 3) * n + 8
                    pending = None
                n = put(labels[f.name], v, M, M + 120, y, W - 2 * M - 120)
                rendered_labels[f.name] = labels[f.name]
                y -= (size + 3) * n + 8
            elif pending is None:
                pending = (f, v)
            else:
                put(labels[pending[0].name], pending[1], M, M + 120, y, 130)
                put(labels[f.name], v, M + 270, M + 270 + 100, y, 120)
                rendered_labels[pending[0].name] = labels[pending[0].name]
                rendered_labels[f.name] = labels[f.name]
                y -= size + 11
                pending = None
        if pending:
            put(labels[pending[0].name], pending[1], M, M + 120, y, 150)
            rendered_labels[pending[0].name] = labels[pending[0].name]
            y -= size + 11

    # ---- tables
    for f in tables:
        rows = fields.get(f.name)
        if not rows:
            continue
        if y < 160:
            y = new_page()
        y -= 6
        c.setFont(bold, size + 1)
        c.drawString(M, y, f"{labels[f.name]}:")
        rendered_labels[f.name] = labels[f.name]
        y -= 16
        if f.kind == "cpt_lines":
            cols = [("CPT", M), ("Description", M + 60), ("Units", M + 330), ("Charge", M + 400)]
        else:
            cols = [("Test", M), ("Result", M + 150), ("Unit", M + 215), ("Reference Range", M + 290), ("Flag", M + 400)]
        c.setFont(bold, size - .5)
        for name, x in cols:
            c.drawString(x, y, name)
        y -= 4
        c.setStrokeColor(Color(.5, .5, .5))
        c.setLineWidth(.5)
        c.line(M, y, W - M, y)
        y -= 12
        c.setFont(reg, size)
        for r in rows:
            if y < 70:
                y = new_page()
                c.setFont(reg, size)
            if f.kind == "cpt_lines":
                vals = [r["cpt"], r["description"][:46], str(r["units"]), f"${r['charge']:,.2f}"]
            else:
                vals = [r["test"], f"{r['value']}", r["unit"], f"{r['ref_low']} - {r['ref_high']}", r.get("flag") or ""]
            for (name, x), v in zip(cols, vals):
                c.drawString(x, y, str(v))
            y -= size + 5
    # signature line for realism (a printed line is harmless to extraction)
    if y > 110:
        y -= 20
        c.setStrokeColor(Color(.3, .3, .3))
        c.line(M, y, M + 200, y)
        c.setFont(reg, 7.5)
        c.drawString(M, y - 10, "Authorised signature")
    footer()
    c.save()
    return {"layout": layout, "font": fontkey, "date_style": date_style, "title": title, "pages": page[0], "labels": rendered_labels}
