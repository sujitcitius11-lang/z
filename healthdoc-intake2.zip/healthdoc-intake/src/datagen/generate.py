"""Synthetic healthcare document generator: Faker + (optional) Azure OpenAI narrative + ReportLab PDFs.

Produces 5 document types x 500 = 2,500 documents with:
  * a consistent "world" of 900 fictional patients and 120 fictional providers (valid NPI check digits)
  * three layouts, three fonts, five date styles, label synonyms
  * ~14 % scans / photos with three noise levels (PDF-scan, JPG, PNG)
  * ~12 % deliberate DEFECTS (bad NPI, future date, wrong totals, missing fields, ...) so validation has work to do
  * exact duplicate files and re-used claim numbers (idempotency / duplicate detection)
  * an ANSWER KEY (data/synthetic/answer_key.json) used to MEASURE extraction accuracy
No real data is used anywhere.
"""
from __future__ import annotations

import json
import random
import shutil
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Callable

from faker import Faker

import config
from src import common
from src import reference_data as R
from src import schemas as S
from src.datagen import narrative, noise, renderer

ABBR = {"enrollment": "ENR", "claim": "CLM", "referral": "REF", "prescription": "RXP", "lab_report": "LAB"}
START, END = date(2025, 1, 1), date(2026, 10, 15)


# ------------------------------------------------------------------------------------ the world


def _rand_date(rng: random.Random, start=START, end=END, growth=True) -> date:
    span = (end - start).days
    x = rng.random() ** (0.7 if growth else 1.0)          # more recent dates are slightly more likely (growing volume)
    return start + timedelta(days=int(x * span))


def build_world(rng: random.Random, fake: Faker, n_patients=900, n_providers=120) -> dict:
    patients = []
    for i in range(n_patients):
        first, last = fake.first_name(), fake.last_name()
        dob = date(1935, 1, 1) + timedelta(days=rng.randint(0, (date(2023, 6, 30) - date(1935, 1, 1)).days))
        patients.append({
            "name": f"{first} {last}", "dob": dob.isoformat(), "gender": rng.choices(R.GENDERS, [48, 49, 3])[0],
            "address": f"{fake.street_address()}, {fake.city()}, {fake.state_abbr()} {fake.postcode()}",
            "phone": f"({rng.randint(201, 989)}) {rng.randint(200, 999)}-{rng.randint(0, 9999):04d}",
            "email": f"{first}.{last}{rng.randint(1, 99)}@{rng.choice(['example.com', 'mailtest.org', 'sample.net'])}".lower().replace("'", ""),
            "member_id": "".join(rng.choice("ABCDEFGHJKLMNPRSTUVWXYZ") for _ in range(3)) + "".join(str(rng.randint(0, 9)) for _ in range(9)),
            "insurer": rng.choice(R.INSURERS), "plan_name": rng.choice(R.PLAN_NAMES), "plan_type": rng.choice(R.PLAN_TYPES),
            "group_number": f"GRP{rng.randint(10000, 99999)}", "employer": rng.choice(R.EMPLOYERS),
        })
    providers = []
    for _ in range(n_providers):
        first, last = fake.first_name(), fake.last_name()
        providers.append({"name": f"{first} {last}, {rng.choice(['MD', 'MD', 'MD', 'DO', 'NP'])}", "npi": common.make_npi(rng),
                          "specialty": rng.choice(R.SPECIALTIES + ["Family Medicine"] * 4), "facility": rng.choice(R.FACILITIES)})
    return {"patients": patients, "providers": providers}


# ------------------------------------------------------------------------------------ truth builders


def _dx(rng, n=None):
    n = n or rng.choice([1, 1, 2, 2, 3])
    return rng.sample(list(R.ICD10), n)


def _fmt_val(v, decimals):
    return f"{v:.{decimals}f}"


def _lab_rows(rng, panel: str) -> list[dict]:
    rows = []
    for t in R.LAB_PANELS[panel]:
        unit, lo, hi, dec = R.LAB_TESTS[t]
        r = rng.random()
        if r < .74:
            v = rng.uniform(lo, hi)
        elif r < .97:
            v = rng.uniform(hi, hi * 1.25) if rng.random() < .6 else rng.uniform(lo * .7, lo)
        else:
            v = hi * rng.uniform(1.55, 2.2) if rng.random() < .5 else lo * rng.uniform(.2, .45)
        v = round(v, dec)
        flag = "H" if v > hi else "L" if v < lo else ""
        rows.append({"test": t, "value": _fmt_val(v, dec), "unit": unit, "ref_low": _fmt_val(lo, dec), "ref_high": _fmt_val(hi, dec), "flag": flag})
    return rows


def make_truth(doc_type: str, world: dict, rng: random.Random, pool: dict) -> tuple[dict, dict]:
    """Return (fields, extra) where extra holds the simulated arrival date."""
    p = rng.choice(world["patients"])
    prov = rng.choice(world["providers"])
    d = _rand_date(rng)
    f: dict = {}
    if doc_type == "enrollment":
        eff = d + timedelta(days=rng.randint(7, 60))
        f = {"application_date": d.isoformat(), "patient_name": p["name"], "dob": p["dob"], "gender": p["gender"], "address": p["address"],
             "phone": p["phone"], "email": p["email"] if rng.random() < .85 else None, "insurer": p["insurer"], "plan_name": p["plan_name"],
             "plan_type": p["plan_type"], "group_number": p["group_number"] if rng.random() < .8 else None, "member_id": p["member_id"],
             "employer": p["employer"], "dependents": rng.choice([0, 0, 1, 2, 3, 4]), "effective_date": eff.isoformat()}
    elif doc_type == "claim":
        surgical = rng.random() < .08
        codes = rng.sample([c for c in R.CPT if (R.CPT[c][1] > 5000) == surgical or not surgical and R.CPT[c][1] < 3000], rng.randint(1, 4) if not surgical else rng.randint(1, 2))
        lines = []
        for c in codes:
            units = rng.choice([1, 1, 1, 2])
            charge = round(R.CPT[c][1] * units * rng.uniform(.95, 1.1), 2)
            lines.append({"cpt": c, "description": R.CPT[c][0], "units": units, "charge": charge})
        f = {"claim_number": f"CLM{d.strftime('%y')}{rng.randint(0, 9999999):07d}", "patient_name": p["name"], "dob": p["dob"], "member_id": p["member_id"],
             "insurer": p["insurer"], "provider_name": prov["name"], "provider_npi": prov["npi"], "facility": prov["facility"],
             "service_date": d.isoformat(), "place_of_service": rng.choices(list(R.PLACE_OF_SERVICE), [55, 5, 25, 10, 5])[0],
             "diagnosis_codes": _dx(rng), "line_items": lines, "billed_amount": round(sum(l["charge"] for l in lines), 2)}
    elif doc_type == "referral":
        dx = _dx(rng, rng.choice([1, 1, 2]))
        urg = rng.choices(R.URGENCY, [70, 25, 5])[0]
        target = rng.choice(world["providers"])
        f = {"referral_id": f"REF{rng.randint(0, 99999999):08d}", "referral_date": d.isoformat(), "patient_name": p["name"], "dob": p["dob"],
             "member_id": p["member_id"], "insurer": p["insurer"], "referring_provider": prov["name"], "referring_npi": prov["npi"],
             "referred_to_provider": target["name"], "referred_to_specialty": rng.choice(R.SPECIALTIES), "urgency": urg, "diagnosis_codes": dx,
             "reason": narrative.referral_reason(pool, dx[0], rng),
             "authorization_number": f"AUTH{rng.randint(0, 99999999):08d}" if (urg != "Routine" or rng.random() < .4) else None}
    elif doc_type == "prescription":
        name, strengths, form, sig, qty = rng.choice(R.DRUGS)
        f = {"rx_number": f"RX{rng.randint(0, 99999999):08d}", "date_written": d.isoformat(), "patient_name": p["name"], "dob": p["dob"],
             "member_id": p["member_id"] if rng.random() < .8 else None, "prescriber_name": prov["name"], "prescriber_npi": prov["npi"],
             "drug_name": name, "strength": rng.choice(strengths), "dosage_form": form, "quantity": qty, "refills": rng.choice([0, 0, 1, 2, 3, 5, 11]),
             "directions": sig, "pharmacy_name": rng.choice(R.PHARMACIES) if rng.random() < .85 else None}
    elif doc_type == "lab_report":
        panel = rng.choice(list(R.LAB_PANELS))
        coll = d
        f = {"accession_number": f"ACC{rng.randint(0, 999999999):09d}", "lab_name": rng.choice(R.LABS), "patient_name": p["name"], "dob": p["dob"],
             "ordering_provider": prov["name"], "ordering_npi": prov["npi"], "specimen_type": rng.choice(R.SPECIMEN_TYPES),
             "collected_date": coll.isoformat(), "reported_date": (coll + timedelta(days=rng.randint(0, 3))).isoformat(),
             "panel_name": panel, "results": _lab_rows(rng, panel)}
    arrival_field = "application_date" if doc_type == "enrollment" else S.PRIMARY_DATE[doc_type]
    arrive = date.fromisoformat(f[arrival_field]) + timedelta(days=rng.choice([0, 0, 1, 1, 2]))
    arrive = min(arrive, config.REFERENCE_DATE - timedelta(days=1))
    hour, minute = rng.choices(range(7, 20), weights=[3, 6, 9, 10, 9, 7, 8, 9, 8, 6, 4, 2, 1])[0], rng.randint(0, 59)
    return f, {"received_at": datetime(arrive.year, arrive.month, arrive.day, hour, minute, rng.randint(0, 59)).isoformat() + "Z", "patient_key": p["member_id"]}


# ------------------------------------------------------------------------------------ defects


def inject_defect(doc_type: str, f: dict, rng: random.Random) -> str | None:
    """Mutate the fields so a validation rule SHOULD fire. Returns the defect code (the 'expected issue')."""
    specs = {x.name: x for x in S.SCHEMAS[doc_type]}
    npi_field = S.PROVIDER_FIELDS.get(doc_type, (None, None))[1]
    options = ["missing_required", "future_date", "bad_member_id"]
    if npi_field:
        options += ["invalid_npi", "dob_after_service"]
    if doc_type == "claim":
        options += ["invalid_icd", "amount_mismatch", "amount_mismatch"]
    if doc_type == "referral":
        options += ["invalid_icd"]
    if doc_type == "lab_report":
        options += ["flag_mismatch", "flag_mismatch"]
    if doc_type == "prescription":
        options += ["bad_refills"]
    if doc_type == "enrollment":
        options += ["bad_phone", "underage_dependents"]
    d = rng.choice(options)
    pd_field = S.PRIMARY_DATE[doc_type]
    if d == "missing_required":
        cand = [n for n in S.required_fields(doc_type) if n not in ("patient_name",) and f.get(n) not in (None, "")]
        f[rng.choice(cand)] = None
    elif d == "future_date":
        if doc_type == "enrollment":
            f["dob"] = (date(2027, 3, 1) + timedelta(days=rng.randint(0, 400))).isoformat()
        else:
            f[pd_field] = (config.REFERENCE_DATE + timedelta(days=rng.randint(40, 300))).isoformat()
            if doc_type == "lab_report":
                f["collected_date"] = f[pd_field]
    elif d == "bad_member_id":
        if f.get("member_id"):
            f["member_id"] = f["member_id"][:3] + f["member_id"][3:9]       # 6 digits instead of 9
        else:
            return inject_defect(doc_type, f, rng)
    elif d == "invalid_npi":
        n = f[npi_field]
        f[npi_field] = n[:9] + str((int(n[9]) + rng.randint(1, 8)) % 10)
    elif d == "dob_after_service":
        dt = date.fromisoformat(f[pd_field])
        f["dob"] = (dt + timedelta(days=rng.randint(30, 3000))).isoformat()
    elif d == "invalid_icd":
        codes = list(f["diagnosis_codes"])
        codes[0] = rng.choice(["ZZ9.99", "E1.1", "99.123", "I1O"])
        f["diagnosis_codes"] = codes
    elif d == "amount_mismatch":
        f["billed_amount"] = round(f["billed_amount"] * rng.choice([.5, .8, 1.2, 2.0]) + 7, 2)
    elif d == "flag_mismatch":
        row = rng.choice(f["results"])
        row["flag"] = "" if row["flag"] else "H"
    elif d == "bad_refills":
        f["refills"] = rng.choice([15, 20, 99])
    elif d == "bad_phone":
        f["phone"] = f["phone"][:-3]
    elif d == "underage_dependents":
        f["dependents"] = rng.choice([14, 18])
    return d


# ------------------------------------------------------------------------------------ edge cases


def make_edge_cases(out: Path, rng: random.Random) -> list[dict]:
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    out.mkdir(parents=True, exist_ok=True)
    items = []

    def pdf(name, lines):
        c = canvas.Canvas(str(out / name), pagesize=letter)
        y = 700
        for ln in lines:
            c.setFont("Helvetica", 12)
            c.drawString(60, y, ln)
            y -= 22
        c.save()

    for i in range(5):
        pdf(f"fax_cover_{i}.pdf", ["FAX COVER SHEET", f"To: Records Dept  Pages: {rng.randint(2, 9)}", "From: Front Desk", "Please deliver urgently.", "Confidential: if received in error, call us."])
        items.append({"file": f"fax_cover_{i}.pdf", "expect": "unknown"})
    for i in range(5):
        pdf(f"memo_{i}.pdf", ["INTERNAL MEMO", "Subject: Staff meeting moved to Thursday", "Please bring your reports."])
        items.append({"file": f"memo_{i}.pdf", "expect": "unknown"})
    for i in range(4):
        c = canvas.Canvas(str(out / f"blank_{i}.pdf"), pagesize=letter)
        c.showPage()
        c.save()
        items.append({"file": f"blank_{i}.pdf", "expect": "unknown"})
    for i in range(3):
        (out / f"corrupt_{i}.pdf").write_bytes(b"%PDF-1.4\n%%garbage" + bytes(rng.getrandbits(8) for _ in range(300)))
        items.append({"file": f"corrupt_{i}.pdf", "expect": "failed"})
    return items


# ------------------------------------------------------------------------------------ orchestration


def generate_all(out_dir: Path | None = None, per_type: int = config.DOCS_PER_TYPE, seed: int = config.DATASET_SEED,
                 scanned_ratio: float = 0.10, defect_ratio: float = 0.12, dup_per_type: int = 12,
                 use_azure_narrative: bool = True, types: list[str] | None = None,
                 progress: Callable[[int, int, str], None] | None = None, clean: bool = True) -> dict:
    t0 = time.time()
    out_dir = Path(out_dir or config.SYNTH_DIR)
    docs_dir = out_dir / "documents"
    if clean and docs_dir.exists():
        shutil.rmtree(docs_dir)
    docs_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    fake = Faker("en_US")
    Faker.seed(seed)
    world = build_world(rng, fake)
    pool = narrative.get_pool(rng, use_azure_narrative)
    types = types or S.DOC_TYPES
    total = per_type * len(types)
    answer_key, done = [], 0
    claim_numbers: list[str] = []

    for dt in types:
        (docs_dir / dt).mkdir(exist_ok=True)
        made: list[dict] = []
        n_dup = min(dup_per_type, per_type // 10)
        for i in range(per_type):
            doc_id = f"{ABBR[dt]}-{i + 1:04d}"
            fields, extra = make_truth(dt, world, rng, pool)
            defects: list[str] = []
            if dt == "claim" and claim_numbers and rng.random() < .02:
                fields["claim_number"] = rng.choice(claim_numbers)       # re-used claim number (different content)
                defects.append("duplicate_claim_number")
            elif rng.random() < defect_ratio:
                d = inject_defect(dt, fields, rng)
                if d:
                    defects.append(d)
            if dt == "claim":
                claim_numbers.append(fields["claim_number"])
            org = renderer.org_name(dt, fields, fields.get("facility") or rng.choice(R.FACILITIES))
            base = docs_dir / dt / f"{dt}_{i + 1:04d}"
            pdf_path = base.with_suffix(".pdf")

            # exact duplicates: the last n_dup docs of each type re-use the bytes of an earlier document
            if i >= per_type - n_dup and made:
                src = rng.choice([m for m in made if "duplicate_exact" not in m["meta"]["defects"]])
                shutil.copyfile(docs_dir / dt / src["file"], docs_dir / dt / (base.name + Path(src["file"]).suffix))
                entry = {"doc_id": doc_id, "doc_type": dt, "file": base.name + Path(src["file"]).suffix, "fields": src["fields"],
                         "meta": {**src["meta"], "defects": ["duplicate_exact"], "duplicate_of": src["doc_id"], "received_at": extra["received_at"]}}
                made.append(entry)
                answer_key.append(entry)
                done += 1
                continue

            meta = renderer.render(dt, fields, pdf_path, rng, org)
            fmt, level, final_file = "pdf_digital", 0.0, pdf_path
            if rng.random() < scanned_ratio:
                level = rng.choices([rng.uniform(.05, .25), rng.uniform(.25, .5), rng.uniform(.5, .8)], [55, 35, 10])[0]
                choice = rng.choices(["pdf_scan", "jpg", "tif"], [55, 25, 20])[0] if meta["pages"] == 1 else "pdf_scan"
                if choice == "pdf_scan":
                    noise.to_scanned_pdf(pdf_path, pdf_path, level, rng)
                else:
                    final_file = base.with_suffix(".jpg" if choice == "jpg" else ".tif")
                    noise.to_image_file(pdf_path, final_file, level, rng)
                    pdf_path.unlink()
                fmt = choice
            entry = {"doc_id": doc_id, "doc_type": dt, "file": final_file.name, "fields": fields,
                     "meta": {"format": fmt, "noise": round(level, 2), "defects": defects, "received_at": extra["received_at"],
                              "layout": meta["layout"], "font": meta["font"], "date_style": meta["date_style"], "pages": meta["pages"],
                              "title": meta["title"], "labels": meta["labels"]}}
            made.append(entry)
            answer_key.append(entry)
            done += 1
            if progress and done % 25 == 0:
                progress(done, total, dt)

    edge = make_edge_cases(out_dir / "edge_cases", rng)
    (out_dir / "answer_key.json").write_text(json.dumps(answer_key), encoding="utf-8")
    (out_dir / "edge_cases" / "edge_cases.json").write_text(json.dumps(edge, indent=1), encoding="utf-8")
    from collections import Counter
    manifest = {
        "generated_at": common.iso_now(), "seed": seed, "per_type": per_type, "total_documents": len(answer_key),
        "by_type": dict(Counter(a["doc_type"] for a in answer_key)), "by_format": dict(Counter(a["meta"]["format"] for a in answer_key)),
        "defect_counts": dict(Counter(d for a in answer_key for d in a["meta"]["defects"])),
        "layouts": dict(Counter(a["meta"]["layout"] for a in answer_key)),
        "narrative_source": pool["source"], "patients": len(world["patients"]), "providers": len(world["providers"]),
        "edge_cases": len(edge), "seconds": round(time.time() - t0, 1),
        "note": "All data is synthetic. Faker for identities, ReportLab for PDFs, Azure OpenAI optional for narrative text.",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    if progress:
        progress(total, total, "done")
    return manifest


def load_answer_key(out_dir: Path | None = None) -> dict[str, dict]:
    p = Path(out_dir or config.SYNTH_DIR) / "answer_key.json"
    if not p.exists():
        return {}
    return {a["file"]: a for a in json.loads(p.read_text(encoding="utf-8"))}
