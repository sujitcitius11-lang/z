"""Make a clean PDF look like a scan or a phone photo: rotation, blur, grain, speckles, JPEG artefacts.

noise level 0 (clean scan) .. 1 (very poor). Heavy levels are DELIBERATELY hard so OCR makes mistakes
and the validation / human-review path gets exercised.
"""
from __future__ import annotations

import io
import random

import numpy as np
from PIL import Image, ImageFilter

DPI = 200


def pdf_to_images(path, dpi: int = DPI) -> list[Image.Image]:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(str(path))
    imgs = [pdf[i].render(scale=dpi / 72).to_pil().convert("L") for i in range(len(pdf))]
    pdf.close()
    return imgs


def degrade(img: Image.Image, level: float, rng: random.Random) -> Image.Image:
    nprng = np.random.default_rng(rng.randint(0, 2**31))
    angle = rng.uniform(-0.4, 0.4) + rng.choice([-1, 1]) * level * rng.uniform(0.5, 2.6)
    img = img.rotate(angle, resample=Image.BICUBIC, expand=False, fillcolor=255)
    if level > 0.15:
        img = img.filter(ImageFilter.GaussianBlur(radius=0.2 + level * 1.0))
    arr = np.asarray(img, dtype=np.float32)
    arr = (arr - 128) * (1 - 0.35 * level) + 128 + rng.uniform(-12, 8) * level          # lower contrast / shade
    arr += nprng.normal(0, 4 + 22 * level, arr.shape)                                       # grain
    n_speckles = int(arr.size * 0.0004 * level * 5)
    if n_speckles:
        ys = nprng.integers(0, arr.shape[0], n_speckles)
        xs = nprng.integers(0, arr.shape[1], n_speckles)
        arr[ys, xs] = nprng.choice([0, 255], n_speckles)
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=int(60 - 22 * level))
    buf.seek(0)
    return Image.open(buf).convert("L")


def to_scanned_pdf(src_pdf, dst_pdf, level: float, rng: random.Random) -> int:
    imgs = [degrade(i, level, rng) for i in pdf_to_images(src_pdf)]
    imgs[0].save(str(dst_pdf), "PDF", resolution=DPI, save_all=True, append_images=imgs[1:], quality=55)
    return len(imgs)


def to_image_file(src_pdf, dst_path, level: float, rng: random.Random) -> None:
    img = degrade(pdf_to_images(src_pdf)[0], level, rng)
    if str(dst_path).lower().endswith((".jpg", ".jpeg")):
        img.save(str(dst_path), "JPEG", quality=int(60 - 20 * level))
    elif str(dst_path).lower().endswith((".tif", ".tiff")):
        img.save(str(dst_path), "TIFF", compression="jpeg", quality=int(55 - 20 * level))
    else:
        img.save(str(dst_path), "PNG", optimize=True)


# ----------------------------------------------------------------------------------------------- harder degradations (the "hard pack")
def phone_photo(img: Image.Image, rng: random.Random, level: float = 0.6) -> Image.Image:
    """A page photographed on a desk: perspective tilt, uneven lighting (shadow gradient), blur, JPEG."""
    w, h = img.size
    j = lambda m: rng.uniform(-m, m)
    d = 0.025 + 0.03 * level
    quad = (j(w * d), j(h * d), j(w * d), h - j(h * d) - h * 0.01, w - j(w * d), h - j(h * d), w - j(w * d), j(h * d))
    img = img.transform((w, h), Image.QUAD, quad, resample=Image.BICUBIC, fillcolor=235)
    arr = np.asarray(img, dtype=np.float32)
    yy, xx = np.mgrid[0:h, 0:w]
    ang = rng.uniform(0, 6.28)
    grad = (np.cos(ang) * xx / w + np.sin(ang) * yy / h)
    arr = arr * (1 - 0.30 * level * (grad - grad.min()) / (np.ptp(grad) + 1e-6)) + rng.uniform(-10, 4)
    arr += np.random.default_rng(rng.randint(0, 2**31)).normal(0, 6 + 14 * level, arr.shape)
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.5 + 0.9 * level))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=int(45 - 15 * level))
    buf.seek(0)
    return Image.open(buf).convert("L")


def fax(img: Image.Image, rng: random.Random, level: float = 0.5) -> Image.Image:
    """A fax: low resolution (~100 dpi), 1-bit black and white, horizontal streaks, dropouts."""
    w, h = img.size
    small = img.resize((int(w * 0.75), int(h * 0.75)), Image.BILINEAR)      # ~150 dpi (fax 'fine' mode is 204x196)
    arr = np.asarray(small, dtype=np.float32)
    nprng = np.random.default_rng(rng.randint(0, 2**31))
    arr += nprng.normal(0, 10 + 14 * level, arr.shape)
    for _ in range(int(1 + 5 * level)):                      # scan-line streaks
        y = int(nprng.integers(0, arr.shape[0]))
        arr[y:y + 1, :] -= nprng.uniform(30, 90)
    bw = (arr > rng.uniform(120, 160)).astype(np.uint8) * 255
    return Image.fromarray(bw).convert("1").convert("L")


def to_hard_file(src_pdf, dst_path, style: str, rng: random.Random, level: float = 0.6) -> int:
    """style: photo (single page JPEG) | fax (multi-page PDF) | lowres (multi-page PDF scanned at 100 dpi, heavy noise). -> pages"""
    from pathlib import Path
    dpi = 150 if style in ("fax", "lowres") else DPI
    pages = pdf_to_images(src_pdf, dpi=200)
    if style == "photo":
        out = [phone_photo(pages[0], rng, level)]
        out[0].save(str(dst_path), "JPEG", quality=40)
        return 1
    if style == "fax":
        out = [fax(p, rng, level) for p in pages]
    else:
        out = []
        for p in pages:
            q = p.resize((int(p.width * 0.75), int(p.height * 0.75)), Image.BILINEAR)
            out.append(degrade(q, min(0.75, level), rng))
    out[0].save(str(dst_path), "PDF", resolution=dpi, save_all=True, append_images=out[1:])
    return len(out)
