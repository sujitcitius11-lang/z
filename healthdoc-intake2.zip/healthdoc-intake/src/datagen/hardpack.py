"""The "hard pack": documents that are deliberately harder than the main dataset, plus multi-document PACKETS.

Why: on clean, labelled forms every OCR+extraction pipeline looks excellent. Real intake is messier, so this pack adds
  * a fourth layout (boxed form, labels WITHOUT colons)
  * phone photos (perspective tilt, shadows), faxes (100 dpi, 1-bit, streaks), low-resolution scans, heavy noise
  * long multi-page documents (claims with 14-26 lines, lab reports with 40+ rows)
  * packets: one file with 2-5 documents (a fax cover sheet, blank separator pages, two claims back to back, a 2-page claim inside ...)
Every file has an answer key, so accuracy and splitting are MEASURED (scripts/run_hardpack.py), not assumed.
"""
from __future__ import annotations

import json
import random
import shutil
from collections import Counter
from pathlib import Path

from faker import Faker
from pypdf import PdfReader, PdfWriter

import config
from src import common
from src import reference_data as R
from src import schemas as S
from src.datagen import narrative, noise, renderer
from src.datagen.generate import _lab_rows, build_world, inject_defect, make_truth

STYLES = [("digital", .25), ("photo", .25), ("fax", .20), ("lowres", .30)]


def _big_claim(f: dict, rng: random.Random) -> None:
    codes = rng.choices(list(R.CPT), k=rng.randint(28, 44))        # real claims repeat codes (different dates / units)
    lines = []
    for c in codes:
        units = rng.choice([1, 1, 2])
        lines.append({"cpt": c, "description": R.CPT[c][0], "units": units, "charge": round(R.CPT[c][1] * units * rng.uniform(.95, 1.1), 2)})
    f["line_items"] = lines
    f["billed_amount"] = round(sum(l["charge"] for l in lines), 2)


def _big_lab(f: dict, rng: random.Random) -> None:
    seen, rows = set(), []
    for panel in rng.sample(list(R.LAB_PANELS), len(R.LAB_PANELS)):
        for r in _lab_rows(rng, panel):
            if r["test"] not in seen:
                seen.add(r["test"])
                rows.append(r)
    f["results"] = rows
    f["panel_name"] = "Comprehensive Panel"


def _render(dt, fields, path, rng, layout):
    org = renderer.org_name(dt, fields, fields.get("facility") or rng.choice(R.FACILITIES))
    return renderer.render(dt, fields, path, rng, org, layout)


def _cover(path: Path, rng: random.Random):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=letter)
    y = 700
    for ln in ["FAX COVER SHEET", f"To: Records Dept   Pages: {rng.randint(3, 9)}", "From: Front Desk", "Please process urgently.", "Confidential: if received in error, call us."]:
        c.setFont("Helvetica", 12)
        c.drawString(60, y, ln)
        y -= 22
    c.save()


def _blank(path: Path):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=letter)
    c.showPage()
    c.save()


def generate_hard(out_dir: Path | None = None, per_type: int = 40, n_packets: int = 60, seed: int = 77) -> dict:
    out = Path(out_dir or config.DATA_DIR / "hard")
    if out.exists():
        shutil.rmtree(out)
    (out / "documents").mkdir(parents=True)
    (out / "packets").mkdir()
    tmp = out / "_tmp"
    tmp.mkdir()
    rng = random.Random(seed)
    fake = Faker("en_US")
    Faker.seed(seed)
    world = build_world(rng, fake, 200, 40)
    pool = narrative.get_pool(rng, False)
    key = []

    # ---------------------------------------------------------------- single hard documents
    for dt in S.DOC_TYPES:
        for i in range(per_type):
            fields, extra = make_truth(dt, world, rng, pool)
            if dt == "claim" and rng.random() < .30:
                _big_claim(fields, rng)
            if dt == "lab_report" and rng.random() < .30:
                _big_lab(fields, rng)
            defects = []
            if rng.random() < .10 and (d := inject_defect(dt, fields, rng)):
                defects.append(d)
            layout = rng.choices(["A", "B", "C", "D"], [.2, .2, .2, .4])[0]
            base = f"{dt}_hard_{i + 1:03d}"
            pdf = out / "documents" / f"{base}.pdf"
            meta = _render(dt, fields, pdf, rng, layout)
            style = rng.choices([s for s, _ in STYLES], [w for _, w in STYLES])[0]
            if style == "photo" and meta["pages"] > 1:
                style = "lowres"
            level = 0.0 if style == "digital" else round(rng.uniform(.4, .9), 2)
            final = pdf
            if style == "photo":
                final = pdf.with_suffix(".jpg")
                noise.to_hard_file(pdf, final, "photo", rng, level)
                pdf.unlink()
            elif style in ("fax", "lowres"):
                noise.to_hard_file(pdf, pdf, style, rng, level)
            key.append({"doc_id": base, "doc_type": dt, "file": final.name, "fields": fields,
                        "meta": {"format": "hard_" + style, "noise": level, "defects": defects, "received_at": extra["received_at"], "layout": layout,
                                 "pages": meta["pages"], "style": style}})
    (out / "answer_key.json").write_text(json.dumps(key), encoding="utf-8")

    # ---------------------------------------------------------------- packets
    pk = []
    scenarios = ["mixed", "mixed", "same_type_twice", "same_patient", "cover_first", "blank_between", "multipage_inside"]
    for n in range(n_packets):
        sc = rng.choice(scenarios)
        parts: list[dict] = []                  # {"kind", "doc_type", "fields", "pdf"}

        def add_doc(dt, patient_from=None, big=False):
            fields, _ = make_truth(dt, world, rng, pool)
            if patient_from:
                for k in ("patient_name", "dob", "member_id", "insurer"):
                    if k in fields and k in patient_from:
                        fields[k] = patient_from[k]
            if big and dt == "claim":
                _big_claim(fields, rng)
            f = tmp / f"p{n}_{len(parts)}.pdf"
            _render(dt, fields, f, rng, rng.choice(["A", "B", "C", "D"]))
            parts.append({"kind": "document", "doc_type": dt, "fields": fields, "pdf": f})
            return fields

        k = rng.randint(2, 4)
        if sc == "same_type_twice":
            dt = rng.choice(S.DOC_TYPES)
            add_doc(dt); add_doc(dt)
            if rng.random() < .5:
                add_doc(rng.choice(S.DOC_TYPES))
        elif sc == "same_patient":
            first = add_doc(rng.choice(["referral", "claim", "prescription"]))
            for dt in rng.sample([t for t in S.DOC_TYPES if t != parts[0]["doc_type"]], k - 1):
                add_doc(dt, patient_from=first)
        elif sc == "multipage_inside":
            add_doc("claim", big=True)
            for dt in rng.sample([t for t in S.DOC_TYPES if t != "claim"], k - 1):
                add_doc(dt)
            rng.shuffle(parts)
        else:
            for dt in rng.sample(S.DOC_TYPES, k):
                add_doc(dt)
        if sc == "cover_first":
            f = tmp / f"p{n}_cover.pdf"
            _cover(f, rng)
            parts.insert(0, {"kind": "document", "doc_type": "unknown", "fields": {}, "pdf": f})
        if sc == "blank_between" and len(parts) > 1:
            f = tmp / f"p{n}_blank.pdf"
            _blank(f)
            parts.insert(rng.randint(1, len(parts) - 1), {"kind": "blank", "doc_type": "unknown", "fields": {}, "pdf": f})
        w, page, segs = PdfWriter(), 0, []
        for pt in parts:
            r = PdfReader(str(pt["pdf"]))
            for pg in r.pages:
                w.add_page(pg)
            segs.append({"kind": pt["kind"], "doc_type": pt["doc_type"], "pages": [page, page + len(r.pages) - 1], "fields": pt["fields"]})
            page += len(r.pages)
        name = f"packet_{n + 1:03d}.pdf"
        raw = tmp / name
        with open(raw, "wb") as fh:
            w.write(fh)
        style = rng.choices(["digital", "scan", "fax"], [.5, .35, .15])[0]
        level = 0.0 if style == "digital" else round(rng.uniform(.15, .45), 2)
        dest = out / "packets" / name
        if style == "digital":
            shutil.copyfile(raw, dest)
        elif style == "scan":
            noise.to_scanned_pdf(raw, dest, level, rng)
        else:
            noise.to_hard_file(raw, dest, "fax", rng, level)
        pk.append({"file": name, "scenario": sc, "style": style, "noise": level, "pages": page, "segments": segs})
    (out / "packets.json").write_text(json.dumps(pk), encoding="utf-8")
    shutil.rmtree(tmp)
    manifest = {"documents": len(key), "packets": len(pk), "seed": seed, "styles": dict(Counter(a["meta"]["style"] for a in key)),
                "layouts": dict(Counter(a["meta"]["layout"] for a in key)), "multi_page_docs": sum(1 for a in key if a["meta"]["pages"] > 1),
                "packet_scenarios": dict(Counter(p["scenario"] for p in pk)), "packet_styles": dict(Counter(p["style"] for p in pk)),
                "generated_at": common.iso_now()}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    return manifest


def load_hard_key(out_dir: Path | None = None) -> dict[str, dict]:
    p = Path(out_dir or config.DATA_DIR / "hard") / "answer_key.json"
    return {a["file"]: a for a in json.loads(p.read_text(encoding="utf-8"))} if p.exists() else {}


def load_packets(out_dir: Path | None = None) -> list[dict]:
    p = Path(out_dir or config.DATA_DIR / "hard") / "packets.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
