"""Free-text snippets (referral reasons, lab comments).

Default: template pool built from the ICD-10 descriptions. If Azure OpenAI is configured and
`use_azure=True`, a pool of ~60 snippets is requested ONCE (not 2,500 calls: cost control) and cached in
data/synthetic/narrative_pool.json. The pool records which source produced it.
"""
from __future__ import annotations

import json
import random

import config
from src import reference_data as R


def _template_pool(rng: random.Random) -> dict:
    reasons = {}
    for code, desc in R.ICD10.items():
        reasons[code] = [t.format(dx=desc.lower()) for t in R.REFERRAL_REASON_TEMPLATES]
    return {"source": "templates", "referral_reasons": reasons, "lab_comments": R.LAB_COMMENTS}


def _azure_pool() -> dict | None:
    """Ask Azure OpenAI for realistic but fictional snippets. Returns None on any failure."""
    try:
        from src.providers.azure_clients import openai_client, openai_deployment
        client = openai_client()
        codes = list(R.ICD10.items())[:30]
        prompt = (
            "Write fictional, de-identified clinical referral reasons for a synthetic training dataset. "
            "For each ICD-10 code below give 2 different one-or-two sentence referral reasons (no names, no dates, "
            "no real patients). Also give 8 short laboratory report comments. Return JSON: "
            '{"referral_reasons": {"<code>": ["...", "..."]}, "lab_comments": ["..."]}\n'
            + "\n".join(f"{c}: {d}" for c, d in codes))
        resp = client.chat.completions.create(
            model=openai_deployment(), temperature=0.8, response_format={"type": "json_object"},
            messages=[{"role": "system", "content": "You create synthetic healthcare training text. Never include real people."},
                      {"role": "user", "content": prompt}])
        data = json.loads(resp.choices[0].message.content)
        data["source"] = "azure_openai"
        return data
    except Exception:
        return None


def get_pool(rng: random.Random, use_azure: bool = True) -> dict:
    cache = config.SYNTH_DIR / "narrative_pool.json"
    if use_azure and config.mode("openai") == "azure":
        if cache.exists():
            try:
                cached = json.loads(cache.read_text(encoding="utf-8"))
                if cached.get("source") == "azure_openai":
                    return cached
            except Exception:
                pass
        pool = _azure_pool()
        if pool:
            cache.write_text(json.dumps(pool, indent=1), encoding="utf-8")
            return pool
    return _template_pool(rng)


def referral_reason(pool: dict, code: str, rng: random.Random) -> str:
    options = pool["referral_reasons"].get(code) or next(iter(pool["referral_reasons"].values()))
    return rng.choice(options)
