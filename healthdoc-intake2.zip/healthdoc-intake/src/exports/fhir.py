"""FHIR R4 export: turn a processed document into a FHIR Bundle (type "collection") that Azure Health Data Services / any FHIR server can ingest.

   enrollment  -> Patient, Organization (insurer), Coverage
   claim       -> Patient, Practitioner, Organization, Claim (diagnoses + one item per CPT line)
   referral    -> Patient, Practitioner (requester + performer), ServiceRequest
   prescription-> Patient, Practitioner, MedicationRequest
   lab_report  -> Patient, Practitioner, DiagnosticReport + one Observation per result (value, reference range, H/L interpretation)

Honest limits: this is a faithful MAPPING of what was extracted, not a clinical-grade profile. Free-text drug names are not coded (no RxNorm lookup),
diagnoses use the ICD-10-CM system URI, procedures use the CPT system URI, labs are not LOINC-coded. Bundles are checked against the R4B model
in the tests (fhir.resources) but have not been posted to a real FHIR server.
"""
from __future__ import annotations

import uuid

ICD10 = "http://hl7.org/fhir/sid/icd-10-cm"
CPT = "http://www.ama-assn.org/go/cpt"
NPI = "http://hl7.org/fhir/sid/us-npi"
V2_INTERP = "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation"
_NS = uuid.UUID("6f1d2c9e-8a4b-4b8e-9f10-2d7a5c3e1b77")


def _id(doc_id: str, kind: str, extra: str = "") -> str:
    return str(uuid.uuid5(_NS, f"{doc_id}|{kind}|{extra}"))


def _val(fields: dict, name: str):
    x = fields.get(name)
    return x.get("value") if isinstance(x, dict) else x


def _human_name(full: str | None) -> list[dict]:
    if not full:
        return []
    clean = full.split(",")[0].strip()
    parts = clean.split()
    return [{"use": "official", "text": full, "family": parts[-1] if parts else clean, "given": parts[:-1]}] if len(parts) > 1 else [{"text": full}]


def _patient(doc_id: str, f: dict) -> dict | None:
    name = _val(f, "patient_name")
    if not name:
        return None
    p: dict = {"resourceType": "Patient", "id": _id(doc_id, "Patient"), "name": _human_name(name)}
    ident = []
    if _val(f, "member_id"):
        ident.append({"system": "urn:docintake:member-id", "value": str(_val(f, "member_id"))})
    if ident:
        p["identifier"] = ident
    if _val(f, "dob"):
        p["birthDate"] = str(_val(f, "dob"))[:10]
    g = (_val(f, "gender") or "").lower()
    if g in ("male", "female", "other", "unknown"):
        p["gender"] = g
    tel = []
    if _val(f, "phone"):
        tel.append({"system": "phone", "value": _val(f, "phone")})
    if _val(f, "email"):
        tel.append({"system": "email", "value": _val(f, "email")})
    if tel:
        p["telecom"] = tel
    if _val(f, "address"):
        p["address"] = [{"text": _val(f, "address")}]
    return p


def _practitioner(doc_id: str, role: str, name, npi) -> dict | None:
    if not name:
        return None
    r = {"resourceType": "Practitioner", "id": _id(doc_id, "Practitioner", role), "name": _human_name(name)}
    if npi:
        r["identifier"] = [{"system": NPI, "value": str(npi)}]
    return r


def _org(doc_id: str, role: str, name) -> dict | None:
    return {"resourceType": "Organization", "id": _id(doc_id, "Organization", role), "name": name} if name else None


def _ref(res: dict | None, display: str | None = None) -> dict | None:
    return {"reference": f"{res['resourceType']}/{res['id']}", **({"display": display} if display else {})} if res else None


def to_bundle(doc_id: str, doc_type: str, fields: dict) -> dict:
    f = fields
    res: list[dict] = []
    patient = _patient(doc_id, f)
    if patient:
        res.append(patient)
    pref = _ref(patient)

    if doc_type == "enrollment":
        payor = _org(doc_id, "payor", _val(f, "insurer"))
        if payor:
            res.append(payor)
        if patient and payor:
            cov = {"resourceType": "Coverage", "id": _id(doc_id, "Coverage"), "status": "active", "beneficiary": pref, "payor": [_ref(payor)],
                   "subscriberId": _val(f, "member_id") or None, "type": {"text": _val(f, "plan_type") or "plan"},
                   "class": [{"type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/coverage-class", "code": "plan"}]},
                              "value": _val(f, "plan_name") or "plan", "name": _val(f, "plan_name")}]}
            if _val(f, "group_number"):
                cov["class"].append({"type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/coverage-class", "code": "group"}]},
                                     "value": _val(f, "group_number")})
            if _val(f, "effective_date"):
                cov["period"] = {"start": str(_val(f, "effective_date"))[:10]}
            res.append({k: v for k, v in cov.items() if v is not None})

    elif doc_type == "claim":
        prov = _practitioner(doc_id, "billing", _val(f, "provider_name"), _val(f, "provider_npi"))
        payor = _org(doc_id, "payor", _val(f, "insurer"))
        res += [x for x in (prov, payor) if x]
        dx = _val(f, "diagnosis_codes") or []
        items = []
        for n, ln in enumerate(_val(f, "line_items") or [], 1):
            items.append({"sequence": n, "productOrService": {"coding": [{"system": CPT, "code": str(ln["cpt"]), "display": ln.get("description")}]},
                          "quantity": {"value": ln.get("units", 1)}, "net": {"value": ln.get("charge"), "currency": "USD"},
                          **({"diagnosisSequence": [1]} if dx else {})})
        if patient and prov and payor:
            claim = {"resourceType": "Claim", "id": _id(doc_id, "Claim"), "status": "active",
                     "type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/claim-type", "code": "professional"}]},
                     "use": "claim", "patient": pref, "created": str(_val(f, "service_date") or "")[:10] or "1970-01-01", "provider": _ref(prov),
                     "priority": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/processpriority", "code": "normal"}]},
                     "identifier": [{"system": "urn:docintake:claim-number", "value": str(_val(f, "claim_number"))}] if _val(f, "claim_number") else [],
                     "insurance": [{"sequence": 1, "focal": True, "coverage": {"display": str(_val(f, "insurer"))}}],
                     "diagnosis": [{"sequence": i + 1, "diagnosisCodeableConcept": {"coding": [{"system": ICD10, "code": c}]}} for i, c in enumerate(dx)],
                     "item": items, "total": {"value": _val(f, "billed_amount"), "currency": "USD"} if _val(f, "billed_amount") is not None else None}
            if _val(f, "service_date"):
                claim["billablePeriod"] = {"start": str(_val(f, "service_date"))[:10], "end": str(_val(f, "service_date"))[:10]}
            res.append({k: v for k, v in claim.items() if v not in (None, [])})

    elif doc_type == "referral":
        req = _practitioner(doc_id, "requester", _val(f, "referring_provider"), _val(f, "referring_npi"))
        perf = _practitioner(doc_id, "performer", _val(f, "referred_to_provider"), None)
        res += [x for x in (req, perf) if x]
        urg = {"Routine": "routine", "Urgent": "urgent", "Emergent": "stat", "Emergency": "stat", "ASAP": "asap"}.get(str(_val(f, "urgency")), "routine")
        if patient:
            sr = {"resourceType": "ServiceRequest", "id": _id(doc_id, "ServiceRequest"), "status": "active", "intent": "order", "priority": urg,
                  "subject": pref, "authoredOn": str(_val(f, "referral_date") or "")[:10] or None,
                  "code": {"text": f"Referral to {_val(f, 'referred_to_specialty') or 'specialist'}"},
                  "requester": _ref(req), "performer": [_ref(perf)] if perf else None,
                  "reasonCode": [{"coding": [{"system": ICD10, "code": c}]} for c in (_val(f, "diagnosis_codes") or [])] +
                                ([{"text": _val(f, "reason")}] if _val(f, "reason") else []),
                  "identifier": [{"system": "urn:docintake:referral-id", "value": str(_val(f, "referral_id"))}] if _val(f, "referral_id") else None}
            res.append({k: v for k, v in sr.items() if v not in (None, [])})

    elif doc_type == "prescription":
        pr = _practitioner(doc_id, "prescriber", _val(f, "prescriber_name"), _val(f, "prescriber_npi"))
        if pr:
            res.append(pr)
        if patient and _val(f, "drug_name"):
            med = f"{_val(f, 'drug_name')} {_val(f, 'strength') or ''} {_val(f, 'dosage_form') or ''}".strip()
            mr = {"resourceType": "MedicationRequest", "id": _id(doc_id, "MedicationRequest"), "status": "active", "intent": "order",
                  "medicationCodeableConcept": {"text": med}, "subject": pref, "authoredOn": str(_val(f, "date_written") or "")[:10] or None,
                  "requester": _ref(pr), "dosageInstruction": [{"text": _val(f, "directions")}] if _val(f, "directions") else None,
                  "dispenseRequest": {k: v for k, v in {"quantity": {"value": _val(f, "quantity")} if _val(f, "quantity") is not None else None,
                                                        "numberOfRepeatsAllowed": _val(f, "refills")}.items() if v is not None},
                  "identifier": [{"system": "urn:docintake:rx-number", "value": str(_val(f, "rx_number"))}] if _val(f, "rx_number") else None}
            res.append({k: v for k, v in mr.items() if v not in (None, [], {})})

    elif doc_type == "lab_report":
        orderer = _practitioner(doc_id, "orderer", _val(f, "ordering_provider"), _val(f, "ordering_npi"))
        if orderer:
            res.append(orderer)
        obs_refs = []
        for n, row in enumerate(_val(f, "results") or []):
            flag = (row.get("flag") or "").replace("N", "")
            o = {"resourceType": "Observation", "id": _id(doc_id, "Observation", str(n)), "status": "final",
                 "code": {"text": row["test"]}, "subject": pref,
                 "valueQuantity": {"value": row["value"], "unit": row.get("unit")},
                 "referenceRange": [{"low": {"value": row["ref_low"], "unit": row.get("unit")}, "high": {"value": row["ref_high"], "unit": row.get("unit")}}]}
            if _val(f, "collected_date"):
                o["effectiveDateTime"] = str(_val(f, "collected_date"))[:10]
            if flag:
                o["interpretation"] = [{"coding": [{"system": V2_INTERP, "code": flag}]}]
            if patient:
                res.append(o)
                obs_refs.append({"reference": f"Observation/{o['id']}"})
        if patient:
            dr = {"resourceType": "DiagnosticReport", "id": _id(doc_id, "DiagnosticReport"), "status": "final",
                  "code": {"text": _val(f, "panel_name") or "Laboratory report"}, "subject": pref,
                  "effectiveDateTime": str(_val(f, "collected_date") or "")[:10] or None, "issued": None,
                  "performer": [_ref(orderer)] if orderer else None, "result": obs_refs or None,
                  "identifier": [{"system": "urn:docintake:accession", "value": str(_val(f, "accession_number"))}] if _val(f, "accession_number") else None}
            if _val(f, "reported_date"):
                dr["issued"] = str(_val(f, "reported_date"))[:10] + "T00:00:00Z"
            res.append({k: v for k, v in dr.items() if v not in (None, [], {})})

    return {"resourceType": "Bundle", "id": _id(doc_id, "Bundle"), "type": "collection",
            "entry": [{"fullUrl": f"urn:uuid:{r['id']}", "resource": r} for r in res]}


def validate_bundle(bundle: dict) -> list[str]:
    """Structural check against the FHIR R4B model (needs `pip install fhir.resources`). Returns a list of problems (empty = valid)."""
    try:
        from fhir.resources.R4B.bundle import Bundle
    except ImportError:
        return ["fhir.resources is not installed: structural validation skipped"]
    try:
        Bundle.model_validate(bundle)
    except Exception as exc:
        return [str(exc)[:400]]
    ids = {f"{e['resource']['resourceType']}/{e['resource']['id']}" for e in bundle["entry"]}
    bad = []
    for e in bundle["entry"]:
        for ref in _refs(e["resource"]):
            if ref not in ids:
                bad.append(f"{e['resource']['resourceType']} points to {ref}, which is not in the bundle")
    return bad


def _refs(obj):
    if isinstance(obj, dict):
        r = obj.get("reference")
        if isinstance(r, str) and "/" in r and not r.startswith("urn:") and not r.startswith("http"):
            yield r
        for v in obj.values():
            yield from _refs(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _refs(v)
