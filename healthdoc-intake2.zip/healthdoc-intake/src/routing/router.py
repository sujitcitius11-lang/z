"""Routing: decide which workflow / team gets each document, with priority and an SLA clock.

The SAME decision table is implemented in the Azure Logic App (logic_apps/routing_workflow.json) as a Switch
action, so the cloud and the local simulation agree. Python decides the workflow (testable, versioned);
the Logic App performs the actions (notify, create task, update ticket).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

import config
from src import reference_data as R

WORKFLOWS = {
    "W-ENR": {"name": "Membership Enrollment", "team": "Membership Operations", "sla_hours": 48, "priority": "Normal"},
    "W-CLM": {"name": "Claims Adjudication", "team": "Claims Processing", "sla_hours": 72, "priority": "Normal"},
    "W-CLM-HV": {"name": "Senior Claims Review (high value)", "team": "Senior Claims Examiners", "sla_hours": 24, "priority": "High"},
    "W-REF": {"name": "Care Coordination", "team": "Care Coordination", "sla_hours": 24, "priority": "Normal"},
    "W-REF-URG": {"name": "Urgent Referral Desk", "team": "Urgent Referral Desk", "sla_hours": 4, "priority": "Critical"},
    "W-RX": {"name": "Pharmacy Services", "team": "Pharmacy Services", "sla_hours": 8, "priority": "Normal"},
    "W-LAB": {"name": "Clinical Lab Review", "team": "Clinical Laboratory Review", "sla_hours": 24, "priority": "Normal"},
    "W-LAB-CRIT": {"name": "Critical Lab Alert", "team": "Clinical Alert Nurse Line", "sla_hours": 2, "priority": "Critical"},
    "W-REVIEW": {"name": "Manual Review Queue", "team": "Data Quality Reviewers", "sla_hours": 8, "priority": "Normal"},
    "W-TRIAGE": {"name": "Manual Triage (unclassified)", "team": "Intake Triage", "sla_hours": 8, "priority": "Normal"},
    "W-DUP": {"name": "Duplicate (archived)", "team": "No action", "sla_hours": 0, "priority": "Low"},
    "W-DLQ": {"name": "Exceptions / Dead Letter", "team": "IT Operations", "sla_hours": 4, "priority": "High"},
}
DEFAULT_WORKFLOW = {"enrollment": "W-ENR", "claim": "W-CLM", "referral": "W-REF", "prescription": "W-RX", "lab_report": "W-LAB"}


@dataclass
class RouteDecision:
    workflow_id: str
    workflow_name: str
    team: str
    priority: str
    sla_hours: int
    reason: str
    intended_workflow_id: str | None = None      # where a reviewed document goes after approval
    sla_due_at: str | None = None
    actions: list[str] = field(default_factory=list)

    def to_dict(self):
        return self.__dict__.copy()


def has_critical_lab(results: list[dict] | None) -> bool:
    for r in results or []:
        lo, hi, v = r["ref_low"], r["ref_high"], r["value"]
        if v > hi * R.CRITICAL_FACTOR or v < lo * 0.5:
            return True
    return False


def target_workflow(doc_type: str, fields: dict) -> tuple[str, str]:
    """The workflow a CLEAN document of this kind goes to, and why."""
    v = {k: (x or {}).get("value") if isinstance(x, dict) else x for k, x in fields.items()}
    if doc_type == "claim" and isinstance(v.get("billed_amount"), (int, float)) and v["billed_amount"] >= config.HIGH_VALUE_CLAIM:
        return "W-CLM-HV", f"Billed amount {v['billed_amount']:,.2f} >= high-value threshold {config.HIGH_VALUE_CLAIM:,.0f}"
    if doc_type == "referral" and v.get("urgency") in ("Urgent", "Emergent"):
        return "W-REF-URG", f"Referral urgency is {v['urgency']}"
    if doc_type == "lab_report" and has_critical_lab(v.get("results")):
        return "W-LAB-CRIT", "Result far outside the reference range (critical value)"
    return DEFAULT_WORKFLOW.get(doc_type, "W-TRIAGE"), f"Standard route for {doc_type.replace('_', ' ')}"


def route(doc_type: str, fields: dict, status: str, review_reasons: list[str] | None = None,
          received_at: str | None = None) -> RouteDecision:
    intended = None
    if status == "FAILED":
        wid, reason = "W-DLQ", "Processing failed after retries"
    elif doc_type == "unknown":
        wid, reason = "W-TRIAGE", "Document type could not be determined"
    elif status == "NEEDS_REVIEW":
        wid, reason = "W-REVIEW", "; ".join(review_reasons or ["Needs human review"])
        intended, _ = target_workflow(doc_type, fields)
    else:
        wid, reason = target_workflow(doc_type, fields)
    w = WORKFLOWS[wid]
    start = datetime.fromisoformat(received_at.rstrip("Z")) if received_at else datetime.utcnow()
    actions = ["notify_team_email", "create_work_item"] + (["page_on_call"] if w["priority"] == "Critical" else []) + (["teams_message"] if w["priority"] in ("High", "Critical") else [])
    return RouteDecision(wid, w["name"], w["team"], w["priority"], w["sla_hours"], reason, intended,
                         (start + timedelta(hours=w["sla_hours"])).isoformat() + "Z", actions)
