"""Hand the routing decision to the Logic App.

Azure : HTTP POST to the Logic App's HTTP-request trigger (URL kept in Key Vault as LOGIC_APP_ROUTING_URL). The Logic
        App (logic_apps/routing_workflow.json) switches on workflow_id and sends the e-mail / Teams message / work item.
Local : the same actions are written to the WorkflowActions table (the "outbox") so you can see exactly what the Logic
        App WOULD have done.  Each action has a status: sent | simulated | failed.
"""
from __future__ import annotations

import json
import urllib.request

import config
from src import common
from src.storage.sql_store import SqlStore, get_sql

CHANNELS = {"notify_team_email": "email", "create_work_item": "azure-devops", "page_on_call": "pager", "teams_message": "teams"}


@common.retry()
def _post(url: str, payload: dict) -> int:
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status
    except urllib.error.HTTPError as exc:
        if exc.code in (429, 500, 502, 503, 504):
            raise common.TransientError(str(exc)) from exc
        raise


def dispatch(doc_id: str, route: dict, summary: dict, store: SqlStore | None = None) -> list[dict]:
    store = store or get_sql()
    payload = {"doc_id": doc_id, "workflow_id": route["workflow_id"], "workflow_name": route["workflow_name"], "team": route["team"],
               "priority": route["priority"], "sla_due_at": route["sla_due_at"], "reason": route["reason"], "actions": route["actions"],
               "summary": summary}                                  # summary holds NON-PHI facts (doc type, counts, amounts)
    live = config.mode("logic_apps") == "azure"
    results = []
    status_live = "sent"
    if live:
        try:
            _post(config.env("LOGIC_APP_ROUTING_URL"), payload)
        except Exception as exc:
            status_live = "failed"
            payload["error"] = str(exc)
    for a in route["actions"]:
        row = {"action_id": common.new_id("ACT-"), "ts": common.iso_now(), "doc_id": doc_id, "workflow_id": route["workflow_id"],
               "action_type": a, "target": route["team"], "status": status_live if live else "simulated", "channel": CHANNELS.get(a, a),
               "payload_json": json.dumps(payload)}
        store.insert("WorkflowActions", row)
        results.append(row)
    return results
