"""Relational store: Azure SQL Database in the cloud, SQLite on a laptop. SAME tables, SAME code.

The table definitions below are the single source of truth; DDL for both engines is generated from them
(`python scripts/export_sql_schema.py` writes sql/schema_azure.sql). Writes are portable: UPDATE-then-INSERT
instead of dialect-specific MERGE / INSERT OR REPLACE.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from typing import Any, Iterable

import config

# (column, type, extras).  types: text, int, real, ts (ISO string), json (text), bigint_auto
TABLES: dict[str, dict] = {
    "Documents": {"pk": ["doc_id"], "cols": [
        ("doc_id", "text"), ("file_name", "text"), ("blob_container", "text"), ("blob_name", "text"), ("sha256", "text"),
        ("source", "text"), ("doc_type", "text"), ("type_confidence", "real"), ("status", "text"), ("review_status", "text"),
        ("route_id", "text"), ("priority", "text"), ("received_at", "ts"), ("processed_at", "ts"), ("processing_ms", "int"),
        ("page_count", "int"), ("is_scanned", "int"), ("ocr_engine", "text"), ("extract_engine", "text"), ("ocr_confidence", "real"),
        ("doc_confidence", "real"), ("issue_count", "int"), ("error_count", "int"), ("warning_count", "int"), ("fallback_used", "int"),
        ("duplicate_of", "text"), ("patient_key", "text"), ("provider_name", "text"), ("provider_npi", "text"), ("insurer", "text"),
        ("primary_date", "text"), ("billed_amount", "real"), ("tokens_in", "int"), ("tokens_out", "int"), ("est_cost_usd", "real"),
        ("failure_reason", "text"),
        ("parent_doc_id", "text"), ("page_range", "text"), ("split_count", "int"), ("phi_masked_spans", "int"), ("cross_doc_flags", "int"),
    ], "idx": [("sha256",), ("status",), ("doc_type",), ("received_at",), ("blob_name",), ("parent_doc_id",), ("patient_key",), ("provider_npi",)]},
    "ExtractedFields": {"pk": ["doc_id", "field_name"], "cols": [
        ("doc_id", "text"), ("field_name", "text"), ("value_json", "json"), ("confidence", "real"), ("source", "text"), ("note", "text"),
        ("corrected_json", "json"), ("corrected_by", "text"),
    ], "idx": []},
    "ValidationIssues": {"pk": ["issue_id"], "cols": [
        ("issue_id", "auto"), ("doc_id", "text"), ("rule_id", "text"), ("severity", "text"), ("field_name", "text"), ("message", "text"),
        ("resolved", "int"),
    ], "idx": [("doc_id",), ("rule_id",)]},
    "Routing": {"pk": ["doc_id"], "cols": [
        ("doc_id", "text"), ("workflow_id", "text"), ("workflow_name", "text"), ("team", "text"), ("priority", "text"),
        ("sla_hours", "int"), ("sla_due_at", "ts"), ("reason", "text"), ("intended_workflow_id", "text"), ("created_at", "ts"),
        ("status", "text"),
    ], "idx": [("workflow_id",)]},
    "ReviewTasks": {"pk": ["task_id"], "cols": [
        ("task_id", "text"), ("doc_id", "text"), ("reason", "text"), ("assigned_to", "text"), ("status", "text"), ("created_at", "ts"),
        ("resolved_at", "ts"), ("reviewer", "text"), ("resolution_notes", "text"), ("fields_changed", "int"),
    ], "idx": [("doc_id",), ("status",)]},
    "AuditLog": {"pk": ["audit_id"], "cols": [
        ("audit_id", "auto"), ("ts", "ts"), ("doc_id", "text"), ("actor", "text"), ("action", "text"), ("detail_json", "json"),
        ("correlation_id", "text"),
    ], "idx": [("doc_id",), ("action",)]},
    "Events": {"pk": ["event_id"], "cols": [
        ("event_id", "text"), ("ts", "ts"), ("event_type", "text"), ("subject", "text"), ("doc_id", "text"), ("status", "text"),
        ("attempts", "int"), ("payload_json", "json"),
    ], "idx": [("status",)]},
    "DeadLetter": {"pk": ["dl_id"], "cols": [
        ("dl_id", "text"), ("ts", "ts"), ("doc_id", "text"), ("blob_name", "text"), ("stage", "text"), ("reason", "text"),
        ("attempts", "int"), ("status", "text"), ("payload_json", "json"),
    ], "idx": [("status",)]},
    "WorkflowActions": {"pk": ["action_id"], "cols": [
        ("action_id", "text"), ("ts", "ts"), ("doc_id", "text"), ("workflow_id", "text"), ("action_type", "text"), ("target", "text"),
        ("status", "text"), ("channel", "text"), ("payload_json", "json"),
    ], "idx": [("doc_id",)]},
    "ProcessingStages": {"pk": ["doc_id", "stage"], "cols": [
        ("doc_id", "text"), ("stage", "text"), ("ms", "int"), ("status", "text"), ("ts", "ts"),
    ], "idx": []},
    "Corrections": {"pk": ["corr_id"], "cols": [          # reviewer fixes = the training signal of the feedback loop
        ("corr_id", "auto"), ("ts", "ts"), ("doc_id", "text"), ("doc_type", "text"), ("field_name", "text"), ("read_value", "json"),
        ("corrected_value", "json"), ("confidence", "real"), ("source", "text"), ("reviewer", "text"), ("rule_ids", "text"),
        ("ocr_engine", "text"), ("applied_count", "int"),
    ], "idx": [("doc_type", "field_name"), ("doc_id",)]},
    "Telemetry": {"pk": ["tel_id"], "cols": [               # LOCAL stand-in for Application Insights custom events / metrics
        ("tel_id", "auto"), ("ts", "ts"), ("kind", "text"), ("name", "text"), ("doc_id", "text"), ("value", "real"), ("props_json", "json"),
    ], "idx": [("name",)], "local_only": True},
    "CosmosItems": {"pk": ["id"], "cols": [          # LOCAL stand-in for Azure Cosmos DB (not created in Azure SQL)
        ("id", "text"), ("doc_type", "text"), ("body", "json"), ("ts", "ts"),
    ], "idx": [("doc_type",)], "local_only": True},
}

_SQLITE_TYPES = {"text": "TEXT", "int": "INTEGER", "real": "REAL", "ts": "TEXT", "json": "TEXT", "auto": "INTEGER PRIMARY KEY AUTOINCREMENT"}
_TSQL_TYPES = {"text": "NVARCHAR(450)", "int": "BIGINT", "real": "FLOAT", "ts": "NVARCHAR(40)", "json": "NVARCHAR(MAX)", "auto": "BIGINT IDENTITY(1,1) PRIMARY KEY"}
_TSQL_LONG = {"reason", "message", "note", "failure_reason", "resolution_notes", "detail_json"}


def ddl_sqlite() -> list[str]:
    out = []
    for t, spec in TABLES.items():
        cols = []
        has_auto = any(c[1] == "auto" for c in spec["cols"])
        for name, typ in spec["cols"]:
            cols.append(f"{name} {_SQLITE_TYPES[typ]}")
        if not has_auto:
            cols.append(f"PRIMARY KEY ({', '.join(spec['pk'])})")
        out.append(f"CREATE TABLE IF NOT EXISTS {t} ({', '.join(cols)})")
        for i, ix in enumerate(spec["idx"]):
            out.append(f"CREATE INDEX IF NOT EXISTS ix_{t}_{'_'.join(ix)} ON {t} ({', '.join(ix)})")
    return out


def ddl_tsql() -> list[str]:
    out = []
    for t, spec in TABLES.items():
        if spec.get("local_only"):
            continue
        cols = []
        has_auto = any(c[1] == "auto" for c in spec["cols"])
        for name, typ in spec["cols"]:
            tt = "NVARCHAR(MAX)" if (typ == "text" and name in _TSQL_LONG) else _TSQL_TYPES[typ]
            if name in spec["pk"] and typ != "auto":
                tt += " NOT NULL"
            cols.append(f"[{name}] {tt}")
        if not has_auto:
            cols.append(f"CONSTRAINT PK_{t} PRIMARY KEY ({', '.join('[' + c + ']' for c in spec['pk'])})")
        out.append(f"IF OBJECT_ID(N'dbo.{t}', N'U') IS NULL CREATE TABLE dbo.{t} ({', '.join(cols)});")
        for ix in spec["idx"]:
            nm = f"ix_{t}_{'_'.join(ix)}"
            out.append(f"IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = '{nm}') CREATE INDEX {nm} ON dbo.{t} ({', '.join('[' + c + ']' for c in ix)});")
    return out


class SqlStore:
    """Thin portable data-access layer. Use `get_sql()` to obtain the right backend."""

    def __init__(self, backend: str | None = None):
        self.backend = backend or config.mode("sql")
        self._lock = threading.RLock()
        self._local = threading.local()
        self.init_schema()

    # --------------------------------------------------------------- connections
    def _conn(self):
        c = getattr(self._local, "conn", None)
        if c is None:
            if self.backend == "azure":
                import pyodbc
                c = pyodbc.connect(config.env("AZURE_SQL_CONNECTION_STRING"), autocommit=True)
            else:
                c = sqlite3.connect(config.SQLITE_PATH, timeout=60, check_same_thread=False, isolation_level=None)
                c.row_factory = sqlite3.Row
                c.execute("PRAGMA journal_mode=WAL")
                c.execute("PRAGMA synchronous=NORMAL")
                c.execute("PRAGMA busy_timeout=60000")
            self._local.conn = c
        return c

    def init_schema(self):
        stmts = ddl_sqlite() if self.backend == "local" else ddl_tsql()
        c = self._conn()
        is_index = lambda st: " INDEX " in st.upper().split("(")[0] or st.upper().startswith("IF NOT EXISTS (SELECT 1 FROM SYS.INDEXES")
        for st in stmts:
            if not is_index(st):
                c.execute(st)
        self._migrate(c)                     # old database + new columns, BEFORE the indexes that may use them
        for st in stmts:
            if is_index(st):
                c.execute(st)

    def _migrate(self, c):
        """Add columns that newer versions of the app need to a database created by an older version."""
        for t, spec in TABLES.items():
            if spec.get("local_only") and self.backend == "azure":
                continue
            if self.backend == "local":
                have = {r[1] for r in c.execute(f"PRAGMA table_info({t})").fetchall()}
                for name, typ in spec["cols"]:
                    if name not in have and typ != "auto":
                        c.execute(f"ALTER TABLE {t} ADD COLUMN {name} {_SQLITE_TYPES[typ]}")
            else:
                for name, typ in spec["cols"]:
                    if typ != "auto":
                        tt = "NVARCHAR(MAX)" if (typ == "text" and name in _TSQL_LONG) else _TSQL_TYPES[typ]
                        c.execute(f"IF COL_LENGTH('dbo.{t}', '{name}') IS NULL ALTER TABLE dbo.{t} ADD [{name}] {tt} NULL")

    # --------------------------------------------------------------- primitives
    def execute(self, sql: str, params: Iterable = ()) -> int:
        cur = self._conn().execute(sql, tuple(params))
        return cur.rowcount

    def query(self, sql: str, params: Iterable = ()) -> list[dict]:
        cur = self._conn().execute(sql, tuple(params))
        if self.backend == "azure":
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]
        return [dict(r) for r in cur.fetchall()]

    def one(self, sql: str, params: Iterable = ()) -> dict | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def df(self, sql: str, params: Iterable = ()):
        import pandas as pd
        return pd.DataFrame(self.query(sql, params))

    def scalar(self, sql: str, params: Iterable = (), default=None):
        r = self.one(sql, params)
        if not r:
            return default
        v = next(iter(r.values()))
        return default if v is None else v

    # --------------------------------------------------------------- helpers
    @staticmethod
    def _prep(row: dict) -> dict:
        return {k: (json.dumps(v, default=str) if isinstance(v, (dict, list)) else (int(v) if isinstance(v, bool) else v)) for k, v in row.items()}

    def insert(self, table: str, row: dict) -> int | None:
        row = self._prep(row)
        cols = list(row)
        sql = f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join('?' for _ in cols)})"
        cur = self._conn().execute(sql, tuple(row.values()))
        if self.backend == "local":
            return cur.lastrowid
        return None

    def upsert(self, table: str, row: dict, keys: list[str] | None = None):
        keys = keys or TABLES[table]["pk"]
        row = self._prep(row)
        sets = [c for c in row if c not in keys]
        where = " AND ".join(f"{k}=?" for k in keys)
        n = 0
        if sets:
            n = self.execute(f"UPDATE {table} SET {', '.join(c + '=?' for c in sets)} WHERE {where}", [row[c] for c in sets] + [row[k] for k in keys])
        if n <= 0:
            exists = self.one(f"SELECT 1 AS x FROM {table} WHERE {where}", [row[k] for k in keys])
            if not exists:
                self.insert(table, row)

    def delete(self, table: str, where: str, params: Iterable = ()):
        self.execute(f"DELETE FROM {table} WHERE {where}", params)

    def top(self, n: int) -> tuple[str, str]:
        """(prefix, suffix) to limit rows portably: SELECT {prefix} ... {suffix}"""
        return (f"TOP {int(n)}", "") if self.backend == "azure" else ("", f"LIMIT {int(n)}")

    # --------------------------------------------------------------- domain queries used by several modules
    def get_document(self, doc_id: str) -> dict | None:
        return self.one("SELECT * FROM Documents WHERE doc_id=?", [doc_id])

    def get_by_blob(self, blob_name: str) -> dict | None:
        return self.one("SELECT * FROM Documents WHERE blob_name=? ORDER BY received_at DESC", [blob_name])

    def get_by_hash(self, sha: str) -> dict | None:
        return self.one("SELECT * FROM Documents WHERE sha256=? AND status NOT IN ('DUPLICATE','FAILED','PROCESSING')", [sha])

    def identities_for_member(self, member_id: str, exclude_doc: str | None = None, limit: int = 25) -> list[dict]:
        """name + DOB printed on OTHER documents of the same member (uses the indexed patient_key hash of the member id)."""
        import hashlib
        key = hashlib.sha256(str(member_id).encode()).hexdigest()[:12]
        top, tail = self.top(limit)
        ids = [r["doc_id"] for r in self.query(f"SELECT {top} doc_id FROM Documents WHERE patient_key=? AND doc_id<>? AND status NOT IN ('DUPLICATE','FAILED','SPLIT') {tail}",
                                             [key, exclude_doc or ""])]
        out = []
        for d in ids:
            f = self.fields_of(d)
            out.append({"doc_id": d, "name": (f.get("patient_name") or {}).get("corrected") or (f.get("patient_name") or {}).get("value"),
                        "dob": (f.get("dob") or {}).get("corrected") or (f.get("dob") or {}).get("value")})
        return out

    def provider_names_for_npi(self, npi: str, exclude_doc: str | None = None, limit: int = 25) -> list[str]:
        top, tail = self.top(limit)
        rows = self.query(f"SELECT {top} provider_name FROM Documents WHERE provider_npi=? AND doc_id<>? AND provider_name IS NOT NULL "
                          f"AND status NOT IN ('DUPLICATE','FAILED','SPLIT') {tail}", [str(npi), exclude_doc or ""])
        return [r["provider_name"] for r in rows]

    def claim_number_exists(self, claim_number: str, exclude_doc: str | None = None) -> bool:
        r = self.one("SELECT COUNT(*) AS n FROM ExtractedFields f JOIN Documents d ON d.doc_id=f.doc_id "
                     "WHERE f.field_name='claim_number' AND f.value_json=? AND d.doc_id<>? AND d.status NOT IN ('DUPLICATE','FAILED','SPLIT')",
                     [json.dumps(claim_number), exclude_doc or ""])
        return bool(r and r["n"])

    def fields_of(self, doc_id: str) -> dict[str, dict]:
        out = {}
        for r in self.query("SELECT * FROM ExtractedFields WHERE doc_id=?", [doc_id]):
            val = json.loads(r["value_json"]) if r["value_json"] is not None else None
            cor = json.loads(r["corrected_json"]) if r.get("corrected_json") else None
            out[r["field_name"]] = {"value": val, "confidence": r["confidence"], "source": r["source"], "note": r["note"],
                                    "corrected": cor, "corrected_by": r["corrected_by"]}
        return out

    def reset_all(self):
        for t in TABLES:
            self.execute(f"DELETE FROM {t}")


_instance: SqlStore | None = None


def get_sql(fresh: bool = False) -> SqlStore:
    global _instance
    if _instance is None or fresh:
        _instance = SqlStore()
    return _instance
