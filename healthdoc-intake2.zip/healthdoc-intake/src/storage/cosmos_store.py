"""Document store for the RAW extraction JSON (OCR text, model answer, confidences, timings).

Why two databases?  Azure SQL holds the clean, structured, reportable facts (fast joins, Power BI).
Cosmos DB holds the flexible raw JSON whose shape can change between models/versions, partitioned by /doc_type.
Local mode keeps the same items in the SQLite table CosmosItems.
"""
from __future__ import annotations

import json

import config
from src import common


class CosmosStore:
    def __init__(self, backend: str | None = None):
        self.backend = backend or config.mode("cosmos")
        if self.backend == "azure":
            from azure.cosmos import CosmosClient, PartitionKey
            key = config.env("COSMOS_KEY")
            if key:
                client = CosmosClient(config.env("COSMOS_ENDPOINT"), credential=key)
            else:
                from src.providers.azure_clients import credential
                client = CosmosClient(config.env("COSMOS_ENDPOINT"), credential=credential())
            try:
                db = client.create_database_if_not_exists(config.COSMOS_DATABASE)
                self.container = db.create_container_if_not_exists(id=config.COSMOS_CONTAINER, partition_key=PartitionKey(path="/doc_type"))
            except Exception:
                # Cosmos DATA-PLANE RBAC (managed identity) cannot create databases/containers; infra/main.bicep creates them,
                # so just attach to the existing ones.
                self.container = client.get_database_client(config.COSMOS_DATABASE).get_container_client(config.COSMOS_CONTAINER)
        else:
            from src.storage.sql_store import get_sql
            self.sql = get_sql()

    def upsert(self, item: dict) -> None:
        """item needs `id` and `doc_type`."""
        item = {**item, "_ts_iso": common.iso_now()}
        if self.backend == "azure":
            self.container.upsert_item(item)
        else:
            self.sql.upsert("CosmosItems", {"id": item["id"], "doc_type": item["doc_type"], "body": json.dumps(item, default=str), "ts": item["_ts_iso"]})

    def get(self, item_id: str, doc_type: str) -> dict | None:
        if self.backend == "azure":
            try:
                return self.container.read_item(item_id, partition_key=doc_type)
            except Exception:
                return None
        r = self.sql.one("SELECT body FROM CosmosItems WHERE id=?", [item_id])
        return json.loads(r["body"]) if r else None

    def count(self, doc_type: str | None = None) -> int:
        if self.backend == "azure":
            q = "SELECT VALUE COUNT(1) FROM c" + (" WHERE c.doc_type=@t" if doc_type else "")
            params = [{"name": "@t", "value": doc_type}] if doc_type else []
            return next(iter(self.container.query_items(q, parameters=params, enable_cross_partition_query=True)), 0)
        if doc_type:
            return int(self.sql.scalar("SELECT COUNT(*) FROM CosmosItems WHERE doc_type=?", [doc_type], 0))
        return int(self.sql.scalar("SELECT COUNT(*) FROM CosmosItems", default=0))

    def delete(self, item_id: str, doc_type: str) -> None:
        if self.backend == "azure":
            try:
                self.container.delete_item(item_id, partition_key=doc_type)
            except Exception:
                pass
        else:
            self.sql.delete("CosmosItems", "id=?", [item_id])


_inst: CosmosStore | None = None


def get_cosmos(fresh: bool = False) -> CosmosStore:
    global _inst
    if _inst is None or fresh:
        _inst = CosmosStore()
    return _inst
