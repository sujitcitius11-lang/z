"""Blob storage: Azure Blob Storage in the cloud, a folder tree (data/blob/<container>/...) on a laptop.

Containers:  incoming -> (processed | review | quarantine)
The `incoming` container is the one Event Grid watches (BlobCreated events).
"""
from __future__ import annotations

import json
import mimetypes
import shutil
from pathlib import Path

import config


class LocalBlobStore:
    mode = "local"

    def __init__(self, root: Path | None = None):
        self.root = Path(root or config.BLOB_DIR)
        for c in config.BLOB_CONTAINERS.values():
            (self.root / c).mkdir(parents=True, exist_ok=True)

    def _p(self, container: str, name: str) -> Path:
        p = (self.root / container / name).resolve()
        if self.root.resolve() not in p.parents:
            raise ValueError("blob name escapes the container")
        return p

    def upload(self, container: str, name: str, data: bytes, metadata: dict | None = None, overwrite: bool = True) -> dict:
        p = self._p(container, name)
        if p.exists() and not overwrite:
            raise FileExistsError(name)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        if metadata:
            mp = self.root / "_meta" / container / (name + ".json")
            mp.parent.mkdir(parents=True, exist_ok=True)
            mp.write_text(json.dumps(metadata), encoding="utf-8")
        return {"container": container, "name": name, "size": len(data), "url": f"file://{p}",
                "content_type": mimetypes.guess_type(name)[0] or "application/octet-stream"}

    def download(self, container: str, name: str) -> bytes:
        p = self._p(container, name)
        if not p.exists():
            raise FileNotFoundError(f"{container}/{name}")
        return p.read_bytes()

    def metadata(self, container: str, name: str) -> dict:
        mp = self.root / "_meta" / container / (name + ".json")
        return json.loads(mp.read_text(encoding="utf-8")) if mp.exists() else {}

    def exists(self, container: str, name: str) -> bool:
        return self._p(container, name).exists()

    def list(self, container: str, prefix: str = "") -> list[dict]:
        base = self.root / container
        out = []
        for p in sorted(base.rglob("*")):
            if p.is_file():
                n = p.relative_to(base).as_posix()
                if n.startswith(prefix):
                    out.append({"name": n, "size": p.stat().st_size})
        return out

    def move(self, src_container: str, dst_container: str, name: str) -> None:
        src, dst = self._p(src_container, name), self._p(dst_container, name)
        if not src.exists():
            return
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        sm = self.root / "_meta" / src_container / (name + ".json")
        if sm.exists():
            dm = self.root / "_meta" / dst_container / (name + ".json")
            dm.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(sm), str(dm))

    def delete(self, container: str, name: str) -> None:
        p = self._p(container, name)
        if p.exists():
            p.unlink()

    def url(self, container: str, name: str) -> str:
        return f"file://{self._p(container, name)}"

    def count(self, container: str) -> int:
        return sum(1 for p in (self.root / container).rglob("*") if p.is_file())

    def reset(self):
        for c in config.BLOB_CONTAINERS.values():
            shutil.rmtree(self.root / c, ignore_errors=True)
            (self.root / c).mkdir(parents=True, exist_ok=True)
        shutil.rmtree(self.root / "_meta", ignore_errors=True)


class AzureBlobStore:
    mode = "azure"

    def __init__(self):
        from azure.storage.blob import BlobServiceClient
        cs = config.env("AZURE_STORAGE_CONNECTION_STRING")
        if cs:
            self.svc = BlobServiceClient.from_connection_string(cs)
        else:
            from src.providers.azure_clients import credential
            self.svc = BlobServiceClient(account_url=config.env("AZURE_STORAGE_ACCOUNT_URL"), credential=credential())
        for c in config.BLOB_CONTAINERS.values():
            cc = self.svc.get_container_client(c)
            if not cc.exists():
                cc.create_container()

    def _b(self, container, name):
        return self.svc.get_blob_client(container, name)

    def upload(self, container, name, data, metadata=None, overwrite=True):
        from azure.storage.blob import ContentSettings
        ct = mimetypes.guess_type(name)[0] or "application/octet-stream"
        b = self._b(container, name)
        b.upload_blob(data, overwrite=overwrite, metadata={k: str(v) for k, v in (metadata or {}).items()}, content_settings=ContentSettings(content_type=ct))
        return {"container": container, "name": name, "size": len(data), "url": b.url, "content_type": ct}

    def download(self, container, name):
        return self._b(container, name).download_blob().readall()

    def metadata(self, container, name):
        try:
            return dict(self._b(container, name).get_blob_properties().metadata or {})
        except Exception:
            return {}

    def exists(self, container, name):
        return self._b(container, name).exists()

    def list(self, container, prefix=""):
        cc = self.svc.get_container_client(container)
        return [{"name": b.name, "size": b.size} for b in cc.list_blobs(name_starts_with=prefix or None)]

    def move(self, src_container, dst_container, name):
        src, dst = self._b(src_container, name), self._b(dst_container, name)
        if not src.exists():
            return
        dst.start_copy_from_url(src.url)
        src.delete_blob()

    def delete(self, container, name):
        self._b(container, name).delete_blob()

    def url(self, container, name):
        return self._b(container, name).url

    def count(self, container):
        return sum(1 for _ in self.svc.get_container_client(container).list_blobs())

    def reset(self):
        for c in config.BLOB_CONTAINERS.values():
            for b in list(self.svc.get_container_client(c).list_blobs()):
                self.svc.get_container_client(c).delete_blob(b.name)


_inst = None


def get_blob(fresh: bool = False):
    global _inst
    if _inst is None or fresh:
        _inst = AzureBlobStore() if config.mode("blob") == "azure" else LocalBlobStore()
    return _inst
