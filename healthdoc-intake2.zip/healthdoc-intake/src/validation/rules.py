"""Validation rules. Every rule has an ID, a severity and a plain-English message.

error   -> the document cannot go straight to its workflow; a person must look at it
warning -> suspicious; two or more warnings also send the document to a person

Rule catalogue (also shown in the UI, "Workflows & Rules" page):
"""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from typing import Callable

import config
from src import common
from src import reference_data as R
from src import schemas as S

CATALOGUE = {
    "R001": ("error", "Required field is missing"),
    "R002": ("error", "Date cannot be read as a valid date"),
    "R003": ("error", "Document date is in the future"),
    "R004": ("error", "Date of birth is implausible (future or older than 120 years)"),
    "R005": ("error", "Service / issue date is before the patient's date of birth"),
    "R006": ("error", "NPI fails the check-digit test"),
    "R007": ("error", "ID does not match the expected format"),
    "R008": ("error", "ICD-10 code has an invalid format"),
    "R009": ("warning", "ICD-10 code is not in the reference list"),
    "R010": ("error", "CPT code has an invalid format"),
    "R011": ("error", "Total billed does not equal the sum of the service lines"),
    "R012": ("error", "Amount is zero, negative or unreadable"),
    "R013": ("error", "Lab flag does not agree with the reference range"),
    "R014": ("warning", "Printed reference range differs from the standard range for this test"),
    "R015": ("warning", "Lab panel is incomplete (fewer results than expected)"),
    "R016": ("error", "Refills outside 0-11"),
    "R017": ("error", "Quantity must be greater than zero"),
    "R018": ("error", "Phone or email format is invalid"),
    "R019": ("error", "Report date is before the collection date"),
    "R020": ("warning", "Effective date is before the application date"),
    "R021": ("warning", "Field was read with low confidence"),
    "R022": ("error", "Claim number already exists on a different claim"),
    "R023": ("warning", "Value is not one of the expected options"),
    "R024": ("warning", "Drug name not in the reference list"),
    "R025": ("error", "Number of dependents is implausible"),
    "R026": ("warning", "Billed amount is unusually large"),
    "R027": ("error", "Member ID belongs to a different patient name on another document (identity conflict)"),
    "R028": ("warning", "Same member and name, but a different date of birth on another document"),
    "R029": ("warning", "Provider NPI appears with a clearly different provider name on another document"),
}

CROSS_RULES = ("R027", "R028", "R029")


@dataclass
class Issue:
    rule_id: str
    severity: str
    field: str
    message: str

    def to_dict(self):
        return asdict(self)


def _issue(rule, field, extra=""):
    sev, msg = CATALOGUE[rule]
    return Issue(rule, sev, field, f"{msg}{': ' + extra if extra else ''}")


def _is_iso(v) -> date | None:
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


CHOICES = {
    "gender": set(R.GENDERS), "plan_type": set(R.PLAN_TYPES), "urgency": set(R.URGENCY),
    "referred_to_specialty": set(R.SPECIALTIES), "dosage_form": {d[2] for d in R.DRUGS}, "specimen_type": set(R.SPECIMEN_TYPES),
}
_KNOWN_DRUGS = {d[0].lower() for d in R.DRUGS}


def _name_sim(a, b) -> float:
    """Similarity of two person names, ignoring case, punctuation, titles and word order (OCR slips still count as 'same')."""
    import difflib
    clean = lambda x: " ".join(sorted(re.sub(r"\b(md|do|np|dr|mr|mrs|ms|phd|pa)\b", "", re.sub(r"[^a-z ]", " ", str(x).lower())).split()))
    return difflib.SequenceMatcher(None, clean(a), clean(b)).ratio()


def validate(doc_type: str, fields: dict[str, dict], claim_exists: Callable[[str], bool] | None = None,
             identity_lookup: Callable[[str], list[dict]] | None = None,
             provider_lookup: Callable[[str], list[str]] | None = None) -> list[Issue]:
    """fields: name -> {"value", "confidence"}.  Returns the list of issues (may be empty).
    identity_lookup(member_id) -> [{"name","dob"}] seen on OTHER documents; provider_lookup(npi) -> [provider names] seen on other documents.
    They switch on the cross-document rules R027-R029."""
    if doc_type not in S.SCHEMAS:
        return []
    today = config.REFERENCE_DATE
    v = {k: (x or {}).get("value") for k, x in fields.items()}
    issues: list[Issue] = []

    # R001 required
    for f in S.SCHEMAS[doc_type]:
        if f.required and v.get(f.name) in (None, "", []):
            issues.append(_issue("R001", f.name, f.display))

    # kind based checks
    for f in S.SCHEMAS[doc_type]:
        val = v.get(f.name)
        if val in (None, "", []):
            continue
        if f.kind == "date":
            d = _is_iso(val)
            if d is None:
                issues.append(_issue("R002", f.name, str(val)))
        elif f.kind == "npi" and not common.is_valid_npi(val):
            issues.append(_issue("R006", f.name, str(val)))
        elif f.kind == "id" and f.name in S.ID_PATTERNS and not re.match(S.ID_PATTERNS[f.name][2], str(val)):
            issues.append(_issue("R007", f.name, str(val)))
        elif f.kind == "icd_list":
            for c in val:
                if not re.match(S.ICD_REGEX, c):
                    issues.append(_issue("R008", f.name, c))
                elif c not in R.ICD10:
                    issues.append(_issue("R009", f.name, c))
        elif f.kind == "phone" and not re.match(S.PHONE_REGEX, str(val)):
            issues.append(_issue("R018", f.name, str(val)))
        elif f.kind == "email" and not re.match(S.EMAIL_REGEX, str(val)):
            issues.append(_issue("R018", f.name, str(val)))
        elif f.kind == "choice" and f.name in CHOICES and str(val) not in CHOICES[f.name]:
            issues.append(_issue("R023", f.name, str(val)))
        elif f.kind == "cpt_lines":
            for r in val:
                if not re.match(S.CPT_REGEX, str(r["cpt"])):
                    issues.append(_issue("R010", f.name, str(r["cpt"])))
        elif f.kind == "money" and (not isinstance(val, (int, float)) or val <= 0):
            issues.append(_issue("R012", f.name, str(val)))

    # dates and cross-field logic
    dob = _is_iso(v.get("dob"))
    if dob and (dob > today or (today - dob).days > 120 * 366):
        issues.append(_issue("R004", "dob", str(v.get("dob"))))
    pf = S.PRIMARY_DATE[doc_type]
    pdv = _is_iso(v.get(pf))
    if pdv:
        limit = today + timedelta(days=90) if doc_type == "enrollment" else today
        if pdv > limit:
            issues.append(_issue("R003", pf, str(v.get(pf))))
        if dob and doc_type != "enrollment" and pdv < dob:
            issues.append(_issue("R005", pf, f"{v.get(pf)} < DOB {v.get('dob')}"))
    if doc_type == "enrollment":
        app, eff = _is_iso(v.get("application_date")), _is_iso(v.get("effective_date"))
        if app and eff and eff < app:
            issues.append(_issue("R020", "effective_date"))
        if isinstance(v.get("dependents"), int) and v["dependents"] > 10:
            issues.append(_issue("R025", "dependents", str(v["dependents"])))
        if v.get("dependents") == 14 or v.get("dependents") == 18:
            pass
    if doc_type == "claim":
        lines, total = v.get("line_items") or [], v.get("billed_amount")
        if lines and isinstance(total, (int, float)) and abs(sum(l["charge"] for l in lines) - total) > 0.05:
            issues.append(_issue("R011", "billed_amount", f"printed {total:,.2f} vs lines {sum(l['charge'] for l in lines):,.2f}"))
        if isinstance(total, (int, float)) and total > 250000:
            issues.append(_issue("R026", "billed_amount", f"{total:,.2f}"))
        if v.get("place_of_service") and str(v["place_of_service"]) not in R.PLACE_OF_SERVICE:
            issues.append(_issue("R023", "place_of_service", str(v["place_of_service"])))
        cn = v.get("claim_number")
        if cn and claim_exists and claim_exists(cn):
            issues.append(_issue("R022", "claim_number", cn))
    if doc_type == "prescription":
        if isinstance(v.get("refills"), int) and not 0 <= v["refills"] <= 11:
            issues.append(_issue("R016", "refills", str(v["refills"])))
        if isinstance(v.get("quantity"), int) and v["quantity"] <= 0:
            issues.append(_issue("R017", "quantity"))
        if v.get("drug_name") and str(v["drug_name"]).lower() not in _KNOWN_DRUGS:
            issues.append(_issue("R024", "drug_name", str(v["drug_name"])))
    if doc_type == "lab_report":
        c, r_ = _is_iso(v.get("collected_date")), _is_iso(v.get("reported_date"))
        if c and r_ and r_ < c:
            issues.append(_issue("R019", "reported_date"))
        rows = v.get("results") or []
        for row in rows:
            lo, hi, val = row["ref_low"], row["ref_high"], row["value"]
            expect = "H" if val > hi else "L" if val < lo else ""
            if (row.get("flag") or "") != expect:
                issues.append(_issue("R013", "results", f"{row['test']} = {val} (range {lo}-{hi}) flag '{row.get('flag') or ''}'"))
            std = R.LAB_TESTS.get(row["test"])
            if std and (abs(std[1] - lo) > 1e-6 or abs(std[2] - hi) > 1e-6):
                issues.append(_issue("R014", "results", f"{row['test']}: {lo}-{hi} (standard {std[1]}-{std[2]})"))
        panel = v.get("panel_name")
        if panel in R.LAB_PANELS and rows and len(rows) < len(R.LAB_PANELS[panel]):
            issues.append(_issue("R015", "results", f"{len(rows)} of {len(R.LAB_PANELS[panel])} {panel} results found"))

    # ---- cross-document checks (the same person / provider must look the same everywhere)
    mid, pname = v.get("member_id"), v.get("patient_name")
    if identity_lookup and mid and pname:
        others = identity_lookup(str(mid)) or []
        if others:
            best = max(others, key=lambda o: _name_sim(pname, o.get("name") or ""))
            if _name_sim(pname, best.get("name") or "") < 0.6:
                issues.append(_issue("R027", "member_id", f"{mid} is also used by \"{best.get('name')}\""))
            elif v.get("dob") and best.get("dob") and str(best["dob"])[:10] != str(v["dob"])[:10]:
                issues.append(_issue("R028", "dob", f"{v['dob']} here, {str(best['dob'])[:10]} on another document"))
    pf = S.PROVIDER_FIELDS.get(doc_type)
    if provider_lookup and pf and v.get(pf[0]) and v.get(pf[1]):
        names = provider_lookup(str(v[pf[1]])) or []
        if names and max(_name_sim(v[pf[0]], n) for n in names) < 0.6:
            issues.append(_issue("R029", pf[1], f"NPI {v[pf[1]]} is also listed for \"{names[0]}\""))

    # R021 low confidence
    for name, x in fields.items():
        if x and x.get("value") not in (None, "", []) and x.get("confidence", 1) < config.FIELD_CONF_MIN:
            issues.append(_issue("R021", name, f"confidence {x['confidence']:.2f}"))
    # de-duplicate identical issues
    seen, out = set(), []
    for i in issues:
        k = (i.rule_id, i.field, i.message)
        if k not in seen:
            seen.add(k)
            out.append(i)
    return out


def decide_status(issues: list[Issue], type_confidence: float, doc_confidence: float, doc_type: str) -> tuple[str, list[str]]:
    """-> ('PASSED'|'NEEDS_REVIEW', reasons)"""
    reasons = []
    if doc_type == "unknown":
        return "NEEDS_REVIEW", ["Document type could not be determined"]
    errs = [i for i in issues if i.severity == "error"]
    warns = [i for i in issues if i.severity == "warning"]
    if errs:
        reasons.append(f"{len(errs)} validation error(s): " + ", ".join(sorted({i.rule_id for i in errs})))
    if len(warns) >= 2:
        reasons.append(f"{len(warns)} warnings: " + ", ".join(sorted({i.rule_id for i in warns})))
    if type_confidence < config.CLASSIFY_CONF_MIN:
        reasons.append(f"Low classification confidence ({type_confidence:.2f})")
    if doc_confidence < config.DOC_CONF_MIN:
        reasons.append(f"Low document confidence ({doc_confidence:.2f})")
    return ("NEEDS_REVIEW", reasons) if reasons else ("PASSED", [])


def document_confidence(fields: dict[str, dict], doc_type: str) -> float:
    """Mean confidence of the REQUIRED fields (a missing required field counts as 0)."""
    req = S.required_fields(doc_type)
    if not req:
        return 1.0
    vals = [(fields.get(n) or {}).get("confidence", 0.0) if (fields.get(n) or {}).get("value") not in (None, "", []) else 0.0 for n in req]
    return round(sum(vals) / len(vals), 4)
