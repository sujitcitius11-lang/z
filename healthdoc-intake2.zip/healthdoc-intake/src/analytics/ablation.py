"""Ablation study: what does each layer of the system actually add?

The same OCR text is fed to every variant, so differences come only from the layer being switched on.

  V1  OCR text + plain label matching              (no OCR-error repair, no fuzzy labels, no validation, everything passes)
  V2  + OCR-error repair and fuzzy label repair    (better reading, still no safety net)
  V3  + validation rules R001-R026                 (documents with an ERROR go to a person)
  V4  + confidence gating = the full system        (low classification / document confidence and 2+ warnings also go to a person)

Honest scope: with no Azure account the "reader" is the local engine. When Azure is configured the harness adds two more variants
(Document Intelligence + plain labels, Document Intelligence + Azure OpenAI) that need real calls; they are reported as "not run" otherwise.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

import config
from src import schemas as S
from src.analytics.evaluation import doc_wrong_fields
from src.providers import heuristic
from src.providers.ocr import get_ocr
from src.validation import rules


def _read(path: Path, ocr):
    r = ocr.analyze(path.read_bytes(), path.name)
    return r


def _extract(text, words, conf, repair: bool):
    heuristic.OPTIONS.update(fuzzy=repair, repair=repair, colonless=repair)
    try:
        dt, tconf, _ = heuristic.classify(text)
        fields = heuristic.extract(dt, text, words, conf) if dt != "unknown" else {}
        return dt, tconf, fields
    finally:
        heuristic.OPTIONS.update(fuzzy=True, repair=True, colonless=True)


def run(answer_key: dict[str, dict], sample_size: int = 300, seed: int = 11, docs_dir: Path | None = None) -> dict:
    docs_dir = docs_dir or config.SYNTH_DIR / "documents"
    rng = random.Random(seed)
    cand = [k for k, v in answer_key.items() if "duplicate_exact" not in v["meta"]["defects"]]
    # stratify: keep every format represented
    by_fmt: dict[str, list] = {}
    for k in cand:
        by_fmt.setdefault(answer_key[k]["meta"]["format"], []).append(k)
    sample = []
    for fmt, ks in by_fmt.items():
        rng.shuffle(ks)
        sample += ks[: max(1, round(sample_size * len(ks) / len(cand)))]
    ocr = get_ocr()
    stats = {n: {"fields": 0, "ok": 0, "docs": 0, "docs_ok": 0, "review": 0, "auto": 0, "silent": 0} for n in ("V1", "V2", "V3", "V4")}
    for fname in sample:
        a = answer_key[fname]
        path = docs_dir / a["doc_type"] / fname
        if not path.exists():
            continue
        o = _read(path, ocr)
        for v, repair in (("V1", False), ("V2", True)):
            dt, tconf, fields = _extract(o.text, o.words, o.avg_confidence, repair)
            res = {"file": fname, "doc_type": dt, "fields": fields}
            wrong = doc_wrong_fields(answer_key, res)
            n_truth = len([f for f in S.SCHEMAS[a["doc_type"]] if a["fields"].get(f.name) not in (None, "")])
            variants = [v] if v == "V1" else ["V2", "V3", "V4"]
            issues = rules.validate(dt, fields, claim_exists=lambda cn: False) if dt != "unknown" else []
            dconf = rules.document_confidence(fields, dt) if dt != "unknown" else 0.0
            for name in variants:
                s = stats[name]
                s["docs"] += 1
                s["fields"] += n_truth
                s["ok"] += max(n_truth - wrong, 0)
                s["docs_ok"] += int(wrong == 0)
                if name in ("V1", "V2"):
                    review = False
                elif name == "V3":
                    review = dt == "unknown" or any(i.severity == "error" for i in issues)
                else:
                    review = rules.decide_status(issues, tconf, dconf, dt)[0] == "NEEDS_REVIEW"
                s["review"] += int(review)
                if not review:
                    s["auto"] += 1
                    s["silent"] += int(wrong > 0)
    names = {"V1": "V1  OCR + plain label matching", "V2": "V2  + OCR-error repair & fuzzy labels", "V3": "V3  + validation rules (errors go to a person)",
             "V4": "V4  + confidence gating (full system)"}
    pct = lambda a, b: round(100 * a / b, 2) if b else None
    variants = [{"id": k, "name": names[k], "field_accuracy": pct(s["ok"], s["fields"]), "doc_exact": pct(s["docs_ok"], s["docs"]),
                 "review_rate": pct(s["review"], s["docs"]), "silent_error_rate": pct(s["silent"], s["auto"]), "documents": s["docs"],
                 "auto_passed": s["auto"], "silent_errors": s["silent"]} for k, s in stats.items()]
    not_run = []
    if config.mode("doc_intelligence") != "azure" or config.mode("openai") != "azure":
        not_run = ["V5 Document Intelligence + plain label matching", "V6 Document Intelligence + Azure OpenAI extraction (+ rules + gating)"]
    return {"sample_size": len(sample), "seed": seed, "variants": variants, "not_run": not_run}
