"""KPI calculations. The Streamlit Overview page, the tests and the Power BI DAX measures all use THESE definitions
(see powerbi/measures.dax, each measure notes the Python function it mirrors)."""
from __future__ import annotations

import config
from src.storage.sql_store import SqlStore, get_sql

AUTO_STATUSES = ("PASSED",)


def kpis(sql: SqlStore | None = None) -> dict:
    sql = sql or get_sql()
    d = sql.df("SELECT status, review_status, processing_ms, est_cost_usd, doc_confidence, type_confidence, is_scanned, issue_count, "
               "doc_type FROM Documents")
    if d.empty:
        return {"total": 0}
    total = len(d)
    unique = d[~d.status.isin(["DUPLICATE", "SPLIT"])]
    passed = d[d.status == "PASSED"]
    stp = d[(d.status == "PASSED") & (d.review_status == "none")]
    reviewed = d[d.review_status.isin(["approved", "approved_override", "corrected", "rejected", "pending"])]
    ms = unique[unique.processing_ms.notna()].processing_ms
    manual_hours = (len(unique) * config.MANUAL_MINUTES_PER_DOC) / 60
    actual_hours = (len(reviewed) * config.REVIEW_MINUTES_PER_DOC) / 60
    return {
        "total": total, "unique": len(unique),
        "passed": len(passed), "needs_review": int((d.status == "NEEDS_REVIEW").sum()), "failed": int((d.status == "FAILED").sum()),
        "duplicates": int((d.status == "DUPLICATE").sum()), "rejected": int((d.status == "REJECTED").sum()),
        "stp_rate": round(100 * len(stp) / max(len(unique), 1), 1),                  # straight-through processing
        "review_rate": round(100 * len(reviewed) / max(len(unique), 1), 1),
        "failure_rate": round(100 * (d.status == "FAILED").sum() / total, 1),
        "avg_processing_s": round(float(ms.mean()) / 1000, 2) if len(ms) else 0.0,
        "p95_processing_s": round(float(ms.quantile(.95)) / 1000, 2) if len(ms) else 0.0,
        "avg_doc_confidence": round(float(unique.doc_confidence.dropna().mean()), 3) if unique.doc_confidence.notna().any() else 0.0,
        "scanned_share": round(100 * float(unique.is_scanned.fillna(0).mean()), 1),
        "est_cost_usd": round(float(d.est_cost_usd.fillna(0).sum()), 2),
        "est_cost_per_doc_usd": round(float(d.est_cost_usd.fillna(0).sum()) / max(len(unique), 1), 4),
        "manual_hours_baseline": round(manual_hours, 1), "hours_with_automation": round(actual_hours, 1),
        "hours_saved": round(manual_hours - actual_hours, 1),
        "effort_reduction_pct": round(100 * (1 - actual_hours / manual_hours), 1) if manual_hours else 0.0,
    }


def volume_by_day(sql: SqlStore | None = None):
    sql = sql or get_sql()
    return sql.df("SELECT substr(received_at,1,10) AS day, doc_type, COUNT(*) AS docs FROM Documents "
                  "WHERE received_at IS NOT NULL GROUP BY substr(received_at,1,10), doc_type ORDER BY day") if (sql.backend == "local") else \
        sql.df("SELECT LEFT(received_at,10) AS day, doc_type, COUNT(*) AS docs FROM Documents WHERE received_at IS NOT NULL GROUP BY LEFT(received_at,10), doc_type ORDER BY day")


def sla_status(sql: SqlStore | None = None, as_of: str | None = None):
    """Open work items past / near their SLA clock, as of the reference date."""
    sql = sql or get_sql()
    as_of = as_of or config.REFERENCE_DATE.isoformat() + "T23:59:59Z"
    return sql.df("SELECT r.doc_id, r.workflow_id, r.workflow_name, r.team, r.priority, r.sla_due_at, d.doc_type, d.status "
                  "FROM Routing r JOIN Documents d ON d.doc_id=r.doc_id WHERE r.status='open' AND r.sla_due_at < ?", [as_of])
