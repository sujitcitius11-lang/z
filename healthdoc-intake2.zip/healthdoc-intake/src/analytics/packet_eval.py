"""Measure packet splitting against the packet answer key.

For every packet: did the system cut it where it should (page ranges), and did each part get the right type?
Boundary precision/recall treat every "a new document starts on page N" as one item to find.
Field accuracy on the parts is measured with the normal evaluator for parts whose page range matched exactly."""
from __future__ import annotations

from collections import defaultdict

from src.analytics.evaluation import evaluate, prf


def _parse(rng: str) -> tuple[int, int]:
    a = rng.lstrip("p").split("-")
    return int(a[0]) - 1, int(a[-1]) - 1


def evaluate_packets(packets: list[dict], sql) -> dict:
    exact = n = 0
    tp = fp = fn = 0
    parts_total = parts_range_ok = parts_type_ok = 0
    by_scn = defaultdict(lambda: [0, 0])
    by_style = defaultdict(lambda: [0, 0])
    pseudo_key, pseudo_res, misses = {}, [], []
    for pk in packets:
        n += 1
        parent = sql.one("SELECT doc_id, status FROM Documents WHERE file_name=?", [pk["file"]])
        kids = sql.query("SELECT d.doc_id, d.file_name, d.doc_type, d.type_confidence, d.status, d.page_range, d.doc_confidence, d.error_count "
                         "FROM Documents d WHERE d.parent_doc_id=? ORDER BY d.file_name", [parent["doc_id"]]) if parent else []
        pred = [(_parse(k["page_range"]), k) for k in kids if k["page_range"]]
        exp = [(tuple(s["pages"]), s) for s in pk["segments"] if s["kind"] == "document"]
        exp_starts = {e[0][0] for e in exp if e[0][0] > 0}
        pred_starts = {p[0][0] for p in pred if p[0][0] > 0}
        tp += len(exp_starts & pred_starts)
        fp += len(pred_starts - exp_starts)
        fn += len(exp_starts - pred_starts)
        ok = sorted(r for r, _ in pred) == sorted(r for r, _ in exp)
        exact += int(ok)
        by_scn[pk["scenario"]][0] += int(ok)
        by_scn[pk["scenario"]][1] += 1
        by_style[pk["style"]][0] += int(ok)
        by_style[pk["style"]][1] += 1
        if not ok and len(misses) < 40:
            misses.append({"file": pk["file"], "scenario": pk["scenario"], "style": pk["style"], "expected": [list(e[0]) for e in exp],
                           "got": [list(p[0]) for p in pred], "parent_status": parent["status"] if parent else None})
        pred_by_range = {r: k for r, k in pred}
        for rng_, seg in exp:
            parts_total += 1
            k = pred_by_range.get(rng_)
            if k:
                parts_range_ok += 1
                parts_type_ok += int(k["doc_type"] == seg["doc_type"])
                if seg["doc_type"] != "unknown":
                    fn_ = k["file_name"]
                    pseudo_key[fn_] = {"doc_type": seg["doc_type"], "fields": seg["fields"],
                                       "meta": {"defects": [], "format": "packet_" + pk["style"], "noise": pk["noise"]}}
                    flds = {r["field_name"]: r for r in sql.query("SELECT field_name, value_json, confidence FROM ExtractedFields WHERE doc_id=?", [k["doc_id"]])}
                    import json
                    pseudo_res.append({"file": fn_, "doc_type": k["doc_type"], "type_confidence": k["type_confidence"], "status": k["status"],
                                       "doc_confidence": k["doc_confidence"], "error_count": k["error_count"],
                                       "fields": {a: {"value": json.loads(b["value_json"]) if b["value_json"] else None, "confidence": b["confidence"] or 0} for a, b in flds.items()}})
    pct = lambda a, b: round(100 * a / b, 2) if b else None
    pr = tp / (tp + fp) if tp + fp else None
    rc = tp / (tp + fn) if tp + fn else None
    fields = evaluate(pseudo_key, pseudo_res) if pseudo_res else None
    return {"packets": n, "exact_split_rate": pct(exact, n), "boundary_precision": None if pr is None else round(100 * pr, 2),
            "boundary_recall": None if rc is None else round(100 * rc, 2),
            "boundary_f1": round(200 * pr * rc / (pr + rc), 2) if pr and rc else None,
            "parts_expected": parts_total, "parts_with_right_pages": pct(parts_range_ok, parts_total),
            "parts_with_right_type": pct(parts_type_ok, parts_range_ok), "by_scenario": {k: {"exact": pct(*v), "packets": v[1]} for k, v in by_scn.items()},
            "by_style": {k: {"exact": pct(*v), "packets": v[1]} for k, v in by_style.items()},
            "part_field_accuracy": fields["field_accuracy_overall"] if fields else None,
            "part_field_prf": prf(pseudo_key, pseudo_res)["overall"] if pseudo_res else None, "misses": misses}
