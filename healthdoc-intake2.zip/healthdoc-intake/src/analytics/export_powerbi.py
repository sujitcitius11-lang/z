"""Export the de-identified STAR SCHEMA that Power BI loads (CSV files in powerbi/data/).

De-identification: no patient name, DOB, address, phone, e-mail or member ID leaves the database. Patients are represented
by a one-way hashed `patient_key`. Provider NPIs/names are kept (providers are not patients).
Source: Azure SQL in the cloud (Power BI connects to it directly: see powerbi/queries/*.m) or the local SQLite file.
"""
from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

import config
from src import common
from src import schemas as S
from src.analytics.evaluation import compare_field
from src.reference_data import SPECIALTIES
from src.routing.router import WORKFLOWS
from src.storage.sql_store import SqlStore, get_sql
from src.validation.rules import CATALOGUE


def _fmt(row) -> str:
    return "Scanned / photo" if row else "Digital PDF"


def build_tables(sql: SqlStore | None = None, answer_key: dict | None = None) -> dict[str, pd.DataFrame]:
    sql = sql or get_sql()
    docs = sql.df("SELECT * FROM Documents")
    if docs.empty:
        raise RuntimeError("No processed documents yet. Run scripts/run_pipeline.py first.")
    docs["received_date"] = docs.received_at.str[:10]
    docs["date_key"] = docs.received_date.str.replace("-", "").astype(int)
    docs["processing_seconds"] = (docs.processing_ms.fillna(0) / 1000).round(3)
    docs["file_format"] = docs.is_scanned.fillna(0).astype(int).map(lambda x: _fmt(x))
    docs["auto_processed"] = ((docs.status == "PASSED") & (docs.review_status == "none")).astype(int)
    docs["sent_to_review"] = docs.review_status.isin(["pending", "approved", "approved_override", "corrected", "rejected"]).astype(int)
    docs["doc_type"] = docs.doc_type.fillna("unknown")
    rt = sql.df("SELECT doc_id, sla_hours, sla_due_at, status AS workflow_status FROM Routing")
    docs = docs.merge(rt, on="doc_id", how="left")
    fact = docs[["doc_id", "date_key", "doc_type", "route_id", "status", "file_format", "patient_key", "provider_npi", "insurer", "is_scanned",
                 "page_count", "ocr_confidence", "doc_confidence", "type_confidence", "processing_ms", "processing_seconds", "issue_count",
                 "error_count", "warning_count", "billed_amount", "est_cost_usd", "sla_hours", "sla_due_at", "received_at", "processed_at",
                 "auto_processed", "sent_to_review", "fallback_used", "duplicate_of", "workflow_status"]].rename(columns={"route_id": "workflow_id", "doc_type": "doc_type_key"})
    fact["insurer"] = fact.insurer.fillna("Unknown")
    fact["provider_npi"] = fact.provider_npi.fillna("")

    issues = sql.df("SELECT v.issue_id, v.doc_id, v.rule_id, v.severity, v.field_name, d.doc_type, SUBSTRING(d.received_at,1,10) AS d FROM ValidationIssues v JOIN Documents d ON d.doc_id=v.doc_id")
    if not issues.empty:
        issues["date_key"] = issues.d.str.replace("-", "").astype(int)
        issues = issues.rename(columns={"doc_type": "doc_type_key"}).drop(columns=["d"])
    stages = sql.df("SELECT doc_id, stage, ms FROM ProcessingStages")
    actions = sql.df("SELECT action_id, doc_id, workflow_id, action_type, channel, status FROM WorkflowActions")
    fields = sql.df("SELECT f.doc_id, f.field_name, f.confidence, CASE WHEN f.value_json IS NULL OR f.value_json='null' THEN 0 ELSE 1 END AS has_value, "
                    "CASE WHEN f.corrected_json IS NULL THEN 0 ELSE 1 END AS was_corrected, d.doc_type AS doc_type_key FROM ExtractedFields f JOIN Documents d ON d.doc_id=f.doc_id")

    tables = {"FactDocuments": fact, "FactValidationIssues": issues, "FactStageTimings": stages, "FactWorkflowActions": actions, "FactFieldConfidence": fields}

    # --- accuracy vs the answer key (only meaningful for synthetic data)
    if answer_key:
        rows = []
        flds = sql.df("SELECT f.doc_id, f.field_name, f.value_json, f.confidence FROM ExtractedFields f")
        by_doc = {k: g for k, g in flds.groupby("doc_id")}
        for _, d in docs.iterrows():
            key = answer_key.get(d.file_name)
            if not key or d.doc_type != key["doc_type"] or d.doc_id not in by_doc:
                continue
            fmt = key["meta"]["format"]
            for _, r in by_doc[d.doc_id].iterrows():
                truth = key["fields"].get(r.field_name)
                if truth in (None, ""):
                    continue
                got = json.loads(r.value_json) if r.value_json else None
                rows.append({"doc_id": d.doc_id, "field_name": r.field_name, "doc_type_key": d.doc_type, "correct": int(compare_field(d.doc_type, r.field_name, truth, got)),
                             "confidence": r.confidence, "source_format": fmt, "noise_band": "digital" if key["meta"]["noise"] == 0 else "light" if key["meta"]["noise"] < .25 else "medium" if key["meta"]["noise"] < .5 else "heavy"})
        tables["FactFieldAccuracy"] = pd.DataFrame(rows)

    # --- dimensions
    lo, hi = pd.to_datetime(docs.received_date.min()), pd.to_datetime(docs.received_date.max())
    dates = pd.date_range(lo - pd.Timedelta(days=lo.day - 1), hi + pd.offsets.MonthEnd(0))
    tables["DimDate"] = pd.DataFrame({"date_key": dates.strftime("%Y%m%d").astype(int), "date": dates.strftime("%Y-%m-%d"), "year": dates.year,
                                      "month_number": dates.month, "month": dates.strftime("%b"), "year_month": dates.strftime("%Y-%m"),
                                      "quarter": "Q" + dates.quarter.astype(str), "weekday": dates.strftime("%a"), "is_weekend": (dates.weekday >= 5).astype(int)})
    tables["DimDocType"] = pd.DataFrame([{"doc_type_key": k, "doc_type": v, "sort_order": i} for i, (k, v) in enumerate({**S.DOC_TYPE_LABELS, 'packet': 'Packet (split)'}.items(), 1)])
    tables["DimWorkflow"] = pd.DataFrame([{"workflow_id": k, **{kk: vv for kk, vv in v.items()}} for k, v in WORKFLOWS.items()]).rename(columns={"name": "workflow_name", "sla_hours": "sla_target_hours"})
    tables["DimStatus"] = pd.DataFrame([{"status": s, "is_final": 1, "sort_order": i, "group": g} for i, (s, g) in enumerate(
        [("PASSED", "Automated"), ("NEEDS_REVIEW", "Human"), ("REJECTED", "Human"), ("DUPLICATE", "Excluded"), ("SPLIT", "Excluded"), ("FAILED", "Exception")], 1)])
    prov = docs[docs.provider_npi.notna() & (docs.provider_npi != "")][["provider_npi", "provider_name"]].drop_duplicates("provider_npi")
    tables["DimProvider"] = pd.concat([prov, pd.DataFrame([{"provider_npi": "", "provider_name": "Not applicable / unreadable"}])], ignore_index=True)
    tables["DimProvider"]["npi_check_digit_ok"] = tables["DimProvider"].provider_npi.map(lambda n: int(common.is_valid_npi(n)))
    tables["DimInsurer"] = pd.DataFrame({"insurer": sorted(set(fact.insurer))})
    tables["DimRule"] = pd.DataFrame([{"rule_id": k, "severity": v[0], "description": v[1]} for k, v in CATALOGUE.items()])
    tables["DimFileFormat"] = pd.DataFrame({"file_format": ["Digital PDF", "Scanned / photo"]})
    return tables


RELATIONSHIPS = [  # (many table, column, one table, column)
    ("FactDocuments", "date_key", "DimDate", "date_key"), ("FactDocuments", "doc_type_key", "DimDocType", "doc_type_key"),
    ("FactDocuments", "workflow_id", "DimWorkflow", "workflow_id"), ("FactDocuments", "status", "DimStatus", "status"),
    ("FactDocuments", "provider_npi", "DimProvider", "provider_npi"), ("FactDocuments", "insurer", "DimInsurer", "insurer"),
    ("FactDocuments", "file_format", "DimFileFormat", "file_format"),
    ("FactValidationIssues", "doc_id", "FactDocuments", "doc_id"), ("FactValidationIssues", "rule_id", "DimRule", "rule_id"),
    ("FactStageTimings", "doc_id", "FactDocuments", "doc_id"), ("FactWorkflowActions", "doc_id", "FactDocuments", "doc_id"),
    ("FactFieldConfidence", "doc_id", "FactDocuments", "doc_id"), ("FactFieldAccuracy", "doc_id", "FactDocuments", "doc_id"),
]


def export_all(out_dir: Path | None = None, sql: SqlStore | None = None, answer_key: dict | None = None) -> dict:
    out_dir = Path(out_dir or config.POWERBI_DATA_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    if answer_key is None:
        from src.datagen.generate import load_answer_key
        answer_key = load_answer_key()
    tables = build_tables(sql, answer_key)
    for name, df in tables.items():
        df.to_csv(out_dir / f"{name}.csv", index=False, encoding="utf-8")
    schema = {"tables": {n: {"rows": int(len(df)), "columns": [{"name": c, "dtype": str(t)} for c, t in df.dtypes.items()]} for n, df in tables.items()},
              "relationships": [dict(zip(("from_table", "from_column", "to_table", "to_column"), r)) for r in RELATIONSHIPS if r[0] in tables and r[2] in tables]}
    (out_dir / "schema.json").write_text(json.dumps(schema, indent=1), encoding="utf-8")
    return {n: len(df) for n, df in tables.items()}
