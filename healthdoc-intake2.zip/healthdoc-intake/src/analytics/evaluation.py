"""Measure the system against the ANSWER KEY (the generator's ground truth).

Metrics: classification accuracy + confusion matrix, field-level accuracy (per type, per field, per scanned/digital),
confidence calibration (is a 0.95-confidence field really right 95 % of the time?), validation recall on injected defects.
"""
from __future__ import annotations

import re
from collections import defaultdict

from src import schemas as S


def _norm(kind: str, v):
    if v is None or v == "":
        return None
    try:
        if kind == "name" or kind in ("text", "choice"):
            return re.sub(r"[^a-z0-9]", "", str(v).lower())
        if kind == "date":
            return str(v)[:10]
        if kind == "money":
            return round(float(v), 2)
        if kind == "int":
            return int(v)
        if kind == "phone":
            return re.sub(r"\D", "", str(v))
        if kind == "npi":
            return re.sub(r"\D", "", str(v))
        if kind in ("id", "email"):
            return re.sub(r"[^A-Za-z0-9@.]", "", str(v)).upper()
        if kind == "icd_list":
            return [str(c).upper() for c in v]
        if kind == "cpt_lines":
            return [(str(r["cpt"]), int(r["units"]), round(float(r["charge"]), 2)) for r in v]
        if kind == "lab_rows":
            return [(re.sub(r"[^a-z0-9]", "", str(r["test"]).lower()), float(r["value"]), float(r["ref_low"]), float(r["ref_high"]),
                     (r.get("flag") or "").replace("N", "")) for r in v]
    except (ValueError, KeyError, TypeError):
        return ("__unparseable__", str(v))
    return str(v)


def compare_field(doc_type: str, name: str, truth, got) -> bool:
    f = S.field_spec(doc_type, name)
    return _norm(f.kind, truth) == _norm(f.kind, got)


def evaluate(answer_key: dict[str, dict], results: list[dict]) -> dict:
    """answer_key: file -> entry.   results: list of {file, doc_type, type_confidence, fields:{name:{value,confidence}}, status, issues:[codes]}"""
    cls_total = cls_ok = 0
    confusion: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    per_type = defaultdict(lambda: [0, 0])
    per_field = defaultdict(lambda: [0, 0])
    per_format = defaultdict(lambda: [0, 0])
    per_noise = defaultdict(lambda: [0, 0])
    calib = defaultdict(lambda: [0, 0])
    spurious = 0
    errors = []
    defect_total = defect_flagged = 0
    defect_by = defaultdict(lambda: [0, 0])
    clean_total = clean_review = 0
    for r in results:
        key = answer_key.get(r["file"])
        if not key or "duplicate_exact" in key["meta"]["defects"] and r.get("status") == "DUPLICATE":
            continue
        t = key["doc_type"]
        cls_total += 1
        confusion[t][r["doc_type"]] += 1
        if r["doc_type"] == t:
            cls_ok += 1
        fmt = key["meta"]["format"]
        noise_band = "digital" if key["meta"]["noise"] == 0 else "light" if key["meta"]["noise"] < .3 else "medium" if key["meta"]["noise"] < .6 else "heavy"
        if r["doc_type"] == t:
            for f in S.SCHEMAS[t]:
                truth = key["fields"].get(f.name)
                got = r["fields"].get(f.name, {})
                gv, gc = got.get("value"), got.get("confidence", 0)
                if truth in (None, ""):
                    if gv not in (None, ""):
                        spurious += 1
                    continue
                ok = compare_field(t, f.name, truth, gv)
                for d in (per_type[t], per_field[(t, f.name)], per_format[fmt], per_noise[noise_band]):
                    d[0] += int(ok)
                    d[1] += 1
                band = min(int(gc * 10), 9) / 10
                calib[band][0] += int(ok)
                calib[band][1] += 1
                if not ok and len(errors) < 300:
                    errors.append({"file": r["file"], "doc_type": t, "field": f.name, "truth": truth, "got": gv, "confidence": gc, "format": fmt})
        defects = [d for d in key["meta"]["defects"] if d != "duplicate_exact"]
        needs = r.get("status") in ("NEEDS_REVIEW", "FAILED")
        if defects:
            defect_total += 1
            defect_flagged += int(needs)
            for d in defects:
                defect_by[d][0] += int(needs)
                defect_by[d][1] += 1
        elif r.get("status") not in ("DUPLICATE",):
            clean_total += 1
            clean_review += int(needs)

    pct = lambda a: round(100 * a[0] / a[1], 2) if a[1] else None
    return {
        "documents_evaluated": cls_total,
        "classification_accuracy": round(100 * cls_ok / cls_total, 2) if cls_total else None,
        "confusion": {k: dict(v) for k, v in confusion.items()},
        "field_accuracy_overall": pct([sum(v[0] for v in per_type.values()), sum(v[1] for v in per_type.values())]),
        "field_accuracy_by_type": {k: pct(v) for k, v in per_type.items()},
        "field_accuracy_by_field": {f"{k[0]}.{k[1]}": pct(v) for k, v in per_field.items()},
        "field_accuracy_by_format": {k: pct(v) for k, v in per_format.items()},
        "field_accuracy_by_noise": {k: pct(v) for k, v in per_noise.items()},
        "calibration": {f"{k:.1f}-{k + .1:.1f}": {"accuracy": pct(v), "fields": v[1]} for k, v in sorted(calib.items())},
        "spurious_fields": spurious,
        "defect_documents": defect_total,
        "defect_detection_rate": round(100 * defect_flagged / defect_total, 2) if defect_total else None,
        "defect_detection_by_type": {k: {"flagged": v[0], "total": v[1]} for k, v in defect_by.items()},
        "clean_documents": clean_total,
        "false_review_rate": round(100 * clean_review / clean_total, 2) if clean_total else None,
        "errors": errors,
    }


# ====================================================================================================== precision / recall / F1
def prf(answer_key: dict[str, dict], results: list[dict]) -> dict:
    """Precision, recall and F1 for every (document type, field).

    For one field on one document with a known answer:
      * predicted something right          -> TP
      * predicted something wrong          -> FP and FN (we said a wrong thing AND missed the right one)
      * predicted nothing                  -> FN
    A value predicted where the answer key has nothing is an FP.  A document classified as the wrong type
    contributes FN for every field of its REAL type (nothing was read from it correctly).
    Also reports document-level exact match (every field of the document right) per type.
    """
    c = defaultdict(lambda: [0, 0, 0])               # (type, field) -> TP, FP, FN
    doc_ok = defaultdict(lambda: [0, 0])
    for r in results:
        key = answer_key.get(r["file"])
        if not key or "duplicate_exact" in key["meta"]["defects"]:
            continue
        t = key["doc_type"]
        right_type = r["doc_type"] == t
        all_ok = right_type
        for f in S.SCHEMAS[t]:
            truth = key["fields"].get(f.name)
            got = (r["fields"].get(f.name) or {}).get("value") if right_type else None
            has_truth, has_got = truth not in (None, ""), got not in (None, "", [])
            cell = c[(t, f.name)]
            if has_truth and has_got:
                if compare_field(t, f.name, truth, got):
                    cell[0] += 1
                else:
                    cell[1] += 1
                    cell[2] += 1
                    all_ok = False
            elif has_truth:
                cell[2] += 1
                all_ok = False
            elif has_got:
                cell[1] += 1
                all_ok = False
        doc_ok[t][0] += int(all_ok)
        doc_ok[t][1] += 1

    def metrics(tp, fp, fn):
        p = tp / (tp + fp) if tp + fp else None
        rc = tp / (tp + fn) if tp + fn else None
        f1 = 2 * p * rc / (p + rc) if p and rc else (0.0 if (p is not None and rc is not None) else None)
        return {"tp": tp, "fp": fp, "fn": fn, "precision": None if p is None else round(100 * p, 2),
                "recall": None if rc is None else round(100 * rc, 2), "f1": None if f1 is None else round(100 * f1, 2)}

    per_field = {f"{t}.{n}": metrics(*v) for (t, n), v in c.items()}
    per_type = {}
    for t in S.DOC_TYPES:
        tp = sum(v[0] for (tt, _), v in c.items() if tt == t)
        fp = sum(v[1] for (tt, _), v in c.items() if tt == t)
        fn = sum(v[2] for (tt, _), v in c.items() if tt == t)
        m = metrics(tp, fp, fn)
        f1s = [per_field[f"{t}.{n}"]["f1"] for (tt, n) in c if tt == t and per_field[f"{t}.{n}"]["f1"] is not None]
        m["macro_f1"] = round(sum(f1s) / len(f1s), 2) if f1s else None
        m["doc_exact_match"] = round(100 * doc_ok[t][0] / doc_ok[t][1], 2) if doc_ok[t][1] else None
        per_type[t] = m
    TP, FP, FN = (sum(v[i] for v in c.values()) for i in range(3))
    overall = metrics(TP, FP, FN)
    allf1 = [m["f1"] for m in per_field.values() if m["f1"] is not None]
    overall["macro_f1"] = round(sum(allf1) / len(allf1), 2) if allf1 else None
    return {"overall": overall, "per_type": per_type, "per_field": per_field}


def doc_wrong_fields(answer_key: dict, r: dict) -> int:
    """How many fields of this result disagree with the answer key (a wrong type counts every field)."""
    key = answer_key.get(r["file"])
    if not key:
        return 0
    t = key["doc_type"]
    if r["doc_type"] != t:
        return len([f for f in S.SCHEMAS[t] if key["fields"].get(f.name) not in (None, "")])
    n = 0
    for f in S.SCHEMAS[t]:
        truth = key["fields"].get(f.name)
        got = (r["fields"].get(f.name) or {}).get("value")
        if truth in (None, ""):
            n += int(got not in (None, "", []))
        elif not compare_field(t, f.name, truth, got):
            n += 1
    return n


def threshold_sweep(answer_key: dict, results: list[dict]) -> dict:
    """How do the two review thresholds trade work against risk?

    field_sweep : for a field-confidence cut-off t, share of fields at/above t ("coverage") and how many of them were right.
    doc_sweep   : for a document-confidence cut-off t, a document goes straight through when it has no validation error and
                  doc_confidence >= t.  Reports the straight-through rate and the SILENT ERROR rate = straight-through documents
                  that still contain at least one wrong field (the number a client really cares about).
    Needs results[i]['doc_confidence'] and ['error_count']."""
    cuts = [0.0, 0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98]
    fields = []                                      # (confidence, correct)
    docs = []                                        # (doc_conf, errors, wrong_fields)
    for r in results:
        key = answer_key.get(r["file"])
        if not key or "duplicate_exact" in key["meta"]["defects"] or r.get("status") == "DUPLICATE":
            continue
        t = key["doc_type"]
        if r["doc_type"] == t:
            for f in S.SCHEMAS[t]:
                truth = key["fields"].get(f.name)
                if truth in (None, ""):
                    continue
                g = r["fields"].get(f.name) or {}
                fields.append((g.get("confidence", 0.0), compare_field(t, f.name, truth, g.get("value"))))
        docs.append((r.get("doc_confidence", 0.0) or 0.0, r.get("error_count", 0) or 0, doc_wrong_fields(answer_key, r)))
    fs, ds = [], []
    for t in cuts:
        sel = [ok for conf, ok in fields if conf >= t]
        fs.append({"cutoff": t, "coverage": round(100 * len(sel) / len(fields), 2) if fields else None,
                   "accuracy_of_kept": round(100 * sum(sel) / len(sel), 2) if sel else None,
                   "wrong_fields_kept": len(sel) - sum(sel)})
        auto = [(e, w) for dc, e, w in docs if e == 0 and dc >= t]
        ds.append({"cutoff": t, "straight_through": round(100 * len(auto) / len(docs), 2) if docs else None,
                   "silent_error_rate": round(100 * sum(1 for _, w in auto if w) / len(auto), 2) if auto else None,
                   "silent_error_docs": sum(1 for _, w in auto if w), "sent_to_review": len(docs) - len(auto)})
    return {"field_sweep": fs, "doc_sweep": ds, "current_field_min": __import__("config").FIELD_CONF_MIN, "current_doc_min": __import__("config").DOC_CONF_MIN}


def group_accuracy(answer_key: dict, results: list[dict], keyfn) -> dict:
    """Field accuracy grouped by any property of the answer-key entry, e.g. keyfn=lambda k: k['meta']['layout']."""
    g = defaultdict(lambda: [0, 0])
    for r in results:
        key = answer_key.get(r["file"])
        if not key:
            continue
        t = key["doc_type"]
        grp = keyfn(key)
        for f in S.SCHEMAS[t]:
            truth = key["fields"].get(f.name)
            if truth in (None, ""):
                continue
            ok = r["doc_type"] == t and compare_field(t, f.name, truth, (r["fields"].get(f.name) or {}).get("value"))
            g[grp][0] += int(ok)
            g[grp][1] += 1
    return {k: {"accuracy": round(100 * a / b, 2) if b else None, "fields": b} for k, (a, b) in sorted(g.items())}
