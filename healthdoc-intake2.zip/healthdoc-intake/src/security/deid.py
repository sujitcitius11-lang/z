"""PHI masking BEFORE the text reaches a language model (reversible pseudonymisation).

Why: Azure OpenAI is a processing service outside the document store. The less identifying data it sees, the smaller the exposure
(and a BAA-covered service is still better kept to the minimum necessary). Extraction is a COPYING task, so the model can do its job
on placeholders: it sees `Patient Name: [NAME_1]` and answers `"patient_name": "[NAME_1]"`; we put the real value back.

What is replaced (each distinct value gets one stable token, so the model can still tell two different people apart):
  names (patient / applicant), dates (all, including birth and service dates), addresses, phone numbers, e-mail addresses, SSNs,
  member / group numbers.  Found in two ways: (1) by pattern (phone, e-mail, SSN, dates, ID shapes) and (2) by LABEL: the value
  printed after a label of a PHI field (`Patient Name:`, `Address:` ...) is replaced everywhere it occurs in the document.
What is NOT replaced: provider names and NPIs, organisation names, diagnosis/procedure/drug codes, amounts, claim / referral / Rx numbers.
  They are not the patient's identity and the model needs them to read the document.  (HIPAA Safe Harbor would also remove those;
  this is "data minimisation", not de-identification in the legal sense. See docs/KNOWN_LIMITATIONS.md.)
Known gap: a patient's name written in free text WITHOUT a label (e.g. inside a narrative paragraph) is replaced only if the same string was
also found at a labelled place. Recall is measured by scripts/phi_leak_test.py.
"""
from __future__ import annotations

import re

from src import schemas as S
from src.providers import heuristic

PHI_FIELDS = {"patient_name": "NAME", "dob": "DATE", "address": "ADDRESS", "phone": "PHONE", "email": "EMAIL", "member_id": "MEMBERID",
              "group_number": "GROUPNO"}
_PATTERNS = [
    ("EMAIL", re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("PHONE", re.compile(r"(?<!\d)(?:\(\d{3}\)\s?|\d{3}[-.\s])\d{3}[-.\s]\d{4}(?!\d)")),
    ("DATE", heuristic._DATE_RX),
    ("MEMBERID", re.compile(r"\b(?!CLM|REF|ACC)[A-Z]{3}\d{9}\b")),
    ("GROUPNO", re.compile(r"\bGRP\d{5}\b")),
]
_TOKEN = re.compile(r"\[[A-Z]+_\d+\]")


def _labelled_values(doc_type: str, text: str) -> list[tuple[str, str]]:
    """[(kind, printed value)] for PHI fields found by their labels (colon or boxed form)."""
    if doc_type not in S.SCHEMAS:
        return []
    clean = heuristic.colonless_label_pass(doc_type, heuristic.clean_text(text))
    scal = heuristic.extract_scalars(doc_type, heuristic.fuzzy_label_pass(doc_type, clean))
    out = []
    for name, x in scal.items():
        if name in PHI_FIELDS and x.get("raw"):
            out.append((PHI_FIELDS[name], str(x["raw"]).strip()))
    return out


def pseudonymise(text: str, doc_type: str = "unknown", known: dict | None = None) -> tuple[str, dict]:
    """-> (masked text, mapping {token: original}). `known` = optional extra {field: value} to mask (e.g. already-extracted values)."""
    found: list[tuple[str, str]] = _labelled_values(doc_type, text)
    for k, v in (known or {}).items():
        if k in PHI_FIELDS and isinstance(v, str) and len(v) > 2:
            found.append((PHI_FIELDS[k], v))
    for kind, rx in _PATTERNS:
        for m in rx.finditer(text):
            found.append((kind, m.group(0)))
    mapping: dict[str, str] = {}
    reverse: dict[str, str] = {}
    counters: dict[str, int] = {}
    # longest first so "April Finley" is replaced before "April"
    for kind, val in sorted(set(found), key=lambda kv: -len(kv[1])):
        norm = re.sub(r"\s+", " ", val.strip())
        if len(norm) < 3 or norm in reverse:
            continue
        counters[kind] = counters.get(kind, 0) + 1
        tok = f"[{kind}_{counters[kind]}]"
        reverse[norm] = tok
        mapping[tok] = norm
    masked = text
    for norm, tok in sorted(reverse.items(), key=lambda kv: -len(kv[0])):
        pat = r"\s+".join(re.escape(w) for w in norm.split(" "))
        masked = re.sub(rf"(?<![A-Za-z0-9]){pat}(?![A-Za-z0-9])", tok, masked, flags=re.I)
    return masked, mapping


def restore(obj, mapping: dict):
    """Put the real values back into whatever the model returned (string, list or dict)."""
    if isinstance(obj, str):
        for tok, val in mapping.items():
            obj = obj.replace(tok, val)
        return obj
    if isinstance(obj, list):
        return [restore(x, mapping) for x in obj]
    if isinstance(obj, dict):
        return {k: restore(v, mapping) for k, v in obj.items()}
    return obj


def tokenise_value(obj, mapping: dict):
    """The opposite of restore (used when exporting training data): original values -> tokens."""
    rev = {v: k for k, v in mapping.items()}
    if isinstance(obj, str):
        for val, tok in sorted(rev.items(), key=lambda kv: -len(kv[0])):
            obj = re.sub(re.escape(val), tok, obj, flags=re.I)
        return obj
    if isinstance(obj, list):
        return [tokenise_value(x, mapping) for x in obj]
    if isinstance(obj, dict):
        return {k: tokenise_value(v, mapping) for k, v in obj.items()}
    return obj


def leaked(masked_text: str, phi_values: list[str]) -> list[str]:
    """Which of the known PHI strings still appear in the masked text (for measuring the masker)."""
    low = re.sub(r"\s+", " ", masked_text.lower())
    return [v for v in phi_values if v and re.sub(r"\s+", " ", str(v).lower()) in low]
