"""Authentication + authorisation (role based).

AUTH_MODE=demo   a role picker in the sidebar (training / demo; there is NO password: say so in your report)
AUTH_MODE=entra  Microsoft Entra ID sign-in through Streamlit's built-in OIDC (`st.login`). App roles are read
                 from the token's `roles` claim (assign them to users/groups in Entra ID > Enterprise applications).

Roles (Entra "App roles"):
  Intake.Admin     everything, including data generation, reset and Azure configuration
  Intake.Operator  upload & process, pipeline monitor, dead-letter retry
  Intake.Reviewer  human review queue, document explorer
  Intake.Analyst   dashboards, evaluation, Power BI (read-only, de-identified views)
"""
from __future__ import annotations

ROLES = ["Intake.Admin", "Intake.Operator", "Intake.Reviewer", "Intake.Analyst"]

# page -> roles allowed
PAGE_ACCESS = {
    "Overview": ["Intake.Admin", "Intake.Operator", "Intake.Reviewer", "Intake.Analyst"],
    "Upload & Process": ["Intake.Admin", "Intake.Operator"],
    "Document Explorer": ["Intake.Admin", "Intake.Operator", "Intake.Reviewer"],
    "Review Queue": ["Intake.Admin", "Intake.Reviewer"],
    "Workflows & Rules": ["Intake.Admin", "Intake.Operator", "Intake.Reviewer", "Intake.Analyst"],
    "Pipeline Monitor": ["Intake.Admin", "Intake.Operator"],
    "Data Generator": ["Intake.Admin"],
    "Accuracy & Evaluation": ["Intake.Admin", "Intake.Analyst"],
    "Power BI": ["Intake.Admin", "Intake.Analyst"],
    "Azure Services": ["Intake.Admin"],
    "Audit Log": ["Intake.Admin"],
    "About & Requirements": ["Intake.Admin", "Intake.Operator", "Intake.Reviewer", "Intake.Analyst"],
}
# who may see unmasked PHI in the UI
PHI_ROLES = {"Intake.Admin", "Intake.Reviewer"}


def roles_from_claims(claims: dict | None) -> list[str]:
    """Extract our app roles from an Entra ID token's claims (id_token `roles` claim)."""
    if not claims:
        return []
    raw = claims.get("roles") or []
    if isinstance(raw, str):
        raw = [raw]
    return [r for r in raw if r in ROLES]


def allowed_pages(roles: list[str]) -> list[str]:
    return [p for p, allowed in PAGE_ACCESS.items() if any(r in allowed for r in roles)]


def can_see_phi(roles: list[str]) -> bool:
    return any(r in PHI_ROLES for r in roles)


def can_access(page: str, roles: list[str]) -> bool:
    return any(r in PAGE_ACCESS.get(page, []) for r in roles)
