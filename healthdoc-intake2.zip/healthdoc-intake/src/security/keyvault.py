"""Azure Key Vault access. Secrets are looked up by their ENVIRONMENT-VARIABLE name, with `_` mapped to `-`
(Key Vault secret names cannot contain underscores):  AZURE_OPENAI_API_KEY  ->  secret "AZURE-OPENAI-API-KEY".

Lookup order used by config.env():  1) environment variable / .env   2) Key Vault (if KEY_VAULT_URI is set)
In Azure the Function App's managed identity reads the vault: no password is stored anywhere in the code.
Secrets are cached in memory for the life of the process; values are NEVER logged.
"""
from __future__ import annotations

import os
from functools import lru_cache

_SECRET_NAMES_ALLOWED = (
    "AZURE_OPENAI_API_KEY", "DOCUMENT_INTELLIGENCE_API_KEY", "AZURE_STORAGE_CONNECTION_STRING", "AZURE_SQL_CONNECTION_STRING",
    "COSMOS_KEY", "LOGIC_APP_ROUTING_URL", "EVENT_GRID_TOPIC_KEY",
)


def vault_uri() -> str | None:
    return os.getenv("KEY_VAULT_URI") or None


@lru_cache(maxsize=1)
def _client():
    from azure.identity import DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient
    return SecretClient(vault_url=vault_uri(), credential=DefaultAzureCredential())


@lru_cache(maxsize=64)
def get_secret(env_name: str) -> str | None:
    """Return the secret for an env-var style name, or None (also when the vault is unreachable)."""
    if not vault_uri() or env_name not in _SECRET_NAMES_ALLOWED:
        return None
    try:
        return _client().get_secret(env_name.replace("_", "-")).value
    except Exception:
        return None


def status() -> dict:
    """For the Azure Services page: which secrets are available (names only, never values)."""
    out = {}
    for n in _SECRET_NAMES_ALLOWED:
        env_set = bool(os.getenv(n))
        out[n] = "environment" if env_set else ("key vault" if get_secret(n) else "not set")
    return out
