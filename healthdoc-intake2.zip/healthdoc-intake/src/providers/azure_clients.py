"""Factories for Azure SDK clients. Sign-in order: API key (from env / Key Vault) else Microsoft Entra ID
(DefaultAzureCredential = managed identity in Azure, `az login` on a laptop). Nothing here runs unless the
matching service is configured (see config.service_modes)."""
from __future__ import annotations

import config


def credential():
    from azure.identity import DefaultAzureCredential
    return DefaultAzureCredential()


def openai_client():
    from openai import AzureOpenAI
    endpoint = config.env("AZURE_OPENAI_ENDPOINT")
    key = config.env("AZURE_OPENAI_API_KEY")
    version = config.env("AZURE_OPENAI_API_VERSION", "2024-10-21")
    if key:
        return AzureOpenAI(azure_endpoint=endpoint, api_key=key, api_version=version)
    from azure.identity import get_bearer_token_provider
    token = get_bearer_token_provider(credential(), "https://cognitiveservices.azure.com/.default")
    return AzureOpenAI(azure_endpoint=endpoint, azure_ad_token_provider=token, api_version=version)


def openai_deployment() -> str:
    return config.env("AZURE_OPENAI_DEPLOYMENT_NAME") or ""


def document_intelligence_client():
    from azure.ai.documentintelligence import DocumentIntelligenceClient
    endpoint = config.env("DOCUMENT_INTELLIGENCE_ENDPOINT")
    key = config.env("DOCUMENT_INTELLIGENCE_API_KEY")
    if key:
        from azure.core.credentials import AzureKeyCredential
        return DocumentIntelligenceClient(endpoint=endpoint, credential=AzureKeyCredential(key))
    return DocumentIntelligenceClient(endpoint=endpoint, credential=credential())
