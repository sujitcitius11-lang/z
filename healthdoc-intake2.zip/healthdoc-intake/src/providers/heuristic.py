"""Offline classifier + field extractor (the stand-in for Azure OpenAI when no Azure account is configured).

It is NOT a toy regex per template: it reads *label: value* forms whatever the layout, knows every label
synonym from src/schemas.py, parses tables, repairs typical OCR confusions (O/0, I/1 ...) inside fields whose
format is known, and gives every field a confidence based on the OCR word confidences ("grounding").
Free-form prose letters are the case where the real LLM adds value (see docs/KNOWN_LIMITATIONS.md).
"""
from __future__ import annotations

import re

from src import common
from src import schemas as S

# Switches used ONLY by the ablation study (src/analytics/ablation.py) to measure what each technique contributes.
OPTIONS = {"fuzzy": True, "repair": True, "colonless": True}

# ---------------------------------------------------------------------------- text cleaning

_FOOTER = re.compile(r"synthetic document|^page\s*\d+\s*$|authori[sz]ed|signat|generated for software|^\s*[_\-=]{5,}\s*$", re.I)
_TAGLINE = re.compile(r"synthetic training|fictional organi", re.I)


def clean_text(text: str) -> str:
    """Normalise markdown tables, drop repeated page headers / footers."""
    text = text.replace("|", "  ").replace("\u2013", "-").replace("\u2014", "-")
    lines = text.splitlines()
    out: list[str] = []
    for i, ln in enumerate(lines):
        if _TAGLINE.search(ln):
            if out and len(out[-1]) < 60 and i > 3:      # the org name printed above the tagline on later pages
                out.pop()
            continue
        if _FOOTER.search(ln):
            continue
        if re.fullmatch(r"[\s:\-#*]*", ln):
            out.append("")
            continue
        out.append(ln.rstrip())
    return "\n".join(out)


# ---------------------------------------------------------------------------- classification

_TITLE_WORDS = {
    "enrollment": ("enrollment", "application"), "claim": ("claim",), "referral": ("referral",),
    "prescription": ("prescription", "rx"), "lab_report": ("laboratory", "lab report", "lab test", "clinical lab"),
}


def classify(text: str) -> tuple[str, float, dict]:
    low = text.lower()
    head = "\n".join(low.splitlines()[:6])
    scores = {}
    for dt, kw in S.CLASSIFY_KEYWORDS.items():
        s = sum(w * min(low.count(k), 2) for k, w in kw.items())
        if any(t in head for t in _TITLE_WORDS[dt]):
            s += 6
        scores[dt] = s
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    top, second = ranked[0], ranked[1]
    if top[1] < 6 or len(text.strip()) < 40:
        return "unknown", round(min(0.4, top[1] / 20), 2), scores
    conf = min(0.99, 0.55 + 0.45 * (top[1] - second[1]) / top[1])
    return top[0], round(conf, 2), scores


# ---------------------------------------------------------------------------- OCR repair for known formats

_TO_DIGIT = str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1", "|": "1", "S": "5", "B": "8", "Z": "2", "G": "6"})
_TO_ALPHA = str.maketrans({"0": "O", "1": "I", "5": "S", "8": "B", "2": "Z"})


def repair_id(name: str, raw: str) -> tuple[str, bool]:
    """Return (value, repaired?) using the known 'letters + digits' shape of the field."""
    raw = re.sub(r"[^A-Za-z0-9]", "", raw or "")
    if not OPTIONS["repair"] or name not in S.ID_PATTERNS:
        return raw, False
    nalpha, ndig, rx = S.ID_PATTERNS[name]
    if re.match(rx, raw):
        return raw, False
    if len(raw) != nalpha + ndig:
        return raw, False
    fixed = raw[:nalpha].upper().translate(_TO_ALPHA) + raw[nalpha:].translate(_TO_DIGIT)
    return (fixed, fixed != raw) if re.match(rx, fixed) else (raw, False)


def repair_digits(raw: str) -> str:
    if not OPTIONS["repair"]:
        return re.sub(r"\D", "", raw or "")
    return re.sub(r"\D", "", (raw or "").translate(_TO_DIGIT))


def repair_icd(code: str) -> str:
    """Fix OCR confusions (O/0, I/1 ...) in the two digit positions, but ONLY when the result is a known ICD-10 code;
    otherwise an invalid code (e.g. 'ZZ9.99') must stay invalid so validation can flag it."""
    from src import reference_data as R
    code = code.strip().upper()
    if OPTIONS["repair"] and len(code) >= 3 and code not in R.ICD10:
        fixed = code[0] + code[1:3].translate(_TO_DIGIT) + code[3:]
        if fixed in R.ICD10:
            return fixed
    return code


# ---------------------------------------------------------------------------- scalar extraction

_DATE_RX = re.compile(
    r"(\d{1,2}/\d{1,2}/\d{2,4}|\d{4}-\d{2}-\d{2}|[A-Z][a-z]{2,8}\.? \d{1,2},? \d{4}|\d{1,2}-[A-Za-z]{3}-\d{4}|\d{1,2} [A-Za-z]{3} \d{4})")


def _label_regex(doc_type: str):
    pairs = []
    for f in S.SCHEMAS[doc_type]:
        for lab in f.labels:
            pairs.append((lab, f.name))
    pairs.sort(key=lambda p: -len(p[0]))
    alt = "|".join(re.escape(l).replace(r"\ ", r"[ \t]+") for l, _ in pairs)
    lookup = {re.sub(r"\s+", " ", l.lower()): n for l, n in pairs}
    return re.compile(rf"(?<![A-Za-z0-9])({alt})[ \t]*[:;]", re.I), lookup


_RX_CACHE: dict = {}


def _first_line(region: str) -> str:
    for ln in region.splitlines():
        if ln.strip():
            return ln.strip()
    return ""


def _parse_scalar(f: S.FieldSpec, raw: str) -> tuple[object, float, str | None]:
    """-> (value, penalty multiplier, note)"""
    raw = raw.strip()
    if f.kind == "date":
        m = _DATE_RX.search(raw)
        iso = common.to_iso_date(m.group(1)) if m else None
        return (iso, 1.0, None) if iso else (raw or None, 0.5, "unparseable date")
    if f.kind == "money":
        m = re.search(r"-?\$?\s*[\d,]+\.\d{2}", raw)
        v = common.parse_money(m.group(0)) if m else common.parse_money(raw)
        return (v, 1.0, None) if v is not None else (raw or None, 0.5, "unparseable amount")
    if f.kind == "int":
        digits = re.search(r"\d+", raw.translate(_TO_DIGIT) if not re.search(r"\d", raw) else raw)
        return (int(digits.group(0)), 1.0, None) if digits else (raw or None, 0.5, "not a number")
    if f.kind == "phone":
        p = common.normalise_phone(repair_digits(raw))
        return (p, 1.0, None) if p else (raw or None, 0.6, "phone has wrong digit count")
    if f.kind == "email":
        m = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", raw.replace(" ", ""))
        return (m.group(0).lower(), 1.0, None) if m else (raw or None, 0.5, "email not recognised")
    if f.kind == "npi":
        d = repair_digits(raw)
        return (d or None, 1.0 if len(d) == 10 else 0.6, None if len(d) == 10 else "NPI should have 10 digits")
    if f.kind == "id":
        if f.name == "place_of_service":
            d = repair_digits(raw)
            return d or None, 1.0, None
        v, repaired = repair_id(f.name, raw)
        return (v or None), (0.92 if repaired else 1.0), ("OCR repair applied" if repaired else None)
    if f.kind == "icd_list":
        codes = [repair_icd(c) for c in re.split(r"[,;\s]+", raw) if c.strip()]
        return (codes or None), 1.0, None
    return (re.sub(r"\s+", " ", raw) or None), 1.0, None


def fuzzy_label_pass(doc_type: str, text: str) -> str:
    """OCR often damages a label ("Applecant Nan") and loses its colon. A line that is ONLY a close match
    (>= 0.82 similarity, similar length) to a known label is rewritten to `Label:`.  Lines with extra text are left
    alone, so titles such as "Patient Referral" can never be mistaken for the label "Patient"."""
    import difflib
    if not OPTIONS["fuzzy"]:
        return text
    labels = sorted({l for f in S.SCHEMAS[doc_type] for l in f.labels if len(l) > 4}, key=len, reverse=True)
    out = []
    for ln in text.splitlines():
        s = ln.strip().rstrip(".,")
        if not s or re.search(r"[:;]", s) or len(s) > 32:
            out.append(ln)
            continue
        best, best_r = None, 0.0
        for lab in labels:
            if abs(len(lab) - len(s)) > 2:
                continue
            r = difflib.SequenceMatcher(None, s.lower(), lab.lower()).ratio()
            if r > best_r:
                best, best_r = lab, r
        out.append(f"{best}:" if best and best_r >= 0.82 else ln)
    return "\n".join(out)


def colonless_label_pass(doc_type: str, text: str) -> str:
    """Boxed forms print `Patient Name   April Finley` with NO colon. When a page has fewer than two `Label:` pairs (one is the table caption), a line that STARTS with
    a known label followed by a value is rewritten to `Label: value`. (Skipped on normal forms so titles like "Patient Referral" are safe.)"""
    if not OPTIONS["colonless"]:
        return text
    if doc_type not in _RX_CACHE:
        _RX_CACHE[doc_type] = _label_regex(doc_type)
    if len(_RX_CACHE[doc_type][0].findall(text)) >= 2:          # a normal `Label:` form: leave it alone
        return text
    labels = sorted({l for f in S.SCHEMAS[doc_type] for l in f.labels if f.kind not in ("cpt_lines", "lab_rows")}, key=len, reverse=True)
    out, seen = [], 0
    for ln in text.splitlines():
        st = ln.strip()
        low = st.lower()
        seen += bool(st)
        if seen <= 2:                                           # letterhead and document title (the tagline line is already removed by clean_text)
            out.append(ln)
            continue
        for lab in labels:
            if low.startswith(lab.lower()) and len(st) > len(lab) + 1 and st[len(lab)] in " \t":
                ln = f"{lab}: {st[len(lab):].strip()}"
                break
        out.append(ln)
    return "\n".join(out)


def extract_scalars(doc_type: str, text: str) -> dict[str, dict]:
    if doc_type not in _RX_CACHE:
        _RX_CACHE[doc_type] = _label_regex(doc_type)
    rx, lookup = _RX_CACHE[doc_type]
    matches = list(rx.finditer(text))
    out: dict[str, dict] = {}
    for i, m in enumerate(matches):
        name = lookup.get(re.sub(r"\s+", " ", m.group(1).lower()))
        f = S.field_spec(doc_type, name)
        if not f or f.kind in ("cpt_lines", "lab_rows") or name in out:
            continue
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        region = text[m.end():end]
        raw = " ".join(l.strip() for l in region.splitlines() if l.strip()) if f.multiline else _first_line(region)
        if not raw:
            continue
        value, mult, note = _parse_scalar(f, raw)
        out[name] = {"value": value, "raw": raw, "mult": mult, "note": note, "source": "label"}
    return out


# ---------------------------------------------------------------------------- tables

_CLAIM_ROW = re.compile(r"^\s*([0-9OIlS]{5})\s+(.+?)\s+(\d+)\s+\$?\s*([\d,]+\.\d{2})\s*$")
_NUM = r"-?\d+(?:[.,\u00b0\u00b7':]\d+)?"
_LAB_ROW = re.compile(
    rf"^\s*([A-Za-z][A-Za-z0-9 ^/()]*?)\s+({_NUM})\s+(\S+)\s+({_NUM})\s*[-~=:.\u00b0]{{1,3}}\s*({_NUM})\s*(HH|LL|H|L|N)?\s*$")


def _num(t: str) -> float:
    return float(re.sub(r"[,\u00b0\u00b7':]", ".", t))


def extract_claim_lines(text: str) -> list[dict]:
    rows = []
    for ln in text.splitlines():
        m = _CLAIM_ROW.match(ln)
        if m:
            rows.append({"cpt": repair_digits(m.group(1)), "description": m.group(2).strip(), "units": int(m.group(3)),
                         "charge": common.parse_money(m.group(4))})
    return rows


def extract_lab_rows(text: str) -> list[dict]:
    rows = []
    for ln in text.splitlines():
        m = _LAB_ROW.match(ln)
        if m and not m.group(1).strip().lower().startswith(("test", "reference")):
            flag = (m.group(6) or "").replace("N", "")
            rows.append({"test": m.group(1).strip(), "value": _num(m.group(2)), "unit": m.group(3), "ref_low": _num(m.group(4)),
                         "ref_high": _num(m.group(5)), "flag": flag})
    return rows


# ---------------------------------------------------------------------------- grounding (confidence)


def ground(raw: str | None, words: list[dict], default: float) -> float:
    """Mean OCR confidence of the words that make up the value. Falls back to the document average."""
    if not raw or not words:
        return default
    toks = {t.lower().strip(".,:;") for t in re.split(r"\s+", str(raw)) if t}
    hits = [w["conf"] for w in words if w["text"].lower().strip(".,:;") in toks]
    return sum(hits) / len(hits) if hits else default * 0.9


def extract(doc_type: str, text: str, words: list[dict], doc_conf: float) -> dict[str, dict]:
    """-> {field: {"value","confidence","source","note"}} for every field of the type (missing ones have value None)."""
    text = clean_text(text)
    text = colonless_label_pass(doc_type, text)
    scal = extract_scalars(doc_type, fuzzy_label_pass(doc_type, text))
    out: dict[str, dict] = {}
    for f in S.SCHEMAS[doc_type]:
        if f.kind == "cpt_lines":
            rows = extract_claim_lines(text)
            conf = ground(" ".join(r["cpt"] for r in rows), words, doc_conf) if rows else 0.0
            out[f.name] = {"value": rows or None, "confidence": round(conf, 3), "source": "table", "note": None}
        elif f.kind == "lab_rows":
            rows = extract_lab_rows(text)
            conf = ground(" ".join(r["test"] for r in rows), words, doc_conf) if rows else 0.0
            out[f.name] = {"value": rows or None, "confidence": round(conf, 3), "source": "table", "note": None}
        elif f.name in scal:
            s = scal[f.name]
            conf = ground(s["raw"], words, doc_conf) * s["mult"]
            out[f.name] = {"value": s["value"], "confidence": round(min(conf, 0.995), 3), "source": s["source"], "note": s["note"]}
        else:
            out[f.name] = {"value": None, "confidence": 0.0, "source": "absent", "note": None}
    return out
