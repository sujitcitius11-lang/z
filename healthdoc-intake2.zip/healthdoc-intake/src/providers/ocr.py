"""OCR / layout reading.

AzureDocIntelOcr : Azure AI Document Intelligence, model `prebuilt-layout` (text, tables, word confidences).
LocalOcr         : the offline stand-in. Digital PDFs -> pdfplumber text layer (confidence 0.99).
                   Scans / images -> Tesseract (word confidences from the engine).
Both return the same OcrResult, so nothing downstream knows which one ran.
"""
from __future__ import annotations

import io
import os
from dataclasses import dataclass, field

import config
from src import common

os.environ.setdefault("OMP_THREAD_LIMIT", "1")


def _find_tesseract() -> None:
    """Windows installs Tesseract without adding it to PATH. Look in the usual places (or TESSERACT_CMD) so the user does not have to."""
    import shutil
    try:
        import pytesseract
    except ImportError:
        return
    cmd = os.getenv("TESSERACT_CMD")
    if not cmd and not shutil.which("tesseract"):
        for c in (r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                  os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe")):
            if os.path.exists(c):
                cmd = c
                break
    if cmd:
        pytesseract.pytesseract.tesseract_cmd = cmd


def tesseract_available() -> bool:
    """True if the Tesseract program can be run (scans / photos need it; digital PDFs do not)."""
    try:
        import pytesseract
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def require_tesseract_or_skip(what: str) -> None:
    """For scripts that must read scanned files: stop with a one-line message instead of a traceback or a report full of zeros."""
    if not tesseract_available():
        print(f"SKIPPED {what}: Tesseract OCR is not installed on this machine (set TESSERACT_CMD or install it). Nothing was written.")
        raise SystemExit(0)


_find_tesseract()       # Tesseract: one thread per process is faster when we run several workers


class UnreadableDocument(Exception):
    """The file is corrupt / not a document. Not transient: retrying will not help -> dead-letter."""


@dataclass
class OcrResult:
    text: str
    pages: int
    avg_confidence: float
    words: list[dict] = field(default_factory=list)     # {"text","conf","page"}
    engine: str = "local"
    is_scanned: bool = False
    ms: int = 0
    page_texts: list[str] = field(default_factory=list)   # text of each page, in order (used by the packet splitter)


def _estimate_skew(gray) -> float:
    """Projection-profile deskew: the angle whose row sums have the highest variance."""
    import numpy as np
    from PIL import Image
    small = gray.copy()
    small.thumbnail((700, 900))
    bw = (np.asarray(small) < 140)
    best, best_a = -1.0, 0.0
    for a in np.arange(-3.0, 3.01, 0.25):
        r = np.asarray(Image.fromarray((bw * 255).astype("uint8")).rotate(a, resample=Image.NEAREST)) > 0
        v = float(np.var(r.sum(axis=1)))
        if v > best:
            best, best_a = v, float(a)
    return best_a


def preprocess(im):
    """Typical scan clean-up before OCR: grey, auto-contrast, median denoise, upscale, deskew."""
    from PIL import Image, ImageFilter, ImageOps
    g = ImageOps.autocontrast(im.convert("L"), cutoff=1)
    g = g.filter(ImageFilter.MedianFilter(3))
    if g.width < 2000:
        f = 2000 / g.width
        g = g.resize((2000, int(g.height * f)), Image.LANCZOS)
    angle = _estimate_skew(g)
    if abs(angle) >= 0.2:
        g = g.rotate(angle, resample=Image.BICUBIC, fillcolor=255)
    return g


def _is_pdf(data: bytes) -> bool:
    return data[:5] == b"%PDF-"


class LocalOcr:
    name = "local (pdfplumber + Tesseract)"

    def analyze(self, data: bytes, filename: str = "") -> OcrResult:
        with common.Timer() as t:
            res = self._pdf(data) if _is_pdf(data) else self._image(data)
        res.ms = t.ms
        return res

    # ---- digital PDF or scanned PDF
    def _pdf(self, data: bytes) -> OcrResult:
        import pdfplumber
        try:
            pdf = pdfplumber.open(io.BytesIO(data))
            pages = len(pdf.pages)
        except Exception as exc:
            raise UnreadableDocument(f"PDF cannot be opened: {exc}") from exc
        words, texts = [], []
        try:
            for i, pg in enumerate(pdf.pages):
                texts.append(pg.extract_text() or "")
                for w in pg.extract_words():
                    words.append({"text": w["text"], "conf": 0.99, "page": i + 1})
        except Exception as exc:
            raise UnreadableDocument(f"PDF text layer unreadable: {exc}") from exc
        finally:
            pdf.close()
        text = "\n".join(texts)
        if len(text.strip()) >= 40:
            return OcrResult(text, pages, 0.99, words, "pdf-text-layer", False, page_texts=texts)
        # no text layer -> it is a scan: rasterise and OCR
        import pypdfium2 as pdfium
        try:
            doc = pdfium.PdfDocument(data)
            imgs = [doc[i].render(scale=200 / 72).to_pil() for i in range(len(doc))]
            doc.close()
        except Exception as exc:
            raise UnreadableDocument(f"PDF pages cannot be rendered: {exc}") from exc
        return self._ocr_images(imgs, pages)

    def _image(self, data: bytes) -> OcrResult:
        from PIL import Image
        try:
            img = Image.open(io.BytesIO(data))
            img.load()
        except Exception as exc:
            raise UnreadableDocument(f"Image cannot be opened: {exc}") from exc
        frames = []
        try:
            n = getattr(img, "n_frames", 1)
            for i in range(n):
                img.seek(i)
                frames.append(img.convert("RGB").copy())
        except Exception:
            frames = [img.convert("RGB")]
        return self._ocr_images(frames, len(frames))

    def _ocr_images(self, images, pages: int) -> OcrResult:
        import pytesseract
        try:
            pytesseract.get_tesseract_version()
        except pytesseract.TesseractNotFoundError as exc:
            raise RuntimeError("Tesseract OCR is not installed. Windows: install it from https://github.com/UB-Mannheim/tesseract/wiki (default folder), "
                               "then reopen the terminal, or set TESSERACT_CMD to the full path of tesseract.exe. Linux: apt install tesseract-ocr.") from exc
        words, lines_out, page_texts = [], [], []
        for pno, im in enumerate(images, 1):
            page_start = len(lines_out)
            im = preprocess(im)
            d = pytesseract.image_to_data(im, config="--psm 6", output_type=pytesseract.Output.DICT)
            cur, buf = None, []
            for i, txt in enumerate(d["text"]):
                txt = txt.strip()
                if not txt:
                    continue
                key = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
                conf = max(float(d["conf"][i]), 0.0) / 100.0
                words.append({"text": txt, "conf": conf, "page": pno})
                if key != cur:
                    if buf:
                        lines_out.append(" ".join(buf))
                    cur, buf = key, []
                buf.append(txt)
            if buf:
                lines_out.append(" ".join(buf))
            page_texts.append("\n".join(lines_out[page_start:]))
        avg = sum(w["conf"] for w in words) / len(words) if words else 0.0
        return OcrResult("\n".join(lines_out), pages, round(avg, 4), words, "tesseract", True, page_texts=page_texts)


class AzureDocIntelOcr:
    name = "Azure AI Document Intelligence (prebuilt-layout)"

    def analyze(self, data: bytes, filename: str = "") -> OcrResult:
        from azure.core.exceptions import HttpResponseError
        from src.providers.azure_clients import document_intelligence_client
        client = document_intelligence_client()
        with common.Timer() as t:
            try:
                try:                                                    # SDK 1.0 GA signature
                    from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
                    poller = client.begin_analyze_document("prebuilt-layout", body=AnalyzeDocumentRequest(bytes_source=data),
                                                           output_content_format="markdown")
                except TypeError:                                       # older preview signature
                    poller = client.begin_analyze_document("prebuilt-layout", analyze_request=data, content_type="application/octet-stream")
                result = poller.result()
            except HttpResponseError as exc:
                if exc.status_code in (408, 429, 500, 502, 503, 504):
                    raise common.TransientError(f"Document Intelligence {exc.status_code}") from exc
                raise UnreadableDocument(f"Document Intelligence rejected the file: {exc.message}") from exc
        words = []
        for pg in result.pages or []:
            for w in pg.words or []:
                words.append({"text": w.content, "conf": float(w.confidence or 0), "page": pg.page_number})
        avg = sum(w["conf"] for w in words) / len(words) if words else 0.0
        is_scanned = _looks_scanned(data)
        page_texts = []
        for pg in result.pages or []:
            page_texts.append("\n".join(getattr(ln, "content", "") for ln in (getattr(pg, "lines", None) or [])))
        return OcrResult(result.content or "", len(result.pages or []), round(avg, 4), words, "azure-document-intelligence", is_scanned, t.ms,
                         page_texts=page_texts)


def _looks_scanned(data: bytes) -> bool:
    if not _is_pdf(data):
        return True
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            return len("".join((p.extract_text() or "") for p in pdf.pages).strip()) < 40
    except Exception:
        return True


def get_ocr():
    return AzureDocIntelOcr() if config.mode("doc_intelligence") == "azure" else LocalOcr()
