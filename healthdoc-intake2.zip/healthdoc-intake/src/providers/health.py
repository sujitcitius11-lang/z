"""Safe connectivity checks for each Azure service (used by the Azure Services page).
A check never changes data. In local mode it reports that the built-in stand-in is active."""
from __future__ import annotations

import config
from src import common

SERVICES = {
    "blob": ("Azure Blob Storage", "Stores every uploaded document in containers incoming / processed / review / quarantine.",
             ["AZURE_STORAGE_CONNECTION_STRING or AZURE_STORAGE_ACCOUNT_URL"]),
    "event_grid": ("Azure Event Grid", "Raises BlobCreated events when a file lands in `incoming` and calls the Function (at-least-once delivery).",
                   ["EVENT_GRID_MODE=azure (the subscription itself is created by infra/main.bicep)", "EVENT_GRID_TOPIC_ENDPOINT / EVENT_GRID_TOPIC_KEY (optional custom topic)"]),
    "doc_intelligence": ("Azure AI Document Intelligence", "OCR + layout (prebuilt-layout): text, tables and word confidences.",
                         ["DOCUMENT_INTELLIGENCE_ENDPOINT", "DOCUMENT_INTELLIGENCE_API_KEY (optional: managed identity otherwise)"]),
    "openai": ("Azure OpenAI Service", "Classifies the document and extracts fields as strict JSON; also writes narrative text for synthetic data.",
               ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT_NAME", "AZURE_OPENAI_API_KEY (optional)"]),
    "functions": ("Azure Functions", "Runs the pipeline when Event Grid delivers an event (functions/function_app.py).", ["deployed Function App (no local setting)"]),
    "logic_apps": ("Azure Logic Apps", "Performs the routing actions: e-mail, Teams message, work item.", ["LOGIC_APP_ROUTING_URL"]),
    "sql": ("Azure SQL Database", "Structured, reportable facts; the source for Power BI.", ["AZURE_SQL_CONNECTION_STRING"]),
    "cosmos": ("Azure Cosmos DB", "Raw OCR text + model JSON per document, partitioned by /doc_type.", ["COSMOS_ENDPOINT", "COSMOS_KEY (optional)"]),
    "power_bi": ("Power BI", "Management dashboards on the de-identified star schema.", ["POWERBI_EMBED_URL (optional, to embed a published report)"]),
    "key_vault": ("Azure Key Vault", "Holds every secret; the Function reads it through its managed identity.", ["KEY_VAULT_URI"]),
    "entra": ("Microsoft Entra ID", "Sign-in and the four app roles (Admin, Operator, Reviewer, Analyst).", ["AUTH_MODE=entra + [auth] in .streamlit/secrets.toml"]),
    "devops": ("Azure DevOps", "Repo, board and the CI/CD pipeline (devops/azure-pipelines.yml).", ["(pipeline service connection; nothing in the app)"]),
    "aks": ("Azure Kubernetes Service (optional)", "Optional: run the Streamlit app as a container (Dockerfile, infra/k8s).", ["(optional)"]),
}


def mode_of(key: str) -> str:
    if key in config.service_modes():
        return config.mode(key)
    if key == "power_bi":
        return "azure" if config.env("POWERBI_EMBED_URL") else "local"
    return "n/a"


def check(key: str) -> tuple[bool, str]:
    """-> (ok, message)"""
    m = config.mode(key) if key in config.service_modes() else "local"
    if m != "azure":
        return True, "Running locally with the built-in stand-in. Nothing to connect."
    try:
        with common.Timer() as t:
            if key == "blob":
                from src.storage.blob_store import AzureBlobStore
                AzureBlobStore()
            elif key == "doc_intelligence":
                from src.providers.azure_clients import document_intelligence_client
                document_intelligence_client()
            elif key == "openai":
                from src.providers.azure_clients import openai_client, openai_deployment
                r = openai_client().chat.completions.create(model=openai_deployment(), max_tokens=5, messages=[{"role": "user", "content": "ping"}])
                _ = r.choices[0].message
            elif key == "sql":
                from src.storage.sql_store import SqlStore
                SqlStore("azure").scalar("SELECT 1")
            elif key == "cosmos":
                from src.storage.cosmos_store import CosmosStore
                CosmosStore("azure").count()
            elif key == "key_vault":
                from src.security import keyvault
                keyvault._client().list_properties_of_secrets().__next__()
            elif key == "logic_apps":
                return True, "URL configured (not called: a test call would trigger real e-mails)."
            elif key == "event_grid":
                return True, "Configured. Upload a file and look for the event in Pipeline Monitor."
        return True, f"Connected in {t.ms} ms."
    except Exception as exc:
        return False, f"{type(exc).__name__}: {str(exc)[:200]}"
