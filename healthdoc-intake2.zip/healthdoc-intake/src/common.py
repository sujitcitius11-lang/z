"""Small shared helpers: hashing, NPI check digit, date/money parsing, PHI masking, timing, retries."""
from __future__ import annotations

import functools
import hashlib
import random
import re
import time
import uuid
from datetime import date, datetime, timezone

import config

# --------------------------------------------------------------------------- time / ids


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def new_id(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Timer:
    """with Timer() as t: ...; t.ms"""

    def __enter__(self):
        self._t = time.perf_counter()
        return self

    def __exit__(self, *a):
        self._end = time.perf_counter()

    @property
    def ms(self) -> int:
        """Elapsed milliseconds (works inside the with-block too)."""
        return int(((getattr(self, "_end", None) or time.perf_counter()) - self._t) * 1000)


# --------------------------------------------------------------------------- NPI (real check-digit rule)


def npi_check_digit(first9: str) -> int:
    """NPI uses the Luhn algorithm over the constant prefix 80840 + the first 9 digits."""
    digits = [int(c) for c in "80840" + first9]
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 0:       # the check digit position is not included, so the rightmost given digit is doubled
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10


def is_valid_npi(npi: str) -> bool:
    npi = re.sub(r"\D", "", str(npi or ""))
    return len(npi) == 10 and npi[0] in "12" and npi_check_digit(npi[:9]) == int(npi[9])


def make_npi(rng: random.Random) -> str:
    first9 = rng.choice("12") + "".join(str(rng.randint(0, 9)) for _ in range(8))
    return first9 + str(npi_check_digit(first9))


# --------------------------------------------------------------------------- dates and money

_DATE_FORMATS = ["%m/%d/%Y", "%Y-%m-%d", "%b %d, %Y", "%B %d, %Y", "%d-%b-%Y", "%m-%d-%Y", "%d %b %Y", "%m/%d/%y"]


def parse_date(text: str | None) -> date | None:
    """Parse any of the date styles that appear on the forms. Returns None if it cannot."""
    if not text:
        return None
    t = re.sub(r"\s+", " ", str(text).strip().replace(",", ", ").replace(",  ", ", ")).strip(" .")
    for fmt in _DATE_FORMATS:
        try:
            d = datetime.strptime(t, fmt).date()
            if fmt.endswith("%y") and d.year > config.REFERENCE_DATE.year + 1:
                d = d.replace(year=d.year - 100)
            return d
        except ValueError:
            continue
    return None


def to_iso_date(text: str | None) -> str | None:
    d = parse_date(text)
    return d.isoformat() if d else None


def format_date(d: date, style: str) -> str:
    return {
        "us": d.strftime("%m/%d/%Y"), "iso": d.isoformat(), "long": d.strftime("%B %d, %Y").replace(" 0", " "),
        "short": d.strftime("%b %d, %Y").replace(" 0", " "), "dmy": d.strftime("%d-%b-%Y"),
    }[style]


def parse_money(text) -> float | None:
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    t = re.sub(r"[^\d.\-]", "", str(text))
    try:
        return round(float(t), 2)
    except ValueError:
        return None


def normalise_phone(text: str | None) -> str | None:
    digits = re.sub(r"\D", "", str(text or ""))
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) != 10:
        return None
    return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"


# --------------------------------------------------------------------------- PHI masking (for logs)


def mask_name(name: str | None) -> str:
    if not name:
        return ""
    return " ".join(p[0] + "***" for p in str(name).replace(",", " ").split() if p)


def mask_id(value: str | None, keep: int = 3) -> str:
    v = str(value or "")
    return v if len(v) <= keep else v[:keep] + "*" * (len(v) - keep)


PHI_FIELDS_TO_MASK = {
    "patient_name": mask_name, "dob": lambda v: "****-**-**", "member_id": mask_id, "phone": lambda v: "(***) ***-****",
    "email": lambda v: "***@***", "address": lambda v: "*** (masked)",
}


def mask_fields(fields: dict) -> dict:
    out = {}
    for k, v in fields.items():
        out[k] = PHI_FIELDS_TO_MASK[k](v) if k in PHI_FIELDS_TO_MASK and v else v
    return out


# --------------------------------------------------------------------------- retry (transient faults)


class TransientError(Exception):
    """Raise (or wrap) for 429 / 503 / timeouts: the retry decorator will try again."""


def retry(max_attempts: int | None = None, base: float | None = None, on=(TransientError, TimeoutError, ConnectionError)):
    """Exponential backoff with jitter. The LAST failure is re-raised (the caller dead-letters it)."""
    attempts = max_attempts or config.MAX_RETRIES
    delay = base if base is not None else config.RETRY_BASE_SECONDS

    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*a, **kw):
            last = None
            for i in range(1, attempts + 1):
                try:
                    return fn(*a, **kw)
                except on as exc:
                    last = exc
                    if i == attempts:
                        break
                    time.sleep(delay * (2 ** (i - 1)) * (0.5 + random.random()))
            raise last
        wrapper.__wrapped__ = fn
        return wrapper
    return deco
