"""Packet splitting: one PDF/TIFF that holds several documents is cut into separate documents, page by page.

Real intake mailboxes and fax lines deliver "packets" (a referral + the lab results + a claim in one file). Each page is looked at
for four START-OF-DOCUMENT signals, strongest first:
  1. the printed page number restarts at 1 ("Page 1")                         -> new document
  2. a document TITLE appears near the top of the page ("HEALTH INSURANCE CLAIM FORM", "Laboratory Report" ...)
  3. a different document number (claim no., referral id, Rx no., accession no.) than the current document  -> new document
  4. the page clearly belongs to a different document TYPE than the current one
A page whose page number continues (2 after 1) always stays with the current document. Blank pages are separators and are dropped.
The same logic runs on any OCR engine, because it only needs the text of each page.
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass

from src.providers import heuristic

_PAGE_NO = re.compile(r"\bpage\s*(\d{1,3})(?:\s*(?:of|/)\s*(\d{1,3}))?[ \t]*$", re.I | re.M)
_IDENT = re.compile(r"\b(CLM\d{6,}|REF\d{6,}|RX\d{6,}|ACC\d{6,})\b")
_TITLE_KW = {"enrollment": ("enrollment", "application"), "claim": ("claim",), "referral": ("referral",),
             "prescription": ("prescription", "rx -", "rx order"), "lab_report": ("laboratory", "lab report", "lab test", "clinical lab")}
_SKIP_TOP = 2          # the first lines of a page are the letterhead (organisation + tagline), not the title


@dataclass
class Segment:
    start: int                 # first page, 0-based
    end: int                   # last page, 0-based, inclusive
    doc_type: str = "unknown"
    type_confidence: float = 0.0
    kind: str = "document"     # "document" | "blank"
    reason: str = ""

    @property
    def page_range(self) -> str:
        return f"p{self.start + 1}" if self.start == self.end else f"p{self.start + 1}-{self.end + 1}"


def _title_type(text: str) -> str | None:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for ln in lines[_SKIP_TOP:_SKIP_TOP + 6]:
        low = ln.lower()
        if len(ln) > 60 or ":" in ln:
            continue
        for dt, kws in _TITLE_KW.items():
            if any(k in low for k in kws):
                return dt
    return None


def page_info(text: str) -> dict:
    nums = _PAGE_NO.findall(text or "")
    page_no = int(nums[-1][0]) if nums else None
    ident = (_IDENT.findall(text or "") or [None])[0]
    body = heuristic.clean_text(text or "")
    dt, conf, scores = heuristic.classify(body)
    return {"blank": len((text or "").strip()) < 15, "page_no": page_no, "ident": ident, "title_type": _title_type(text or ""),
            "type": dt, "type_conf": conf, "type_score": max(scores.values()) if scores else 0}


def split_pages(page_texts: list[str]) -> list[Segment]:
    infos = [page_info(t) for t in page_texts]
    segs: list[Segment] = []
    cur: Segment | None = None
    cur_ident = cur_no = cur_type = None
    for i, p in enumerate(infos):
        if p["blank"]:
            if cur is not None:
                segs.append(cur)
                cur = None
            segs.append(Segment(i, i, "unknown", 0.0, "blank", "blank page"))
            cur_ident = cur_no = cur_type = None
            continue
        reason = None
        if cur is None:
            reason = "first page after start/blank"
        elif p["page_no"] is not None and cur_no is not None and p["page_no"] == cur_no + 1 and not (p["title_type"] and p["title_type"] != cur_type):
            reason = None                                                     # numbering continues: same document
        elif p["page_no"] == 1:
            reason = "page number restarts at 1"
        elif p["title_type"] is not None:
            reason = f"title of a {p['title_type']} found"
        elif p["ident"] and cur_ident and p["ident"] != cur_ident:
            reason = "different document number"
        elif p["type"] != "unknown" and p["type_score"] >= 12 and cur_type not in (None, "unknown") and p["type"] != cur_type:
            reason = f"page reads like a {p['type']}"
        if reason:
            if cur is not None:
                segs.append(cur)
            cur = Segment(i, i, reason=reason)
            cur_ident, cur_type = p["ident"], p["title_type"] or (p["type"] if p["type"] != "unknown" else None)
        else:
            cur.end = i
            cur_ident = cur_ident or p["ident"]
            cur_type = cur_type or (p["title_type"] or (p["type"] if p["type"] != "unknown" else None))
        cur_no = p["page_no"]
    if cur is not None:
        segs.append(cur)
    for s in segs:
        if s.kind == "document":
            text = heuristic.clean_text("\n".join(page_texts[s.start:s.end + 1]))
            s.doc_type, s.type_confidence, _ = heuristic.classify(text)
    return segs


def real_segments(segs: list[Segment]) -> list[Segment]:
    return [s for s in segs if s.kind == "document"]


# ------------------------------------------------------------------------------------------------------ cutting the file
def slice_bytes(data: bytes, filename: str, start: int, end: int) -> bytes | None:
    """Bytes of pages start..end (0-based, inclusive) as a new file, or None when the format cannot be cut."""
    name = filename.lower()
    if data[:5] == b"%PDF-" or name.endswith(".pdf"):
        from pypdf import PdfReader, PdfWriter
        r, w = PdfReader(io.BytesIO(data)), PdfWriter()
        for i in range(start, end + 1):
            w.add_page(r.pages[i])
        buf = io.BytesIO()
        w.write(buf)
        return buf.getvalue()
    if name.endswith((".tif", ".tiff")):
        from PIL import Image
        img = Image.open(io.BytesIO(data))
        frames = []
        for i in range(start, end + 1):
            img.seek(i)
            frames.append(img.convert("L").copy())
        buf = io.BytesIO()
        frames[0].save(buf, "TIFF", save_all=True, append_images=frames[1:], compression="jpeg")
        return buf.getvalue()
    return None


def slice_ocr(ocr, start: int, end: int):
    """Re-use the OCR of the whole packet for one part (no second OCR call = no second Document Intelligence charge)."""
    from dataclasses import replace
    words = [{**w, "page": w["page"] - start} for w in ocr.words if start + 1 <= w["page"] <= end + 1]
    texts = ocr.page_texts[start:end + 1]
    conf = sum(w["conf"] for w in words) / len(words) if words else ocr.avg_confidence
    return replace(ocr, text="\n".join(texts), pages=end - start + 1, words=words, page_texts=texts, avg_confidence=round(conf, 4), ms=0)
