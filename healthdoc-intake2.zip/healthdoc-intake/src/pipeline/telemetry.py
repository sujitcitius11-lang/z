"""Monitoring hooks: custom events and metrics.

Azure : when APPLICATIONINSIGHTS_CONNECTION_STRING is set and `azure-monitor-opentelemetry` is installed, events are sent to Application Insights
        (logger records carrying `microsoft.custom_event.name`, which App Insights shows in the `customEvents` table; metrics via OpenTelemetry).
Local : the same calls write to the Telemetry table so the Pipeline Monitor page works offline.
Telemetry NEVER carries PHI: only ids, status, type, timings.   KQL examples: docs/MONITORING.md
"""
from __future__ import annotations

import json
import logging
import os

from src import common

_log = logging.getLogger("docintake.telemetry")
_azure_ready: bool | None = None


def _azure() -> bool:
    global _azure_ready
    if _azure_ready is None:
        conn = os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")
        _azure_ready = False
        if conn and os.getenv("FORCE_LOCAL", "0").lower() not in ("1", "true", "yes"):
            try:
                from azure.monitor.opentelemetry import configure_azure_monitor
                configure_azure_monitor(connection_string=conn)
                _azure_ready = True
            except Exception as exc:                 # package missing / bad string: fall back to local, never break processing
                _log.warning("Application Insights not available (%s); using local telemetry", exc)
    return _azure_ready


def track(kind: str, name: str, doc_id: str | None = None, value: float | None = None, **props) -> None:
    """kind = 'event' | 'metric'."""
    try:
        if _azure():
            _log.info(name, extra={"microsoft.custom_event.name": name, "doc_id": doc_id or "", "value": value or 0, **{k: str(v) for k, v in props.items()}})
            return
        from src.storage.sql_store import get_sql
        get_sql().insert("Telemetry", {"ts": common.iso_now(), "kind": kind, "name": name, "doc_id": doc_id, "value": value,
                                       "props_json": json.dumps(props, default=str)})
    except Exception:                                # monitoring must never stop the pipeline
        pass


def event(name: str, doc_id: str | None = None, value: float | None = None, **props) -> None:
    track("event", name, doc_id, value, **props)


def metric(name: str, value: float, doc_id: str | None = None, **props) -> None:
    track("metric", name, doc_id, value, **props)
