"""Append-only audit trail. Every step of every document writes one row (SQL AuditLog) and one JSON line
(logs/audit.jsonl). Details are PHI-safe: names/IDs are masked, no raw document text is ever logged."""
from __future__ import annotations

import json
import threading

import config
from src import common
from src.storage.sql_store import SqlStore, get_sql

_lock = threading.Lock()
LOG_FILE = config.LOG_DIR / "audit.jsonl"


def audit(action: str, doc_id: str | None = None, actor: str = "system", correlation_id: str | None = None,
          store: SqlStore | None = None, **detail) -> None:
    store = store or get_sql()
    safe = common.mask_fields(detail)
    row = {"ts": common.iso_now(), "doc_id": doc_id, "actor": actor, "action": action,
           "detail_json": json.dumps(safe, default=str), "correlation_id": correlation_id}
    try:
        store.insert("AuditLog", row)
    except Exception:
        pass                                    # auditing must never crash the pipeline
    try:
        with _lock, LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({**row, "detail": safe}, default=str) + "\n")
    except Exception:
        pass
