"""The heart of the system: what happens when a document lands in Blob Storage.

  Event Grid event ─► handle_event ─► download ─► idempotency check ─► OCR ─► classify + extract ─► validate
                                       ─► decide status ─► route ─► store (SQL + Cosmos) ─► move blob ─► Logic App ─► audit

The same class is used by (1) the Azure Function (functions/function_app.py), (2) the local Event Grid emulator
and (3) the batch runner, so the cloud and the laptop run IDENTICAL business logic.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta

import config
from src import common
from src import schemas as S
from src.pipeline import events as ev
from src.pipeline import feedback, splitter, telemetry
from src.pipeline.audit import audit
from src.providers.llm import get_engine
from src.providers.ocr import UnreadableDocument, get_ocr
from src.routing import logic_app, router
from src.storage.blob_store import get_blob
from src.storage.cosmos_store import get_cosmos
from src.storage.sql_store import get_sql
from src.validation import rules

FINAL = ("PASSED", "NEEDS_REVIEW", "DUPLICATE", "REJECTED", "FAILED", "SPLIT")


def doc_id_for(blob_name: str) -> str:
    """Deterministic, so a re-delivered event maps to the same document row (idempotency)."""
    return "DOC-" + hashlib.sha1(blob_name.encode()).hexdigest()[:10].upper()


def patient_key(fields: dict) -> str:
    """Pseudonymous patient key (de-identified analytics): hash of member id, else name + DOB."""
    v = lambda n: (fields.get(n) or {}).get("value")
    basis = v("member_id") or f"{v('patient_name')}|{v('dob')}"
    return hashlib.sha256(str(basis).encode()).hexdigest()[:12] if basis and basis != "None|None" else ""


def estimate_cost(pages: int, tokens_in: int, tokens_out: int, text_len: int) -> float:
    """What this document WOULD cost on Azure (placeholder rates in config.py)."""
    tin = tokens_in or text_len // 4 + 350
    tout = tokens_out or 450
    return round(pages * config.COST_PER_1000_PAGES_LAYOUT / 1000 + tin * config.COST_PER_1M_INPUT_TOKENS / 1e6
                 + tout * config.COST_PER_1M_OUTPUT_TOKENS / 1e6, 5)


class DocumentProcessor:
    def __init__(self, blob=None, sql=None, cosmos=None, ocr=None, engine=None):
        self.blob = blob or get_blob()
        self.sql = sql or get_sql()
        self.cosmos = cosmos or get_cosmos()
        self.ocr = ocr or get_ocr()
        self.engine = engine or get_engine()

    # ------------------------------------------------------------------ entry point for Event Grid / Function
    def handle_event(self, event: dict) -> dict:
        container, name = ev.parse_subject(event["subject"])
        if container != config.BLOB_CONTAINERS["incoming"]:
            return {"status": "IGNORED", "reason": f"container {container} is not watched"}
        return self.process_blob(container, name)

    # ------------------------------------------------------------------ the pipeline
    def process_blob(self, container: str, name: str, _ocr=None, _parent: dict | None = None) -> dict:
        """_ocr / _parent are used only when a packet is split: a part re-uses the packet's OCR and remembers where it came from."""
        doc_id = doc_id_for(name)
        cid = common.new_id("COR-")
        existing = self.sql.get_document(doc_id)
        if existing and existing["status"] in FINAL and existing["status"] != "FAILED":
            audit("duplicate_event_ignored", doc_id, correlation_id=cid, store=self.sql, blob=name)     # at-least-once delivery
            return {"doc_id": doc_id, "status": "IGNORED", "reason": "already processed", "existing_status": existing["status"]}

        meta = self.blob.metadata(container, name)
        received_at = meta.get("received_at") or common.iso_now()
        file_name = name.rsplit("/", 1)[-1]
        stages: dict[str, int] = {}
        self.sql.upsert("Documents", {"doc_id": doc_id, "file_name": file_name, "blob_container": container, "blob_name": name,
                                      "source": meta.get("source", "upload"), "status": "PROCESSING", "received_at": received_at})
        audit("received", doc_id, correlation_id=cid, store=self.sql, blob=name, source=meta.get("source", "upload"))
        try:
            with common.Timer() as t:
                data = self.blob.download(container, name)
            stages["download"] = t.ms
            sha = common.sha256_bytes(data)
            self.sql.upsert("Documents", {"doc_id": doc_id, "sha256": sha})
            if _parent:
                self.sql.upsert("Documents", {"doc_id": doc_id, "parent_doc_id": _parent["doc_id"], "page_range": _parent["page_range"]})

            # ---- idempotency: same bytes already processed under another name -> duplicate, do not process twice
            dup = self.sql.get_by_hash(sha)
            if dup and dup["doc_id"] != doc_id:
                return self._duplicate(doc_id, dup, name, container, received_at, cid, stages)

            # ---- OCR (retry on transient faults)
            ocr = _ocr or common.retry()(self.ocr.analyze)(data, file_name)
            stages["ocr"] = ocr.ms
            audit("ocr_done", doc_id, correlation_id=cid, store=self.sql, engine=ocr.engine, pages=ocr.pages,
                  confidence=ocr.avg_confidence, scanned=ocr.is_scanned)

            # ---- packet splitting: one file holding several documents becomes several documents
            if config.PACKET_SPLITTING and _parent is None and ocr.pages > 1 and len(ocr.page_texts) == ocr.pages:
                segs = splitter.split_pages(ocr.page_texts)
                if len(splitter.real_segments(segs)) > 1:
                    res = self._split_packet(doc_id, container, name, file_name, data, sha, meta, received_at, ocr, segs, cid, stages)
                    if res:
                        return res

            # ---- classify + extract
            out = self.engine.classify_and_extract(ocr.text, ocr.words, ocr.avg_confidence)
            stages["classify_extract"] = out.ms
            if out.doc_type in S.SCHEMAS and (mem := feedback.apply_memory(out.doc_type, out.fields, self.sql, doc_id)):
                audit("memory_applied", doc_id, correlation_id=cid, store=self.sql, fields=mem)
            audit("classified", doc_id, correlation_id=cid, store=self.sql, doc_type=out.doc_type, confidence=out.type_confidence,
                  engine=out.engine, fallback=out.fallback_used)

            # ---- validate
            with common.Timer() as t:
                issues = rules.validate(out.doc_type, out.fields, claim_exists=lambda cn: self.sql.claim_number_exists(cn, doc_id),
                                        identity_lookup=lambda m: self.sql.identities_for_member(m, doc_id),
                                        provider_lookup=lambda n: self.sql.provider_names_for_npi(n, doc_id))
                doc_conf = rules.document_confidence(out.fields, out.doc_type)
                status, reasons = rules.decide_status(issues, out.type_confidence, doc_conf, out.doc_type)
            stages["validate"] = t.ms
            audit("validated", doc_id, correlation_id=cid, store=self.sql, issues=len(issues), status=status, rules=sorted({i.rule_id for i in issues}))

            # ---- route
            with common.Timer() as t:
                decision = router.route(out.doc_type, out.fields, status, reasons, received_at)
            stages["route"] = t.ms

            # ---- persist
            with common.Timer() as t:
                total_ms = sum(stages.values()) + 0
                self._persist(doc_id, file_name, container, name, sha, meta, received_at, ocr, out, issues, doc_conf, status, decision,
                              reasons, total_ms)
            stages["store"] = t.ms
            self._save_stages(doc_id, stages, received_at)

            # ---- move the blob and hand over to the Logic App
            dest = {"PASSED": "processed", "NEEDS_REVIEW": "review"}[status]
            self.blob.move(container, config.BLOB_CONTAINERS[dest], name)
            self._finish_time(doc_id, received_at, sum(stages.values()))
            summary = {"doc_type": out.doc_type, "status": status, "billed_amount": (out.fields.get("billed_amount") or {}).get("value"),
                       "issue_count": len(issues), "urgency": (out.fields.get("urgency") or {}).get("value")}
            logic_app.dispatch(doc_id, decision.to_dict(), summary, self.sql)
            ev.publish_custom_event("docintake.document.processed", doc_id, {"status": status, "doc_type": out.doc_type, "route": decision.workflow_id})
            audit("routed", doc_id, correlation_id=cid, store=self.sql, workflow=decision.workflow_id, priority=decision.priority)
            telemetry.event("document_processed", doc_id, sum(stages.values()), status=status, doc_type=out.doc_type, workflow=decision.workflow_id)
            telemetry.metric("ocr_confidence", ocr.avg_confidence, doc_id, doc_type=out.doc_type)
            return {"doc_id": doc_id, "status": status, "doc_type": out.doc_type, "route": decision.workflow_id, "issues": len(issues), "stages": stages}
        except Exception as exc:
            return self._fail(doc_id, container, name, received_at, cid, exc, stages)

    # ------------------------------------------------------------------ packets
    def _split_packet(self, doc_id, container, name, file_name, data, sha, meta, received_at, ocr, segs, cid, stages) -> dict | None:
        parts = splitter.real_segments(segs)
        blobs = []
        for k, sg in enumerate(parts, 1):
            piece = splitter.slice_bytes(data, file_name, sg.start, sg.end)
            if piece is None:
                audit("split_skipped", doc_id, correlation_id=cid, store=self.sql, reason="file format cannot be cut by page")
                return None
            stem, _, ext = file_name.rpartition(".")
            blobs.append((f"{stem}__part{k:02d}.{ext or 'pdf'}", piece, sg))
        audit("split_packet", doc_id, correlation_id=cid, store=self.sql, parts=len(blobs),
              segments=[{"pages": sg.page_range, "type": sg.doc_type, "why": sg.reason} for _, _, sg in blobs])
        prefix = name.rpartition("/")[0]
        children = []
        for cname, piece, sg in blobs:
            full = f"{prefix}/{cname}" if prefix else cname
            self.blob.upload(container, full, piece, {**{k: v for k, v in meta.items() if k in ("received_at", "source")}, "parent": doc_id})
            r = self.process_blob(container, full, _ocr=splitter.slice_ocr(ocr, sg.start, sg.end), _parent={"doc_id": doc_id, "page_range": sg.page_range})
            children.append({"file": cname, "pages": sg.page_range, **{k: r.get(k) for k in ("doc_id", "status", "doc_type", "route")}})
        self.sql.upsert("Documents", {"doc_id": doc_id, "doc_type": "packet", "status": "SPLIT", "review_status": "none", "page_count": ocr.pages,
                                      "is_scanned": int(ocr.is_scanned), "ocr_engine": ocr.engine, "ocr_confidence": ocr.avg_confidence,
                                      "split_count": len(children), "issue_count": 0, "error_count": 0, "warning_count": 0,
                                      "est_cost_usd": round(ocr.pages * config.COST_PER_1000_PAGES_LAYOUT / 1000, 5),
                                      "processing_ms": stages.get("ocr", 0)})
        self._save_stages(doc_id, {**stages}, received_at)
        self._finish_time(doc_id, received_at, sum(stages.values()))
        self.blob.move(container, config.BLOB_CONTAINERS["processed"], name)
        ev.publish_custom_event("docintake.packet.split", doc_id, {"parts": len(children)})
        telemetry.event("packet_split", doc_id, len(children), pages=ocr.pages)
        return {"doc_id": doc_id, "status": "SPLIT", "doc_type": "packet", "children": children, "stages": stages}

    # ------------------------------------------------------------------ helpers
    def _persist(self, doc_id, file_name, container, name, sha, meta, received_at, ocr, out, issues, doc_conf, status, decision, reasons, total_ms):
        f = out.fields
        pname, pnpi = S.PROVIDER_FIELDS.get(out.doc_type, (None, None))
        val = lambda n: (f.get(n) or {}).get("value") if n else None
        pdate = val(S.PRIMARY_DATE.get(out.doc_type)) if out.doc_type in S.PRIMARY_DATE else None
        errs = sum(1 for i in issues if i.severity == "error")
        row = {
            "doc_id": doc_id, "doc_type": out.doc_type, "type_confidence": out.type_confidence, "status": status,
            "review_status": "pending" if status == "NEEDS_REVIEW" else "none", "route_id": decision.workflow_id, "priority": decision.priority,
            "page_count": ocr.pages, "is_scanned": int(ocr.is_scanned), "ocr_engine": ocr.engine, "extract_engine": out.engine,
            "ocr_confidence": ocr.avg_confidence, "doc_confidence": doc_conf, "issue_count": len(issues), "error_count": errs,
            "warning_count": len(issues) - errs, "fallback_used": int(out.fallback_used), "patient_key": patient_key(f),
            "provider_name": val(pname), "provider_npi": val(pnpi), "insurer": val("insurer"),
            "primary_date": str(pdate) if pdate else None, "billed_amount": val("billed_amount") if isinstance(val("billed_amount"), (int, float)) else None,
            "tokens_in": out.tokens_in, "tokens_out": out.tokens_out, "phi_masked_spans": out.masked_spans, "cross_doc_flags": sum(1 for i in issues if i.rule_id in rules.CROSS_RULES),
            "est_cost_usd": estimate_cost(ocr.pages, out.tokens_in, out.tokens_out, len(ocr.text)), "processing_ms": total_ms,
        }
        self.sql.upsert("Documents", row)
        self.sql.delete("ExtractedFields", "doc_id=?", [doc_id])
        for n, x in f.items():
            self.sql.insert("ExtractedFields", {"doc_id": doc_id, "field_name": n, "value_json": json.dumps(x.get("value"), default=str),
                                                "confidence": x.get("confidence", 0.0), "source": x.get("source"), "note": x.get("note")})
        self.sql.delete("ValidationIssues", "doc_id=?", [doc_id])
        for i in issues:
            self.sql.insert("ValidationIssues", {"doc_id": doc_id, "rule_id": i.rule_id, "severity": i.severity, "field_name": i.field,
                                                 "message": i.message, "resolved": 0})
        d = decision.to_dict()
        self.sql.upsert("Routing", {"doc_id": doc_id, "workflow_id": d["workflow_id"], "workflow_name": d["workflow_name"], "team": d["team"],
                                    "priority": d["priority"], "sla_hours": d["sla_hours"], "sla_due_at": d["sla_due_at"], "reason": d["reason"],
                                    "intended_workflow_id": d["intended_workflow_id"], "created_at": received_at, "status": "open"})
        if status == "NEEDS_REVIEW":
            self.sql.upsert("ReviewTasks", {"task_id": "RV-" + doc_id[4:], "doc_id": doc_id, "reason": "; ".join(reasons), "status": "open",
                                            "created_at": received_at})
        self.cosmos.upsert({"id": doc_id, "doc_type": out.doc_type, "file": file_name, "blob": f"{container}/{name}", "sha256": sha,
                            "ocr": {"engine": ocr.engine, "pages": ocr.pages, "confidence": ocr.avg_confidence, "text": ocr.text},
                            "model": {"engine": out.engine, "raw": out.raw, "tokens_in": out.tokens_in, "tokens_out": out.tokens_out},
                            "fields": {k: {"value": v.get("value"), "confidence": v.get("confidence"), "note": v.get("note")} for k, v in f.items()},
                            "issues": [i.to_dict() for i in issues], "status": status})

    def _save_stages(self, doc_id, stages, received_at):
        ts = common.iso_now()
        for st, ms in stages.items():
            self.sql.upsert("ProcessingStages", {"doc_id": doc_id, "stage": st, "ms": ms, "status": "ok", "ts": ts})

    def _finish_time(self, doc_id, received_at, ms):
        """processed_at = arrival + the measured processing time (the clock of the synthetic arrivals is simulated)."""
        try:
            t = datetime.fromisoformat(received_at.rstrip("Z")) + timedelta(milliseconds=ms)
            self.sql.upsert("Documents", {"doc_id": doc_id, "processed_at": t.isoformat(timespec="milliseconds") + "Z", "processing_ms": ms})
        except ValueError:
            self.sql.upsert("Documents", {"doc_id": doc_id, "processed_at": common.iso_now(), "processing_ms": ms})

    def _duplicate(self, doc_id, original, name, container, received_at, cid, stages):
        self.sql.upsert("Documents", {"doc_id": doc_id, "status": "DUPLICATE", "duplicate_of": original["doc_id"], "doc_type": original["doc_type"],
                                      "route_id": "W-DUP", "review_status": "none", "priority": "Low", "issue_count": 0, "error_count": 0,
                                      "warning_count": 0, "est_cost_usd": 0.0})
        self.sql.upsert("Routing", {"doc_id": doc_id, "workflow_id": "W-DUP", "workflow_name": "Duplicate (archived)", "team": "No action",
                                    "priority": "Low", "sla_hours": 0, "sla_due_at": received_at, "reason": f"Identical to {original['doc_id']}",
                                    "created_at": received_at, "status": "closed"})
        self.blob.move(container, config.BLOB_CONTAINERS["quarantine"], name)       # archived outside the normal flow
        self._finish_time(doc_id, received_at, sum(stages.values()))
        audit("duplicate_detected", doc_id, correlation_id=cid, store=self.sql, original=original["doc_id"])
        return {"doc_id": doc_id, "status": "DUPLICATE", "duplicate_of": original["doc_id"], "stages": stages}

    def _fail(self, doc_id, container, name, received_at, cid, exc, stages):
        reason = f"{type(exc).__name__}: {exc}"[:400]
        decision = router.route("unknown", {}, "FAILED", None, received_at)
        self.sql.upsert("Documents", {"doc_id": doc_id, "status": "FAILED", "failure_reason": reason, "route_id": "W-DLQ", "priority": decision.priority,
                                      "doc_type": "unknown", "review_status": "none", "issue_count": 0, "error_count": 0, "warning_count": 0,
                                      "est_cost_usd": 0.0})
        self.sql.upsert("Routing", {"doc_id": doc_id, "workflow_id": "W-DLQ", "workflow_name": decision.workflow_name, "team": decision.team,
                                    "priority": decision.priority, "sla_hours": decision.sla_hours, "sla_due_at": decision.sla_due_at,
                                    "reason": reason, "created_at": received_at, "status": "open"})
        telemetry.event("document_failed", doc_id, None, reason=type(exc).__name__)
        self.sql.insert("DeadLetter", {"dl_id": common.new_id("DL-"), "ts": common.iso_now(), "doc_id": doc_id, "blob_name": name,
                                       "stage": "processing", "reason": reason, "attempts": config.MAX_RETRIES, "status": "open",
                                       "payload_json": json.dumps({"container": container, "stages": stages})})
        try:
            self.blob.move(container, config.BLOB_CONTAINERS["quarantine"], name)
        except Exception:
            pass
        self._finish_time(doc_id, received_at, sum(stages.values()))
        logic_app.dispatch(doc_id, decision.to_dict(), {"doc_type": "unknown", "status": "FAILED"}, self.sql)
        audit("failed_dead_lettered", doc_id, correlation_id=cid, store=self.sql, reason=reason)
        return {"doc_id": doc_id, "status": "FAILED", "reason": reason}
