"""Operations on documents after the automatic pipeline: human review, dead-letter retry, reset.

Human-in-the-loop rules
  approve  : the reviewer confirms the extraction as is (allowed even with warnings; errors need a note)
  correct  : the reviewer edits field values -> the document is RE-VALIDATED; if it is now clean it is released to its
             intended workflow, otherwise it stays in the queue with the remaining issues
  reject   : the document is closed as REJECTED and kept in quarantine
Every action is audited with the reviewer's identity.
"""
from __future__ import annotations

import json

import config
from src import common
from src import schemas as S
from src.pipeline.audit import audit
from src.pipeline.events import blob_created_event
from src.routing import logic_app, router
from src.storage.blob_store import get_blob
from src.storage.cosmos_store import get_cosmos
from src.storage.sql_store import SqlStore, get_sql
from src.validation import rules


def effective_fields(sql: SqlStore, doc_id: str) -> dict[str, dict]:
    """Extracted fields with human corrections applied (corrected value wins)."""
    out = {}
    for n, x in sql.fields_of(doc_id).items():
        if x.get("corrected") is not None:
            out[n] = {"value": x["corrected"], "confidence": 1.0, "source": "human", "note": f"corrected by {x['corrected_by']}"}
        else:
            out[n] = x
    return out


def coerce(kind: str, text):
    """Turn what a reviewer typed into the typed value for the field."""
    if text is None or text == "":
        return None
    if not isinstance(text, str):
        return text
    if kind == "money":
        return common.parse_money(text)
    if kind == "int":
        return int(float(text))
    if kind == "date":
        return common.to_iso_date(text) or text
    if kind == "icd_list":
        return [c.strip().upper() for c in text.replace(";", ",").split(",") if c.strip()]
    if kind in ("cpt_lines", "lab_rows"):
        return json.loads(text)
    return text.strip()


def resolve_review(doc_id: str, reviewer: str, action: str, corrections: dict | None = None, notes: str = "",
                   sql: SqlStore | None = None) -> dict:
    sql = sql or get_sql()
    doc = sql.get_document(doc_id)
    if not doc:
        raise KeyError(doc_id)
    if action not in ("approve", "correct", "reject"):
        raise ValueError(action)
    blob = get_blob()
    now = common.iso_now()
    dtype = doc["doc_type"]
    changed = 0
    typed: dict = {}
    if action == "correct" and corrections:
        for name, raw in corrections.items():
            f = S.field_spec(dtype, name)
            if not f:
                continue
            val = coerce(f.kind, raw)
            typed[name] = val
            sql.upsert("ExtractedFields", {"doc_id": doc_id, "field_name": name, "corrected_json": json.dumps(val, default=str), "corrected_by": reviewer})
            changed += 1
    eff = effective_fields(sql, doc_id)
    if typed:                                                   # feedback loop: remember what the reviewer fixed (read value vs typed value)
        by_field: dict[str, list[str]] = {}
        for i in sql.query("SELECT rule_id, field_name FROM ValidationIssues WHERE doc_id=?", [doc_id]):
            by_field.setdefault(i["field_name"], []).append(i["rule_id"])
        from src.pipeline import feedback
        feedback.record_corrections(sql, doc_id, dtype, reviewer, typed, by_field)
    issues = rules.validate(dtype, eff, claim_exists=lambda cn: sql.claim_number_exists(cn, doc_id),
                            identity_lookup=lambda m: sql.identities_for_member(m, doc_id),
                            provider_lookup=lambda n: sql.provider_names_for_npi(n, doc_id)) if dtype in S.SCHEMAS else []
    # confidence warnings no longer apply to values a human confirmed
    issues = [i for i in issues if not (i.rule_id == "R021" and (eff.get(i.field) or {}).get("source") == "human")]
    errs = [i for i in issues if i.severity == "error"]

    result_status, review_status = "NEEDS_REVIEW", "pending"
    if action == "reject":
        result_status, review_status = "REJECTED", "rejected"
    elif action == "approve":
        if errs and not notes.strip():
            raise ValueError("Approving a document that still has validation errors needs a justification note.")
        result_status, review_status = "PASSED", "approved_override" if errs else "approved"
    elif action == "correct":
        if not errs:
            result_status, review_status = "PASSED", "corrected"

    # re-write issues (resolved flag)
    sql.delete("ValidationIssues", "doc_id=?", [doc_id])
    for i in issues:
        sql.insert("ValidationIssues", {"doc_id": doc_id, "rule_id": i.rule_id, "severity": i.severity, "field_name": i.field,
                                        "message": i.message, "resolved": int(result_status == "PASSED" and i.severity != "error")})
    sql.upsert("Documents", {"doc_id": doc_id, "status": result_status, "review_status": review_status, "issue_count": len(issues),
                             "error_count": len(errs), "warning_count": len(issues) - len(errs)})
    if result_status == "PASSED":
        route = router.route(dtype, eff, "PASSED", None, doc["received_at"])
        sql.upsert("Routing", {"doc_id": doc_id, "workflow_id": route.workflow_id, "workflow_name": route.workflow_name, "team": route.team,
                               "priority": route.priority, "sla_hours": route.sla_hours, "sla_due_at": route.sla_due_at,
                               "reason": f"Released after human review ({review_status}): {route.reason}", "status": "open"})
        sql.upsert("Documents", {"doc_id": doc_id, "route_id": route.workflow_id, "priority": route.priority})
        blob.move(config.BLOB_CONTAINERS["review"], config.BLOB_CONTAINERS["processed"], doc["blob_name"])
        logic_app.dispatch(doc_id, route.to_dict(), {"doc_type": dtype, "status": "PASSED", "released_after_review": True}, sql)
    elif result_status == "REJECTED":
        sql.upsert("Routing", {"doc_id": doc_id, "status": "closed", "reason": f"Rejected by reviewer: {notes}"})
        blob.move(config.BLOB_CONTAINERS["review"], config.BLOB_CONTAINERS["quarantine"], doc["blob_name"])
    task_status = {"PASSED": "approved" if action == "approve" else "corrected", "REJECTED": "rejected"}.get(result_status, "open")
    sql.upsert("ReviewTasks", {"task_id": "RV-" + doc_id[4:], "doc_id": doc_id, "status": task_status,
                               "resolved_at": now if result_status != "NEEDS_REVIEW" else None, "reviewer": reviewer, "resolution_notes": notes,
                               "fields_changed": changed})
    try:                                                       # keep the raw JSON store in step
        item = get_cosmos().get(doc_id, dtype)
        if item:
            item["status"], item["human_review"] = result_status, {"reviewer": reviewer, "action": action, "notes": notes, "at": now}
            get_cosmos().upsert(item)
    except Exception:
        pass
    audit(f"review_{action}", doc_id, actor=reviewer, store=sql, fields_changed=changed, new_status=result_status, notes_given=bool(notes))
    return {"doc_id": doc_id, "status": result_status, "review_status": review_status, "remaining_errors": [i.to_dict() for i in errs]}


def retry_dead_letter(dl_id: str, actor: str = "operator", sql: SqlStore | None = None) -> dict:
    """Put a quarantined blob back into `incoming` so Event Grid fires again."""
    from src.pipeline.batch import make_pipeline
    sql = sql or get_sql()
    row = sql.one("SELECT * FROM DeadLetter WHERE dl_id=?", [dl_id])
    if not row:
        raise KeyError(dl_id)
    blob = get_blob()
    q, inc = config.BLOB_CONTAINERS["quarantine"], config.BLOB_CONTAINERS["incoming"]
    name = row["blob_name"]
    if not blob.exists(q, name):
        sql.upsert("DeadLetter", {"dl_id": dl_id, "status": "discarded"})
        return {"status": "gone", "detail": "blob no longer in quarantine"}
    blob.move(q, inc, name)
    if row["doc_id"]:
        sql.delete("Documents", "doc_id=?", [row["doc_id"]])        # allow a clean re-run
    sql.upsert("DeadLetter", {"dl_id": dl_id, "status": "retried"})
    audit("dead_letter_retry", row["doc_id"], actor=actor, store=sql, dl_id=dl_id)
    grid = make_pipeline()
    size = len(blob.download(inc, name))
    status = grid.publish(blob_created_event(inc, name, size, "application/octet-stream"))
    return {"status": status}


def reset_all(keep_logs: bool = False) -> None:
    sql = get_sql()
    sql.reset_all()
    get_blob().reset()
    if not keep_logs:
        for f in config.LOG_DIR.glob("*.jsonl"):
            f.unlink()
