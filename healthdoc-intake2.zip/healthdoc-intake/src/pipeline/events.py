"""Event Grid.

In Azure: Storage emits `Microsoft.Storage.BlobCreated` to an Event Grid SYSTEM TOPIC; an event subscription
(infra/main.bicep) pushes it to the Function (functions/function_app.py). Event Grid delivers AT LEAST ONCE and
retries on failure, so the handler is idempotent.

Locally: `LocalEventGrid` creates events with the SAME JSON schema, records them in the Events table, delivers them to
subscribers, retries with back-off and dead-letters after the retry limit, so the UI Pipeline Monitor shows the
same life-cycle you would see in Azure.
"""
from __future__ import annotations

import json
import time
import uuid
from typing import Callable

import config
from src import common
from src.pipeline.audit import audit
from src.storage.sql_store import get_sql

EVENT_MAX_ATTEMPTS = 3


def blob_created_event(container: str, name: str, size: int, content_type: str, url: str = "", metadata: dict | None = None) -> dict:
    acct = "docintakestore"
    return {
        "id": str(uuid.uuid4()), "topic": f"/subscriptions/0000/resourceGroups/rg-docintake/providers/Microsoft.Storage/storageAccounts/{acct}",
        "subject": f"/blobServices/default/containers/{container}/blobs/{name}", "eventType": "Microsoft.Storage.BlobCreated",
        "eventTime": common.iso_now(), "dataVersion": "", "metadataVersion": "1",
        "data": {"api": "PutBlob", "clientRequestId": str(uuid.uuid4()), "contentType": content_type, "contentLength": size,
                 "blobType": "BlockBlob", "url": url, "eTag": "0x" + uuid.uuid4().hex[:15].upper(), "metadata": metadata or {}},
    }


def parse_subject(subject: str) -> tuple[str, str]:
    """'/blobServices/default/containers/incoming/blobs/2026/10/x.pdf' -> ('incoming', '2026/10/x.pdf')"""
    marker = "/containers/"
    rest = subject.split(marker, 1)[1]
    container, _, name = rest.partition("/blobs/")
    return container, name


class LocalEventGrid:
    def __init__(self):
        self.subscribers: list[Callable[[dict], object]] = []
        self.sql = get_sql()

    def subscribe(self, handler: Callable[[dict], object]):
        self.subscribers.append(handler)

    def publish(self, event: dict) -> str:
        """Deliver to every subscriber with retries. Returns delivered | dead_lettered."""
        self.sql.upsert("Events", {"event_id": event["id"], "ts": event["eventTime"], "event_type": event["eventType"],
                                   "subject": event["subject"], "status": "pending", "attempts": 0, "payload_json": json.dumps(event)})
        status, attempts, last = "delivered", 0, ""
        for handler in self.subscribers:
            for attempts in range(1, EVENT_MAX_ATTEMPTS + 1):
                try:
                    handler(event)
                    last = ""
                    break
                except Exception as exc:               # a handler exception = delivery failure -> retry (like Event Grid)
                    last = f"{type(exc).__name__}: {exc}"
                    self.sql.upsert("Events", {"event_id": event["id"], "status": "retrying", "attempts": attempts})
                    time.sleep(config.RETRY_BASE_SECONDS * (2 ** (attempts - 1)))
            else:
                status = "dead_lettered"
        self.sql.upsert("Events", {"event_id": event["id"], "status": status, "attempts": attempts})
        if status == "dead_lettered":
            self.sql.insert("DeadLetter", {"dl_id": common.new_id("DL-"), "ts": common.iso_now(), "doc_id": None,
                                           "blob_name": parse_subject(event["subject"])[1], "stage": "event_delivery",
                                           "reason": last, "attempts": attempts, "status": "open", "payload_json": json.dumps(event)})
            audit("event_dead_lettered", subject=event["subject"], reason=last)
        return status


def publish_custom_event(event_type: str, subject: str, data: dict) -> bool:
    """Publish a `docintake.*` event to an Azure Event Grid custom topic when configured (e.g. document.processed)."""
    endpoint, key = config.env("EVENT_GRID_TOPIC_ENDPOINT"), config.env("EVENT_GRID_TOPIC_KEY")
    if config.FORCE_LOCAL or not endpoint:
        return False
    try:
        from azure.core.credentials import AzureKeyCredential
        from azure.core.messaging import CloudEvent
        from azure.eventgrid import EventGridPublisherClient
        client = EventGridPublisherClient(endpoint, AzureKeyCredential(key))
        client.send(CloudEvent(source="docintake", type=event_type, subject=subject, data=data))
        return True
    except Exception:
        return False
