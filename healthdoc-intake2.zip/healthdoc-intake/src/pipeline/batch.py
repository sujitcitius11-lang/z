"""Ingest files: upload to the `incoming` blob container, raise the BlobCreated event, let the pipeline run.

Local mode wires the processor to the LocalEventGrid. In Azure the upload alone is enough: Azure's own Event Grid
subscription calls the Function, so `ingest()` only uploads and (optionally) waits for the result.
"""
from __future__ import annotations

import json
import multiprocessing as mp
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

import config
from src import common
from src.pipeline.events import LocalEventGrid, blob_created_event
from src.pipeline.processor import DocumentProcessor, doc_id_for
from src.storage.blob_store import get_blob
from src.storage.sql_store import get_sql


def make_pipeline() -> LocalEventGrid:
    grid = LocalEventGrid()
    grid.subscribe(DocumentProcessor().handle_event)
    return grid


def blob_name_for(filename: str, received_at: str | None = None) -> str:
    d = datetime.fromisoformat((received_at or common.iso_now()).rstrip("Z"))
    return f"{d:%Y/%m/%d}/{filename}"


def ingest(filename: str, data: bytes, source: str = "upload", received_at: str | None = None, grid: LocalEventGrid | None = None) -> dict:
    """Upload one document. Returns {blob, doc_id, event_status}."""
    if not filename.lower().endswith(config.ALLOWED_EXTENSIONS):
        raise ValueError(f"unsupported file type: {filename}")
    if len(data) > config.UPLOAD_LIMIT_MB * 1024 * 1024:
        raise ValueError(f"file larger than {config.UPLOAD_LIMIT_MB} MB")
    blob = get_blob()
    inc = config.BLOB_CONTAINERS["incoming"]
    ts = received_at or common.iso_now()
    name = blob_name_for(filename, ts)
    if blob.exists(inc, name) or blob.exists(config.BLOB_CONTAINERS["processed"], name) or blob.exists(config.BLOB_CONTAINERS["review"], name) \
            or blob.exists(config.BLOB_CONTAINERS["quarantine"], name):
        stem, dot, ext = filename.rpartition(".")
        name = blob_name_for(f"{stem}_{common.new_id()[:6]}.{ext}", ts)          # same filename, different upload
    info = blob.upload(inc, name, data, metadata={"received_at": ts, "source": source})
    if config.mode("event_grid") == "azure":
        return {"blob": name, "doc_id": doc_id_for(name), "event_status": "raised_by_azure"}
    grid = grid or make_pipeline()
    status = grid.publish(blob_created_event(inc, name, info["size"], info["content_type"], info["url"]))
    return {"blob": name, "doc_id": doc_id_for(name), "event_status": status}


# ----------------------------------------------------------------------------- parallel batch
_worker_grid = None


def _init_worker():
    global _worker_grid
    _worker_grid = make_pipeline()


def _work(args):
    path, received_at, source = args
    try:
        p = Path(path)
        r = ingest(p.name, p.read_bytes(), source, received_at, grid=_worker_grid)
        return {"file": p.name, **r}
    except Exception as exc:
        return {"file": Path(path).name, "error": f"{type(exc).__name__}: {exc}"}


def run_batch(files: list[Path], received: dict[str, str] | None = None, workers: int = 2, source: str = "batch",
              progress: Callable[[int, int], None] | None = None) -> dict:
    received = received or {}
    jobs = [(str(f), received.get(f.name), source) for f in files]
    t0, done, errors = time.time(), 0, []
    if workers <= 1:
        _init_worker()
        it = map(_work, jobs)
        pool = None
    else:
        pool = mp.get_context("spawn").Pool(workers, initializer=_init_worker)
        it = pool.imap_unordered(_work, jobs, chunksize=4)
    for r in it:
        done += 1
        if "error" in r:
            errors.append(r)
        if progress and (done % 10 == 0 or done == len(jobs)):
            progress(done, len(jobs))
    if pool:
        pool.close()
        pool.join()
    return {"files": len(jobs), "errors": errors, "seconds": round(time.time() - t0, 1)}
