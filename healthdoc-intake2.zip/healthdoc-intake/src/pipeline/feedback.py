"""The review feedback loop: reviewer corrections make the system better, not just the one document.

Four ways the corrections are used
  1. LOG       every corrected field is stored (what the system read, what the person typed, confidence, rules involved)
  2. MEMORY    when the SAME wrong reading was corrected the SAME way at least MIN_REPEATS times, later documents with that reading are
               fixed automatically (and marked "learned from reviewers"). Only for text-like fields (names, free text, choices):
               never for ids, dates, amounts or codes, where a remembered answer could be dangerous.
  3. TUNING    review outcomes show which thresholds are too strict or too loose (how often a flagged document was approved unchanged)
  4. TRAINING  corrected documents are exported as a fine-tuning file (chat format for Azure OpenAI) or CSV, with PHI masked by default

Honest limit: memory only helps with repeating, identical misreadings. It does not retrain a model; the export is the step towards that.
"""
from __future__ import annotations

import csv
import io
import json
import re
from collections import Counter, defaultdict

import config
from src import common
from src import schemas as S
from src.pipeline.audit import audit
from src.storage.sql_store import SqlStore, get_sql

MIN_REPEATS = int(__import__("os").getenv("FEEDBACK_MIN_REPEATS", "2"))
SAFE_KINDS = ("name", "text", "choice")


def _norm(v) -> str:
    return re.sub(r"[^a-z0-9]", "", str(v).lower()) if v not in (None, "") else ""


# ------------------------------------------------------------------------------------------------------------ 1. log
def record_corrections(sql: SqlStore, doc_id: str, doc_type: str, reviewer: str, corrections: dict, issues_by_field: dict[str, list[str]]) -> int:
    """Called by the review action. `corrections` = {field: typed corrected value}. Stores the pairs that really changed a value."""
    n = 0
    read = sql.fields_of(doc_id)
    doc = sql.get_document(doc_id) or {}
    for name, new in corrections.items():
        old = (read.get(name) or {}).get("value")
        if _norm(old) == _norm(new) and old == new:
            continue
        f = S.field_spec(doc_type, name)
        sql.insert("Corrections", {"ts": common.iso_now(), "doc_id": doc_id, "doc_type": doc_type, "field_name": name,
                                   "read_value": json.dumps(old, default=str), "corrected_value": json.dumps(new, default=str),
                                   "confidence": (read.get(name) or {}).get("confidence"), "source": (read.get(name) or {}).get("source"),
                                   "reviewer": reviewer, "rule_ids": ",".join(issues_by_field.get(name, [])), "ocr_engine": doc.get("ocr_engine"),
                                   "applied_count": 0})
        n += 1
    return n


# ------------------------------------------------------------------------------------------------------------ 2. memory
def learned_rules(sql: SqlStore | None = None, min_repeats: int | None = None) -> list[dict]:
    """[{doc_type, field, read, corrected, times}] for consistent corrections of text-like fields."""
    sql = sql or get_sql()
    min_repeats = min_repeats or MIN_REPEATS
    pairs: dict[tuple, Counter] = defaultdict(Counter)
    for r in sql.query("SELECT doc_type, field_name, read_value, corrected_value FROM Corrections"):
        f = S.field_spec(r["doc_type"], r["field_name"])
        if not f or f.kind not in SAFE_KINDS:
            continue
        try:
            old, new = json.loads(r["read_value"]), json.loads(r["corrected_value"])
        except (TypeError, ValueError):
            continue
        if old in (None, "") or new in (None, ""):
            continue
        pairs[(r["doc_type"], r["field_name"], _norm(old))][json.dumps(new)] += 1
    out = []
    for (dt, fn, old_n), counter in pairs.items():
        (new_j, times), = counter.most_common(1)
        if times >= min_repeats and times == sum(counter.values()):          # never contradicted
            out.append({"doc_type": dt, "field": fn, "read": old_n, "corrected": json.loads(new_j), "times": times})
    return sorted(out, key=lambda r: -r["times"])


def apply_memory(doc_type: str, fields: dict[str, dict], sql: SqlStore | None = None, doc_id: str | None = None, rules: list[dict] | None = None) -> int:
    """Fix fields in place using what reviewers taught the system. Returns how many fields were changed."""
    if not getattr(config, "FEEDBACK_MEMORY", True):
        return 0
    sql = sql or get_sql()
    rules = rules if rules is not None else learned_rules(sql)
    idx = {(r["doc_type"], r["field"], r["read"]): r for r in rules}
    n = 0
    for name, x in fields.items():
        v = x.get("value")
        if v in (None, "") or not isinstance(v, str):
            continue
        hit = idx.get((doc_type, name, _norm(v)))
        if hit and hit["corrected"] != v:
            x["note"] = f"auto-corrected from \"{v}\": reviewers fixed this reading {hit['times']} times"
            x["value"], x["source"] = hit["corrected"], "memory"
            x["confidence"] = round(max(x.get("confidence", 0.0), 0.9), 3)
            n += 1
    if n and doc_id:
        audit("feedback_memory_applied", doc_id, store=sql, fields=n)
    return n


# ------------------------------------------------------------------------------------------------------------ 3. tuning
def review_analytics(sql: SqlStore | None = None) -> dict:
    sql = sql or get_sql()
    tasks = sql.query("SELECT t.doc_id, t.status, t.reason, t.fields_changed, d.doc_confidence, d.error_count, d.warning_count, d.doc_type "
                      "FROM ReviewTasks t JOIN Documents d ON d.doc_id=t.doc_id WHERE t.status IN ('approved','corrected','rejected')")
    n = len(tasks)
    st = Counter(t["status"] for t in tasks)
    by_reason = defaultdict(lambda: Counter())
    only_conf = [t for t in tasks if (t["error_count"] or 0) == 0 and (t["warning_count"] or 0) < 2]
    for t in tasks:
        key = "validation error" if (t["error_count"] or 0) else "2+ warnings" if (t["warning_count"] or 0) >= 2 else "low confidence only"
        by_reason[key][t["status"]] += 1
    conf_bands = defaultdict(lambda: [0, 0])
    for r in sql.query("SELECT c.confidence FROM Corrections c"):
        if r["confidence"] is not None:
            conf_bands[min(int(r["confidence"] * 10), 9) / 10][0] += 1
    fld = Counter(f"{r['doc_type']}.{r['field_name']}" for r in sql.query("SELECT doc_type, field_name FROM Corrections"))
    rules = Counter(x for r in sql.query("SELECT rule_ids FROM Corrections") for x in (r["rule_ids"] or "").split(",") if x)
    adv = []
    if len(only_conf) >= 20:
        unchanged = sum(1 for t in only_conf if t["status"] == "approved") / len(only_conf)
        if unchanged >= 0.9:
            adv.append(f"{unchanged:.0%} of documents flagged only for low confidence were approved without any change ({len(only_conf)} reviews): "
                       f"DOC_CONF_MIN (now {config.DOC_CONF_MIN}) may be too strict. Lower it a little and re-check the silent-error rate on the Accuracy page.")
        elif unchanged <= 0.5:
            adv.append(f"Only {unchanged:.0%} of low-confidence-only reviews were approved unchanged: the threshold is catching real problems; keep it or raise it.")
    elif n:
        adv.append(f"Only {len(only_conf)} low-confidence-only reviews so far; at least 20 are needed before a threshold recommendation is meaningful.")
    return {"reviews": n, "approved_unchanged": st["approved"], "corrected": st["corrected"], "rejected": st["rejected"],
            "by_reason": {k: dict(v) for k, v in by_reason.items()}, "corrections_total": sum(fld.values()),
            "top_fields": fld.most_common(10), "top_rules": rules.most_common(10), "advice": adv, "learned_rules": len(learned_rules(sql))}


# ------------------------------------------------------------------------------------------------------------ 4. training data
def export_training(sql: SqlStore | None = None, mask: bool = True) -> dict:
    """-> {"jsonl": str, "csv": str, "documents": n}. JSONL is Azure OpenAI chat fine-tuning format: the model sees the OCR text and must answer the
    corrected JSON. With mask=True the text and values are pseudonymised first (src/security/deid.py), which a real project must do before any
    training use of patient data."""
    from src.pipeline.operations import effective_fields
    from src.providers.llm import SYSTEM_EXTRACT
    from src.storage.cosmos_store import get_cosmos
    sql = sql or get_sql()
    cos = get_cosmos()
    docs = sql.query("SELECT DISTINCT doc_id, doc_type FROM Corrections")
    lines, rows = [], []
    for d in docs:
        item = cos.get(d["doc_id"], d["doc_type"])
        if not item:
            continue
        text = (item.get("ocr") or {}).get("text", "")
        eff = effective_fields(sql, d["doc_id"])
        answer = {k: v.get("value") for k, v in eff.items()}
        if mask:
            from src.security import deid
            text, m = deid.pseudonymise(text, d["doc_type"], {k: v.get("value") for k, v in eff.items()})
            answer = {k: deid.tokenise_value(v, m) for k, v in answer.items()}
        lines.append(json.dumps({"messages": [{"role": "system", "content": SYSTEM_EXTRACT},
                                              {"role": "user", "content": f"DOCUMENT TEXT:\n<<<\n{text[:12000]}\n>>>"},
                                              {"role": "assistant", "content": json.dumps(answer, default=str)}]}))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["ts", "doc_id", "doc_type", "field", "read_value", "corrected_value", "confidence", "reviewer", "rules"])
    for r in sql.query("SELECT * FROM Corrections ORDER BY corr_id"):
        w.writerow([r["ts"], r["doc_id"], r["doc_type"], r["field_name"], r["read_value"], r["corrected_value"], r["confidence"], r["reviewer"], r["rule_ids"]])
    return {"jsonl": "\n".join(lines), "csv": buf.getvalue(), "documents": len(lines), "masked": mask}
