"""Reusable UI pieces: banner, KPI tiles, chips, intake belt, conveyor, field table, original-document image."""
from __future__ import annotations

import html as _html
import io

import streamlit as st

import config
from app import theme
from src import common
from src import reference_data as R
from src import schemas as S
from src.storage.blob_store import get_blob
from src.validation.rules import CATALOGUE

esc = _html.escape


def md(html: str) -> None:
    """Render raw HTML safely (no indentation, or Markdown turns it into a code block)."""
    st.markdown("".join(line.strip() for line in html.strip().splitlines()), unsafe_allow_html=True)


def banner(title: str, purpose: str, user: dict | None = None) -> None:
    who = ""
    if user:
        who = f'<div class="who"><b>{esc(user["name"])}</b><br>{esc(user["role_label"])}</div>'
    md(f'<div class="banner"><div><h1>{esc(title)}</h1><p>{esc(purpose)}</p></div>{who}</div>')
    md('<div class="synth">Synthetic data only. Every patient, provider and organisation in this system is fictional.</div>')


def tiles(items: list[tuple]) -> None:
    """items: (label, value, sub, color[, unit])"""
    out = []
    for it in items:
        label, value, sub, color = it[:4]
        unit = f"<small>{esc(it[4])}</small>" if len(it) > 4 and it[4] else ""
        out.append(f'<div class="tile" style="--c:{color}"><div class="l">{esc(label)}</div><div class="v">{esc(str(value))}{unit}</div>'
                   f'<div class="s">{esc(sub)}</div></div>')
    md(f'<div class="tiles">{"".join(out)}</div>')


def status_chip(status: str) -> str:
    fg, bg, label = theme.STATUS.get(status, (theme.SLATE, "#ECEFF5", status.title()))
    return f'<span class="chip" style="--fg:{fg};--bg:{bg}">{esc(label)}</span>'


def priority_chip(p: str) -> str:
    fg, bg = theme.PRIORITY.get(p, (theme.SLATE, "#ECEFF5"))
    return f'<span class="chip" style="--fg:{fg};--bg:{bg}">{esc(p)}</span>'


def severity_chip(sev: str) -> str:
    return f'<span class="chip sev-{esc(sev)}">{esc(sev)}</span>'


def empty(title: str, body: str) -> None:
    md(f'<div class="empty"><b>{esc(title)}</b>{esc(body)}</div>')


def note(text: str, warn: bool = False) -> None:
    md(f'<div class="{"warnbox" if warn else "note"}">{esc(text)}</div>')


def belt(counts: dict[str, int]) -> None:
    """The 'intake belt': one bar, every document, coloured by where it ended up."""
    total = sum(counts.values()) or 1
    segs, legend = [], []
    for key in ("PASSED", "NEEDS_REVIEW", "REJECTED", "DUPLICATE", "SPLIT", "FAILED"):
        n = counts.get(key, 0)
        if not n:
            continue
        fg, bg, label = theme.STATUS[key]
        color = {"PASSED": theme.TEAL, "NEEDS_REVIEW": "#E0A030", "REJECTED": theme.PURPLE, "DUPLICATE": "#A9B2C8", "SPLIT": theme.SLATE, "FAILED": theme.CORAL}[key]
        segs.append(f'<div style="width:{100 * n / total:.2f}%;background:{color}" title="{label}: {n}"></div>')
        legend.append(f'<span><i style="background:{color}"></i>{label} {n:,} ({100 * n / total:.1f}%)</span>')
    md(f'<div class="belt">{"".join(segs)}</div><div class="belt-legend">{"".join(legend)}</div>')


STAGES = [("download", "Blob Storage"), ("event", "Event Grid"), ("ocr", "Document Intelligence"), ("classify_extract", "OpenAI extract"),
          ("validate", "Validate"), ("route", "Route"), ("store", "SQL and Cosmos")]


def conveyor(stage_ms: dict[str, int], failed: bool = False, event_ok: bool = True) -> None:
    out = []
    for key, label in STAGES:
        if key == "event":
            cls, m = ("ok", "delivered") if event_ok else ("bad", "failed")
        elif key in stage_ms:
            cls, m = "ok", f"{stage_ms[key]:,} ms"
        else:
            cls, m = ("bad", "stopped") if failed else ("skip", "skipped")
        out.append(f'<div class="st {cls}"><div class="n">{esc(label)}</div><div class="m">{m}</div></div>')
    md(f'<div class="conv">{"".join(out)}</div>')


def conf_bar(c: float | None) -> str:
    c = max(0.0, min(1.0, c or 0.0))
    col = theme.TEAL if c >= config.FIELD_CONF_MIN else "#E0A030" if c >= 0.5 else theme.CORAL
    return f'<span class="cbar"><i style="width:{c * 100:.0f}%;background:{col}"></i></span> <span class="muted">{c:.2f}</span>'


def show_value(name: str, value, phi: bool, limit: int = 110) -> str:
    """Printable value, masked for roles that may not see PHI."""
    if value is None or value == "":
        return '<span class="muted">not found</span>'
    if not phi and name in common.PHI_FIELDS_TO_MASK:
        value = common.PHI_FIELDS_TO_MASK[name](value)
    if isinstance(value, list):
        if value and isinstance(value[0], dict):
            if "cpt" in value[0]:
                s = "; ".join(f'{r["cpt"]} x{r["units"]} ${r["charge"]:,.2f}' for r in value)
            else:
                s = "; ".join(f'{r["test"]} {r["value"]}{r.get("flag") and " " + r["flag"] or ""}' for r in value)
        else:
            s = ", ".join(map(str, value))
    elif isinstance(value, float) and name in ("billed_amount",):
        s = f"${value:,.2f}"
    else:
        s = str(value)
    return esc(s if len(s) <= limit else s[:limit] + "...")


def field_table(doc_type: str, fields: dict[str, dict], issues: list[dict], phi: bool) -> None:
    by_field: dict[str, list[dict]] = {}
    for i in issues:
        by_field.setdefault(i["field_name"], []).append(i)
    rows = []
    for f in S.SCHEMAS.get(doc_type, []):
        x = fields.get(f.name, {})
        cor = x.get("corrected")
        conf = x.get("confidence") or 0
        val = cor if cor is not None else x.get("value")
        bad = any(i["severity"] == "error" for i in by_field.get(f.name, []))
        low = (val not in (None, "") and conf < config.FIELD_CONF_MIN and cor is None)
        cls = "err" if bad else "low" if low else ""
        extra = ""
        if cor is not None:
            extra = f' <span class="chip" style="--fg:{theme.PURPLE};--bg:#F1E8FA">corrected by {esc(str(x.get("corrected_by") or "reviewer"))}</span>'
        elif x.get("note"):
            extra = f' <span class="muted">({esc(x["note"])})</span>'
        req = "" if f.required else ' <span class="muted">(optional)</span>'
        rows.append(f'<tr class="{cls}"><td>{esc(f.display)}{req}</td><td>{show_value(f.name, val, phi)}{extra}</td>'
                    f'<td>{conf_bar(1.0 if cor is not None else conf)}</td></tr>')
    md(f'<table class="ftab"><tr><th>Field</th><th>Value</th><th>Confidence</th></tr>{"".join(rows)}</table>')


def issues_list(issues: list[dict]) -> None:
    if not issues:
        md('<div class="note">No validation issues.</div>')
        return
    rows = []
    for i in issues:
        rule = CATALOGUE.get(i["rule_id"], ("", ""))[1]
        rows.append(f'<tr><td>{esc(i["rule_id"])}</td><td>{severity_chip(i["severity"])}</td><td>{esc(i["field_name"] or "")}</td>'
                    f'<td>{esc(i["message"])}</td></tr>')
    md(f'<table class="ftab"><tr><th>Rule</th><th>Severity</th><th>Field</th><th>What was found</th></tr>{"".join(rows)}</table>')


# ------------------------------------------------------------------ the original document as an image
def find_blob(doc: dict) -> tuple[str, str] | None:
    blob = get_blob()
    for c in ("processed", "review", "quarantine", "incoming"):
        try:
            if doc.get("blob_name") and blob.exists(config.BLOB_CONTAINERS[c], doc["blob_name"]):
                return config.BLOB_CONTAINERS[c], doc["blob_name"]
        except Exception:
            continue
    return None


@st.cache_data(ttl=300, show_spinner=False)
def _render_bytes(data: bytes, is_pdf: bool, page: int = 0, scale: float = 1.5) -> bytes | None:
    from PIL import Image
    try:
        if is_pdf:
            import pypdfium2 as pdfium
            pdf = pdfium.PdfDocument(data)
            page = min(page, len(pdf) - 1)
            img = pdf[page].render(scale=scale).to_pil().convert("RGB")
            pdf.close()
        else:
            img = Image.open(io.BytesIO(data)).convert("RGB")
            img.thumbnail((1100, 1500))
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return buf.getvalue()
    except Exception:
        return None


def page_count(data: bytes) -> int:
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(data)
        n = len(pdf)
        pdf.close()
        return n
    except Exception:
        return 1


def show_document(doc: dict, phi: bool, key: str = "") -> None:
    """Show page 1 (and a page picker for multi-page PDFs). Hidden for roles that may not see PHI."""
    if not phi:
        note("The original document image contains patient information and is hidden for your role.", warn=True)
        return
    loc = find_blob(doc)
    if not loc:
        empty("Original file not found", "It may have been removed from Blob Storage after processing.")
        return
    data = get_blob().download(*loc)
    is_pdf = data[:5] == b"%PDF-"
    n = page_count(data) if is_pdf else 1
    p = 0
    if n > 1:
        p = st.number_input("Page", 1, n, 1, key=f"pg_{key}_{doc['doc_id']}") - 1
    png = _render_bytes(data, is_pdf, p)
    if png:
        st.image(png, width="stretch", caption=f"{doc.get('file_name')} ({loc[0]})")
    else:
        empty("Cannot display this file", "The file is corrupt or not a readable document. See the Pipeline Monitor for the failure reason.")
