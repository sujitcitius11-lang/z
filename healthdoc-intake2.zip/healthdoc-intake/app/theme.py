"""Look and feel: indigo ink sidebar, paper-white work surface, teal for done / amber for human / coral for failed.
One memorable element: the 'intake belt' (a segmented bar that shows where every document ended up)."""
from __future__ import annotations

import streamlit as st

INK = "#1E2761"
INK_DEEP = "#141B4D"
TEAL = "#0E9384"
TEAL_DARK = "#0B6E63"
INDIGO = "#3B4BC8"
AMBER = "#B7791F"
CORAL = "#D1435B"
SLATE = "#64708C"
PURPLE = "#8A4FBF"
BG = "#F5F7FB"
BORDER = "#DDE3EE"
TEXT = "#1B2238"
MUTED = "#5B6580"

# status -> (foreground, background, label)
STATUS = {
    "PASSED": (TEAL_DARK, "#E3F5F2", "Passed"),
    "NEEDS_REVIEW": (AMBER, "#FFF3DB", "Needs review"),
    "FAILED": (CORAL, "#FDE8EC", "Failed"),
    "DUPLICATE": (SLATE, "#ECEFF5", "Duplicate"),
    "SPLIT": (PURPLE, "#F1EAF8", "Packet split"),
    "REJECTED": (PURPLE, "#F1E8FA", "Rejected"),
    "PROCESSING": (INDIGO, "#E7EAFB", "Processing"),
}
PRIORITY = {"Critical": (CORAL, "#FDE8EC"), "High": (AMBER, "#FFF3DB"), "Normal": (INDIGO, "#E7EAFB"), "Low": (SLATE, "#ECEFF5")}
TYPE_COLORS = {"enrollment": "#3B4BC8", "claim": "#0E9384", "referral": "#E08A1E", "prescription": "#C2417B",
               "lab_report": "#4B8FD6", "unknown": "#8A94AD"}
COLORWAY = ["#3B4BC8", "#0E9384", "#E08A1E", "#C2417B", "#4B8FD6", "#8A94AD", "#6B8E23", "#8A4FBF"]

CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Sora:wght@500;600;700&display=swap');
html, body, [class*="css"], .stMarkdown, .stText, label, input, textarea, button {{ font-family: 'Public Sans', 'Segoe UI', system-ui, sans-serif; }}
.block-container {{ padding-top: 1.1rem; padding-bottom: 3rem; max-width: 1400px; }}
#MainMenu, footer {{ visibility: hidden; }}
header[data-testid="stHeader"] {{ background: transparent; height: 2.2rem; }}
h1, h2, h3, h4 {{ font-family: 'Sora', 'Public Sans', sans-serif; color: {TEXT}; letter-spacing: -0.01em; }}
h3 {{ font-size: 1.12rem !important; margin-top: 1.1rem; }}

/* sidebar */
[data-testid="stSidebar"] {{ background: linear-gradient(180deg, {INK} 0%, {INK_DEEP} 100%); }}
[data-testid="stSidebar"] * {{ color: #E4E8FA; }}
[data-testid="stSidebar"] [data-baseweb="select"] * {{ color: #1B2150 !important; }}
[data-testid="stSidebar"] .stRadio label p {{ font-size: .93rem; }}
[data-testid="stSidebar"] input {{ background: rgba(255,255,255,.08) !important; color: #fff !important; }}
[data-testid="stSidebar"] [data-baseweb="input"] *, [data-testid="stSidebar"] [data-testid="stTextInputRootElement"] {{ background-color: #2B3480 !important; color: #fff !important; -webkit-text-fill-color: #fff !important; }}
[data-testid="stSidebar"] hr {{ border-color: rgba(255,255,255,.14); }}
[data-testid="stSidebar"] .stCaption, [data-testid="stSidebar"] small {{ color: #A9B3DC !important; }}
.brand {{ display:flex; align-items:center; gap:12px; padding: 6px 2px 14px 2px; }}
.brand .name {{ font-family:'Sora',sans-serif; font-weight:700; font-size:1.12rem; color:#fff; line-height:1.15; }}
.brand .tag {{ font-size:.78rem; color:#A9B3DC; }}
.svc-grid {{ display:flex; flex-wrap:wrap; gap:5px; margin-top:4px; }}
.svc {{ font-size:.72rem; padding:2px 8px; border-radius:999px; background:rgba(255,255,255,.09); border:1px solid rgba(255,255,255,.14); }}
.svc.az {{ background:rgba(14,147,132,.28); border-color:rgba(94,234,212,.5); color:#CFFAF1; }}

/* banner */
.banner {{ display:flex; align-items:flex-end; gap:18px; background:{INK}; background-image: linear-gradient(100deg,{INK} 0%, #27358A 70%, #2E4AA6 100%);
  border-radius: 14px; padding: 18px 24px 16px 24px; margin-bottom: 10px; color:#fff; }}
.banner h1 {{ margin:0; color:#fff; font-size:1.55rem; font-weight:700; }}
.banner p {{ margin:4px 0 0 0; color:#C9D1F5; font-size:.95rem; max-width: 70ch; }}
.banner .who {{ margin-left:auto; text-align:right; font-size:.82rem; color:#C9D1F5; white-space:nowrap; }}
.banner .who b {{ color:#fff; font-weight:600; }}
.synth {{ font-size:.8rem; color:{MUTED}; border-left:3px solid {TEAL}; padding:2px 10px; margin: 0 0 14px 2px; }}

/* cards + tiles */
.card {{ background:#fff; border:1px solid {BORDER}; border-radius:12px; padding:14px 16px; }}
.tiles {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(176px, 1fr)); gap:12px; margin: 4px 0 14px 0; }}
.tile {{ background:#fff; border:1px solid {BORDER}; border-radius:12px; padding:13px 15px 12px 15px; border-left:4px solid var(--c); }}
.tile .l {{ font-size:.8rem; color:{MUTED}; font-weight:500; }}
.tile .v {{ font-family:'Sora',sans-serif; font-size:1.75rem; font-weight:700; color:{TEXT}; line-height:1.2; margin-top:2px; }}
.tile .v small {{ font-size:.9rem; font-weight:600; color:{MUTED}; margin-left:3px; }}
.tile .s {{ font-size:.76rem; color:{MUTED}; margin-top:2px; }}

/* chips */
.chip {{ display:inline-block; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:600; background:var(--bg); color:var(--fg); white-space:nowrap; }}
.sev-error {{ --fg:{CORAL}; --bg:#FDE8EC; }} .sev-warning {{ --fg:{AMBER}; --bg:#FFF3DB; }}

/* intake belt */
.belt {{ display:flex; height:26px; border-radius:8px; overflow:hidden; border:1px solid {BORDER}; background:#fff; }}
.belt div {{ height:100%; }}
.belt-legend {{ display:flex; flex-wrap:wrap; gap:16px; margin:7px 0 12px 0; font-size:.84rem; color:{MUTED}; }}
.belt-legend i {{ display:inline-block; width:10px; height:10px; border-radius:3px; margin-right:6px; vertical-align:-1px; }}

/* pipeline conveyor */
.conv {{ display:flex; align-items:stretch; gap:0; margin: 6px 0 4px 0; flex-wrap:wrap; }}
.conv .st {{ flex:1 1 110px; position:relative; background:#fff; border:1px solid {BORDER}; padding:8px 10px 8px 16px; min-width:104px;
  clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 50%, calc(100% - 12px) 100%, 0 100%, 12px 50%); margin-right:-6px; }}
.conv .st:first-child {{ clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 50%, calc(100% - 12px) 100%, 0 100%); padding-left:10px; }}
.conv .st .n {{ font-size:.8rem; font-weight:600; color:{TEXT}; }}
.conv .st .m {{ font-size:.74rem; color:{MUTED}; }}
.conv .st.ok {{ background:#E3F5F2; }} .conv .st.bad {{ background:#FDE8EC; }} .conv .st.skip {{ background:#F1F3F8; }}

/* field table */
.ftab {{ width:100%; border-collapse:collapse; font-size:.88rem; }}
.ftab th {{ text-align:left; font-weight:600; color:{MUTED}; font-size:.78rem; padding:4px 8px; border-bottom:1px solid {BORDER}; }}
.ftab td {{ padding:6px 8px; border-bottom:1px solid #EEF1F7; vertical-align:top; }}
.ftab tr.low td {{ background:#FFF8E8; }} .ftab tr.err td {{ background:#FEF1F3; }}
.cbar {{ width:84px; height:7px; background:#E9EDF5; border-radius:4px; overflow:hidden; display:inline-block; vertical-align:middle; }}
.cbar i {{ display:block; height:100%; }}
.muted {{ color:{MUTED}; font-size:.85rem; }}
.empty {{ border:1.5px dashed {BORDER}; border-radius:12px; padding:22px; text-align:center; color:{MUTED}; background:#fff; }}
.empty b {{ color:{TEXT}; display:block; margin-bottom:4px; font-family:'Sora',sans-serif; }}
.note {{ background:#EEF1FD; border:1px solid #D5DBF8; border-radius:10px; padding:9px 13px; font-size:.86rem; color:#2B3480; margin:6px 0 10px 0; }}
.warnbox {{ background:#FFF8E8; border:1px solid #F1DDA8; border-radius:10px; padding:9px 13px; font-size:.86rem; color:#6B4A0B; margin:6px 0 10px 0; }}

/* streamlit widgets */
div[data-testid="stDataFrame"] {{ border:1px solid {BORDER}; border-radius:10px; }}
.stButton > button[kind="primary"] {{ background:{TEAL}; border-color:{TEAL}; font-weight:600; }}
.stButton > button[kind="primary"]:hover {{ background:{TEAL_DARK}; border-color:{TEAL_DARK}; }}
.stTabs [data-baseweb="tab"] {{ font-weight:600; }}
:focus-visible {{ outline: 2px solid {INDIGO}; outline-offset: 2px; }}
@media (prefers-reduced-motion: reduce) {{ * {{ animation: none !important; transition: none !important; }} }}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def style_fig(fig, height: int = 330, legend: bool = True):
    """Consistent Plotly look."""
    fig.update_layout(
        height=height, margin=dict(l=8, r=8, t=34, b=8), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Public Sans, Segoe UI, sans-serif", size=12, color=TEXT), colorway=COLORWAY,
        title=dict(font=dict(family="Sora, sans-serif", size=14, color=TEXT), x=0, xanchor="left"),
        showlegend=legend, legend=dict(orientation="h", y=-0.18, x=0, font=dict(size=11)),
    )
    fig.update_xaxes(gridcolor="#E8ECF4", linecolor=BORDER, zeroline=False)
    fig.update_yaxes(gridcolor="#E8ECF4", linecolor=BORDER, zeroline=False)
    return fig
