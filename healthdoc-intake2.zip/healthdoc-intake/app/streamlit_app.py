"""Healthcare document intake: operations desk.   Run:  streamlit run app/streamlit_app.py"""
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import streamlit as st  # noqa: E402

import config  # noqa: E402
from app import theme  # noqa: E402
from app.components import banner, esc, md  # noqa: E402
from src.security import auth  # noqa: E402

st.set_page_config(page_title="Document Intake Desk", page_icon="📄", layout="wide", initial_sidebar_state="expanded")
theme.inject_css()

PAGES = {  # page -> (module, purpose)
    "Overview": ("overview", "How many documents arrived, where each one ended up and how fast."),
    "Upload & Process": ("upload", "Drop in documents and watch each one travel through the pipeline."),
    "Document Explorer": ("explorer", "Find any document and see exactly what the system read, checked and decided."),
    "Review Queue": ("review", "Documents the system was not sure about. Check, correct and release them."),
    "Workflows & Rules": ("workflows", "Where documents are sent, how fast, and which validation rules decide it."),
    "Pipeline Monitor": ("monitor", "Events, retries, duplicates and failed documents in the processing chain."),
    "Data Generator": ("generator", "Create synthetic healthcare documents with a known answer key."),
    "Accuracy & Evaluation": ("evaluation", "How often the system reads documents correctly, measured against the answer key."),
    "Power BI": ("powerbi", "The de-identified dataset and report that managers use."),
    "Azure Services": ("azure", "Every Azure service in this solution: mode, settings and connection checks."),
    "Audit Log": ("audit", "A PHI-safe record of every action taken on every document."),
    "About & Requirements": ("about", "Architecture, scope and how each project requirement is met."),
}
ROLE_LABELS = {"Intake.Admin": "Administrator", "Intake.Operator": "Operator", "Intake.Reviewer": "Reviewer", "Intake.Analyst": "Analyst"}
assert set(PAGES) == set(auth.PAGE_ACCESS), "pages must match auth.PAGE_ACCESS"


def sign_in() -> dict:
    """-> {"name", "roles", "role_label", "phi"}; stops the script when Entra sign-in is required."""
    if config.AUTH_MODE == "entra":
        try:
            if not st.user.is_logged_in:
                st.markdown("### Sign in")
                st.write("This deployment uses Microsoft Entra ID. Sign in with your work account.")
                if st.button("Sign in with Microsoft", type="primary"):
                    st.login("microsoft")
                st.stop()
            claims = dict(st.user)
            roles = auth.roles_from_claims(claims)
            name = claims.get("email") or claims.get("name") or "signed-in user"
            if not roles:
                st.error("You are signed in, but no Intake app role is assigned to your account. Ask an administrator to assign Intake.Reviewer, "
                         "Intake.Operator, Intake.Analyst or Intake.Admin in Microsoft Entra ID.")
                st.stop()
        except AttributeError:
            st.error("Entra sign-in needs Streamlit 1.42 or newer and an [auth] section in .streamlit/secrets.toml (client_id, client_secret, "
                     "redirect_uri, cookie_secret, server_metadata_url). See docs/CONCEPTS_AND_RUN_GUIDE.md. Set AUTH_MODE=demo to use the demo role picker.")
            st.stop()
        with st.sidebar:
            if st.button("Sign out"):
                st.logout()
    else:
        with st.sidebar:
            label = st.selectbox("Demo role", list(ROLE_LABELS.values()), index=0, key="demo_role",
                                 help="Demo mode has no password. In production the role comes from Microsoft Entra ID (AUTH_MODE=entra).")
            name = st.text_input("Your name", st.session_state.get("demo_name", "demo.user@docintake.local"), key="demo_name")
        roles = [next(r for r, l in ROLE_LABELS.items() if l == label)]
    return {"name": name or "demo.user", "roles": roles, "role_label": " and ".join(ROLE_LABELS[r] for r in roles),
            "phi": auth.can_see_phi(roles)}


def service_badges() -> None:
    modes = config.service_modes()
    names = {"blob": "Blob", "event_grid": "Event Grid", "doc_intelligence": "Doc Intelligence", "openai": "OpenAI", "sql": "SQL", "cosmos": "Cosmos",
             "key_vault": "Key Vault", "logic_apps": "Logic Apps", "entra": "Entra ID"}
    chips = "".join(f'<span class="svc {"az" if modes[k] == "azure" else ""}">{n}: {modes[k]}</span>' for k, n in names.items())
    md(f'<div class="svc-grid">{chips}</div>')


with st.sidebar:
    md('<div class="brand"><svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg"><rect width="38" height="38" rx="10" fill="#0E9384"/>'
       '<path d="M11 8h11l6 6v16H11z" fill="#fff"/><path d="M22 8v6h6" fill="#BFEFE8"/><path d="M15 23l3 3 6-7" stroke="#0E9384" stroke-width="2.4" '
       'fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg><div><div class="name">Document Intake Desk</div>'
       '<div class="tag">AI-powered healthcare document processing</div></div></div>')

user = sign_in()
allowed = [p for p in PAGES if p in auth.allowed_pages(user["roles"])]
with st.sidebar:
    page = st.radio("Go to", allowed, key=f"nav_{'_'.join(user['roles'])}", label_visibility="collapsed")
    st.divider()
    st.caption("Services (local = built-in stand-in, azure = live Azure resource)")
    service_badges()
    st.caption("Synthetic data only. Not for clinical use.")

module_name, purpose = PAGES[page]
banner(page, purpose, user)
try:
    mod = importlib.import_module(f"app.views.{module_name}")
    mod.render(user)
except Exception as exc:  # a broken page must never take the whole app down
    st.error(f"This page could not be displayed: {type(exc).__name__}: {exc}")
    st.exception(exc)
