import json
import tempfile
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src import schemas as S
from src.datagen.generate import generate_all


def _page_png(path: Path) -> bytes | None:
    import io
    try:
        if path.suffix.lower() == ".pdf":
            import pypdfium2 as pdfium
            pdf = pdfium.PdfDocument(str(path))
            img = pdf[0].render(scale=1.3).to_pil()
        else:
            from PIL import Image
            img = Image.open(path).convert("RGB")
            img.thumbnail((900, 1200))
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return buf.getvalue()
    except Exception:
        return None


def render(user):
    man_path = config.SYNTH_DIR / "manifest.json"
    if man_path.exists():
        m = json.loads(man_path.read_text(encoding="utf-8"))
        C.tiles([("Documents", f"{m['total_documents']:,}", "5 types x 500", theme.INDIGO), ("Patients", m["patients"], "fictional, consistent across documents", theme.TEAL),
                 ("Providers", m["providers"], "valid NPI check digits", theme.TEAL), ("Text source", m["narrative_source"].replace("_", " "), "referral reasons and lab comments", theme.PURPLE),
                 ("Seed", m["seed"], "same seed = same dataset", theme.SLATE)])
        c1, c2, c3 = st.columns(3)
        with c1:
            d = pd.DataFrame({"type": [S.DOC_TYPE_LABELS[k] for k in m["by_type"]], "docs": list(m["by_type"].values())})
            st.plotly_chart(theme.style_fig(px.bar(d, x="type", y="docs", title="By document type").update_traces(marker_color=theme.INDIGO), 300, False), width="stretch")
        with c2:
            d = pd.DataFrame({"format": list(m["by_format"]), "docs": list(m["by_format"].values())})
            st.plotly_chart(theme.style_fig(px.pie(d, names="format", values="docs", hole=.55, title="By file format"), 300), width="stretch")
        with c3:
            d = pd.DataFrame({"defect": list(m["defect_counts"]), "docs": list(m["defect_counts"].values())}).sort_values("docs")
            st.plotly_chart(theme.style_fig(px.bar(d, x="docs", y="defect", orientation="h", title="Deliberate defects").update_traces(marker_color=theme.CORAL), 300, False), width="stretch")
        C.note("Defects are injected on purpose (bad NPI, future date, wrong totals, missing fields, duplicates ...) so validation, review and duplicate "
               "detection have real work to do. The answer key records what was injected, which is how detection is measured.")
    else:
        C.empty("No dataset yet", "Run scripts/generate_data.py or use the generator below.")

    st.markdown("### Browse the dataset with its answer key")
    key = svc.answer_key()
    if key:
        c1, c2 = st.columns([1, 3])
        t = c1.selectbox("Type", S.DOC_TYPES, format_func=lambda x: S.DOC_TYPE_LABELS[x])
        files = [f for f, a in key.items() if a["doc_type"] == t]
        f = c1.selectbox("Document", files[:300])
        a = key[f]
        c1.caption(f"Format: {a['meta']['format']}  |  layout {a['meta']['layout']}  |  noise {a['meta']['noise']}  |  defects: {', '.join(a['meta']['defects']) or 'none'}")
        png = _page_png(config.SYNTH_DIR / "documents" / t / f)
        with c2:
            i, j = st.columns(2)
            if png:
                i.image(png, caption="The document as it was generated", width="stretch")
            shown = {k: v for k, v in a["fields"].items()}
            if not user["phi"]:
                from src import common
                shown = common.mask_fields(shown)
            j.markdown("**Answer key (ground truth)**")
            j.json(shown, expanded=1)

    st.markdown("### Generate a new dataset")
    if "Intake.Admin" not in user["roles"]:
        C.note("Only an Administrator can generate datasets.")
        return
    with st.form("gen"):
        c1, c2, c3, c4 = st.columns(4)
        per = c1.number_input("Documents per type", 1, 500, 20)
        seed = c2.number_input("Seed", 0, 99999, 2026)
        scan = c3.slider("Scanned / photo share", 0, 50, 10) / 100
        dfr = c4.slider("Defect share", 0, 40, 12) / 100
        c5, c6 = st.columns(2)
        dup = c5.number_input("Exact duplicates per type", 0, 50, 2)
        use_az = c6.checkbox("Use Azure OpenAI for narrative text when configured", True)
        replace = st.checkbox("Replace the real dataset in data/synthetic (the processed documents in the database keep pointing to their blobs)")
        confirm = st.text_input("Type REPLACE to confirm replacing") if replace else ""
        go = st.form_submit_button("Generate", type="primary")
    if go:
        if replace and confirm != "REPLACE":
            st.error("Type REPLACE to confirm.")
            return
        out = config.SYNTH_DIR if replace else Path(tempfile.mkdtemp(prefix="gen_", dir=config.DATA_DIR))
        bar = st.progress(0.0, "Generating ...")
        man = generate_all(out, int(per), int(seed), scan, dfr, int(dup), use_az, progress=lambda d, t, s: bar.progress(d / t, f"{d}/{t} {s}"), clean=True)
        bar.empty()
        st.success(f"Generated {man['total_documents']} documents in {man['seconds']} s at {out}")
        st.json({k: man[k] for k in ("by_type", "by_format", "defect_counts", "narrative_source")})
        svc.refresh()
