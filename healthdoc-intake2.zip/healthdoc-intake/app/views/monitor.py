import json

import pandas as pd
import plotly.express as px
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src.pipeline import events as ev
from src.pipeline.operations import retry_dead_letter


def _main(user):
    s = svc.sql()
    evs = svc.qdf("SELECT event_id, ts, event_type, subject, status, attempts FROM Events ORDER BY ts DESC")
    dl = svc.qdf("SELECT * FROM DeadLetter ORDER BY ts DESC")
    ignored = int(s.scalar("SELECT COUNT(*) FROM AuditLog WHERE action='duplicate_event_ignored'", default=0))
    dups = int(s.scalar("SELECT COUNT(*) FROM Documents WHERE status='DUPLICATE'", default=0))
    open_dl = int((dl.status == "open").sum()) if not dl.empty else 0
    C.tiles([
        ("Events received", f"{len(evs):,}", "BlobCreated events from the incoming container", theme.INDIGO),
        ("Delivered first time", f"{int(((evs.status == 'delivered') & (evs.attempts <= 1)).sum()) if not evs.empty else 0:,}", "no retry needed", theme.TEAL),
        ("Needed a retry", f"{int((evs.attempts > 1).sum()) if not evs.empty else 0:,}", "Event Grid style back-off", "#E0A030"),
        ("Open dead letters", open_dl, "need an operator", theme.CORAL),
        ("Duplicates caught", dups, "same bytes under another name", theme.PURPLE),
        ("Re-delivered events ignored", ignored, "idempotency at work", theme.SLATE),
    ])
    st.markdown("##### Blob containers")
    b = svc.blob()
    cols = st.columns(4)
    for col, (label, name) in zip(cols, config.BLOB_CONTAINERS.items()):
        col.metric(label.title(), f"{b.count(name):,}")
    C.note("incoming should be empty when everything is processed. review = waiting for a person, quarantine = failed or duplicate files.")

    c1, c2 = st.columns(2)
    with c1:
        d = svc.qdf("SELECT processing_ms FROM Documents WHERE processing_ms IS NOT NULL AND status<>'DUPLICATE'")
        if not d.empty:
            fig = px.histogram(d[d.processing_ms < d.processing_ms.quantile(.99)], x="processing_ms", nbins=40, title="Processing time per document (ms)")
            fig.update_traces(marker_color=theme.INDIGO)
            fig.update_layout(xaxis_title="milliseconds", yaxis_title="Documents")
            st.plotly_chart(theme.style_fig(fig, 320, False), width="stretch")
            st.caption("Digital PDFs finish in tens of milliseconds; scans and photos need OCR and take seconds (the long tail).")
    with c2:
        stg = svc.qdf("SELECT stage, ms FROM ProcessingStages")
        if not stg.empty:
            g = stg.groupby("stage").ms.describe(percentiles=[.5, .95])[["mean", "50%", "95%", "max"]].round(1).reset_index()
            g.columns = ["Stage", "Average ms", "Median ms", "95th pct ms", "Max ms"]
            st.markdown("**Latency by stage**")
            st.dataframe(g, hide_index=True, width="stretch")

    st.markdown("### Dead-letter queue")
    if dl.empty:
        C.empty("Dead-letter queue is empty", "Nothing has failed.")
    else:
        can_act = any(r in ("Intake.Admin", "Intake.Operator") for r in user["roles"])
        show = dl[["dl_id", "ts", "stage", "blob_name", "reason", "attempts", "status"]]
        st.dataframe(show, hide_index=True, width="stretch", height=min(360, 40 + 35 * len(show)))
        opn = dl[dl.status == "open"]
        if can_act and not opn.empty:
            pick = st.selectbox("Choose a dead letter", opn.dl_id.tolist(), format_func=lambda i: f"{i}  {opn[opn.dl_id == i].blob_name.iloc[0]}")
            a, b2 = st.columns(2)
            if a.button("Retry (put the file back in incoming)", type="primary"):
                out = retry_dead_letter(pick, actor=user["name"], sql=s)
                svc.refresh()
                st.success(f"Retried: {out}. A corrupt file will fail again and return to the queue.")
            if b2.button("Discard"):
                s.upsert("DeadLetter", {"dl_id": pick, "status": "discarded"})
                svc.refresh()
                st.rerun()
        elif not can_act:
            C.note("Only an Operator or Administrator can retry or discard dead letters.")

    st.markdown("### Events")
    if not evs.empty:
        sc = evs.status.value_counts().rename_axis("status").reset_index(name="events")
        st.dataframe(sc, hide_index=True)
        st.dataframe(evs.head(200), hide_index=True, width="stretch", height=300)
        with st.expander("Show one raw event (Event Grid schema)"):
            row = s.one("SELECT payload_json FROM Events ORDER BY ts DESC")
            if row:
                st.json(json.loads(row["payload_json"]))


def _telemetry():
    import plotly.express as px
    from app import theme
    st.markdown("### Telemetry (Application Insights)")
    if config.env("APPLICATIONINSIGHTS_CONNECTION_STRING") and not config.FORCE_LOCAL:
        C.note("Application Insights is configured: events and metrics go to Azure. Use the KQL queries in docs/MONITORING.md there. The table below shows the local copy only.")
    t = svc.qdf("SELECT ts, kind, name, doc_id, value FROM Telemetry ORDER BY tel_id DESC LIMIT 5000")
    if t.empty:
        C.empty("No telemetry yet", "Events appear here as documents are processed (document_processed, document_failed, packet_split ...).")
        return
    c1, c2 = st.columns(2)
    cnt = t.groupby("name", as_index=False).size()
    fig = px.bar(cnt, x="name", y="size", title="Events recorded")
    fig.update_traces(marker_color=theme.INDIGO)
    c1.plotly_chart(theme.style_fig(fig, 300, False), width="stretch")
    pr = t[(t.name == "document_processed") & t.value.notna()]
    if not pr.empty:
        fig = px.histogram(pr, x="value", nbins=40, title="document_processed: latency (ms)")
        fig.update_traces(marker_color=theme.TEAL)
        c2.plotly_chart(theme.style_fig(fig, 300, False), width="stretch")


def render(user):
    _main(user)
    _telemetry()
