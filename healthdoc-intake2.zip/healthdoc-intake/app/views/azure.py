import pandas as pd
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src.providers import health
from src.security import keyvault


def render(user):
    modes = config.service_modes()
    az = sum(1 for k in modes if modes[k] == "azure")
    C.tiles([("Services on Azure", az, f"of {len(modes)} switchable services", theme.INDIGO), ("Running locally", len(modes) - az, "built-in stand-ins", theme.TEAL),
             ("Force local", "ON" if config.FORCE_LOCAL else "off", "FORCE_LOCAL in .env", theme.SLATE)])
    C.note("Every service has a local stand-in with the same interface, so the whole system runs on a laptop. A service switches to Azure by itself as soon as its "
           "settings are present (names below, never values). The code that talks to Azure is covered by tests that use fake clients; it has not been run "
           "against a live subscription from this environment.")
    st.markdown("### Services")
    for key, (name, what, env) in health.SERVICES.items():
        mode = health.mode_of(key)
        with st.expander(f"{name}   -   {mode}", expanded=False):
            st.write(what)
            st.markdown("**Settings:** " + ", ".join(f"`{e}`" for e in env))
            if st.button("Test connection", key=f"t_{key}"):
                ok, msg = health.check(key)
                (st.success if ok else st.error)(msg)
    st.markdown("### Secrets")
    kv = keyvault.status()
    st.dataframe(pd.DataFrame([{"secret": k, "found in": v} for k, v in kv.items()]), hide_index=True, width="stretch")
    st.caption("Values are never displayed. Order of lookup: environment variable, then Key Vault (when KEY_VAULT_URI is set) using the managed identity.")

    st.markdown("### Cost estimator (placeholder prices)")
    c1, c2, c3 = st.columns(3)
    n = c1.number_input("Documents per month", 100, 5_000_000, 20000, step=1000)
    pages = c2.number_input("Average pages per document", 1.0, 20.0, 1.2, step=0.1)
    sc = c3.slider("Share needing the LLM (all of them by default)", 0, 100, 100) / 100
    ocr = n * pages * config.COST_PER_1000_PAGES_LAYOUT / 1000
    llm = n * sc * (1200 * config.COST_PER_1M_INPUT_TOKENS + 450 * config.COST_PER_1M_OUTPUT_TOKENS) / 1e6
    d = pd.DataFrame([{"item": "Document Intelligence (layout)", "usd / month": round(ocr, 2)}, {"item": "Azure OpenAI tokens", "usd / month": round(llm, 2)},
                      {"item": "Total for the two metered AI services", "usd / month": round(ocr + llm, 2)}])
    st.dataframe(d, hide_index=True, width="stretch")
    st.caption("Rates are placeholders in config.py (COST_PER_1000_PAGES_LAYOUT, COST_PER_1M_*_TOKENS). Check the Azure pricing page before quoting a client. "
               "Storage, Functions, SQL, Cosmos, Logic Apps and Power BI licences are extra. Savings tip: send only documents the cheap OCR could not classify to the LLM.")
