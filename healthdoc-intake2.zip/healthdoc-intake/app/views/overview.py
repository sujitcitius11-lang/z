import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src import schemas as S
from src.analytics import metrics
from src.validation.rules import CATALOGUE


def render(user):
    k = svc.kpis()
    if not k.get("total"):
        C.empty("No documents processed yet", "Open Upload & Process and drop in a few documents, or run scripts/run_pipeline.py to process the synthetic set.")
        return
    docs = svc.documents()
    counts = docs.status.value_counts().to_dict()
    st.markdown(f"##### Where {k['total']:,} documents ended up")
    C.belt(counts)
    C.tiles([
        ("Documents received", f"{k['total']:,}", f"{k['unique']:,} unique, {k['duplicates']:,} duplicates", theme.INDIGO),
        ("Straight-through rate", k["stp_rate"], "passed with no human touch", theme.TEAL, "%"),
        ("Sent to a person", k["review_rate"], f"{k['needs_review']:,} waiting or reviewed", "#E0A030", "%"),
        ("Failed", k["failure_rate"], f"{k['failed']:,} dead-lettered", theme.CORAL, "%"),
        ("Average time per document", k["avg_processing_s"], f"95th percentile {k['p95_processing_s']} s", theme.INDIGO, "s"),
        ("Hours saved", f"{k['hours_saved']:,.0f}", f"assumes {config.MANUAL_MINUTES_PER_DOC:g} min by hand vs {config.REVIEW_MINUTES_PER_DOC:g} min per flagged document", theme.TEAL, "h"),
        ("Estimated Azure cost", f"${k['est_cost_usd']:,.2f}", f"${k['est_cost_per_doc_usd']} per document, placeholder prices", theme.SLATE),
        ("Average confidence", k["avg_doc_confidence"], f"{k['scanned_share']}% of documents were scans or photos", theme.TEAL),
    ])

    c1, c2 = st.columns([3, 2])
    with c1:
        v = metrics.volume_by_day(svc.sql())
        if not v.empty:
            v["week"] = pd.to_datetime(v["day"]).dt.to_period("W").dt.start_time
            w = v.groupby(["week", "doc_type"], as_index=False).docs.sum()
            fig = px.area(w, x="week", y="docs", color="doc_type", color_discrete_map=theme.TYPE_COLORS, title="Documents received per week")
            fig.update_layout(xaxis_title=None, yaxis_title="Documents", legend_title=None)
            st.plotly_chart(theme.style_fig(fig, 340), width="stretch")
            st.caption("Arrival dates of the synthetic documents are simulated across 2025 to 2026.")
    with c2:
        sc = docs.status.value_counts().reset_index()
        sc.columns = ["status", "docs"]
        sc["label"] = sc.status.map(lambda s: theme.STATUS.get(s, (0, 0, s))[2])
        fig = px.pie(sc, names="label", values="docs", hole=.62, title="Outcome",
                     color="label", color_discrete_map={theme.STATUS[s][2]: c for s, c in
                                                       {"PASSED": theme.TEAL, "NEEDS_REVIEW": "#E0A030", "REJECTED": theme.PURPLE, "DUPLICATE": "#A9B2C8", "SPLIT": theme.SLATE, "FAILED": theme.CORAL}.items()})
        fig.update_traces(textinfo="percent", sort=False)
        st.plotly_chart(theme.style_fig(fig, 340), width="stretch")

    c3, c4 = st.columns(2)
    with c3:
        t = docs.groupby(["doc_type", "status"], as_index=False).size()
        t["type"] = t.doc_type.map(lambda x: S.DOC_TYPE_LABELS.get(x, x))
        fig = px.bar(t, x="type", y="size", color="status", title="Documents by type and outcome",
                     color_discrete_map={s: c for s, c in {"PASSED": theme.TEAL, "NEEDS_REVIEW": "#E0A030", "REJECTED": theme.PURPLE, "DUPLICATE": "#A9B2C8", "SPLIT": theme.SLATE, "FAILED": theme.CORAL}.items()})
        fig.update_layout(xaxis_title=None, yaxis_title="Documents", legend_title=None)
        st.plotly_chart(theme.style_fig(fig), width="stretch")
    with c4:
        w = docs.groupby("workflow_name", as_index=False).size().sort_values("size")
        fig = px.bar(w, x="size", y="workflow_name", orientation="h", title="Documents by destination workflow")
        fig.update_traces(marker_color=theme.INDIGO)
        fig.update_layout(xaxis_title="Documents", yaxis_title=None)
        st.plotly_chart(theme.style_fig(fig, legend=False), width="stretch")

    c5, c6 = st.columns(2)
    with c5:
        iss = svc.qdf("SELECT rule_id, severity, COUNT(*) AS n FROM ValidationIssues GROUP BY rule_id, severity ORDER BY n DESC")
        if iss.empty:
            C.empty("No validation issues", "Every document passed every rule.")
        else:
            iss = iss.head(10).copy()
            iss["rule"] = iss.rule_id + "  " + iss.rule_id.map(lambda r: CATALOGUE.get(r, ("", ""))[1][:48])
            fig = px.bar(iss.sort_values("n"), x="n", y="rule", color="severity", orientation="h", title="Most frequent validation findings",
                         color_discrete_map={"error": theme.CORAL, "warning": "#E0A030"})
            fig.update_layout(xaxis_title="Times found", yaxis_title=None, legend_title=None)
            st.plotly_chart(theme.style_fig(fig, 360), width="stretch")
    with c6:
        st_ = svc.qdf("SELECT stage, ms FROM ProcessingStages")
        if st_.empty:
            C.empty("No timing data yet", "Stage timings appear after the first document is processed.")
        else:
            g = st_.groupby("stage").ms.agg(["mean", lambda x: x.quantile(.95)]).reset_index()
            g.columns = ["stage", "Average", "95th percentile"]
            order = ["download", "ocr", "classify_extract", "validate", "route", "store"]
            g["stage"] = pd.Categorical(g.stage, order, ordered=True)
            m = g.sort_values("stage").melt("stage", var_name="measure", value_name="ms")
            fig = px.bar(m, x="stage", y="ms", color="measure", barmode="group", title="Time per pipeline stage (milliseconds)",
                         color_discrete_sequence=[theme.INDIGO, theme.TEAL])
            fig.update_layout(xaxis_title=None, yaxis_title="ms", legend_title=None)
            st.plotly_chart(theme.style_fig(fig, 360), width="stretch")

    st.markdown("### Open work past its deadline")
    sla = metrics.sla_status(svc.sql())
    if sla.empty:
        C.empty("Nothing is past its deadline", "Every open work item is still inside its service-level window.")
    else:
        C.note(f"{len(sla):,} open work items are past their deadline as of {config.REFERENCE_DATE}. In this demo no team ever closes a work item, "
               "so the number only shows how the deadline clock works. The oldest are listed first.", warn=False)
        show = sla.sort_values("sla_due_at").head(25).rename(columns={"doc_id": "Document", "workflow_name": "Workflow", "team": "Team", "priority": "Priority",
                                                                       "sla_due_at": "Deadline", "doc_type": "Type", "status": "Status"})
        st.dataframe(show[["Document", "Type", "Workflow", "Team", "Priority", "Deadline", "Status"]], hide_index=True, width="stretch")
