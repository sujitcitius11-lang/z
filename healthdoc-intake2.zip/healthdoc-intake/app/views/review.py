import pandas as pd
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src import schemas as S
from src.pipeline import operations as ops
from src.routing.router import WORKFLOWS

PRIO = {"Critical": 0, "High": 1, "Normal": 2, "Low": 3}


def _queue() -> pd.DataFrame:
    q = svc.qdf("SELECT t.task_id, t.doc_id, t.reason, d.file_name, d.doc_type, d.priority, d.error_count, d.warning_count, d.doc_confidence, "
                "r.sla_due_at, r.intended_workflow_id FROM ReviewTasks t JOIN Documents d ON d.doc_id=t.doc_id "
                "LEFT JOIN Routing r ON r.doc_id=t.doc_id WHERE t.status='open' AND d.status='NEEDS_REVIEW'")
    if q.empty:
        return q
    q["p"] = q.priority.map(PRIO).fillna(2)
    return q.sort_values(["p", "sla_due_at"]).reset_index(drop=True)


def _input(f: S.FieldSpec, cur, key: str):
    if cur is None:
        txt = ""
    elif isinstance(cur, (list, dict)):
        import json
        txt = json.dumps(cur) if f.kind in ("cpt_lines", "lab_rows") else ", ".join(map(str, cur))
    else:
        txt = str(cur)
    if f.kind in ("cpt_lines", "lab_rows") or f.multiline:
        return st.text_area(f.display, txt, key=key, height=90), txt
    return st.text_input(f.display, txt, key=key), txt


def _queue_view(user):
    q = _queue()
    if q.empty:
        C.empty("The queue is empty", "No documents are waiting for a person. New ones appear here when validation finds a problem or confidence is low.")
        return
    errors_only = st.toggle("Only documents with validation errors", value=False, key="rv_err")
    if errors_only:
        q = q[q.error_count > 0].reset_index(drop=True)
    st.markdown(f"##### {len(q):,} documents waiting")
    view = pd.DataFrame({"Priority": q.priority, "File": q.file_name, "Type": q.doc_type, "Why it is here": q.reason.str[:90], "Errors": q.error_count,
                         "Warnings": q.warning_count, "Deadline": q.sla_due_at.str[:16].str.replace("T", " ")})
    ev = st.dataframe(view.head(200), hide_index=True, width="stretch", height=240, on_select="rerun", selection_mode="single-row", key="rv_table")
    sel = ev.selection.rows[0] if ev and ev.selection and ev.selection.rows else 0
    if sel >= len(q):
        sel = 0
    row = q.iloc[sel]
    doc_id = row.doc_id
    d = svc.doc_detail(doc_id)
    doc = d["doc"]
    st.divider()
    st.markdown(f"### {doc['file_name']}  " + C.status_chip(doc["status"]) + " " + C.priority_chip(doc.get("priority") or "Normal"), unsafe_allow_html=True)
    C.note(f"Why a person is needed: {row.reason}")
    if row.intended_workflow_id:
        st.caption(f"After release this document goes to: {WORKFLOWS[row.intended_workflow_id]['name']}")
    left, right = st.columns([4, 5])
    with left:
        C.show_document(doc, user["phi"], "rv")
    eff = ops.effective_fields(svc.sql(), doc_id)
    issues_by = {}
    for i in d["issues"]:
        issues_by.setdefault(i["field_name"], []).append(i)
    inputs: dict[str, tuple] = {}
    with right:
        if doc["doc_type"] in S.SCHEMAS:
            if not user["phi"]:
                C.note("Your role cannot see patient details, so the form is read-only. Ask an administrator or reviewer.", warn=True)
            C.issues_list(d["issues"])
            st.markdown("##### Check and correct the fields")
            for f in S.SCHEMAS[doc["doc_type"]]:
                x = eff.get(f.name, {})
                cur = x.get("value")
                label_issue = issues_by.get(f.name)
                if label_issue:
                    st.caption(f"{f.display}: " + "; ".join(f"{i['rule_id']} {i['message']}" for i in label_issue))
                c1, c2 = st.columns([6, 1])
                with c1:
                    new, old = _input(f, cur, f"rv_{doc_id}_{f.name}")
                with c2:
                    st.markdown(f'<div style="padding-top:1.9rem">{C.conf_bar(x.get("confidence"))}</div>', unsafe_allow_html=True)
                inputs[f.name] = (new, old)
        else:
            C.note("This document could not be classified. You can reject it, or approve it to send it to manual triage.", warn=False)
    notes = st.text_input("Note (required to approve a document that still has errors)", key=f"rv_note_{doc_id}")
    b1, b2, b3, _ = st.columns([2, 2, 2, 3])
    disabled = not user["phi"]
    act = None
    if b1.button("Correct and release", type="primary", disabled=disabled, key=f"rv_c_{doc_id}"):
        act = "correct"
    if b2.button("Approve as read", disabled=disabled, key=f"rv_a_{doc_id}"):
        act = "approve"
    if b3.button("Reject document", disabled=disabled, key=f"rv_r_{doc_id}"):
        act = "reject"
    if act:
        changes = {n: new for n, (new, old) in inputs.items() if new != old}
        try:
            out = ops.resolve_review(doc_id, user["name"], act, changes if act == "correct" else {}, notes, svc.sql())
            svc.refresh()
            if out["status"] == "NEEDS_REVIEW":
                st.warning("Saved, but the document still breaks these rules and stays in the queue:")
                for e in out["remaining_errors"]:
                    st.write(f"- {e['rule_id']} on {e['field']}: {e['message']}")
            elif out["status"] == "REJECTED":
                st.success("Document rejected and moved to quarantine.")
            else:
                st.success(f"Released ({out['review_status'].replace('_', ' ')}). It now goes to its workflow.")
            if out["status"] != "NEEDS_REVIEW":
                st.session_state["rv_table"] = {"selection": {"rows": [], "columns": []}}
        except ValueError as exc:
            st.error(str(exc))
        except Exception as exc:
            st.error(f"Could not save the review: {type(exc).__name__}: {exc}")


def _learning_view(user):
    import json
    from src.pipeline import feedback
    a = feedback.review_analytics(svc.sql())
    C.note("Every correction a reviewer makes is stored. When the same wrong reading has been corrected the same way "
           f"{feedback.MIN_REPEATS} times, new documents with that reading are fixed automatically (text-like fields only: never ids, dates, amounts or codes). "
           "Review outcomes also show whether the review thresholds are right, and corrected documents can be exported as fine-tuning data.")
    C.tiles([("Reviews finished", f"{a['reviews']:,}", "approved, corrected or rejected", theme.INDIGO),
             ("Approved unchanged", f"{a['approved_unchanged']:,}", "the reviewer found nothing to fix", theme.TEAL),
             ("Corrected", f"{a['corrected']:,}", f"{a['corrections_total']} field fixes recorded", "#E0A030"),
             ("Rules learned", f"{a['learned_rules']:,}", "applied to new documents automatically", theme.PURPLE)])
    for line in a["advice"]:
        C.note(line)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### Most corrected fields")
        st.dataframe(pd.DataFrame(a["top_fields"], columns=["field", "corrections"]), hide_index=True, width="stretch") if a["top_fields"] else st.caption("No corrections yet.")
    with c2:
        st.markdown("##### Rules that led to corrections")
        st.dataframe(pd.DataFrame(a["top_rules"], columns=["rule", "corrections"]), hide_index=True, width="stretch") if a["top_rules"] else st.caption("No corrections yet.")
    st.markdown("##### What the system has learned")
    rules_ = feedback.learned_rules(svc.sql())
    if rules_:
        st.dataframe(pd.DataFrame(rules_), hide_index=True, width="stretch")
    else:
        st.caption("Nothing learned yet. Correct the same misreading twice and it will appear here.")
    st.markdown("##### Training data")
    mask = st.toggle("Mask patient identifiers in the export", value=True, key="fb_mask")
    if user["phi"] or mask:
        if st.button("Prepare export"):
            st.session_state["fb_export"] = feedback.export_training(svc.sql(), mask=mask)
        ex = st.session_state.get("fb_export")
        if ex:
            st.caption(f"{ex['documents']} corrected documents ({'masked' if ex['masked'] else 'UNMASKED'}).")
            d1, d2 = st.columns(2)
            d1.download_button("Fine-tuning file (JSONL, Azure OpenAI chat format)", ex["jsonl"], "corrections_finetune.jsonl", "application/jsonl", disabled=not ex["jsonl"])
            d2.download_button("Corrections (CSV)", ex["csv"], "corrections.csv", "text/csv")
    else:
        C.note("Unmasked exports are limited to roles that may see PHI.", warn=True)


def render(user):
    t1, t2 = st.tabs(["Review queue", "Learning from corrections"])
    with t1:
        _queue_view(user)
    with t2:
        _learning_view(user)
