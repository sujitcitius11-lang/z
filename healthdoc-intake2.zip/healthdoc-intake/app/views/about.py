import re

import streamlit as st

import config
from app import components as C

SVG = """<svg viewBox="0 0 1100 330" xmlns="http://www.w3.org/2000/svg" style="width:100%;font-family:Segoe UI,Arial,sans-serif">
<defs><marker id="a" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#64708C"/></marker></defs>
<style>.b{fill:#fff;stroke:#3B4BC8;stroke-width:1.6;rx:10}.t{font-size:13px;fill:#1B2238;font-weight:600}.s{font-size:10.5px;fill:#5B6580}.g{stroke:#64708C;stroke-width:1.6;fill:none;marker-end:url(#a)}.h{fill:#E7EAFB}</style>
<rect x="10" y="20" width="110" height="64" class="b"/><text x="65" y="48" class="t" text-anchor="middle">Upload</text><text x="65" y="66" class="s" text-anchor="middle">UI / batch / fax</text>
<rect x="150" y="20" width="120" height="64" class="b"/><text x="210" y="48" class="t" text-anchor="middle">Blob Storage</text><text x="210" y="66" class="s" text-anchor="middle">incoming</text>
<rect x="300" y="20" width="120" height="64" class="b"/><text x="360" y="48" class="t" text-anchor="middle">Event Grid</text><text x="360" y="66" class="s" text-anchor="middle">BlobCreated</text>
<rect x="450" y="20" width="130" height="64" class="b"/><text x="515" y="48" class="t" text-anchor="middle">Azure Function</text><text x="515" y="66" class="s" text-anchor="middle">idempotent handler</text>
<rect x="610" y="0" width="150" height="52" class="b"/><text x="685" y="24" class="t" text-anchor="middle">Document Intelligence</text><text x="685" y="40" class="s" text-anchor="middle">OCR + layout</text>
<rect x="610" y="62" width="150" height="52" class="b"/><text x="685" y="86" class="t" text-anchor="middle">Azure OpenAI</text><text x="685" y="102" class="s" text-anchor="middle">classify + extract JSON</text>
<rect x="790" y="20" width="130" height="64" class="b"/><text x="855" y="48" class="t" text-anchor="middle">Validate</text><text x="855" y="66" class="s" text-anchor="middle">code, not the LLM</text>
<rect x="950" y="20" width="130" height="64" class="b"/><text x="1015" y="48" class="t" text-anchor="middle">Route</text><text x="1015" y="66" class="s" text-anchor="middle">workflow + SLA</text>
<path class="g" d="M120 52 H148"/><path class="g" d="M270 52 H298"/><path class="g" d="M420 52 H448"/><path class="g" d="M580 40 H608"/><path class="g" d="M580 64 H608"/><path class="g" d="M760 52 H788"/><path class="g" d="M920 52 H948"/>
<rect x="700" y="180" width="140" height="60" class="b"/><text x="770" y="206" class="t" text-anchor="middle">Azure SQL</text><text x="770" y="224" class="s" text-anchor="middle">facts, issues, audit</text>
<rect x="860" y="180" width="140" height="60" class="b"/><text x="930" y="206" class="t" text-anchor="middle">Cosmos DB</text><text x="930" y="224" class="s" text-anchor="middle">raw OCR + model JSON</text>
<rect x="1015" y="130" width="85" height="56" class="b"/><text x="1057" y="154" class="t" text-anchor="middle">Logic App</text><text x="1057" y="170" class="s" text-anchor="middle">notify team</text>
<rect x="520" y="270" width="160" height="50" class="b"/><text x="600" y="293" class="t" text-anchor="middle">Review Queue (human)</text><text x="600" y="309" class="s" text-anchor="middle">approve / correct / reject</text>
<rect x="700" y="270" width="140" height="50" class="b"/><text x="770" y="293" class="t" text-anchor="middle">Power BI</text><text x="770" y="309" class="s" text-anchor="middle">de-identified star schema</text>
<path class="g" d="M1015 84 L930 178"/><path class="g" d="M1040 84 V128"/><path class="g" d="M855 84 L770 178"/><path class="g" d="M855 84 L640 268"/><path class="g" d="M770 240 V268"/>
<rect x="10" y="130" width="330" height="190" fill="#F5F7FB" stroke="#DDE3EE" rx="12"/><text x="24" y="156" class="t">Cross-cutting</text>
<text x="24" y="182" class="s">Key Vault: every secret, read by managed identity</text><text x="24" y="202" class="s">Microsoft Entra ID: sign-in and four app roles</text>
<text x="24" y="222" class="s">Audit log (PHI-masked) on every step</text><text x="24" y="242" class="s">Retries with back-off, dead-letter queue</text>
<text x="24" y="262" class="s">Azure DevOps: CI/CD (build, test, deploy)</text><text x="24" y="282" class="s">AKS (optional): host the UI as a container</text>
</svg>"""


def render(user):
    st.markdown("**What it does:** accepts healthcare documents (PDF or image), reads them with OCR, classifies the type, extracts the key fields, "
                "validates them with business rules, routes each document to the right team with a deadline, and publishes the results to dashboards. "
                "Anything the system is unsure about goes to a person.")
    st.markdown(SVG, unsafe_allow_html=True)
    st.markdown("### Design rule")
    st.markdown("**Code decides, the model reads.** Azure OpenAI only turns text into fields. Validation, routing, SLA and the review decision are plain, "
                "unit-tested code, so they are repeatable and explainable. Confidence is measured from OCR word confidence, not from what the model says about itself.")
    st.markdown("### Requirements and where each one is met")
    p = config.DOCS_DIR / "REQUIREMENTS_TRACEABILITY.md"
    if p.exists():
        st.markdown(p.read_text(encoding="utf-8"))
    else:
        C.note("docs/REQUIREMENTS_TRACEABILITY.md was not found.", warn=True)
    lim = config.DOCS_DIR / "KNOWN_LIMITATIONS.md"
    if lim.exists():
        with st.expander("Known limitations (read before quoting numbers to a client)"):
            st.markdown(lim.read_text(encoding="utf-8"))
