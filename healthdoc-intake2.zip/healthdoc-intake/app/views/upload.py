import random
import time

import streamlit as st

import config
from app import components as C
from app import services as svc
from src.pipeline import batch
from src.pipeline.processor import estimate_cost


def _stages(doc_id: str) -> dict:
    return {r["stage"]: r["ms"] for r in svc.sql().query("SELECT stage, ms FROM ProcessingStages WHERE doc_id=?", [doc_id])}


def _result_card(file_name: str, res: dict, user):
    d = svc.sql().get_document(res["doc_id"])
    if not d:
        C.note(f"{file_name}: the event was raised, but no result is stored yet (Azure Functions may still be processing).", warn=True)
        return
    stages = _stages(res["doc_id"])
    ev_ok = res.get("event_status") in ("delivered", "raised_by_azure")
    left, right = st.columns([5, 3])
    with left:
        st.markdown(f"**{file_name}**  " + C.status_chip(d["status"]), unsafe_allow_html=True)
        C.conveyor(stages, failed=d["status"] == "FAILED", event_ok=ev_ok)
    with right:
        bits = [f"Type: **{d.get('doc_type') or 'unknown'}**"]
        if d.get("route_id"):
            r = svc.sql().one("SELECT workflow_name, team, sla_hours FROM Routing WHERE doc_id=?", [res["doc_id"]])
            if r:
                bits.append(f"Sent to: **{r['workflow_name']}** ({r['sla_hours']} h deadline)")
        if d.get("doc_confidence") is not None:
            bits.append(f"Confidence {d['doc_confidence']:.2f}, {d.get('issue_count') or 0} issue(s)")
        if d["status"] == "DUPLICATE":
            bits.append(f"Identical to {d['duplicate_of']}; not processed twice")
        if d["status"] == "FAILED":
            bits.append(f"Reason: {d.get('failure_reason')}")
        if d["status"] == "SPLIT":
            bits.append(f"**Packet of {d.get('split_count')} documents**, cut page by page:")
        st.markdown("  \n".join(bits))
        if d["status"] == "SPLIT":
            kids = svc.sql().query("SELECT file_name, doc_type, status, page_range FROM Documents WHERE parent_doc_id=? ORDER BY file_name", [res["doc_id"]])
            import pandas as pd
            st.dataframe(pd.DataFrame(kids).rename(columns={"file_name": "Part", "doc_type": "Type", "status": "Outcome", "page_range": "Pages"}),
                         hide_index=True, width="stretch")
        if d.get("phi_masked_spans"):
            st.caption(f"{d['phi_masked_spans']} patient identifiers were replaced by placeholders before the text went to the language model.")
        if d.get("est_cost_usd"):
            st.caption(f"Estimated Azure cost: ${d['est_cost_usd']:.4f}")


def _run(files: list[tuple[str, bytes]], user, source="ui-upload"):
    grid = batch.make_pipeline() if config.mode("event_grid") != "azure" else None
    results = []
    bar = st.progress(0.0, text="Starting")
    for i, (name, data) in enumerate(files, 1):
        bar.progress((i - 1) / len(files), text=f"Processing {name} ({i} of {len(files)})")
        try:
            r = batch.ingest(name, data, source=source, grid=grid)
            if config.mode("event_grid") == "azure":
                for _ in range(30):                       # Azure delivers the event to the Function; wait for its result
                    if svc.sql().get_document(r["doc_id"]) and svc.sql().get_document(r["doc_id"])["status"] != "PROCESSING":
                        break
                    time.sleep(2)
            results.append((name, r, None))
        except Exception as exc:
            results.append((name, None, f"{type(exc).__name__}: {exc}"))
    bar.progress(1.0, text="Done")
    svc.refresh()
    st.session_state["last_results"] = results


def render(user):
    st.markdown("### Add documents")
    up = st.file_uploader("PDF, PNG, JPG or TIFF, up to 20 MB each", type=[e.lstrip(".") for e in config.ALLOWED_EXTENSIONS],
                          accept_multiple_files=True, key="uploader")
    c1, c2, c3, c4 = st.columns([2, 2, 3, 2])
    go = c1.button("Process uploaded files", type="primary", disabled=not up)
    sample = c2.button("Process 10 fresh sample documents")
    edge = c3.button("Run the edge-case pack (fax cover, memos, blank, corrupt)")
    pack = c4.button("Try 3 sample packets")
    if pack:
        import json as _j
        src = config.DATA_DIR / "hard"
        if not (src / "packets.json").exists():
            src = config.ROOT / "data" / "sample" / "hard"
        pk = _j.loads((src / "packets.json").read_text(encoding="utf-8")) if (src / "packets.json").exists() else []
        chosen = [p for sc in ("mixed", "cover_first", "blank_between") for p in pk if p["scenario"] == sc and p["style"] == "digital"][:0]
        for sc in ("mixed", "cover_first", "blank_between"):
            chosen += [p for p in pk if p["scenario"] == sc and p["style"] == "digital"][:1]
        if not chosen:
            C.note("No sample packets found. Run scripts/run_hardpack.py --regenerate to create them.", warn=True)
        else:
            _run([(f"{p['file'][:-4]}_{random.randint(100, 999)}.pdf", (src / "packets" / p["file"]).read_bytes()) for p in chosen], user, "ui-packet")
    if go and up:
        _run([(f.name, f.getvalue()) for f in up], user)
    if sample:
        from src.datagen.generate import generate_all
        scratch = config.DATA_DIR / "scratch_synth_upload"
        seed = random.randint(1000, 999999)
        with st.spinner("Generating 10 new synthetic documents"):
            m = generate_all(scratch, per_type=2, seed=seed, scanned_ratio=.2, defect_ratio=.35, dup_per_type=0, use_azure_narrative=False)
        import json
        key = json.loads((scratch / "answer_key.json").read_text(encoding="utf-8"))
        _run([(a["file"], (scratch / "documents" / a["doc_type"] / a["file"]).read_bytes()) for a in key], user, "ui-sample")
    if edge:
        files = sorted((config.SYNTH_DIR / "edge_cases").glob("*.pdf"))
        if not files:
            C.note("The edge-case pack was not found. Generate the dataset first (Data Generator page).", warn=True)
        else:
            _run([(f.name, f.read_bytes()) for f in files], user, "ui-edge")
            C.note("These files were already processed once, so the readable ones are caught as duplicates and the corrupt ones fail again. Both are the intended behaviour.")

    res = st.session_state.get("last_results")
    if not res:
        C.empty("Nothing processed in this session", "Upload files above, or press Process 10 fresh sample documents to see the pipeline work end to end.")
        _how()
        return
    st.markdown("### Results")
    n_ok = sum(1 for _, r, e in res if r)
    tot_cost = 0.0
    for name, r, err in res:
        with st.container(border=True):
            if err:
                st.markdown(f"**{name}**  " + C.status_chip("FAILED"), unsafe_allow_html=True)
                C.note(err, warn=True)
            else:
                _result_card(name, r, user)
                d = svc.sql().get_document(r["doc_id"])
                tot_cost += (d or {}).get("est_cost_usd") or 0
    st.caption(f"{n_ok} of {len(res)} files accepted. Estimated Azure cost of this batch: ${tot_cost:.4f} (placeholder prices from config.py).")
    _how()


def _how():
    with st.expander("What happens to each file"):
        st.markdown("1. The file is stored in the **incoming** Blob container.\n2. Blob Storage raises a *BlobCreated* event; **Event Grid** delivers it to the processing Function "
                    "(retrying, and dead-lettering if it keeps failing).\n3. **Document Intelligence** reads the text (OCR) and its confidence.\n4. **Azure OpenAI** classifies the document and "
                    "extracts the fields. 5. **Validation rules** check formats, dates, codes and totals.\n6. The **router** picks a workflow; a **Logic App** notifies the team.\n7. Clean facts go to "
                    "**Azure SQL**, the raw JSON to **Cosmos DB**, and the file moves to *processed*, *review* or *quarantine*.\n\nIn local mode, stand-ins do the same jobs, so the results are comparable.")
