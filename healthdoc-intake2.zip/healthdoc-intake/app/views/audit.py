import json

import streamlit as st

from app import components as C
from app import services as svc


def render(user):
    df = svc.qdf("SELECT audit_id, ts, doc_id, actor, action, detail_json, correlation_id FROM AuditLog ORDER BY audit_id DESC")
    if df.empty:
        C.empty("No audit entries yet", "Every pipeline step and every human action writes one row here.")
        return
    c1, c2, c3 = st.columns([2, 2, 3])
    actions = c1.multiselect("Action", sorted(df.action.unique()))
    actors = c2.multiselect("Actor", sorted(df.actor.unique()))
    q = c3.text_input("Search document id, correlation id or detail")
    if actions:
        df = df[df.action.isin(actions)]
    if actors:
        df = df[df.actor.isin(actors)]
    if q:
        m = df.apply(lambda r: q.lower() in " ".join(str(v) for v in r.values).lower(), axis=1)
        df = df[m]
    C.note("PHI-safe by design: names are reduced to initials, IDs are masked, and no document text is ever written to the audit trail.")
    st.caption(f"{len(df):,} entries")
    st.dataframe(df.head(1000), hide_index=True, width="stretch", height=520)
    st.download_button("Download this view as CSV", df.to_csv(index=False).encode(), "audit_log.csv", "text/csv")
    top = df.action.value_counts().rename_axis("action").reset_index(name="entries")
    st.dataframe(top, hide_index=True)
