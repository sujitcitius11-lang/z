import json

import pandas as pd
import plotly.express as px
import streamlit as st
import streamlit.components.v1 as components

import config
from app import components as C
from app import services as svc
from app import theme
from src.analytics import export_powerbi as X

PB = config.POWERBI_DIR


def _download(label, path, mime="text/plain"):
    if path.exists():
        st.download_button(label, path.read_bytes(), path.name, mime, key=f"dl_{path.name}")
    else:
        st.caption(f"{path.name}: not found")


def render(user):
    st.markdown("Power BI reads a **de-identified star schema**: no patient name, date of birth, member ID, address, phone or e-mail leaves the database. "
                "Patients appear only as a one-way hashed key. In Azure, Power BI connects straight to the Azure SQL views (`sql/powerbi_views.sql`); "
                "for a laptop demo it loads the CSV files below.")
    c1, c2 = st.columns([1, 3])
    if c1.button("Rebuild the CSV files", type="primary", width="stretch"):
        with st.spinner("Exporting ..."):
            counts = X.export_all(sql=svc.sql(), answer_key=svc.answer_key())
        st.success("Exported " + ", ".join(f"{k} ({v:,})" for k, v in counts.items()))
    schema_path = config.POWERBI_DATA_DIR / "schema.json"
    if not schema_path.exists():
        C.empty("The CSV files are not built yet", "Press the button above (needs processed documents).")
        return
    schema = json.loads(schema_path.read_text(encoding="utf-8"))

    tabs = st.tabs(["Live preview", "Data model", "Download kit", "Embed a published report"])
    with tabs[0]:
        embed = config.env("POWERBI_EMBED_URL")
        if embed:
            components.iframe(embed, height=640)
        C.note("This preview is drawn from the same exported tables the Power BI report uses, with the same measures, so the numbers agree with the report. "
               "The real report is built in Power BI Desktop (see REPORT_BUILD_GUIDE.md).")
        fd = pd.read_csv(config.POWERBI_DATA_DIR / "FactDocuments.csv")
        dd = pd.read_csv(config.POWERBI_DATA_DIR / "DimDate.csv")[["date_key", "year_month"]]
        f = fd.merge(dd, on="date_key", how="left")
        k = svc.kpis()
        C.tiles([("Total documents", f"{len(f):,}", "FactDocuments rows", theme.INDIGO), ("STP rate", k["stp_rate"], "Auto-Processed / Unique", theme.TEAL, "%"),
                 ("Review rate", k["review_rate"], "Sent To Review / Unique", "#E0A030", "%"), ("Avg seconds", k["avg_processing_s"], "Avg Processing Seconds", theme.INDIGO, "s"),
                 ("Est. cost", f"${k['est_cost_usd']:,.2f}", "Est Cost USD", theme.SLATE)])
        a, b = st.columns(2)
        m = f.groupby(["year_month", "doc_type_key"], as_index=False).size()
        a.plotly_chart(theme.style_fig(px.bar(m, x="year_month", y="size", color="doc_type_key", color_discrete_map=theme.TYPE_COLORS, title="Page 1 - Documents per month", labels={"size": "Documents", "year_month": "Month", "doc_type_key": "Type"}), 330), width="stretch")
        s = f.groupby("status", as_index=False).size()
        b.plotly_chart(theme.style_fig(px.pie(s, names="status", values="size", hole=.55, title="Page 1 - Outcome", color="status", color_discrete_map={k: v[0] for k, v in theme.STATUS.items()}), 330), width="stretch")
        c, d = st.columns(2)
        w = f.groupby("workflow_id", as_index=False).agg(docs=("doc_id", "count"), avg_s=("processing_seconds", "mean"))
        c.plotly_chart(theme.style_fig(px.bar(w, x="workflow_id", y="docs", title="Page 2 - Work per workflow").update_traces(marker_color=theme.TEAL), 320, False), width="stretch")
        iss = pd.read_csv(config.POWERBI_DATA_DIR / "FactValidationIssues.csv")
        if not iss.empty:
            r = iss.groupby(["rule_id", "severity"], as_index=False).size().sort_values("size").tail(10)
            d.plotly_chart(theme.style_fig(px.bar(r, x="size", y="rule_id", color="severity", orientation="h", title="Page 3 - Top validation findings",
                                                   color_discrete_map={"error": theme.CORAL, "warning": "#E0A030"}), 320), width="stretch")
        fa = config.POWERBI_DATA_DIR / "FactFieldAccuracy.csv"
        if fa.exists():
            acc = pd.read_csv(fa)
            g = acc.groupby("noise_band", as_index=False).correct.mean()
            g["accuracy"] = g.correct * 100
            st.plotly_chart(theme.style_fig(px.bar(g, x="noise_band", y="accuracy", title="Page 4 - Field accuracy by image quality").update_traces(marker_color=theme.INDIGO).update_layout(yaxis_range=[0, 100]), 300, False), width="stretch")
    with tabs[1]:
        st.markdown("**Tables** (Import mode, one fact per grain, conformed dimensions)")
        rows = [{"table": n, "kind": "fact" if n.startswith("Fact") else "dimension", "rows": t["rows"], "columns": ", ".join(c["name"] for c in t["columns"])[:140]} for n, t in schema["tables"].items()]
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
        st.markdown("**Relationships** (many to one, single direction from the dimension to the fact)")
        st.dataframe(pd.DataFrame(schema["relationships"]), hide_index=True, width="stretch")
        dot = "digraph G { rankdir=LR; node [shape=box, style=rounded, fontname=Helvetica]; " + " ".join(
            f'"{r["from_table"]}" -> "{r["to_table"]}" [label="{r["from_column"]}"];' for r in schema["relationships"]) + " }"
        st.graphviz_chart(dot)
    with tabs[2]:
        st.markdown("Everything needed to build the report in Power BI Desktop:")
        a, b = st.columns(2)
        with a:
            for t in schema["tables"]:
                _download(f"{t}.csv", config.POWERBI_DATA_DIR / f"{t}.csv", "text/csv")
        with b:
            _download("measures.dax", PB / "measures.dax")
            _download("theme.json", PB / "theme.json", "application/json")
            _download("REPORT_BUILD_GUIDE.md", PB / "REPORT_BUILD_GUIDE.md", "text/markdown")
            _download("all_queries_csv.m (Power Query)", PB / "queries" / "all_queries_csv.m")
            _download("powerbi_views.sql (Azure SQL)", config.ROOT / "sql" / "powerbi_views.sql")
    with tabs[3]:
        st.markdown("1. Publish the report to the Power BI service (workspace with a Pro, PPU or Fabric capacity licence).\n"
                    "2. In the service: File > Embed report > **Website or portal** gives a URL (for internal sharing; the viewer needs access).\n"
                    "3. Put it in `.env` as `POWERBI_EMBED_URL=...` and restart the app. It then appears in the Live preview tab.\n"
                    "4. For customer-facing embedding use Power BI Embedded with a service principal instead (not covered here).")
