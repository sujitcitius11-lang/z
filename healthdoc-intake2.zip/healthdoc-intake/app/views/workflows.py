import json

import pandas as pd
import plotly.express as px
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src.routing.router import WORKFLOWS
from src.validation.rules import CATALOGUE


def render(user):
    t1, t2, t3, t4 = st.tabs(["Workflows", "Routing decisions", "Validation rules", "Logic App actions"])
    with t1:
        w = svc.qdf("SELECT workflow_id, COUNT(*) AS total, SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) AS open_items, "
                    "SUM(CASE WHEN status='open' AND sla_due_at < ? THEN 1 ELSE 0 END) AS past_deadline FROM Routing GROUP BY workflow_id",
                    (config.REFERENCE_DATE.isoformat() + "T23:59:59Z",))
        wm = {r.workflow_id: r for r in w.itertuples()} if not w.empty else {}
        rows = []
        for wid, x in WORKFLOWS.items():
            r = wm.get(wid)
            rows.append({"Code": wid, "Workflow": x["name"], "Team": x["team"], "Priority": x["priority"], "Deadline (hours)": x["sla_hours"],
                         "Documents": int(r.total) if r else 0, "Open": int(r.open_items) if r else 0, "Past deadline": int(r.past_deadline) if r else 0})
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=430)
        C.note("Past deadline counts open work items whose deadline is before the reference date. The demo never closes work items, so older ones are all late.")
        df = pd.DataFrame(rows)
        df = df[df.Documents > 0]
        if not df.empty:
            fig = px.bar(df.sort_values("Documents"), x="Documents", y="Workflow", orientation="h", title="Documents per workflow")
            fig.update_traces(marker_color=theme.TEAL)
            fig.update_layout(yaxis_title=None)
            st.plotly_chart(theme.style_fig(fig, 340, legend=False), width="stretch")
    with t2:
        st.markdown("Python decides the workflow, in this order. The Logic App has the same table as a Switch action.")
        st.dataframe(pd.DataFrame([
            {"Order": 1, "If": "Processing failed after retries", "Then send to": "W-DLQ Exceptions / Dead Letter"},
            {"Order": 2, "If": "Document type could not be determined", "Then send to": "W-TRIAGE Manual Triage"},
            {"Order": 3, "If": "A validation error, two or more warnings, or low confidence", "Then send to": "W-REVIEW Manual Review Queue (then to its normal workflow once released)"},
            {"Order": 4, "If": f"Claim billed {config.HIGH_VALUE_CLAIM:,.0f} or more", "Then send to": "W-CLM-HV Senior Claims Review (24 h)"},
            {"Order": 5, "If": "Referral urgency is Urgent or Emergent", "Then send to": "W-REF-URG Urgent Referral Desk (4 h, pages on-call)"},
            {"Order": 6, "If": "A lab result is more than 1.5 times above, or under half of, its reference range", "Then send to": "W-LAB-CRIT Critical Lab Alert (2 h, pages on-call)"},
            {"Order": 7, "If": "Anything else", "Then send to": "The standard workflow for its type: enrollment, claims, referrals, pharmacy, lab review"},
        ]), hide_index=True, width="stretch")
        r = svc.qdf("SELECT reason, COUNT(*) AS documents FROM Routing GROUP BY reason ORDER BY documents DESC")
        if not r.empty:
            st.markdown("Most common reasons recorded")
            r["reason"] = r.reason.str[:110]
            st.dataframe(r.head(12), hide_index=True, width="stretch")
    with t3:
        fired = svc.qdf("SELECT rule_id, COUNT(*) AS times_found, COUNT(DISTINCT doc_id) AS documents FROM ValidationIssues GROUP BY rule_id")
        fm = {r.rule_id: r for r in fired.itertuples()} if not fired.empty else {}
        rows = [{"Rule": k, "Severity": v[0], "What it checks": v[1], "Times found": int(fm[k].times_found) if k in fm else 0,
                 "Documents": int(fm[k].documents) if k in fm else 0} for k, v in CATALOGUE.items()]
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=620)
        st.caption("Errors always send a document to a person. A single warning does not; two warnings do.")
    with t4:
        a = svc.qdf("SELECT ts, doc_id, workflow_id, action_type, channel, target, status FROM WorkflowActions ORDER BY ts DESC")
        if a.empty:
            C.empty("No actions yet", "The Logic App (or its local stand-in) records an action for every routed document.")
        else:
            c1, c2, c3 = st.columns(3)
            wf = c1.multiselect("Workflow", sorted(a.workflow_id.unique()), key="wa_wf")
            ty = c2.multiselect("Action", sorted(a.action_type.unique()), key="wa_ty")
            stt = c3.multiselect("Status", sorted(a.status.unique()), key="wa_st")
            m = a
            if wf:
                m = m[m.workflow_id.isin(wf)]
            if ty:
                m = m[m.action_type.isin(ty)]
            if stt:
                m = m[m.status.isin(stt)]
            st.caption(f"{len(m):,} actions. 'simulated' means the local stand-in recorded what the Logic App would have done.")
            st.dataframe(m.head(500), hide_index=True, width="stretch", height=330)
        p = config.ROOT / "logic_apps" / "routing_workflow.json"
        with st.expander("Logic App definition (read-only)"):
            if p.exists():
                st.json(json.loads(p.read_text(encoding="utf-8")), expanded=1)
            else:
                C.empty("Definition not found", "logic_apps/routing_workflow.json is added with the Azure deployment kit.")
