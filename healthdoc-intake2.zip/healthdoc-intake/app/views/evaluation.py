import config
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from app import components as C
from app import services as svc
from app import theme
from src import schemas as S


def render(user):
    if not svc.answer_key():
        C.empty("No answer key found", "Accuracy can only be measured for synthetic documents that have an answer key (data/synthetic/answer_key.json).")
        return
    ev = svc.evaluation()
    if not ev["documents_evaluated"]:
        C.empty("Nothing to evaluate yet", "Process the synthetic documents first.")
        return
    C.tiles([
        ("Documents compared", f"{ev['documents_evaluated']:,}", "duplicates are excluded", theme.INDIGO),
        ("Document type correct", ev["classification_accuracy"], "classification accuracy", theme.TEAL, "%"),
        ("Fields read correctly", ev["field_accuracy_overall"], "strict: the whole value must match", theme.TEAL, "%"),
        ("Defects caught", ev["defect_detection_rate"], f"of {ev['defect_documents']} documents with a planted defect", theme.PURPLE, "%"),
        ("Clean documents sent to a person", ev["false_review_rate"], f"of {ev['clean_documents']:,} (the cost of being careful)", "#E0A030", "%"),
    ])
    C.note("How to read this: the generator knows the right answer for every field. We compare what the system read with that answer. "
           "Strict means a date, name or list must match exactly; one wrong row in a lab table makes the whole table wrong.")

    c1, c2 = st.columns(2)
    with c1:
        labels = S.DOC_TYPES + ["unknown"]
        z = [[ev["confusion"].get(t, {}).get(p, 0) for p in labels] for t in S.DOC_TYPES]
        fig = go.Figure(go.Heatmap(z=z, x=labels, y=S.DOC_TYPES, colorscale=[[0, "#F5F7FB"], [1, theme.INDIGO]], text=z, texttemplate="%{text}", showscale=False))
        fig.update_layout(title="Confusion matrix: real type (rows) vs predicted (columns)", xaxis_title="predicted", yaxis_title="real", yaxis_autorange="reversed")
        st.plotly_chart(theme.style_fig(fig, 340, False), width="stretch")
    with c2:
        d = pd.DataFrame([{"group": f"{k}", "kind": "format", "accuracy": v} for k, v in ev["field_accuracy_by_format"].items()] +
                         [{"group": f"{k}", "kind": "image quality", "accuracy": v} for k, v in ev["field_accuracy_by_noise"].items()])
        fig = px.bar(d, x="group", y="accuracy", color="kind", title="Field accuracy by source format and image quality", color_discrete_sequence=[theme.INDIGO, theme.TEAL])
        fig.update_layout(yaxis_range=[0, 100], xaxis_title=None, yaxis_title="% correct", legend_title=None)
        st.plotly_chart(theme.style_fig(fig, 340), width="stretch")
        st.caption("Digital PDFs are almost perfect. Scans and photos lose accuracy as the image gets worse: that is why low-confidence fields go to a person.")

    c3, c4 = st.columns(2)
    with c3:
        cal = pd.DataFrame([{"band": k, "accuracy": v["accuracy"], "fields": v["fields"]} for k, v in ev["calibration"].items()])
        fig = px.bar(cal, x="band", y="accuracy", text=cal.fields.map(lambda n: f"{n:,}"), title="Calibration: when the system says 0.9+, is it right?")
        fig.update_traces(marker_color=theme.TEAL, textposition="outside")
        fig.update_layout(yaxis_range=[0, 110], xaxis_title="confidence reported", yaxis_title="% actually correct")
        st.plotly_chart(theme.style_fig(fig, 340, False), width="stretch")
        st.caption("Bars should rise from left to right. If a high-confidence band were often wrong, confidence could not be trusted to decide what a person checks.")
    with c4:
        bt = pd.DataFrame([{"type": S.DOC_TYPE_LABELS[k], "accuracy": v} for k, v in ev["field_accuracy_by_type"].items()])
        fig = px.bar(bt, x="type", y="accuracy", title="Field accuracy by document type")
        fig.update_traces(marker_color=theme.INDIGO)
        fig.update_layout(yaxis_range=[0, 100], xaxis_title=None)
        st.plotly_chart(theme.style_fig(fig, 340, False), width="stretch")

    st.markdown("### Did validation catch the planted defects?")
    dd = pd.DataFrame([{"defect": k, "flagged": v["flagged"], "missed": v["total"] - v["flagged"], "total": v["total"]} for k, v in ev["defect_detection_by_type"].items()]).sort_values("total")
    fig = px.bar(dd, y="defect", x=["flagged", "missed"], orientation="h", color_discrete_map={"flagged": theme.TEAL, "missed": theme.CORAL}, title="Planted defect: flagged for review vs missed")
    fig.update_layout(xaxis_title="Documents", yaxis_title=None, legend_title=None)
    st.plotly_chart(theme.style_fig(fig, 380), width="stretch")

    st.markdown("### Weakest fields")
    f = pd.DataFrame([{"field": k, "accuracy %": v} for k, v in ev["field_accuracy_by_field"].items() if v is not None]).sort_values("accuracy %").head(12)
    st.dataframe(f, hide_index=True, width="stretch")
    with st.expander("Sample of individual mistakes"):
        e = pd.DataFrame(ev["errors"][:150])
        if not e.empty and not user["phi"]:
            e["truth"] = e.truth.map(lambda x: "(hidden)" if isinstance(x, str) else x)
            e["got"] = e["got"].map(lambda x: "(hidden)" if isinstance(x, str) else x)
        for c in ("truth", "got"):
            if c in e:
                e[c] = e[c].map(lambda x: x if isinstance(x, str) else str(x))
        st.dataframe(e, hide_index=True, width="stretch")

    # ------------------------------------------------------------------ precision / recall / F1, threshold sweep, ablation
    if ev.get("prf"):
        st.markdown("### Precision, recall and F1")
        C.note("Precision: of the values the system filled in, how many were right. Recall: of the values that exist, how many it got right. "
               "F1 combines both. A wrong value counts against both; a missing value counts against recall only.")
        o = ev["prf"]["overall"]
        C.tiles([("Precision", o["precision"], "values filled in that were right", theme.TEAL, "%"), ("Recall", o["recall"], "real values that were found right", theme.TEAL, "%"),
                 ("Micro-F1", o["f1"], "all fields pooled", theme.INDIGO, "%"), ("Macro-F1", o["macro_f1"], "average of the per-field F1", theme.INDIGO, "%")])
        t = pd.DataFrame([{"type": S.DOC_TYPE_LABELS[k], "precision %": m["precision"], "recall %": m["recall"], "F1 %": m["f1"],
                           "whole document right %": m["doc_exact_match"]} for k, m in ev["prf"]["per_type"].items()])
        st.dataframe(t, hide_index=True, width="stretch")
        with st.expander("Every field (sorted from weakest)"):
            pf = pd.DataFrame([{"field": k, **{x: m[x] for x in ("precision", "recall", "f1", "tp", "fp", "fn")}} for k, m in ev["prf"]["per_field"].items()]).sort_values("f1")
            st.dataframe(pf, hide_index=True, width="stretch")
    if ev.get("sweep"):
        st.markdown("### Where should the review threshold be?")
        sw = pd.DataFrame(ev["sweep"]["doc_sweep"])
        fig = go.Figure()
        fig.add_bar(x=sw.cutoff.astype(str), y=sw.straight_through, name="straight-through %", marker_color=theme.TEAL)
        fig.add_scatter(x=sw.cutoff.astype(str), y=sw.silent_error_rate, name="silent-error % (wrong but auto-passed)", mode="lines+markers", line=dict(color=theme.CORAL), yaxis="y2")
        fig.update_layout(title="Document-confidence cut-off: work saved vs wrong documents that slip through", xaxis_title="cut-off",
                          yaxis=dict(title="straight-through %", range=[0, 100]), yaxis2=dict(title="silent error %", overlaying="y", side="right", rangemode="tozero"))
        st.plotly_chart(theme.style_fig(fig, 360), width="stretch")
        st.caption(f"Current setting: {ev['sweep']['current_doc_min']}. Moving the cut-off up sends more documents to a person and lets fewer wrong ones through. "
                   "Pick the point the client can live with and set DOC_CONF_MIN.")
    if ev.get("ablation"):
        st.markdown("### Ablation: what does each layer add?")
        ab = pd.DataFrame(ev["ablation"]["variants"])
        fig = go.Figure()
        fig.add_bar(x=ab.name, y=ab.field_accuracy, name="field accuracy %", marker_color=theme.INDIGO)
        fig.add_bar(x=ab.name, y=ab.silent_error_rate, name="silent-error % (lower is better)", marker_color=theme.CORAL)
        fig.update_layout(barmode="group", yaxis_title="%", xaxis_title=None)
        st.plotly_chart(theme.style_fig(fig, 380), width="stretch")
        st.dataframe(ab[["name", "field_accuracy", "doc_exact", "review_rate", "silent_error_rate", "documents"]], hide_index=True, width="stretch")
        if ev["ablation"].get("not_run"):
            st.caption("Not run here (needs a live Azure account): " + "; ".join(ev["ablation"]["not_run"]) + ". The harness runs them automatically when Azure is configured.")
        st.caption("Reading it: repair and fuzzy matching raise accuracy a little; validation and confidence gating mostly reduce the wrong answers that go through unseen.")


    # ------------------------------------------------------------------ hard pack, packets, PHI masking (separate measured runs)
    import json as _json
    hp = config.DATA_DIR / "hard_evaluation.json"
    if hp.exists():
        h = _json.loads(hp.read_text(encoding="utf-8"))
        st.markdown("### Stress test: the hard pack")
        C.note("The main dataset is clean and labelled, so its numbers are flattering. The hard pack adds boxed forms without colons, phone photos, faxes, "
               "low-resolution scans and multi-page documents. Run separately in a scratch database (scripts/run_hardpack.py).")
        o, sl = h["documents"], h["silent"]
        C.tiles([("Hard documents", f"{h['manifest']['documents']:,}", "photos, faxes, low-res scans, boxed forms", theme.INDIGO),
                 ("Fields right", o["field_accuracy_overall"], "strict match", "#E0A030", "%"),
                 ("Precision", h["prf"]["precision"], "filled-in values that were right", theme.TEAL, "%"),
                 ("Recall", h["prf"]["recall"], "real values found right", theme.CORAL, "%"),
                 ("Silent errors", sl["rate"], f"{sl['silent_errors']} of {sl['auto_passed']} auto-passed", theme.PURPLE, "%")])
        rows = [{"group": f"layout {k}", "kind": "layout", "accuracy": v["accuracy"]} for k, v in h["by_layout"].items()] + \
               [{"group": k, "kind": "source", "accuracy": v["accuracy"]} for k, v in h["by_style"].items()]
        fig = px.bar(pd.DataFrame(rows), x="group", y="accuracy", color="kind", title="Hard pack: field accuracy by layout and source", color_discrete_sequence=[theme.INDIGO, theme.TEAL])
        fig.update_layout(yaxis_range=[0, 100], xaxis_title=None, legend_title=None)
        st.plotly_chart(theme.style_fig(fig, 340), width="stretch")
        st.caption("Digital PDFs stay near 99% in every layout. Scanned and photographed boxed forms are where a plain OCR + rules reader struggles: "
                   "that is the case for a layout-aware reader (Document Intelligence) and for the review queue.")
        p = h["packets"]
        st.markdown("### Packet splitting")
        C.tiles([("Packets", f"{p['packets']}", "2-5 documents each, fax covers and blank pages", theme.INDIGO),
                 ("Cut exactly right", p["exact_split_rate"], "every page range correct", theme.TEAL, "%"),
                 ("Boundary F1", p["boundary_f1"], f"precision {p['boundary_precision']}%, recall {p['boundary_recall']}%", theme.TEAL, "%"),
                 ("Part type right", p["parts_with_right_type"], "of correctly cut parts", theme.INDIGO, "%"),
                 ("Fields right in parts", p["part_field_accuracy"], "strict match", "#E0A030", "%")])
        sc = pd.DataFrame([{"scenario": k, "exactly right %": v["exact"], "packets": v["packets"]} for k, v in p["by_scenario"].items()])
        st.dataframe(sc, hide_index=True, width="stretch")
    pm = config.DATA_DIR / "phi_masking.json"
    if pm.exists():
        m = _json.loads(pm.read_text(encoding="utf-8"))
        st.markdown("### PHI masking before the language model")
        C.tiles([("Identifiers checked", f"{m['phi_values_checked']:,}", f"names, dates of birth, addresses, phones, e-mails, ids in {m['documents']} documents", theme.INDIGO),
                 ("Still visible after masking", f"{m['leaked']}", "would have reached the model", theme.CORAL if m["leaked"] else theme.TEAL),
                 ("Masking recall", m["recall"], "measured against the answer key", theme.TEAL, "%")])
        st.caption("Measured on labelled forms. A name written in free text with no label is only caught if the same string appears at a labelled place (docs/KNOWN_LIMITATIONS.md).")
