import json

import pandas as pd
import plotly.express as px
import streamlit as st

import config
from app import components as C
from app import services as svc
from app import theme
from src import common
from src import schemas as S
from src.routing.router import WORKFLOWS


def mask_raw(item: dict, phi: bool) -> dict:
    if phi or not item:
        return item
    item = json.loads(json.dumps(item, default=str))
    item.get("ocr", {}).pop("text", None)                         # the OCR text contains the whole document
    item.get("model", {}).pop("raw", None)
    for n, f in (item.get("fields") or {}).items():
        if n in common.PHI_FIELDS_TO_MASK and f.get("value"):
            f["value"] = common.PHI_FIELDS_TO_MASK[n](f["value"])
    return item


def detail(doc_id: str, user, key="exp"):
    d = svc.doc_detail(doc_id)
    doc = d["doc"]
    if not doc:
        C.empty("Document not found", doc_id)
        return
    st.markdown(f"### {doc['file_name']}  " + C.status_chip(doc["status"]), unsafe_allow_html=True)
    meta = [f"**Type** {S.DOC_TYPE_LABELS.get(doc.get('doc_type'), doc.get('doc_type'))} ({(doc.get('type_confidence') or 0):.2f})",
            f"**Pages** {doc.get('page_count') or '-'}", f"**Read by** {doc.get('ocr_engine') or '-'} and {doc.get('extract_engine') or '-'}",
            f"**Document confidence** {(doc.get('doc_confidence') or 0):.2f}", f"**Received** {str(doc.get('received_at') or '')[:16].replace('T', ' ')}"]
    st.markdown("   |   ".join(meta))
    if doc.get("failure_reason"):
        C.note(f"Failure reason: {doc['failure_reason']}", warn=True)
    if doc["status"] == "SPLIT":
        kids = svc.qdf("SELECT doc_id, file_name, doc_type, status, page_range FROM Documents WHERE parent_doc_id=? ORDER BY file_name", [doc["doc_id"]])
        C.note(f"This file was a packet holding {doc.get('split_count')} documents. It was cut page by page and each part was processed on its own:")
        st.dataframe(kids.rename(columns={"doc_id": "Document", "file_name": "Part", "doc_type": "Type", "status": "Outcome", "page_range": "Pages"}), hide_index=True, width="stretch")
        return
    if doc.get("parent_doc_id"):
        C.note(f"This document is pages {doc.get('page_range')} of the packet {doc['parent_doc_id']}.")
    if doc.get("cross_doc_flags"):
        C.note(f"{doc['cross_doc_flags']} cross-document check(s) failed: the same member or provider looks different on another document (rules R027-R029).", warn=True)
    if doc["status"] == "DUPLICATE":
        C.note(f"This file is byte-for-byte identical to {doc['duplicate_of']}. It was recognised by its SHA-256 hash and not processed twice.")
    left, right = st.columns([4, 5])
    with left:
        st.markdown("##### Original")
        C.show_document(doc, user["phi"], key)
    with right:
        tabs = st.tabs(["Extracted fields", "Checks", "Routing", "Timeline", "Raw JSON", "Audit trail", "FHIR"])
        with tabs[0]:
            if doc.get("doc_type") in S.SCHEMAS:
                C.field_table(doc["doc_type"], d["fields"], d["issues"], user["phi"])
                st.caption("Amber rows were read with confidence below "
                           f"{config.FIELD_CONF_MIN:.2f}. Red rows break a validation rule. Purple tags mark values a reviewer corrected.")
            else:
                C.empty("No fields", "This document could not be classified, so no fields were extracted.")
        with tabs[1]:
            C.issues_list(d["issues"])
        with tabs[2]:
            r = d["route"]
            if r:
                st.markdown(f"**{r['workflow_name']}** for team **{r['team']}**  " + C.priority_chip(r["priority"]), unsafe_allow_html=True)
                st.write(f"Reason: {r['reason']}")
                st.write(f"Deadline: {r['sla_hours']} hours, due {str(r['sla_due_at'] or '')[:16].replace('T', ' ')}")
                if r.get("intended_workflow_id"):
                    st.write(f"After review it goes to: {WORKFLOWS[r['intended_workflow_id']]['name']}")
            if d["task"]:
                t = d["task"]
                st.write(f"Review task: **{t['status']}**" + (f", by {t['reviewer']}" if t.get("reviewer") else ""))
            if d["actions"]:
                st.markdown("Logic App actions")
                st.dataframe(pd.DataFrame(d["actions"]), hide_index=True, width="stretch")
        with tabs[3]:
            if d["stages"]:
                s = pd.DataFrame(d["stages"])
                fig = px.bar(s, x="ms", y="stage", orientation="h", title="Time spent per stage (milliseconds)")
                fig.update_traces(marker_color=theme.INDIGO)
                fig.update_layout(yaxis_title=None, xaxis_title="ms")
                st.plotly_chart(theme.style_fig(fig, 260, legend=False), width="stretch")
            else:
                C.empty("No timing recorded", "Duplicates and failed uploads skip most stages.")
        with tabs[4]:
            try:
                item = svc.cosmos().get(doc["doc_id"], doc.get("doc_type") or "unknown")
            except Exception:
                item = None
            if item:
                if not user["phi"]:
                    C.note("OCR text and raw model output are hidden, and PHI values are masked, for your role.", warn=True)
                st.json(mask_raw(item, user["phi"]), expanded=1)
            else:
                C.empty("No raw JSON stored", "Duplicates and failed documents are not written to Cosmos DB.")
        with tabs[5]:
            if d["audit"]:
                a = pd.DataFrame(d["audit"])
                a["detail"] = a.detail_json.map(lambda s: (s or "")[:140])
                st.dataframe(a[["ts", "actor", "action", "detail"]], hide_index=True, width="stretch")
            else:
                C.empty("No audit records", "")
        with tabs[6]:
            _fhir_tab(doc, d, user)


def _fhir_tab(doc, d, user):
    import json
    from src.exports import fhir
    from src.pipeline.operations import effective_fields
    if doc.get("doc_type") not in S.SCHEMAS:
        C.empty("Nothing to export", "Only classified documents can be exported.")
        return
    if not user["phi"]:
        C.note("The FHIR bundle contains the patient's real identifiers, so only roles that may see PHI can export it.", warn=True)
        return
    bundle = fhir.to_bundle(doc["doc_id"], doc["doc_type"], effective_fields(svc.sql(), doc["doc_id"]))
    problems = fhir.validate_bundle(bundle)
    kinds = ", ".join(sorted({e["resource"]["resourceType"] for e in bundle["entry"]}))
    C.note(f"FHIR R4 bundle with: {kinds}. " + ("Structure check passed." if not problems else "Structure check: " + "; ".join(problems[:2])), warn=bool(problems))
    st.download_button("Download FHIR bundle (JSON)", json.dumps(bundle, indent=1), f"{doc['doc_id']}_fhir.json", "application/fhir+json")
    st.json(bundle, expanded=1)


def render(user):
    df = svc.documents()
    if df.empty:
        C.empty("No documents yet", "Process some documents on the Upload & Process page first.")
        return
    f1, f2, f3, f4 = st.columns([2, 2, 3, 2])
    q = f1.text_input("Search file name or document ID", key="exp_q")
    types = f2.multiselect("Type", sorted(df.doc_type.dropna().unique()), key="exp_type", format_func=lambda t: S.DOC_TYPE_LABELS.get(t, t))
    statuses = f3.multiselect("Status", ["PASSED", "NEEDS_REVIEW", "FAILED", "DUPLICATE", "REJECTED", "SPLIT"], key="exp_status",
                              format_func=lambda s: theme.STATUS[s][2])
    scanned = f4.selectbox("Source", ["All", "Digital PDF", "Scan or photo"], key="exp_scan")
    g1, g2, g3 = st.columns([3, 3, 3])
    wfs = g1.multiselect("Workflow", sorted(df.workflow_name.dropna().unique()), key="exp_wf")
    dmin, dmax = pd.to_datetime(df.received_at.str[:10]).min().date(), pd.to_datetime(df.received_at.str[:10]).max().date()
    dr = g2.date_input("Received between", (dmin, dmax), min_value=dmin, max_value=dmax, key="exp_dates")
    cr = g3.slider("Document confidence", 0.0, 1.0, (0.0, 1.0), 0.05, key="exp_conf")

    m = df.copy()
    if q:
        m = m[m.file_name.str.contains(q, case=False, na=False) | m.doc_id.str.contains(q, case=False, na=False)]
    if types:
        m = m[m.doc_type.isin(types)]
    if statuses:
        m = m[m.status.isin(statuses)]
    if wfs:
        m = m[m.workflow_name.isin(wfs)]
    if scanned != "All":
        m = m[m.is_scanned.fillna(0).astype(int) == (1 if scanned == "Scan or photo" else 0)]
    if isinstance(dr, tuple) and len(dr) == 2:
        day = m.received_at.str[:10]
        m = m[(day >= dr[0].isoformat()) & (day <= dr[1].isoformat())]
    m = m[(m.doc_confidence.fillna(0) >= cr[0]) & (m.doc_confidence.fillna(0) <= cr[1]) | m.doc_confidence.isna() & (cr[0] == 0)]
    st.caption(f"{len(m):,} of {len(df):,} documents match. Click a row to open it.")
    show = m.sort_values("received_at", ascending=False).head(500)
    table = pd.DataFrame({"Document": show.doc_id, "File": show.file_name, "Type": show.doc_type, "Status": show.status, "Workflow": show.workflow_name,
                          "Confidence": show.doc_confidence.round(2), "Issues": show.issue_count, "Received": show.received_at.str[:10]})
    ev = st.dataframe(table, hide_index=True, width="stretch", height=300, on_select="rerun", selection_mode="single-row", key="exp_table")
    if len(m) > 500:
        st.caption("Showing the 500 most recent matches. Narrow the filters to see others.")
    sel = ev.selection.rows if ev and ev.selection else []
    manual = st.session_state.get("explorer_open")
    if sel:
        detail(table.iloc[sel[0]]["Document"], user)
    elif manual:
        detail(manual, user)
    else:
        C.empty("Select a document", "Pick a row in the table to see the original, the extracted fields, the checks and the full history.")
