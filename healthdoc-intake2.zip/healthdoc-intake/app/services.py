"""Cached accessors so every page shares one connection set and heavy queries are not repeated on every click."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pandas as pd
import streamlit as st

import config
from src.storage.blob_store import get_blob
from src.storage.cosmos_store import get_cosmos
from src.storage.sql_store import get_sql


@st.cache_resource
def sql():
    return get_sql()


@st.cache_resource
def blob():
    return get_blob()


@st.cache_resource
def cosmos():
    return get_cosmos()


@st.cache_data(ttl=6, show_spinner=False)
def qdf(query: str, params: tuple = ()) -> pd.DataFrame:
    return sql().df(query, params)


def refresh() -> None:
    """Call after anything that changes data."""
    st.cache_data.clear()


def documents() -> pd.DataFrame:
    return qdf("SELECT d.*, r.workflow_name, r.team, r.sla_due_at, r.sla_hours, r.status AS workflow_status "
               "FROM Documents d LEFT JOIN Routing r ON r.doc_id = d.doc_id")


@st.cache_data(ttl=6, show_spinner=False)
def kpis() -> dict:
    from src.analytics import metrics
    return metrics.kpis(sql())


def doc_detail(doc_id: str) -> dict:
    s = sql()
    doc = s.get_document(doc_id)
    return {
        "doc": doc,
        "fields": s.fields_of(doc_id),
        "issues": s.query("SELECT * FROM ValidationIssues WHERE doc_id=? ORDER BY severity, rule_id", [doc_id]),
        "route": s.one("SELECT * FROM Routing WHERE doc_id=?", [doc_id]),
        "stages": s.query("SELECT stage, ms FROM ProcessingStages WHERE doc_id=?", [doc_id]),
        "audit": s.query("SELECT ts, actor, action, detail_json FROM AuditLog WHERE doc_id=? ORDER BY audit_id", [doc_id]),
        "task": s.one("SELECT * FROM ReviewTasks WHERE doc_id=?", [doc_id]),
        "actions": s.query("SELECT ts, action_type, channel, target, status FROM WorkflowActions WHERE doc_id=?", [doc_id]),
    }


def answer_key() -> dict:
    from src.datagen.generate import load_answer_key
    return _answer_key_cached(str(config.SYNTH_DIR))


@st.cache_data(ttl=600, show_spinner=False)
def _answer_key_cached(_dir: str) -> dict:
    from src.datagen.generate import load_answer_key
    return load_answer_key(Path(_dir))


@st.cache_data(ttl=300, show_spinner="Comparing every extracted field with the answer key...")
def evaluation(_tick: int = 0) -> dict:
    """scripts/evaluate.py's collect() + evaluation.evaluate (loaded by path: scripts/ is not a package)."""
    from src.analytics.evaluation import evaluate
    spec = importlib.util.spec_from_file_location("evaluate_script", config.ROOT / "scripts" / "evaluate.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    key = _answer_key_cached(str(config.SYNTH_DIR))
    return evaluate(key, mod.collect(sql()))
