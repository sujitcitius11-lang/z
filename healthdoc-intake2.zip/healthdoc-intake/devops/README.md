# DevOps (Azure Boards + Repos + Pipelines)
* **Repos**: trunk-based, pull requests need 1 review + green pipeline.
* **Pipelines**: `azure-pipelines.yml` = test (pytest, offline) > validate Bicep > deploy dev. Production = separate environment with manual approval.
* **Boards backlog** (suggested epics > stories): 1 Data generation | 2 Ingest + OCR | 3 Classification + extraction | 4 Validation rules | 5 Routing + Logic Apps | 6 Storage (SQL/Cosmos) | 7 Review UI | 8 Dashboards + Power BI | 9 Security (Key Vault, Entra, RBAC) | 10 Infra as code + CI/CD | 11 Evaluation + demo.
* Secrets: never in the repo; pipeline uses a service connection; app uses managed identity + Key Vault.
