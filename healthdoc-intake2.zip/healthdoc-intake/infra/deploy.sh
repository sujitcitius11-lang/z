#!/usr/bin/env bash
# Usage: ./infra/deploy.sh <resource-group> <location> <sqlEntraAdminObjectId> <sqlEntraAdminLogin>
# NOT run in the build environment (needs an Azure subscription). Review `what-if` output first.
set -euo pipefail
RG=$1; LOC=$2; OID=$3; LOGIN=$4
az group create -n "$RG" -l "$LOC"
az deployment group what-if -g "$RG" -f infra/main.bicep -p @infra/main.parameters.json sqlEntraAdminObjectId="$OID" sqlEntraAdminLogin="$LOGIN"
read -rp "Apply? [y/N] " a; [[ $a == y ]] || exit 0
az deployment group create -g "$RG" -f infra/main.bicep -p @infra/main.parameters.json sqlEntraAdminObjectId="$OID" sqlEntraAdminLogin="$LOGIN"
echo "Next: run sql/schema_azure.sql, deploy the function (cd functions && func azure functionapp publish <name>), then re-run with createEventSubscription=true."
