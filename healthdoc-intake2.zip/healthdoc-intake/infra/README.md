# Infrastructure (Bicep)
`main.bicep` declares: Storage (4 containers), Document Intelligence, Azure OpenAI (+ model deployment), Azure SQL (Entra-only admin), Cosmos DB (partition /doc_type),
Key Vault, Log Analytics + App Insights, Function App (managed identity), Logic App, Event Grid system topic (+ optional subscription with dead-lettering) and role assignments (least privilege).
Deployment order matters: the Event Grid subscription needs the function to exist, so deploy twice (`createEventSubscription=false`, publish code, then `true`). `deploy.sh` prints the steps.
**Status: written but NOT compiled or deployed here (no Azure CLI/Bicep available).** Run `az bicep build --file infra/main.bicep` first; expect to fix small API-version or property issues.
Quota: Azure OpenAI model availability and capacity differ per region; set `openAiLocation` accordingly.
