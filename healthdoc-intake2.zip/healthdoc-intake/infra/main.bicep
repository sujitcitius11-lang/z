// Document Intake & Processing: complete Azure landing zone (resource-group scope).
// Deploy:  az deployment group create -g <rg> -f infra/main.bicep -p infra/main.parameters.json
// Two-pass deploy (see infra/README.md): pass 1 with createEventSubscription=false, publish the Function code, pass 2 with true
// (Event Grid can only subscribe to a Function that already exists).
targetScope = 'resourceGroup'

@description('Short lower-case prefix (3-8 letters/digits) used in resource names.')
@minLength(3)
@maxLength(8)
param namePrefix string = 'docint'

@description('Environment label used in tags and names.')
@allowed(['dev', 'test', 'prod'])
param environment string = 'dev'

param location string = resourceGroup().location

@description('Region for Azure OpenAI (model availability differs by region).')
param openAiLocation string = location

@description('Object ID of the Microsoft Entra user/group that becomes the SQL server administrator (Entra-only authentication).')
param sqlEntraAdminObjectId string

@description('Display name / UPN of that Entra admin.')
param sqlEntraAdminLogin string

@description('Azure OpenAI chat model.')
param openAiModelName string = 'gpt-4o-mini'
param openAiModelVersion string = '2024-07-18'
@description('Capacity in thousands of tokens per minute.')
param openAiCapacity int = 30

@description('Create the Event Grid subscription (set true on the SECOND pass, after the Function code is published).')
param createEventSubscription bool = false

@description('Domain used for team mailboxes by the routing Logic App.')
param teamEmailDomain string = 'example.org'

param tags object = {
  project: 'document-intake'
  environment: environment
  owner: 'capstone-team'
  dataClassification: 'synthetic-phi-like'
}

var suffix = uniqueString(resourceGroup().id)
var base = '${namePrefix}-${environment}'
var storageName = take('st${namePrefix}${environment}${suffix}', 24)
var funcStorageName = take('stf${namePrefix}${environment}${suffix}', 24)
var kvName = take('kv-${namePrefix}-${environment}-${suffix}', 24)
var funcName = 'func-${base}-${suffix}'
var planName = 'plan-${base}'
var cosmosName = take('cosmos-${base}-${suffix}', 44)
var sqlServerName = 'sql-${base}-${suffix}'
var sqlDbName = 'docintake'
var diName = 'di-${base}-${suffix}'
var aoaiName = 'aoai-${base}-${suffix}'
var logicName = 'logic-${base}-routing'
var containers = ['incoming', 'processed', 'review', 'quarantine', 'deadletter']

// built-in role definition ids
var roles = {
  storageBlobDataContributor: 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
  cognitiveServicesUser: 'a97b65f3-24c7-4388-baec-2e87135dc908'
  cognitiveServicesOpenAIUser: '5e0bd9bd-7b93-4f28-af87-19fc36ad61bd'
  keyVaultSecretsUser: '4633458b-17de-40f2-af8f-ce6a8c4e20a2'
}

// ------------------------------------------------------------------ monitoring
resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${base}'
  location: location
  tags: tags
  properties: { sku: { name: 'PerGB2018' }, retentionInDays: 30 }
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: 'appi-${base}'
  location: location
  kind: 'web'
  tags: tags
  properties: { Application_Type: 'web', WorkspaceResourceId: logs.id }
}

// ------------------------------------------------------------------ document storage (Blob) + containers
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
    allowSharedKeyAccess: false      // identities only: no account keys for the application data
    accessTier: 'Hot'
  }
}

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  parent: storage
  name: 'default'
  properties: { deleteRetentionPolicy: { enabled: true, days: 7 } }
}

resource blobContainers 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = [for c in containers: {
  parent: blobService
  name: c
  properties: { publicAccess: 'None' }
}]

// Function host storage (separate account: the Functions runtime needs shared-key / file share access)
resource funcStorage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: funcStorageName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: { minimumTlsVersion: 'TLS1_2', allowBlobPublicAccess: false, supportsHttpsTrafficOnly: true }
}

// ------------------------------------------------------------------ AI services
resource docIntel 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: diName
  location: location
  tags: tags
  kind: 'FormRecognizer'
  sku: { name: 'S0' }
  properties: { customSubDomainName: diName, publicNetworkAccess: 'Enabled', disableLocalAuth: true }
}

resource openAi 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: aoaiName
  location: openAiLocation
  tags: tags
  kind: 'OpenAI'
  sku: { name: 'S0' }
  properties: { customSubDomainName: aoaiName, publicNetworkAccess: 'Enabled', disableLocalAuth: true }
}

resource chatDeployment 'Microsoft.CognitiveServices/accounts/deployments@2024-10-01' = {
  parent: openAi
  name: openAiModelName
  sku: { name: 'GlobalStandard', capacity: openAiCapacity }
  properties: { model: { format: 'OpenAI', name: openAiModelName, version: openAiModelVersion } }
}

// ------------------------------------------------------------------ Azure SQL Database (Entra-only)
resource sqlServer 'Microsoft.Sql/servers@2023-08-01-preview' = {
  name: sqlServerName
  location: location
  tags: tags
  properties: {
    minimalTlsVersion: '1.2'
    publicNetworkAccess: 'Enabled'
    administrators: {
      administratorType: 'ActiveDirectory'
      principalType: 'User'
      login: sqlEntraAdminLogin
      sid: sqlEntraAdminObjectId
      tenantId: subscription().tenantId
      azureADOnlyAuthentication: true
    }
  }
}

resource sqlDb 'Microsoft.Sql/servers/databases@2023-08-01-preview' = {
  parent: sqlServer
  name: sqlDbName
  location: location
  tags: tags
  sku: { name: 'GP_S_Gen5_1', tier: 'GeneralPurpose', family: 'Gen5', capacity: 1 }
  properties: { autoPauseDelay: 60, minCapacity: json('0.5'), requestedBackupStorageRedundancy: 'Local' }
}

resource sqlAllowAzure 'Microsoft.Sql/servers/firewallRules@2023-08-01-preview' = {
  parent: sqlServer
  name: 'AllowAzureServices'
  properties: { startIpAddress: '0.0.0.0', endIpAddress: '0.0.0.0' }
}

// ------------------------------------------------------------------ Cosmos DB (serverless, raw extraction JSON)
resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-05-15' = {
  name: cosmosName
  location: location
  tags: tags
  kind: 'GlobalDocumentDB'
  properties: {
    databaseAccountOfferType: 'Standard'
    capabilities: [{ name: 'EnableServerless' }]
    consistencyPolicy: { defaultConsistencyLevel: 'Session' }
    locations: [{ locationName: location, failoverPriority: 0, isZoneRedundant: false }]
    disableLocalAuth: true
    minimalTlsVersion: 'Tls12'
  }
}

resource cosmosDb 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2024-05-15' = {
  parent: cosmos
  name: 'docintake'
  properties: { resource: { id: 'docintake' } }
}

resource cosmosContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-05-15' = {
  parent: cosmosDb
  name: 'extractions'
  properties: {
    resource: {
      id: 'extractions'
      partitionKey: { paths: ['/doc_type'], kind: 'Hash' }
      indexingPolicy: { indexingMode: 'consistent', automatic: true }
    }
  }
}

// ------------------------------------------------------------------ Key Vault (RBAC) + secrets
resource kv 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: kvName
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: { family: 'A', name: 'standard' }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 14
    enablePurgeProtection: true
  }
}

resource secretSql 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'AZURE-SQL-CONNECTION-STRING'
  properties: {
    // passwordless: the Function's system-assigned managed identity signs in to SQL (no password exists)
    value: 'Driver={ODBC Driver 18 for SQL Server};Server=tcp:${sqlServer.properties.fullyQualifiedDomainName},1433;Database=${sqlDbName};Authentication=ActiveDirectoryMsi;Encrypt=yes;TrustServerCertificate=no;'
  }
}

resource secretLogic 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'LOGIC-APP-ROUTING-URL'
  properties: { value: listCallbackUrl('${logicApp.id}/triggers/manual', '2016-06-01').value }
}

// ------------------------------------------------------------------ Logic App (routing) + API connections
var connectionNames = ['office365', 'teams', 'visualstudioteamservices']

resource apiConnections 'Microsoft.Web/connections@2016-06-01' = [for c in connectionNames: {
  name: 'conn-${c}'
  location: location
  tags: tags
  properties: {
    displayName: c
    api: { id: subscriptionResourceId('Microsoft.Web/locations/managedApis', location, c) }
  }
}]

resource logicApp 'Microsoft.Logic/workflows@2019-05-01' = {
  name: logicName
  location: location
  tags: tags
  properties: {
    state: 'Enabled'
    definition: loadJsonContent('../logic_apps/routing_workflow.json')
    parameters: {
      teamEmailDomain: { value: teamEmailDomain }
      '$connections': {
        value: {
          office365: { connectionId: apiConnections[0].id, connectionName: 'office365', id: subscriptionResourceId('Microsoft.Web/locations/managedApis', location, 'office365') }
          teams: { connectionId: apiConnections[1].id, connectionName: 'teams', id: subscriptionResourceId('Microsoft.Web/locations/managedApis', location, 'teams') }
          visualstudioteamservices: { connectionId: apiConnections[2].id, connectionName: 'visualstudioteamservices', id: subscriptionResourceId('Microsoft.Web/locations/managedApis', location, 'visualstudioteamservices') }
        }
      }
    }
  }
}

// ------------------------------------------------------------------ Function App (Linux, Python 3.11, managed identity)
resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  tags: tags
  kind: 'functionapp'
  sku: { name: 'Y1', tier: 'Dynamic' }
  properties: { reserved: true }
}

resource func 'Microsoft.Web/sites@2023-12-01' = {
  name: funcName
  location: location
  tags: tags
  kind: 'functionapp,linux'
  identity: { type: 'SystemAssigned' }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'Python|3.11'
      minTlsVersion: '1.2'
      ftpsState: 'Disabled'
      appSettings: [
        { name: 'AzureWebJobsStorage', value: 'DefaultEndpointsProtocol=https;AccountName=${funcStorage.name};AccountKey=${funcStorage.listKeys().keys[0].value};EndpointSuffix=${environment().suffixes.storage}' }
        { name: 'FUNCTIONS_EXTENSION_VERSION', value: '~4' }
        { name: 'FUNCTIONS_WORKER_RUNTIME', value: 'python' }
        { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT', value: 'true' }
        { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING', value: appInsights.properties.ConnectionString }
        { name: 'KEY_VAULT_URI', value: kv.properties.vaultUri }
        { name: 'EVENT_GRID_MODE', value: 'azure' }
        { name: 'AZURE_STORAGE_ACCOUNT_URL', value: storage.properties.primaryEndpoints.blob }
        { name: 'DOCUMENT_INTELLIGENCE_ENDPOINT', value: docIntel.properties.endpoint }
        { name: 'AZURE_OPENAI_ENDPOINT', value: openAi.properties.endpoint }
        { name: 'AZURE_OPENAI_DEPLOYMENT_NAME', value: chatDeployment.name }
        { name: 'AZURE_OPENAI_API_VERSION', value: '2024-10-21' }
        { name: 'COSMOS_ENDPOINT', value: cosmos.properties.documentEndpoint }
        { name: 'COSMOS_DATABASE', value: 'docintake' }
        { name: 'COSMOS_CONTAINER', value: 'extractions' }
        // secrets are Key Vault REFERENCES, resolved by the platform with the managed identity
        { name: 'AZURE_SQL_CONNECTION_STRING', value: '@Microsoft.KeyVault(SecretUri=${secretSql.properties.secretUri})' }
        { name: 'LOGIC_APP_ROUTING_URL', value: '@Microsoft.KeyVault(SecretUri=${secretLogic.properties.secretUri})' }
      ]
    }
  }
}

// ------------------------------------------------------------------ Event Grid: system topic on the storage account -> Function
resource systemTopic 'Microsoft.EventGrid/systemTopics@2024-06-01-preview' = {
  name: 'evgt-${base}-storage'
  location: location
  tags: tags
  identity: { type: 'SystemAssigned' }
  properties: { source: storage.id, topicType: 'Microsoft.Storage.StorageAccounts' }
}

resource eventSub 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2024-06-01-preview' = if (createEventSubscription) {
  parent: systemTopic
  name: 'evgs-incoming-blobcreated'
  properties: {
    destination: {
      endpointType: 'AzureFunction'
      properties: { resourceId: '${func.id}/functions/process_document', maxEventsPerBatch: 1, preferredBatchSizeInKilobytes: 64 }
    }
    filter: {
      includedEventTypes: ['Microsoft.Storage.BlobCreated']
      subjectBeginsWith: '/blobServices/default/containers/incoming/'
      enableAdvancedFilteringOnArrays: true
    }
    eventDeliverySchema: 'EventGridSchema'
    retryPolicy: { maxDeliveryAttempts: 10, eventTimeToLiveInMinutes: 1440 }
    deadLetterWithResourceIdentity: {
      identity: { type: 'SystemAssigned' }
      deadLetterDestination: { endpointType: 'StorageBlob', properties: { resourceId: storage.id, blobContainerName: 'deadletter' } }
    }
  }
  dependsOn: [topicDeadLetterRole]
}

// ------------------------------------------------------------------ role assignments (least privilege, identities only)
resource roleBlob 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storage.id, func.id, roles.storageBlobDataContributor)
  scope: storage
  properties: { principalId: func.identity.principalId, principalType: 'ServicePrincipal', roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roles.storageBlobDataContributor) }
}

resource roleDi 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(docIntel.id, func.id, roles.cognitiveServicesUser)
  scope: docIntel
  properties: { principalId: func.identity.principalId, principalType: 'ServicePrincipal', roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roles.cognitiveServicesUser) }
}

resource roleAoai 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(openAi.id, func.id, roles.cognitiveServicesOpenAIUser)
  scope: openAi
  properties: { principalId: func.identity.principalId, principalType: 'ServicePrincipal', roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roles.cognitiveServicesOpenAIUser) }
}

resource roleKv 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(kv.id, func.id, roles.keyVaultSecretsUser)
  scope: kv
  properties: { principalId: func.identity.principalId, principalType: 'ServicePrincipal', roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roles.keyVaultSecretsUser) }
}

// Cosmos DB data-plane RBAC (NOT Azure RBAC): built-in "Cosmos DB Built-in Data Contributor"
resource cosmosRole 'Microsoft.DocumentDB/databaseAccounts/sqlRoleAssignments@2024-05-15' = {
  parent: cosmos
  name: guid(cosmos.id, func.id, '00000000-0000-0000-0000-000000000002')
  properties: {
    roleDefinitionId: '${cosmos.id}/sqlRoleDefinitions/00000000-0000-0000-0000-000000000002'
    principalId: func.identity.principalId
    scope: cosmos.id
  }
}

// Event Grid's own identity writes undeliverable events to the `deadletter` container
resource topicDeadLetterRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storage.id, systemTopic.id, roles.storageBlobDataContributor)
  scope: storage
  properties: { principalId: systemTopic.identity.principalId, principalType: 'ServicePrincipal', roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roles.storageBlobDataContributor) }
}

// ------------------------------------------------------------------ outputs (no secrets)
output functionAppName string = func.name
output functionPrincipalId string = func.identity.principalId
output storageAccountName string = storage.name
output keyVaultName string = kv.name
output sqlServerFqdn string = sqlServer.properties.fullyQualifiedDomainName
output sqlDatabaseName string = sqlDbName
output cosmosEndpoint string = cosmos.properties.documentEndpoint
output documentIntelligenceEndpoint string = docIntel.properties.endpoint
output openAiEndpoint string = openAi.properties.endpoint
output logicAppName string = logicApp.name
output appInsightsName string = appInsights.name
output healthUrl string = 'https://${func.properties.defaultHostName}/api/health'
