# Streamlit UI
- app.py: login page, role-based redirect, sidebar shows only permitted pages. Multi-page via pages/. Wide layout.
- Token/role/user in st.session_state; auto-logout on token expiry (401 -> clear state, back to login).
- st.form for register/booking/prescription/billing. st.dataframe/st.data_editor with search+filters.
- Booking: doctor select -> date picker -> available-slot picker.
- Lab: st.file_uploader; download via st.download_button. Invoice/report export via st.download_button.
- Dashboard charts (revenue, patients seen, dept load) via Plotly. st.columns for layout.
- st.cache_data (ttl) for departments/doctors. Feedback via st.success/st.error/st.toast.
## Page -> roles (derived from use cases)
1_Patients: admin, receptionist, patient(self) | 2_Doctors: admin(write), all(read) | 3_Appointments: patient, receptionist, doctor
4_Consultation: doctor | 5_Lab_Reports: lab_technician(write), doctor, patient | 6_Billing: receptionist, patient
7_Pharmacy: pharmacist, admin | 8_Reports: admin, super_admin | 9_Admin: admin, super_admin (users, departments)

## Chatbot
Sidebar button "💬 Chatbot" (all logged-in roles) opens a dialog; calls api_client.chat -> POST /chatbot. Navigation via st.navigation shows only permitted pages.
