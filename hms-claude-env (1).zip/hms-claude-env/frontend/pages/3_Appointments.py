"""Appointments: book (doctor -> date -> slot), list, cancel."""
from datetime import date, timedelta

import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("patient", "receptionist", "doctor")
st.title("📅 Appointments")
try:
    if au.has_role("patient", "receptionist"):
        st.subheader("Book appointment")
        doctors = cm.cached("/doctors", limit=200)
        doc = cm.pick("Doctor", doctors, "doctor_id", lambda r: f"{r['name']} – {r['department_name']}")
        day = st.date_input("Date", date.today() + timedelta(days=1), min_value=date.today())
        slots = api.get(f"/doctors/{doc['doctor_id']}/availability", date=day.isoformat())["slots"] if doc else []
        if doc and not slots:
            st.info("No free slots on this date. Try another day.")
        patient = None
        if au.has_role("receptionist"):
            patient = cm.pick("Patient", cm.cached("/patients", limit=200), "patient_id", lambda r: f"{r['name']} ({r['email']})")
        with st.form("book", clear_on_submit=True):
            slot = st.selectbox("Available slot", slots)
            notes = st.text_input("Reason / notes")
            if st.form_submit_button("Book") and doc and slot:
                body = {"doctor_id": doc["doctor_id"], "appointment_date": f"{day.isoformat()}T{slot}:00", "notes": notes or None}
                if patient:
                    body["patient_id"] = patient["patient_id"]
                try:
                    api.post("/appointments", body)
                    st.success("Appointment booked")
                except api.ApiError as e:
                    cm.fail(e)

    st.subheader("Appointments")
    status = st.selectbox("Status", ["", "Scheduled", "Completed", "Cancelled"])
    rows = api.get("/appointments", status=status, limit=200)
    if rows:
        df = pd.DataFrame(rows)
        st.dataframe(df[["appointment_date", "patient_name", "doctor_name", "status", "notes"]], hide_index=True)
        open_ = [r for r in rows if r["status"] == "Scheduled"]
        sel = cm.pick("Cancel appointment", open_, "appointment_id",
                      lambda r: f"{r['appointment_date'][:16]} – {r['patient_name']} with {r['doctor_name']}", key="cancel_sel")
        if sel and st.button("Cancel selected"):
            api.patch(f"/appointments/{sel['appointment_id']}/cancel")
            st.toast("Cancelled")
            st.rerun()
    else:
        st.info("No appointments found.")
except api.ApiError as e:
    cm.fail(e)
