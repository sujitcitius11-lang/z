"""Lab reports: technicians upload; doctors/patients view and download."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("lab_technician", "doctor", "patient")
st.title("🧪 Lab Reports")
try:
    if au.has_role("lab_technician"):
        st.subheader("Upload result")
        pat = cm.pick("Patient", cm.cached("/patients", limit=200), "patient_id", lambda r: f"{r['name']} ({r['email']})")
        with st.form("lab", clear_on_submit=True):
            test = st.text_input("Test name (e.g. CBC, X-ray)")
            summary = st.text_area("Result summary")
            file = st.file_uploader("Report file (PDF/PNG/JPG, max 5 MB)", type=["pdf", "png", "jpg", "jpeg"])
            if st.form_submit_button("Upload") and pat:
                files = {"file": (file.name, file.getvalue(), file.type)} if file else None
                try:
                    api.post("/lab-reports", data={"patient_id": pat["patient_id"], "test_name": test, "result_summary": summary}, files=files)
                    st.success("Report saved")
                except api.ApiError as e:
                    cm.fail(e)

    st.subheader("Reports")
    rows = api.get("/lab-reports", limit=200)
    if not rows:
        st.info("No lab reports.")
        st.stop()
    st.dataframe(pd.DataFrame(rows)[["created_at", "patient_name", "test_name", "result_summary", "has_file"]], hide_index=True)
    sel = cm.pick("Report", [r for r in rows if r["has_file"]], "report_id", lambda r: f"{r['test_name']} – {r['patient_name']}")
    if sel and st.button("Prepare download"):
        st.session_state["dl"] = (sel["report_id"], sel["test_name"], api.download(f"/lab-reports/{sel['report_id']}/download"))
    dl = st.session_state.get("dl")
    if dl and sel and dl[0] == sel["report_id"]:
        st.download_button(f"Download {dl[1]}", dl[2], file_name=f"{dl[1]}")
except api.ApiError as e:
    cm.fail(e)
