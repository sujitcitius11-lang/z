"""Patients: staff list/register/edit; a patient edits their own profile."""
from datetime import date

import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("admin", "receptionist", "patient")
st.title("🧑 Patients")
GENDERS = ["", "Male", "Female", "Other"]
staff = au.has_role("admin", "receptionist")

q = st.text_input("Search name / email") if staff else None
try:
    rows = api.get("/patients", q=q, limit=200)
except api.ApiError as e:
    cm.fail(e)
    st.stop()

if rows:
    st.dataframe(pd.DataFrame(rows).drop(columns=["patient_id", "user_id"]), hide_index=True)

st.subheader("Edit profile" if not staff else "Edit patient")
sel = cm.pick("Patient", rows, "patient_id", lambda r: f"{r['name']} ({r['email']})") if staff else (rows[0] if rows else None)
if sel:
    with st.form("edit_patient"):
        name = st.text_input("Name", sel["name"])
        phone = st.text_input("Contact number", sel.get("contact_number") or "")
        gender = st.selectbox("Gender", GENDERS, index=GENDERS.index(sel.get("gender") or ""))
        dob = st.date_input("Date of birth", date.fromisoformat(sel["dob"]) if sel.get("dob") else date(1990, 1, 1),
                            min_value=date(1900, 1, 1), max_value=date.today())
        blood = st.text_input("Blood group", sel.get("blood_group") or "")
        emergency = st.text_input("Emergency contact", sel.get("emergency_contact") or "")
        address = st.text_area("Address", sel.get("address") or "")
        allergies = st.text_area("Allergies (comma separated)", sel.get("allergies") or "")
        if st.form_submit_button("Save"):
            try:
                api.put(f"/patients/{sel['patient_id']}", {
                    "name": name, "contact_number": phone or None, "gender": gender or None, "dob": dob.isoformat(),
                    "blood_group": blood or None, "emergency_contact": emergency or None,
                    "address": address or None, "allergies": allergies or None})
                cm.refresh()
                st.toast("Saved")
            except api.ApiError as e:
                cm.fail(e)

if staff:
    st.subheader("Register new patient")
    with st.form("new_patient", clear_on_submit=True):
        c1, c2 = st.columns(2)
        name = c1.text_input("Full name")
        email = c2.text_input("Email")
        pwd = c1.text_input("Temporary password (min 8)", type="password")
        phone = c2.text_input("Contact number")
        gender = c1.selectbox("Gender", GENDERS)
        dob = c2.date_input("Date of birth", date(1990, 1, 1), min_value=date(1900, 1, 1), max_value=date.today())
        blood = c1.text_input("Blood group")
        emergency = c2.text_input("Emergency contact")
        address = st.text_area("Address")
        allergies = st.text_area("Allergies")
        if st.form_submit_button("Register patient"):
            try:
                api.post("/patients", {"name": name, "email": email, "password": pwd, "contact_number": phone or None,
                                       "gender": gender or None, "dob": dob.isoformat(), "blood_group": blood or None,
                                       "emergency_contact": emergency or None, "address": address or None,
                                       "allergies": allergies or None})
                cm.refresh()
                st.success("Patient registered")
            except api.ApiError as e:
                cm.fail(e)
