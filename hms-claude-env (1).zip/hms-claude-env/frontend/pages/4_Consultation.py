"""Consultation: doctors write prescriptions; patients read their own."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("doctor", "patient")
st.title("📝 Consultation")


def show_history(patient_id: str) -> None:
    """Prescription history table."""
    rx = api.get(f"/patients/{patient_id}/prescriptions", limit=100)
    if not rx:
        st.info("No prescriptions yet.")
        return
    for r in rx:
        meds = ", ".join(f"{m['name']} {m['dosage']} x{m['quantity']}" for m in r["medicines"]) or "-"
        st.markdown(f"**{r['diagnosis']}** — {meds}  \n`{r['prescription_id']}` {'✅ dispensed' if r['dispensed'] else ''}")


try:
    if au.has_role("patient"):
        me = api.get("/patients", limit=1)
        show_history(me[0]["patient_id"]) if me else st.info("No patient profile.")
        st.stop()

    appts = api.get("/appointments", status="Scheduled", limit=200)
    sel = cm.pick("Scheduled appointment", appts, "appointment_id",
                  lambda r: f"{r['appointment_date'][:16]} – {r['patient_name']}")
    if sel:
        with st.expander("Patient history", expanded=False):
            show_history(sel["patient_id"])
        st.subheader("Diagnosis & prescription")
        meds = st.data_editor(pd.DataFrame([{"name": "", "dosage": "1-0-1", "quantity": 1}]), num_rows="dynamic",
                              key=f"meds_{sel['appointment_id']}")
        with st.form("rx"):
            diagnosis = st.text_area("Diagnosis")
            notes = st.text_area("Visit notes")
            if st.form_submit_button("Save & complete visit"):
                items = [{"name": r["name"].strip(), "dosage": r["dosage"], "quantity": int(r["quantity"])}
                         for r in meds.to_dict("records") if str(r["name"]).strip()]
                try:
                    if notes:
                        api.put(f"/appointments/{sel['appointment_id']}", {"notes": notes})
                    api.post("/prescriptions", {"appointment_id": sel["appointment_id"], "diagnosis": diagnosis, "medicines": items})
                    st.success("Prescription saved; visit marked Completed")
                except api.ApiError as e:
                    cm.fail(e)
except api.ApiError as e:
    cm.fail(e)
