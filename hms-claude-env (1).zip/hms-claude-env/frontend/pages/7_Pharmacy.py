"""Pharmacy: stock, alerts, add/update, dispense."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("pharmacist", "admin")
st.title("💊 Pharmacy")
try:
    tab_stock, tab_edit, tab_disp = st.tabs(["Stock", "Add / update", "Dispense"])
    with tab_stock:
        c1, c2, c3 = st.columns(3)
        q = c1.text_input("Search")
        low = c2.checkbox("Low stock (≤10)")
        near = c3.checkbox("Near expiry (≤30 days)")
        rows = api.get("/medicines", q=q, low_stock=low or None, near_expiry=near or None, limit=200)
        if low or near:
            st.warning(f"{len(rows)} item(s) need attention") if rows else st.success("No alerts")
        if rows:
            st.dataframe(pd.DataFrame(rows).drop(columns=["medicine_id"]), hide_index=True)
    with tab_edit:
        existing = api.get("/medicines", limit=200)
        sel = cm.pick("Edit existing (or leave for new)", [{"name": "➕ New medicine"}] + existing, "medicine_id", lambda r: r["name"])
        cur = sel if sel and "medicine_id" in sel else {}
        with st.form("med"):
            name = st.text_input("Name", cur.get("name", ""))
            qty = st.number_input("Quantity", min_value=0, value=int(cur.get("quantity_available", 0)))
            exp = st.date_input("Expiry date", pd.to_datetime(cur["expiry_date"]).date() if cur else None)
            price = st.number_input("Unit price", min_value=0.0, value=float(cur.get("unit_price", 0.0)), step=0.5)
            if st.form_submit_button("Save") and exp:
                body = {"name": name, "quantity_available": int(qty), "expiry_date": exp.isoformat(), "unit_price": price}
                try:
                    api.put(f"/medicines/{cur['medicine_id']}", body) if cur else api.post("/medicines", body)
                    st.success("Saved")
                except api.ApiError as e:
                    cm.fail(e)
    with tab_disp:
        with st.form("disp"):
            rx = st.text_input("Prescription ID (UUID)")
            if st.form_submit_button("Dispense"):
                try:
                    out = api.post("/pharmacy/dispense", {"prescription_id": rx.strip()})
                    st.success(f"Dispensed. Total {out['total']:.2f}")
                    st.dataframe(pd.DataFrame(out["items"]), hide_index=True)
                except api.ApiError as e:
                    cm.fail(e)
except api.ApiError as e:
    cm.fail(e)
