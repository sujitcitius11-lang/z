"""Admin: users and departments."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("admin")
st.title("⚙️ Admin")
ROLES = ["admin", "doctor", "receptionist", "patient", "lab_technician", "pharmacist", "super_admin"]
tab_u, tab_d = st.tabs(["Users", "Departments"])
try:
    with tab_u:
        q = st.text_input("Search users")
        users = api.get("/users", q=q, limit=200)
        if users:
            st.dataframe(pd.DataFrame(users).drop(columns=["user_id"]), hide_index=True)
        sel = cm.pick("Deactivate user", [u for u in users if u["status"]], "user_id", lambda u: f"{u['name']} ({u['role']})", key="deact")
        if sel and st.button("Deactivate"):
            api.delete(f"/users/{sel['user_id']}")
            st.toast("User deactivated")
            st.rerun()
        with st.form("new_user", clear_on_submit=True):
            st.subheader("Create user")
            c1, c2 = st.columns(2)
            name, email = c1.text_input("Name"), c2.text_input("Email")
            pwd, role = c1.text_input("Password (min 8)", type="password"), c2.selectbox("Role", ROLES)
            phone = c1.text_input("Contact number")
            if st.form_submit_button("Create"):
                try:
                    api.post("/users", {"name": name, "email": email, "password": pwd, "role": role, "contact_number": phone or None})
                    st.success("User created")
                except api.ApiError as e:
                    cm.fail(e)
    with tab_d:
        depts = api.get("/departments", limit=200)
        if depts:
            st.dataframe(pd.DataFrame(depts).drop(columns=["department_id"]), hide_index=True)
        with st.form("new_dept", clear_on_submit=True):
            name, desc = st.text_input("Department name"), st.text_input("Description")
            if st.form_submit_button("Add department"):
                try:
                    api.post("/departments", {"name": name, "description": desc or None})
                    cm.refresh()
                    st.success("Added")
                except api.ApiError as e:
                    cm.fail(e)
        sel = cm.pick("Delete department", depts, "department_id", lambda d: d["name"], key="del_dept")
        if sel and st.button("Delete department"):
            try:
                api.delete(f"/departments/{sel['department_id']}")
                cm.refresh()
                st.rerun()
            except api.ApiError as e:
                cm.fail(e)
except api.ApiError as e:
    cm.fail(e)
