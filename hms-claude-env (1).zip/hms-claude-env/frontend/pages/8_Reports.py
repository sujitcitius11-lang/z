"""Reports: revenue, patients seen, top departments + CSV/PDF export."""
from datetime import date, timedelta

import pandas as pd
import plotly.express as px
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("admin")
st.title("📊 Reports")
c1, c2 = st.columns(2)
d_from = c1.date_input("From", date.today() - timedelta(days=30))
d_to = c2.date_input("To", date.today())
rng = {"date_from": d_from.isoformat(), "date_to": d_to.isoformat()}
try:
    rev, seen, top = (api.get(f"/reports/{p}", **rng) for p in ("revenue", "patients-seen", "top-departments"))
    left, right = st.columns(2)
    with left:
        st.subheader("Daily revenue")
        st.plotly_chart(px.bar(pd.DataFrame(rev), x="date", y="revenue")) if rev else st.info("No paid bills in range.")
    with right:
        st.subheader("Patients seen")
        st.plotly_chart(px.line(pd.DataFrame(seen), x="date", y="patients", markers=True)) if seen else st.info("No completed visits.")
    st.subheader("Department load")
    st.plotly_chart(px.bar(pd.DataFrame(top), x="department", y="appointments")) if top else st.info("No appointments.")

    st.subheader("Export")
    e1, e2, e3 = st.columns(3)
    report = e1.selectbox("Report", ["revenue", "patients-seen", "top-departments"])
    fmt = e2.selectbox("Format", ["csv", "pdf"])
    if e3.button("Prepare export"):
        st.session_state["exp"] = (f"{report}.{fmt}", api.download("/reports/export", report=report, format=fmt, **rng))
    if exp := st.session_state.get("exp"):
        st.download_button(f"Download {exp[0]}", exp[1], file_name=exp[0])
except api.ApiError as e:
    cm.fail(e)
