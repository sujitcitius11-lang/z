"""Doctors: everyone reads; admin adds/updates."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("admin", "doctor", "receptionist", "patient", "lab_technician", "pharmacist")
st.title("🩺 Doctors")
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
try:
    depts = cm.cached("/departments", limit=200)
    q = st.text_input("Search name / qualification")
    docs = api.get("/doctors", q=q, limit=200)
except api.ApiError as e:
    cm.fail(e)
    st.stop()

if docs:
    df = pd.DataFrame(docs)
    df["availability"] = df["availability"].apply(lambda a: ", ".join(f"{k} {v}" for k, v in a.items()))
    st.dataframe(df[["name", "department_name", "qualification", "availability"]], hide_index=True)

if au.has_role("admin"):
    st.caption("Availability uses hours, e.g. `10-2` = 10:00–14:00, `2-6` = 14:00–18:00.")
    st.subheader("Update availability")
    sel = cm.pick("Doctor", docs, "doctor_id", lambda r: f"{r['name']} – {r['department_name']}")
    if sel:
        with st.form("avail"):
            cols = st.columns(7)
            vals = {d: c.text_input(d, sel["availability"].get(d, "")) for d, c in zip(DAYS, cols)}
            if st.form_submit_button("Save availability"):
                try:
                    api.put(f"/doctors/{sel['doctor_id']}", {"availability": {k: v for k, v in vals.items() if v}})
                    cm.refresh()
                    st.toast("Updated")
                except api.ApiError as e:
                    cm.fail(e)

    st.subheader("Add doctor")
    with st.form("new_doc", clear_on_submit=True):
        c1, c2 = st.columns(2)
        name = c1.text_input("Full name")
        email = c2.text_input("Email")
        pwd = c1.text_input("Password (min 8)", type="password")
        phone = c2.text_input("Contact number")
        dept = c1.selectbox("Department", range(len(depts)), format_func=lambda i: depts[i]["name"]) if depts else None
        qual = c2.text_input("Qualification", "MBBS")
        cols = st.columns(7)
        vals = {d: c.text_input(d, key=f"n_{d}") for d, c in zip(DAYS, cols)}
        if st.form_submit_button("Add doctor"):
            if dept is None:
                st.error("Create a department first (Admin page).")
            else:
                try:
                    api.post("/doctors", {"name": name, "email": email, "password": pwd, "contact_number": phone or None,
                                          "department_id": depts[dept]["department_id"], "qualification": qual,
                                          "availability": {k: v for k, v in vals.items() if v}})
                    cm.refresh()
                    st.success("Doctor added")
                except api.ApiError as e:
                    cm.fail(e)
