"""Billing: receptionist creates bills / marks payment; patient views own."""
import pandas as pd
import streamlit as st

import api_client as api
import auth_utils as au
import common as cm

au.require_role("receptionist", "patient")
st.title("💳 Billing")
try:
    if au.has_role("receptionist"):
        st.subheader("New bill")
        pat = cm.pick("Patient", cm.cached("/patients", limit=200), "patient_id", lambda r: f"{r['name']} ({r['email']})")
        lines = st.data_editor(pd.DataFrame([{"name": "Consultation", "amount": 0.0}]), num_rows="dynamic", key="lines")
        total = float(pd.to_numeric(lines["amount"], errors="coerce").fillna(0).sum())
        st.write(f"**Total: {total:.2f}**")
        if st.button("Create bill") and pat:
            items = [{"name": str(r["name"]), "amount": float(r["amount"])} for r in lines.to_dict("records") if str(r["name"]).strip()]
            try:
                api.post("/billing", {"patient_id": pat["patient_id"], "services": items})
                st.success("Bill created")
            except api.ApiError as e:
                cm.fail(e)

    st.subheader("Bills")
    bills = api.get("/billing", limit=200)
    if not bills:
        st.info("No bills.")
        st.stop()
    st.dataframe(pd.DataFrame(bills)[["created_at", "patient_name", "total_amount", "payment_status", "payment_mode"]], hide_index=True)
    sel = cm.pick("Bill", bills, "bill_id", lambda r: f"{r['created_at'][:10]} – {r['patient_name']} – {r['total_amount']:.2f} ({r['payment_status']})")
    if sel:
        if au.has_role("receptionist"):
            with st.form("pay"):
                status = st.selectbox("Payment status", ["Paid", "Partially Paid", "Unpaid"])
                mode = st.selectbox("Mode", ["Cash", "Card", "Online"])
                if st.form_submit_button("Update payment"):
                    try:
                        api.patch(f"/billing/{sel['bill_id']}/payment", {"payment_status": status, "payment_mode": mode})
                        st.toast("Updated")
                        st.rerun()
                    except api.ApiError as e:
                        cm.fail(e)
        if st.button("Prepare invoice PDF"):
            st.session_state["inv"] = (sel["bill_id"], api.download(f"/billing/{sel['bill_id']}/invoice.pdf"))
        inv = st.session_state.get("inv")
        if inv and inv[0] == sel["bill_id"]:
            st.download_button("Download invoice", inv[1], file_name=f"invoice-{inv[0]}.pdf", mime="application/pdf")
except api.ApiError as e:
    cm.fail(e)
