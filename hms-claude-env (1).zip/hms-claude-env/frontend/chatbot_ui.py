"""Chatbot button + dialog. The Azure key never reaches the browser; calls go via POST /chatbot."""
import streamlit as st

import api_client as api


@st.dialog("💬 HMS Assistant", width="large")
def chatbot_dialog() -> None:
    """Modal chat window."""
    st.caption("Ask how to use HMS. For medical concerns, please consult a doctor.")
    history = st.session_state.setdefault("chat", [])
    box = st.container(height=380)
    with st.form("chat_form", clear_on_submit=True):
        msg = st.text_input("Message", max_chars=1000, label_visibility="collapsed", placeholder="Type your question…")
        c1, c2 = st.columns([1, 1])
        sent = c1.form_submit_button("Send")
        cleared = c2.form_submit_button("Clear chat")
    if cleared:
        history.clear()
    elif sent and msg.strip():
        try:
            with st.spinner("Thinking…"):
                reply = api.chat(msg.strip(), history[-10:])
            history += [{"role": "user", "content": msg.strip()}, {"role": "assistant", "content": reply}]
        except api.ApiError as e:
            st.error(str(e))
    with box:
        for m in history:
            with st.chat_message(m["role"]):
                st.write(m["content"])


def chatbot_button() -> None:
    """Sidebar button that opens the chat dialog."""
    if st.sidebar.button("💬 Chatbot", key="open_chat"):
        chatbot_dialog()
