"""All HTTP calls to the FastAPI backend (R-UI-01). Token comes from st.session_state."""
import os
from pathlib import Path

import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")
BASE = os.getenv("API_BASE_URL", "http://localhost:8000/api/v1").rstrip("/")
TIMEOUT = 30


class ApiError(Exception):
    """Readable API failure."""

    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


def _message(r: requests.Response) -> str:
    try:
        detail = r.json().get("detail", r.text)
    except Exception:
        return r.text[:200] or f"HTTP {r.status_code}"
    if isinstance(detail, list):
        return "; ".join(f"{'.'.join(map(str, e.get('loc', [])[1:]))}: {e.get('msg')}" for e in detail)
    return str(detail)


def request(method: str, path: str, raw: bool = False, **kw):
    """Call the API; returns JSON (or bytes if raw). Raises ApiError."""
    headers = {}
    token = st.session_state.get("token")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.request(method, BASE + path, headers=headers, timeout=TIMEOUT, **kw)
    except requests.RequestException:
        raise ApiError("Cannot reach the API server. Is the backend running?")
    if r.status_code == 401 and token:
        st.session_state.clear()
        st.session_state["flash"] = "Session expired. Please log in again."
        st.rerun()
    if r.status_code >= 400:
        raise ApiError(_message(r), r.status_code)
    if raw:
        return r.content
    return None if r.status_code == 204 else r.json()


def _clean(params: dict) -> dict:
    return {k: v for k, v in params.items() if v not in (None, "")}


def get(path: str, **params):
    """GET with query params (None/empty dropped)."""
    return request("GET", path, params=_clean(params))


def post(path: str, json=None, **kw):
    """POST JSON (or multipart via data/files)."""
    return request("POST", path, json=json, **kw)


def put(path: str, json=None):
    """PUT JSON."""
    return request("PUT", path, json=json)


def patch(path: str, json=None):
    """PATCH JSON."""
    return request("PATCH", path, json=json)


def delete(path: str):
    """DELETE."""
    return request("DELETE", path)


def download(path: str, **params) -> bytes:
    """GET raw bytes (files, PDF, CSV)."""
    return request("GET", path, raw=True, params=_clean(params))


def login(email: str, password: str) -> dict:
    """POST /auth/login."""
    return post("/auth/login", {"email": email, "password": password})


def chat(message: str, history: list[dict]) -> str:
    """Ask the chatbot; keys stay on the backend."""
    return post("/chatbot", {"message": message, "history": history})["reply"]
