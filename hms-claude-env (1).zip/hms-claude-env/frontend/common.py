"""Shared UI helpers. Cached reads include the token in the cache key (no cross-user leaks)."""
import streamlit as st

import api_client as api


@st.cache_data(ttl=60, show_spinner=False)
def _cached_get(token: str, path: str, params: tuple):
    return api.get(path, **dict(params))


def cached(path: str, **params):
    """Cached GET for read-only reference data (departments, doctors, patients)."""
    return _cached_get(st.session_state["token"], path, tuple(sorted(params.items())))


def refresh() -> None:
    """Drop cached reads after a write."""
    st.cache_data.clear()


def fail(e: Exception) -> None:
    """Show an API error."""
    st.error(str(e))


def pick(label: str, rows: list[dict], key_field: str, text, **kw):
    """Selectbox returning the chosen row (or None)."""
    if not rows:
        st.info(f"No {label.lower()} available.")
        return None
    idx = st.selectbox(label, range(len(rows)), format_func=lambda i: text(rows[i]), **kw)
    return rows[idx]
