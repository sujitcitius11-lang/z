"""HMS Streamlit entry: login/register, role-based navigation, chatbot button."""
import streamlit as st

import api_client as api
import auth_utils as au
from chatbot_ui import chatbot_button

st.set_page_config(page_title="HMS", page_icon="🏥", layout="wide")

# (file, title, icon, roles allowed to see it)
PAGES = [
    ("pages/1_Patients.py", "Patients", "🧑", ("admin", "receptionist", "patient")),
    ("pages/2_Doctors.py", "Doctors", "🩺", ("admin", "doctor", "receptionist", "patient", "lab_technician", "pharmacist")),
    ("pages/3_Appointments.py", "Appointments", "📅", ("patient", "receptionist", "doctor")),
    ("pages/4_Consultation.py", "Consultation", "📝", ("doctor", "patient")),
    ("pages/5_Lab_Reports.py", "Lab Reports", "🧪", ("lab_technician", "doctor", "patient")),
    ("pages/6_Billing.py", "Billing", "💳", ("receptionist", "patient")),
    ("pages/7_Pharmacy.py", "Pharmacy", "💊", ("pharmacist", "admin")),
    ("pages/8_Reports.py", "Reports", "📊", ("admin",)),
    ("pages/9_Admin.py", "Admin", "⚙️", ("admin",)),
]


def login_view() -> None:
    """Login / self-registration screen."""
    st.title("🏥 Hospital Management System")
    if flash := st.session_state.pop("flash", None):
        st.warning(flash)
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        tab_in, tab_up = st.tabs(["Login", "Register (patient)"])
        with tab_in, st.form("login"):
            email = st.text_input("Email")
            pwd = st.text_input("Password", type="password")
            if st.form_submit_button("Login"):
                try:
                    au.sign_in(api.login(email, pwd))
                    st.rerun()
                except api.ApiError as e:
                    st.error(str(e))
        with tab_up, st.form("register"):
            name = st.text_input("Full name")
            email = st.text_input("Email", key="reg_email")
            phone = st.text_input("Contact number")
            pwd = st.text_input("Password (min 8 chars)", type="password", key="reg_pwd")
            if st.form_submit_button("Create account"):
                try:
                    api.post("/auth/register", {"name": name, "email": email, "password": pwd,
                                                "contact_number": phone or None})
                    st.success("Account created. Please log in.")
                except api.ApiError as e:
                    st.error(str(e))


au.check_expiry()
if not au.logged_in():
    login_view()
    st.stop()

allowed = [st.Page(f, title=t, icon=i) for f, t, i, roles in PAGES if au.has_role(*roles)]
with st.sidebar:
    st.markdown(f"**{st.session_state['name']}**  \n`{au.role()}`")
chatbot_button()
if st.sidebar.button("Logout"):
    au.sign_out()
    st.rerun()
st.navigation(allowed).run()
