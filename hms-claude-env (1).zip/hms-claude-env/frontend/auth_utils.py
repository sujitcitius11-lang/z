"""Session state, expiry and role checks (UX only; backend enforces real RBAC)."""
import base64
import json
import time

import streamlit as st


def logged_in() -> bool:
    """True when a token is stored."""
    return bool(st.session_state.get("token"))


def role() -> str | None:
    """Current role."""
    return st.session_state.get("role")


def has_role(*roles: str) -> bool:
    """Role check; super_admin passes admin checks."""
    r = role()
    return r in roles or (r == "super_admin" and "admin" in roles)


def sign_in(data: dict) -> None:
    """Store the login response."""
    st.session_state.update(token=data["access_token"], role=data["role"], name=data["name"],
                            user_id=data["user_id"], chat=[])


def sign_out() -> None:
    """Clear the session."""
    st.session_state.clear()


def check_expiry() -> None:
    """Auto-logout when the JWT has expired."""
    token = st.session_state.get("token")
    if not token:
        return
    try:
        body = token.split(".")[1]
        exp = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))["exp"]
    except Exception:
        exp = 0
    if exp < time.time():
        st.session_state.clear()
        st.session_state["flash"] = "Session expired. Please log in again."
        st.rerun()


def require_role(*roles: str) -> None:
    """Stop the page unless the user holds one of `roles`."""
    if not logged_in():
        st.error("Please log in.")
        st.stop()
    if not has_role(*roles):
        st.error("Your role is not permitted to view this page.")
        st.stop()
