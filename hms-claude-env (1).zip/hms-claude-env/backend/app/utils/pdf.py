"""PDF builders (ReportLab)."""
from io import BytesIO

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def _new_page(c: canvas.Canvas, title: str) -> float:
    c.showPage()
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, A4[1] - 50, title)
    c.setFont("Helvetica", 10)
    return A4[1] - 80


def invoice_pdf(bill) -> bytes:
    """Render a bill (ORM Billing) as a PDF invoice."""
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = A4[1] - 50
    c.setFont("Helvetica-Bold", 16)
    c.drawString(40, y, "HMS - Invoice")
    c.setFont("Helvetica", 10)
    meta = [f"Bill ID: {bill.bill_id}", f"Patient: {bill.patient_name}",
            f"Date: {bill.created_at:%Y-%m-%d %H:%M}", f"Status: {bill.payment_status.value}",
            f"Mode: {bill.payment_mode.value if bill.payment_mode else '-'}"]
    for line in meta:
        y -= 18
        c.drawString(40, y, line)
    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(40, y, "Service")
    c.drawRightString(540, y, "Amount")
    c.setFont("Helvetica", 10)
    for s in bill.services:
        y -= 16
        if y < 60:
            y = _new_page(c, "HMS - Invoice (cont.)")
        c.drawString(40, y, str(s.get("name", ""))[:70])
        c.drawRightString(540, y, f"{float(s.get('amount', 0)):.2f}")
    y -= 28
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: {float(bill.total_amount):.2f}")
    c.save()
    return buf.getvalue()


def table_pdf(title: str, rows: list[dict]) -> bytes:
    """Render list-of-dicts as a simple table PDF."""
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, A4[1] - 50, title)
    c.setFont("Helvetica", 10)
    y = A4[1] - 80
    cols = list(rows[0].keys()) if rows else []
    step = (A4[0] - 80) / max(len(cols), 1)
    for i, k in enumerate(cols):
        c.drawString(40 + i * step, y, str(k).upper())
    for r in rows:
        y -= 16
        if y < 60:
            y = _new_page(c, title)
        for i, k in enumerate(cols):
            c.drawString(40 + i * step, y, str(r[k])[:24])
    if not rows:
        c.drawString(40, y, "No data")
    c.save()
    return buf.getvalue()
