"""Doctor availability -> 30-minute slots. Availability: {"Mon": "10-2", "Tue": "2-6"} (hours)."""
from datetime import date

SLOT_MIN = 30
DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


def parse_range(text: str) -> tuple[int, int] | None:
    """Parse '10-2' -> (10, 14); '2-6' -> (14, 18); '9-17' -> (9, 17). None if invalid."""
    try:
        a, b = text.replace(" ", "").split("-")
        start, end = int(a), int(b)
    except ValueError:
        return None
    if start < 7:
        start += 12
    if end <= start:
        end += 12
    return (start, end) if 0 <= start < end <= 24 else None


def slots_for(availability: dict | None, day: date) -> list[str]:
    """All HH:MM slots a doctor offers on `day`."""
    rng = parse_range((availability or {}).get(DAYS[day.weekday()], ""))
    if not rng:
        return []
    out, t = [], rng[0] * 60
    while t + SLOT_MIN <= rng[1] * 60:
        out.append(f"{t // 60:02d}:{t % 60:02d}")
        t += SLOT_MIN
    return out
