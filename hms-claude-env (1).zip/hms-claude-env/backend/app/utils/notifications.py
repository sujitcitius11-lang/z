"""Notification stub: logs in-app notifications. Replace with email/SMS/WebSocket later."""
import logging
import uuid

_log = logging.getLogger("hms.notify")


def notify(user_id: uuid.UUID, message: str) -> None:
    """Record a notification for a user."""
    _log.info("notify user=%s msg=%s", user_id, message)
