"""HMS FastAPI application."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import app.models  # noqa: F401
from app.core.config import settings
from app.db.base import Base
from app.db.init import seed_demo
from app.db.session import SessionLocal, engine
from app.routers import (appointments, auth, billing, chatbot, departments, doctors, lab, patients,
                         pharmacy, prescriptions, reports, users)


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Create tables (dev convenience) and seed demo data."""
    if settings.AUTO_CREATE_TABLES:
        Base.metadata.create_all(engine)
    if settings.SEED_DEMO_DATA:
        with SessionLocal() as db:
            seed_demo(db)
    yield


app = FastAPI(title="Hospital Management System API", version="1.1", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])


@app.get("/health", tags=["health"])
def health():
    """Liveness probe."""
    return {"status": "ok"}


for _r in (auth, users, patients, doctors, departments, appointments, prescriptions,
           lab, billing, pharmacy, reports, chatbot):
    app.include_router(_r.router, prefix="/api/v1")
