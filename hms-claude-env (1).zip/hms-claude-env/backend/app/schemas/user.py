"""User / auth schemas."""
import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import Gender, Role

PHONE = r"^\+?[0-9\- ]{7,15}$"


class RegisterIn(BaseModel):
    """Patient self-registration."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = Field(None, pattern=PHONE)
    gender: Gender | None = None
    dob: date | None = None


class LoginIn(BaseModel):
    """Login body."""

    email: EmailStr
    password: str = Field(min_length=1, max_length=72)


class TokenOut(BaseModel):
    """Login response."""

    access_token: str
    token_type: str = "bearer"
    role: Role
    user_id: uuid.UUID
    name: str


class UserCreate(BaseModel):
    """Admin creates a user."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: Role
    contact_number: str | None = Field(None, pattern=PHONE)


class UserUpdate(BaseModel):
    """Admin updates a user."""

    name: str | None = Field(None, min_length=2, max_length=120)
    password: str | None = Field(None, min_length=8, max_length=72)
    role: Role | None = None
    status: bool | None = None
    contact_number: str | None = Field(None, pattern=PHONE)


class UserOut(BaseModel):
    """User response."""

    model_config = ConfigDict(from_attributes=True)
    user_id: uuid.UUID
    name: str
    email: str
    role: Role
    contact_number: str | None
    status: bool
    created_at: datetime
