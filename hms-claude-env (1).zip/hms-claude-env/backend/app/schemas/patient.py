"""Patient schemas."""
import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import Gender
from app.schemas.user import PHONE


class PatientBase(BaseModel):
    """Shared patient fields."""

    gender: Gender | None = None
    dob: date | None = None
    blood_group: str | None = Field(None, max_length=5)
    address: str | None = None
    emergency_contact: str | None = Field(None, pattern=PHONE)
    allergies: str | None = None


class PatientCreate(PatientBase):
    """Receptionist/admin registers a patient."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = Field(None, pattern=PHONE)


class PatientUpdate(PatientBase):
    """Partial patient update."""

    name: str | None = Field(None, min_length=2, max_length=120)
    contact_number: str | None = Field(None, pattern=PHONE)


class PatientOut(PatientBase):
    """Patient response."""

    model_config = ConfigDict(from_attributes=True)
    patient_id: uuid.UUID
    user_id: uuid.UUID
    name: str
    email: str
    contact_number: str | None
