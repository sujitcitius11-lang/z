"""Pharmacy schemas."""
import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


class MedicineIn(BaseModel):
    """Create/update stock item."""

    name: str = Field(min_length=1, max_length=120)
    quantity_available: int = Field(ge=0)
    expiry_date: date
    unit_price: float = Field(ge=0)


class MedicineOut(MedicineIn):
    """Stock item response."""

    model_config = ConfigDict(from_attributes=True)
    medicine_id: uuid.UUID


class DispenseIn(BaseModel):
    """Dispense against a prescription."""

    prescription_id: uuid.UUID


class DispensedItem(BaseModel):
    """One dispensed line."""

    name: str
    quantity: int
    line_total: float


class DispenseOut(BaseModel):
    """Dispense result."""

    prescription_id: uuid.UUID
    items: list[DispensedItem]
    total: float
