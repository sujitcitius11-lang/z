"""Lab report schema (create uses multipart Form fields)."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class LabReportOut(BaseModel):
    """Lab report response."""

    model_config = ConfigDict(from_attributes=True)
    report_id: uuid.UUID
    patient_id: uuid.UUID
    patient_name: str
    test_name: str
    result_summary: str | None
    has_file: bool
    created_by: uuid.UUID
    created_at: datetime
