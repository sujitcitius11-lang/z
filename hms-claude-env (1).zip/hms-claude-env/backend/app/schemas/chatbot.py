"""Chatbot schemas."""
from typing import Literal

from pydantic import BaseModel, Field


class ChatTurn(BaseModel):
    """One prior message."""

    role: Literal["user", "assistant"]
    content: str = Field(max_length=2000)


class ChatIn(BaseModel):
    """Chat request."""

    message: str = Field(min_length=1, max_length=1000)
    history: list[ChatTurn] = Field(default_factory=list, max_length=20)


class ChatOut(BaseModel):
    """Chat response."""

    reply: str
