"""Billing schemas."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models import PaymentMode, PaymentStatus


class ServiceItem(BaseModel):
    """One billed line."""

    name: str = Field(min_length=1, max_length=120)
    amount: float = Field(ge=0)


class BillCreate(BaseModel):
    """Create a bill; total is computed server-side."""

    patient_id: uuid.UUID
    services: list[ServiceItem] = Field(min_length=1)


class PaymentUpdate(BaseModel):
    """Mark payment."""

    payment_status: PaymentStatus
    payment_mode: PaymentMode | None = None


class BillOut(BaseModel):
    """Bill response."""

    model_config = ConfigDict(from_attributes=True)
    bill_id: uuid.UUID
    patient_id: uuid.UUID
    patient_name: str
    services: list[ServiceItem]
    total_amount: float
    payment_status: PaymentStatus
    payment_mode: PaymentMode | None
    created_at: datetime
