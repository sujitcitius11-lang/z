"""Department and doctor schemas."""
import uuid

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from app.schemas.user import PHONE
from app.utils.slots import DAYS, parse_range


def _check_availability(v: dict | None) -> dict | None:
    if v is None:
        return v
    for day, rng in v.items():
        if day not in DAYS or parse_range(str(rng)) is None:
            raise ValueError(f"Invalid availability '{day}': '{rng}' (use Mon..Sun and e.g. '10-2')")
    return v


class DepartmentIn(BaseModel):
    """Create/update department."""

    name: str = Field(min_length=2, max_length=120)
    description: str | None = None


class DepartmentOut(DepartmentIn):
    """Department response."""

    model_config = ConfigDict(from_attributes=True)
    department_id: uuid.UUID


class DoctorCreate(BaseModel):
    """Admin adds a doctor (creates user + profile)."""

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    contact_number: str | None = Field(None, pattern=PHONE)
    department_id: uuid.UUID
    qualification: str | None = None
    availability: dict[str, str] = Field(default_factory=dict)

    @field_validator("availability")
    @classmethod
    def validate_availability(cls, v):
        """Check day keys and hour ranges."""
        return _check_availability(v)


class DoctorUpdate(BaseModel):
    """Partial doctor update."""

    department_id: uuid.UUID | None = None
    qualification: str | None = None
    availability: dict[str, str] | None = None

    @field_validator("availability")
    @classmethod
    def validate_availability(cls, v):
        """Check day keys and hour ranges."""
        return _check_availability(v)


class DoctorOut(BaseModel):
    """Doctor response."""

    model_config = ConfigDict(from_attributes=True)
    doctor_id: uuid.UUID
    user_id: uuid.UUID
    name: str
    email: str
    department_id: uuid.UUID
    department_name: str
    qualification: str | None
    availability: dict
