"""Appointment and prescription schemas."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models import AppointmentStatus


def _naive(v: datetime | None) -> datetime | None:
    return v.replace(tzinfo=None) if v else v


class AppointmentCreate(BaseModel):
    """Book an appointment (patient_id required unless caller is a patient)."""

    patient_id: uuid.UUID | None = None
    doctor_id: uuid.UUID
    appointment_date: datetime
    notes: str | None = None

    @field_validator("appointment_date")
    @classmethod
    def strip_tz(cls, v):
        """Store naive datetimes."""
        return _naive(v)


class AppointmentUpdate(BaseModel):
    """Reschedule / complete / annotate."""

    appointment_date: datetime | None = None
    status: AppointmentStatus | None = None
    notes: str | None = None

    @field_validator("appointment_date")
    @classmethod
    def strip_tz(cls, v):
        """Store naive datetimes."""
        return _naive(v)


class AppointmentOut(BaseModel):
    """Appointment response."""

    model_config = ConfigDict(from_attributes=True)
    appointment_id: uuid.UUID
    patient_id: uuid.UUID
    doctor_id: uuid.UUID
    patient_name: str
    doctor_name: str
    appointment_date: datetime
    status: AppointmentStatus
    notes: str | None


class MedicineItem(BaseModel):
    """One prescribed medicine."""

    name: str = Field(min_length=1, max_length=120)
    dosage: str = Field(min_length=1, max_length=60)
    quantity: int = Field(1, ge=1, le=1000)


class PrescriptionCreate(BaseModel):
    """Doctor issues a prescription."""

    appointment_id: uuid.UUID
    diagnosis: str = Field(min_length=2)
    medicines: list[MedicineItem] = Field(default_factory=list)


class PrescriptionOut(BaseModel):
    """Prescription response."""

    model_config = ConfigDict(from_attributes=True)
    prescription_id: uuid.UUID
    appointment_id: uuid.UUID
    patient_id: uuid.UUID
    patient_name: str
    diagnosis: str
    medicines: list[MedicineItem]
    created_by: uuid.UUID
    dispensed: bool
