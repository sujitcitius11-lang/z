"""users table."""
import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, enum_col, pk, utcnow


class Role(str, enum.Enum):
    """User roles."""

    admin = "admin"
    doctor = "doctor"
    receptionist = "receptionist"
    patient = "patient"
    lab_technician = "lab_technician"
    pharmacist = "pharmacist"
    super_admin = "super_admin"


class User(Base):
    """Login account."""

    __tablename__ = "users"
    user_id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(enum_col(Role))
    contact_number: Mapped[str | None] = mapped_column(String(30))
    status: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
