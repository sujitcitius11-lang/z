"""patients table."""
import enum
import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, enum_col, pk
from app.models.user import User


class Gender(str, enum.Enum):
    """Gender values."""

    Male = "Male"
    Female = "Female"
    Other = "Other"


class Patient(Base):
    """Patient profile linked to a user."""

    __tablename__ = "patients"
    patient_id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.user_id"), unique=True)
    gender: Mapped[Gender | None] = mapped_column(enum_col(Gender))
    dob: Mapped[date | None] = mapped_column(Date)
    blood_group: Mapped[str | None] = mapped_column(String(5))
    address: Mapped[str | None] = mapped_column(Text)
    emergency_contact: Mapped[str | None] = mapped_column(String(30))
    allergies: Mapped[str | None] = mapped_column(Text)
    user: Mapped[User] = relationship(lazy="joined")

    @property
    def name(self) -> str:
        """Patient name."""
        return self.user.name

    @property
    def email(self) -> str:
        """Patient email."""
        return self.user.email

    @property
    def contact_number(self) -> str | None:
        """Patient phone."""
        return self.user.contact_number
