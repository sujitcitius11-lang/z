"""billing table."""
import enum
import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import JSON, DateTime, ForeignKey, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, enum_col, pk, utcnow
from app.models.patient import Patient


class PaymentStatus(str, enum.Enum):
    """Payment states."""

    Paid = "Paid"
    Unpaid = "Unpaid"
    Partially_Paid = "Partially Paid"


class PaymentMode(str, enum.Enum):
    """Payment modes."""

    Cash = "Cash"
    Card = "Card"
    Online = "Online"


class Billing(Base):
    """Invoice for services."""

    __tablename__ = "billing"
    bill_id: Mapped[uuid.UUID] = pk()
    patient_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("patients.patient_id"), index=True)
    services: Mapped[list] = mapped_column(JSON, default=list)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    payment_status: Mapped[PaymentStatus] = mapped_column(enum_col(PaymentStatus), default=PaymentStatus.Unpaid)
    payment_mode: Mapped[PaymentMode | None] = mapped_column(enum_col(PaymentMode))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    patient: Mapped[Patient] = relationship(lazy="joined")

    @property
    def patient_name(self) -> str:
        """Patient name."""
        return self.patient.name
