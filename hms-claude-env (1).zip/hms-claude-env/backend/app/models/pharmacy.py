"""medicines table."""
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import Date, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, pk


class Medicine(Base):
    """Pharmacy stock item."""

    __tablename__ = "medicines"
    medicine_id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), index=True)
    quantity_available: Mapped[int] = mapped_column(Integer, default=0)
    expiry_date: Mapped[date] = mapped_column(Date)
    unit_price: Mapped[Decimal] = mapped_column(Numeric(10, 2))
