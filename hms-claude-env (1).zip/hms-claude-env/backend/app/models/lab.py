"""lab_reports table."""
import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, pk, utcnow
from app.models.patient import Patient


class LabReport(Base):
    """Lab test result with optional uploaded file."""

    __tablename__ = "lab_reports"
    report_id: Mapped[uuid.UUID] = pk()
    patient_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("patients.patient_id"), index=True)
    test_name: Mapped[str] = mapped_column(String(120))
    result_summary: Mapped[str | None] = mapped_column(Text)
    report_file: Mapped[str | None] = mapped_column(String(255))
    created_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.user_id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    patient: Mapped[Patient] = relationship(lazy="joined")

    @property
    def patient_name(self) -> str:
        """Patient name."""
        return self.patient.name

    @property
    def has_file(self) -> bool:
        """True when a file was uploaded."""
        return bool(self.report_file)
