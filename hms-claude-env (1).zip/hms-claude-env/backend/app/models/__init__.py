"""Import all models so metadata is complete."""
from app.models.appointment import Appointment, AppointmentStatus, Prescription
from app.models.audit import AuditLog
from app.models.billing import Billing, PaymentMode, PaymentStatus
from app.models.doctor import Department, Doctor
from app.models.lab import LabReport
from app.models.patient import Gender, Patient
from app.models.pharmacy import Medicine
from app.models.user import Role, User

__all__ = [
    "Appointment", "AppointmentStatus", "Prescription", "AuditLog", "Billing",
    "PaymentMode", "PaymentStatus", "Department", "Doctor", "LabReport",
    "Gender", "Patient", "Medicine", "Role", "User",
]
