"""departments and doctors tables."""
import uuid

from sqlalchemy import JSON, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, pk
from app.models.user import User


class Department(Base):
    """Hospital department."""

    __tablename__ = "departments"
    department_id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), unique=True)
    description: Mapped[str | None] = mapped_column(Text)


class Doctor(Base):
    """Doctor profile linked to a user and department."""

    __tablename__ = "doctors"
    doctor_id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.user_id"), unique=True)
    department_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("departments.department_id"))
    qualification: Mapped[str | None] = mapped_column(String(120))
    availability: Mapped[dict] = mapped_column(JSON, default=dict)
    user: Mapped[User] = relationship(lazy="joined")
    department: Mapped[Department] = relationship(lazy="joined")

    @property
    def name(self) -> str:
        """Doctor name."""
        return self.user.name

    @property
    def email(self) -> str:
        """Doctor email."""
        return self.user.email

    @property
    def department_name(self) -> str:
        """Department name."""
        return self.department.name
