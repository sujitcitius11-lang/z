"""appointments and prescriptions tables."""
import enum
import uuid
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, enum_col, pk
from app.models.doctor import Doctor
from app.models.patient import Patient


class AppointmentStatus(str, enum.Enum):
    """Appointment lifecycle."""

    Scheduled = "Scheduled"
    Completed = "Completed"
    Cancelled = "Cancelled"


class Appointment(Base):
    """Patient-doctor appointment."""

    __tablename__ = "appointments"
    appointment_id: Mapped[uuid.UUID] = pk()
    patient_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("patients.patient_id"), index=True)
    doctor_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("doctors.doctor_id"), index=True)
    appointment_date: Mapped[datetime] = mapped_column(DateTime, index=True)
    status: Mapped[AppointmentStatus] = mapped_column(enum_col(AppointmentStatus), default=AppointmentStatus.Scheduled)
    notes: Mapped[str | None] = mapped_column(Text)
    patient: Mapped[Patient] = relationship(lazy="joined")
    doctor: Mapped[Doctor] = relationship(lazy="joined")

    @property
    def patient_name(self) -> str:
        """Patient name."""
        return self.patient.name

    @property
    def doctor_name(self) -> str:
        """Doctor name."""
        return self.doctor.name


class Prescription(Base):
    """Diagnosis and medicines issued for an appointment."""

    __tablename__ = "prescriptions"
    prescription_id: Mapped[uuid.UUID] = pk()
    appointment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("appointments.appointment_id"), index=True)
    diagnosis: Mapped[str] = mapped_column(Text)
    medicines: Mapped[list] = mapped_column(JSON, default=list)
    created_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("doctors.doctor_id"))
    dispensed: Mapped[bool] = mapped_column(Boolean, default=False)
    appointment: Mapped[Appointment] = relationship(lazy="joined")

    @property
    def patient_id(self) -> uuid.UUID:
        """Patient of the appointment."""
        return self.appointment.patient_id

    @property
    def patient_name(self) -> str:
        """Patient name."""
        return self.appointment.patient_name
