"""Application settings loaded from environment / .env."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed settings. Later env files override earlier ones."""

    model_config = SettingsConfigDict(env_file=(".env", "../.env"), extra="ignore")

    DATABASE_URL: str = "sqlite:///./hms.db"
    SECRET_KEY: str = "change-me-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    CORS_ORIGINS: str = "http://localhost:8501"
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_MB: int = 5
    LOGIN_RATE_LIMIT: int = 10
    AUTO_CREATE_TABLES: bool = True
    SEED_DEMO_DATA: bool = True

    # Chatbot: Azure AI Foundry / Azure OpenAI deployment
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_API_KEY: str = ""
    AZURE_OPENAI_DEPLOYMENT: str = ""
    AZURE_OPENAI_API_VERSION: str = "2024-10-21"
    CHATBOT_MAX_TOKENS: int = 1000
    CHATBOT_RATE_LIMIT: int = 20
    CHATBOT_SYSTEM_PROMPT: str = (
        "You are the assistant of a Hospital Management System. Help staff and "
        "patients use the app (appointments, billing, lab reports, pharmacy) and "
        "answer general hospital-admin questions briefly. Never diagnose, never "
        "prescribe, never invent patient data; for medical concerns tell the user "
        "to consult a doctor. Refuse unrelated requests politely."
    )

    @property
    def cors_list(self) -> list[str]:
        """CORS origins as a list."""
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
