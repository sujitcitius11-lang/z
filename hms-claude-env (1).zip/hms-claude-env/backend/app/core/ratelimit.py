"""Tiny in-memory sliding-window rate limiter (single process)."""
import time
from collections import defaultdict, deque

from fastapi import HTTPException

_hits: dict[str, deque] = defaultdict(deque)


def check(key: str, limit: int, window: int = 60) -> None:
    """Raise 429 when `key` exceeds `limit` calls per `window` seconds."""
    now = time.monotonic()
    q = _hits[key]
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Too many requests, try again later")
    q.append(now)


def reset() -> None:
    """Clear all counters (used by tests)."""
    _hits.clear()
