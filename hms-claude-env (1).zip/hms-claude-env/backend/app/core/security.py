"""Password hashing and JWT helpers."""
from datetime import datetime, timedelta, timezone

import jwt
from passlib.context import CryptContext

from app.core.config import settings

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Return bcrypt hash."""
    return _pwd.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """Check a password against its hash."""
    return _pwd.verify(password, hashed)


def create_access_token(user_id: str, role: str) -> str:
    """Create a signed JWT access token."""
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": user_id, "role": role, "exp": exp}, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> dict:
    """Decode and validate a JWT (raises jwt.PyJWTError)."""
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
