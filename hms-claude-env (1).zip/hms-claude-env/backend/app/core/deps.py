"""FastAPI dependencies: DB session, current user, RBAC."""
import uuid
from collections.abc import Iterator

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import decode_token
from app.db.session import SessionLocal
from app.models import Role, User

_bearer = HTTPBearer(auto_error=False)


def get_db() -> Iterator[Session]:
    """Yield a DB session."""
    with SessionLocal() as db:
        yield db


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User:
    """Resolve the authenticated, active user from the Bearer token."""
    if creds is None:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        user_id = uuid.UUID(decode_token(creds.credentials)["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.get(User, user_id)
    if user is None or not user.status:
        raise HTTPException(status_code=401, detail="User inactive or not found")
    return user


def require_roles(*roles: Role):
    """Dependency factory allowing only `roles` (super_admin passes admin checks)."""
    allowed = set(roles)
    if Role.admin in allowed:
        allowed.add(Role.super_admin)

    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user

    return checker
