"""Billing and payments."""
import uuid
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Billing, Patient, PaymentStatus, Role, User
from app.schemas.billing import BillCreate, PaymentUpdate
from app.services import audit_service
from app.services.common import get_or_404, patient_of


def _check_access(bill: Billing, user: User) -> None:
    if user.role == Role.patient and bill.patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")


def create(db: Session, data: BillCreate, user: User, ip: str) -> Billing:
    """Create a bill; total = sum of services."""
    get_or_404(db, Patient, data.patient_id, "Patient")
    total = sum((Decimal(str(s.amount)) for s in data.services), Decimal("0")).quantize(Decimal("0.01"))
    bill = Billing(patient_id=data.patient_id, services=[s.model_dump() for s in data.services],
                   total_amount=total, payment_status=PaymentStatus.Unpaid)
    db.add(bill)
    db.commit()
    db.refresh(bill)
    audit_service.log(db, user.user_id, "CREATE", "billing", bill.bill_id, ip)
    return bill


def get(db: Session, bill_id: uuid.UUID, user: User, ip: str) -> Billing:
    """Fetch a bill (patients: own only)."""
    bill = get_or_404(db, Billing, bill_id, "Bill")
    _check_access(bill, user)
    audit_service.log(db, user.user_id, "VIEW", "billing", bill.bill_id, ip)
    return bill


def list_bills(db: Session, user: User, skip: int, limit: int, patient_id: uuid.UUID | None) -> list[Billing]:
    """Role-scoped bills, newest first."""
    stmt = select(Billing).order_by(Billing.created_at.desc())
    if user.role == Role.patient:
        stmt = stmt.where(Billing.patient_id == patient_of(db, user).patient_id)
    elif patient_id:
        stmt = stmt.where(Billing.patient_id == patient_id)
    return list(db.scalars(stmt.offset(skip).limit(limit)).unique())


def set_payment(db: Session, bill_id: uuid.UUID, data: PaymentUpdate, user: User, ip: str) -> Billing:
    """Mark payment status/mode."""
    bill = get_or_404(db, Billing, bill_id, "Bill")
    if data.payment_status != PaymentStatus.Unpaid and data.payment_mode is None:
        raise HTTPException(status_code=422, detail="payment_mode is required for paid/partial payments")
    bill.payment_status = data.payment_status
    bill.payment_mode = data.payment_mode if data.payment_status != PaymentStatus.Unpaid else None
    db.commit()
    audit_service.log(db, user.user_id, "UPDATE", "billing", bill.bill_id, ip)
    return bill

