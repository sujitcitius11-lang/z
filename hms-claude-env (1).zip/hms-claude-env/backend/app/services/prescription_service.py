"""Prescriptions."""
import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Appointment, AppointmentStatus, Patient, Prescription, Role, User
from app.schemas.appointment import PrescriptionCreate
from app.services import audit_service
from app.services.common import doctor_of, get_or_404
from app.utils.notifications import notify


def _check_read(rx: Prescription, user: User) -> None:
    if user.role == Role.patient and rx.appointment.patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")


def create(db: Session, data: PrescriptionCreate, user: User, ip: str) -> Prescription:
    """Doctor issues a prescription for their own appointment; marks it Completed."""
    doctor = doctor_of(db, user)
    appt = get_or_404(db, Appointment, data.appointment_id, "Appointment")
    if appt.doctor_id != doctor.doctor_id:
        raise HTTPException(status_code=403, detail="Not your appointment")
    if appt.status == AppointmentStatus.Cancelled:
        raise HTTPException(status_code=409, detail="Appointment is cancelled")
    rx = Prescription(appointment_id=appt.appointment_id, diagnosis=data.diagnosis,
                      medicines=[m.model_dump() for m in data.medicines], created_by=doctor.doctor_id)
    appt.status = AppointmentStatus.Completed
    db.add(rx)
    db.commit()
    db.refresh(rx)
    notify(appt.patient.user_id, "A new prescription is available")
    audit_service.log(db, user.user_id, "CREATE", "prescriptions", rx.prescription_id, ip)
    return rx


def get(db: Session, rx_id: uuid.UUID, user: User, ip: str) -> Prescription:
    """Read one prescription (patients: own only)."""
    rx = get_or_404(db, Prescription, rx_id, "Prescription")
    _check_read(rx, user)
    audit_service.log(db, user.user_id, "VIEW", "prescriptions", rx.prescription_id, ip)
    return rx


def list_for_patient(db: Session, patient_id: uuid.UUID, user: User, skip: int, limit: int) -> list[Prescription]:
    """Prescriptions of a patient (patients: own only)."""
    patient = get_or_404(db, Patient, patient_id, "Patient")
    if user.role == Role.patient and patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    stmt = (select(Prescription).join(Appointment, Prescription.appointment_id == Appointment.appointment_id)
            .where(Appointment.patient_id == patient_id).order_by(Appointment.appointment_date.desc())
            .offset(skip).limit(limit))
    return list(db.scalars(stmt).unique())
