"""Registration and login."""
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password, verify_password
from app.models import Patient, Role, User
from app.schemas.user import LoginIn, RegisterIn, TokenOut
from app.services import audit_service


def register(db: Session, data: RegisterIn, ip: str) -> User:
    """Self-register a patient (user + empty patient profile)."""
    email = data.email.lower()
    if db.scalar(select(User.user_id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=data.name, email=email, password_hash=hash_password(data.password),
                role=Role.patient, contact_number=data.contact_number, status=True)
    db.add(user)
    db.flush()
    db.add(Patient(user_id=user.user_id, gender=data.gender, dob=data.dob))
    db.commit()
    audit_service.log(db, user.user_id, "CREATE", "users", user.user_id, ip)
    return user


def login(db: Session, data: LoginIn, ip: str) -> TokenOut:
    """Validate credentials and issue a JWT."""
    user = db.scalar(select(User).where(User.email == data.email.lower()))
    if user is None or not user.status or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    audit_service.log(db, user.user_id, "LOGIN", "users", user.user_id, ip)
    token = create_access_token(str(user.user_id), user.role.value)
    return TokenOut(access_token=token, role=user.role, user_id=user.user_id, name=user.name)
