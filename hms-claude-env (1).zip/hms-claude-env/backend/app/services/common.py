"""Shared service helpers."""
import uuid

from fastapi import HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Doctor, Patient, User


def get_or_404(db: Session, model, id_: uuid.UUID, label: str):
    """Fetch by primary key or raise 404."""
    obj = db.get(model, id_)
    if obj is None:
        raise HTTPException(status_code=404, detail=f"{label} not found")
    return obj


def apply_sort(stmt, sort: str, cols: dict, default: str):
    """Order by `sort` ('-col' = desc) limited to whitelisted columns."""
    desc = sort.startswith("-")
    key = sort.lstrip("-")
    if key not in cols:
        key, desc = default, False
    col = cols[key]
    return stmt.order_by(col.desc() if desc else col.asc())


def client_ip(request: Request) -> str:
    """Caller IP."""
    return request.client.host if request.client else ""


def patient_of(db: Session, user: User) -> Patient:
    """Patient profile of a patient-role user."""
    p = db.scalar(select(Patient).where(Patient.user_id == user.user_id))
    if p is None:
        raise HTTPException(status_code=404, detail="Patient profile not found")
    return p


def doctor_of(db: Session, user: User) -> Doctor:
    """Doctor profile of a doctor-role user."""
    d = db.scalar(select(Doctor).where(Doctor.user_id == user.user_id))
    if d is None:
        raise HTTPException(status_code=404, detail="Doctor profile not found")
    return d
