"""Patient management."""
import uuid

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import Gender, Patient, Role, User
from app.schemas.patient import PatientCreate, PatientUpdate
from app.services import audit_service
from app.services.common import apply_sort, get_or_404

SORT = {"name": User.name, "dob": Patient.dob}


def _check_access(patient: Patient, user: User) -> None:
    if user.role == Role.patient and patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")


def list_patients(db: Session, user: User, skip: int, limit: int, q: str | None,
                  gender: Gender | None, sort: str) -> list[Patient]:
    """Staff see all; a patient sees only their own record."""
    stmt = select(Patient).join(User, Patient.user_id == User.user_id)
    if user.role == Role.patient:
        stmt = stmt.where(Patient.user_id == user.user_id)
    if q:
        stmt = stmt.where(or_(User.name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%")))
    if gender:
        stmt = stmt.where(Patient.gender == gender)
    return list(db.scalars(apply_sort(stmt, sort, SORT, "name").offset(skip).limit(limit)).unique())


def get(db: Session, patient_id: uuid.UUID, user: User, ip: str) -> Patient:
    """Fetch one patient (patients: own only)."""
    p = get_or_404(db, Patient, patient_id, "Patient")
    _check_access(p, user)
    audit_service.log(db, user.user_id, "VIEW", "patients", p.patient_id, ip)
    return p


def create(db: Session, data: PatientCreate, actor: User, ip: str) -> Patient:
    """Create user (role patient) + profile."""
    email = data.email.lower()
    if db.scalar(select(User.user_id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=data.name, email=email, password_hash=hash_password(data.password),
                role=Role.patient, contact_number=data.contact_number, status=True)
    db.add(user)
    db.flush()
    p = Patient(user_id=user.user_id, **data.model_dump(include={
        "gender", "dob", "blood_group", "address", "emergency_contact", "allergies"}))
    db.add(p)
    db.commit()
    audit_service.log(db, actor.user_id, "CREATE", "patients", p.patient_id, ip)
    return p


def update(db: Session, patient_id: uuid.UUID, data: PatientUpdate, user: User, ip: str) -> Patient:
    """Partial update (patients: own only)."""
    p = get_or_404(db, Patient, patient_id, "Patient")
    _check_access(p, user)
    d = data.model_dump(exclude_unset=True)
    for k in ("name", "contact_number"):
        if k in d:
            setattr(p.user, k, d.pop(k))
    for k, v in d.items():
        setattr(p, k, v)
    db.commit()
    audit_service.log(db, user.user_id, "UPDATE", "patients", p.patient_id, ip)
    return p
