"""Department CRUD."""
import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Department, Doctor, User
from app.schemas.doctor import DepartmentIn
from app.services import audit_service
from app.services.common import get_or_404


def list_departments(db: Session, skip: int, limit: int) -> list[Department]:
    """Paginated departments by name."""
    return list(db.scalars(select(Department).order_by(Department.name).offset(skip).limit(limit)))


def create(db: Session, data: DepartmentIn, actor: User, ip: str) -> Department:
    """Create a department."""
    if db.scalar(select(Department.department_id).where(Department.name == data.name)):
        raise HTTPException(status_code=409, detail="Department already exists")
    dept = Department(**data.model_dump())
    db.add(dept)
    db.commit()
    audit_service.log(db, actor.user_id, "CREATE", "departments", dept.department_id, ip)
    return dept


def update(db: Session, dept_id: uuid.UUID, data: DepartmentIn, actor: User, ip: str) -> Department:
    """Update a department."""
    dept = get_or_404(db, Department, dept_id, "Department")
    for k, v in data.model_dump().items():
        setattr(dept, k, v)
    db.commit()
    audit_service.log(db, actor.user_id, "UPDATE", "departments", dept.department_id, ip)
    return dept


def delete(db: Session, dept_id: uuid.UUID, actor: User, ip: str) -> None:
    """Delete a department that has no doctors."""
    dept = get_or_404(db, Department, dept_id, "Department")
    if db.scalar(select(Doctor.doctor_id).where(Doctor.department_id == dept_id)):
        raise HTTPException(status_code=409, detail="Department has doctors assigned")
    db.delete(dept)
    db.commit()
    audit_service.log(db, actor.user_id, "DELETE", "departments", dept_id, ip)
