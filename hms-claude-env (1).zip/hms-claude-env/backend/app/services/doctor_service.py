"""Doctor management and availability."""
import uuid
from datetime import date, datetime, time, timedelta

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import Appointment, AppointmentStatus, Department, Doctor, Role, User
from app.schemas.doctor import DoctorCreate, DoctorUpdate
from app.services import audit_service
from app.services.common import apply_sort, get_or_404
from app.utils.slots import slots_for

SORT = {"name": User.name, "qualification": Doctor.qualification}


def list_doctors(db: Session, skip: int, limit: int, department_id: uuid.UUID | None,
                 q: str | None, sort: str) -> list[Doctor]:
    """Filtered doctors."""
    stmt = select(Doctor).join(User, Doctor.user_id == User.user_id).where(User.status.is_(True))
    if department_id:
        stmt = stmt.where(Doctor.department_id == department_id)
    if q:
        stmt = stmt.where(or_(User.name.ilike(f"%{q}%"), Doctor.qualification.ilike(f"%{q}%")))
    return list(db.scalars(apply_sort(stmt, sort, SORT, "name").offset(skip).limit(limit)).unique())


def create(db: Session, data: DoctorCreate, actor: User, ip: str) -> Doctor:
    """Create user (role doctor) + doctor profile."""
    get_or_404(db, Department, data.department_id, "Department")
    email = data.email.lower()
    if db.scalar(select(User.user_id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=data.name, email=email, password_hash=hash_password(data.password),
                role=Role.doctor, contact_number=data.contact_number, status=True)
    db.add(user)
    db.flush()
    doc = Doctor(user_id=user.user_id, department_id=data.department_id,
                 qualification=data.qualification, availability=data.availability)
    db.add(doc)
    db.commit()
    audit_service.log(db, actor.user_id, "CREATE", "doctors", doc.doctor_id, ip)
    return doc


def update(db: Session, doctor_id: uuid.UUID, data: DoctorUpdate, actor: User, ip: str) -> Doctor:
    """Partial doctor update."""
    doc = get_or_404(db, Doctor, doctor_id, "Doctor")
    d = data.model_dump(exclude_unset=True)
    if "department_id" in d:
        get_or_404(db, Department, d["department_id"], "Department")
    for k, v in d.items():
        setattr(doc, k, v)
    db.commit()
    db.refresh(doc)
    audit_service.log(db, actor.user_id, "UPDATE", "doctors", doc.doctor_id, ip)
    return doc


def booked_slots(db: Session, doctor_id: uuid.UUID, day: date, exclude_id: uuid.UUID | None = None) -> set[str]:
    """HH:MM slots already taken by Scheduled appointments."""
    start = datetime.combine(day, time.min)
    stmt = select(Appointment.appointment_date).where(
        Appointment.doctor_id == doctor_id,
        Appointment.status == AppointmentStatus.Scheduled,
        Appointment.appointment_date >= start,
        Appointment.appointment_date < start + timedelta(days=1),
    )
    if exclude_id:
        stmt = stmt.where(Appointment.appointment_id != exclude_id)
    return {d.strftime("%H:%M") for d in db.scalars(stmt)}


def availability(db: Session, doctor_id: uuid.UUID, day: date | None) -> dict:
    """Weekly availability, plus free slots when `day` is given."""
    doc = get_or_404(db, Doctor, doctor_id, "Doctor")
    out = {"doctor_id": doc.doctor_id, "availability": doc.availability, "date": day, "slots": []}
    if day:
        taken = booked_slots(db, doctor_id, day)
        out["slots"] = [s for s in slots_for(doc.availability, day) if s not in taken]
    return out
