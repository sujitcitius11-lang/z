"""Analytics reports and exports."""
import io
from datetime import date, datetime, time, timedelta

import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Appointment, AppointmentStatus, Billing, Department, Doctor, PaymentStatus
from app.utils.pdf import table_pdf


def _range(col, d_from: date | None, d_to: date | None) -> list:
    conds = []
    if d_from:
        conds.append(col >= datetime.combine(d_from, time.min))
    if d_to:
        conds.append(col < datetime.combine(d_to + timedelta(days=1), time.min))
    return conds


def revenue(db: Session, d_from: date | None, d_to: date | None) -> list[dict]:
    """Daily revenue from Paid bills."""
    day = func.date(Billing.created_at)
    stmt = (select(day.label("date"), func.sum(Billing.total_amount).label("revenue"), func.count().label("bills"))
            .where(Billing.payment_status == PaymentStatus.Paid, *_range(Billing.created_at, d_from, d_to))
            .group_by(day).order_by(day))
    return [{"date": str(r.date), "revenue": float(r.revenue or 0), "bills": r.bills} for r in db.execute(stmt)]


def patients_seen(db: Session, d_from: date | None, d_to: date | None) -> list[dict]:
    """Distinct patients with Completed appointments per day."""
    day = func.date(Appointment.appointment_date)
    stmt = (select(day.label("date"), func.count(func.distinct(Appointment.patient_id)).label("patients"))
            .where(Appointment.status == AppointmentStatus.Completed,
                   *_range(Appointment.appointment_date, d_from, d_to))
            .group_by(day).order_by(day))
    return [{"date": str(r.date), "patients": r.patients} for r in db.execute(stmt)]


def top_departments(db: Session, d_from: date | None, d_to: date | None) -> list[dict]:
    """Departments ranked by non-cancelled appointments."""
    cnt = func.count(Appointment.appointment_id)
    stmt = (select(Department.name.label("department"), cnt.label("appointments"))
            .select_from(Department)
            .join(Doctor, Doctor.department_id == Department.department_id)
            .join(Appointment, Appointment.doctor_id == Doctor.doctor_id)
            .where(Appointment.status != AppointmentStatus.Cancelled,
                   *_range(Appointment.appointment_date, d_from, d_to))
            .group_by(Department.name).order_by(cnt.desc()).limit(10))
    return [{"department": r.department, "appointments": r.appointments} for r in db.execute(stmt)]


REPORTS = {"revenue": revenue, "patients-seen": patients_seen, "top-departments": top_departments}


def export(db: Session, report: str, fmt: str, d_from: date | None, d_to: date | None) -> tuple[bytes, str, str]:
    """Return (content, media_type, filename) for CSV or PDF."""
    rows = REPORTS[report](db, d_from, d_to)
    if fmt == "csv":
        buf = io.StringIO()
        pd.DataFrame(rows).to_csv(buf, index=False)
        return buf.getvalue().encode(), "text/csv", f"{report}.csv"
    return table_pdf(f"HMS report: {report}", rows), "application/pdf", f"{report}.pdf"
