"""Pharmacy stock and dispensing."""
import uuid
from datetime import date, timedelta
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Medicine, Prescription, User
from app.schemas.pharmacy import DispensedItem, DispenseOut, MedicineIn
from app.services import audit_service
from app.services.common import get_or_404

LOW_STOCK = 10
NEAR_EXPIRY_DAYS = 30


def list_medicines(db: Session, skip: int, limit: int, q: str | None,
                   low_stock: bool, near_expiry: bool) -> list[Medicine]:
    """Stock list with optional low-stock / near-expiry alert filters."""
    stmt = select(Medicine).order_by(Medicine.name)
    if q:
        stmt = stmt.where(Medicine.name.ilike(f"%{q}%"))
    if low_stock:
        stmt = stmt.where(Medicine.quantity_available <= LOW_STOCK)
    if near_expiry:
        stmt = stmt.where(Medicine.expiry_date <= date.today() + timedelta(days=NEAR_EXPIRY_DAYS))
    return list(db.scalars(stmt.offset(skip).limit(limit)))


def _dec(v: float) -> Decimal:
    return Decimal(str(v)).quantize(Decimal("0.01"))


def create(db: Session, data: MedicineIn, user: User, ip: str) -> Medicine:
    """Add a stock item."""
    med = Medicine(name=data.name, quantity_available=data.quantity_available,
                   expiry_date=data.expiry_date, unit_price=_dec(data.unit_price))
    db.add(med)
    db.commit()
    audit_service.log(db, user.user_id, "CREATE", "medicines", med.medicine_id, ip)
    return med


def update(db: Session, med_id: uuid.UUID, data: MedicineIn, user: User, ip: str) -> Medicine:
    """Replace a stock item's fields."""
    med = get_or_404(db, Medicine, med_id, "Medicine")
    med.name, med.quantity_available, med.expiry_date = data.name, data.quantity_available, data.expiry_date
    med.unit_price = _dec(data.unit_price)
    db.commit()
    audit_service.log(db, user.user_id, "UPDATE", "medicines", med.medicine_id, ip)
    return med


def dispense(db: Session, prescription_id: uuid.UUID, user: User, ip: str) -> DispenseOut:
    """Dispense all medicines of a prescription atomically; 409 if stock is short."""
    rx = get_or_404(db, Prescription, prescription_id, "Prescription")
    if rx.dispensed:
        raise HTTPException(status_code=409, detail="Prescription already dispensed")
    plan, problems = [], []
    for item in rx.medicines:
        stock = db.scalar(select(Medicine).where(
            func.lower(Medicine.name) == item["name"].lower(), Medicine.expiry_date >= date.today(),
            Medicine.quantity_available >= item.get("quantity", 1)).order_by(Medicine.expiry_date))
        if stock is None:
            problems.append(item["name"])
        else:
            plan.append((stock, item.get("quantity", 1)))
    if problems:
        raise HTTPException(status_code=409, detail=f"Insufficient or expired stock: {', '.join(problems)}")
    lines = []
    for stock, qty in plan:
        stock.quantity_available -= qty
        lines.append(DispensedItem(name=stock.name, quantity=qty, line_total=float(stock.unit_price * qty)))
    rx.dispensed = True
    db.commit()
    audit_service.log(db, user.user_id, "UPDATE", "prescriptions", rx.prescription_id, ip)
    return DispenseOut(prescription_id=rx.prescription_id, items=lines, total=sum(i.line_total for i in lines))
