"""Chatbot via Azure AI Foundry / Azure OpenAI chat-completions deployment."""
import logging

import httpx
from fastapi import HTTPException

from app.core.config import settings
from app.schemas.chatbot import ChatTurn

_log = logging.getLogger("hms.chatbot")


def configured() -> bool:
    """True when all Azure settings are present."""
    return all([settings.AZURE_OPENAI_ENDPOINT, settings.AZURE_OPENAI_API_KEY, settings.AZURE_OPENAI_DEPLOYMENT])


async def ask(message: str, history: list[ChatTurn], role: str) -> str:
    """Send the conversation (last 10 turns) to the model and return its reply."""
    if not configured():
        raise HTTPException(status_code=503, detail="Chatbot is not configured. Set AZURE_OPENAI_* in .env")
    url = (f"{settings.AZURE_OPENAI_ENDPOINT.rstrip('/')}/openai/deployments/"
           f"{settings.AZURE_OPENAI_DEPLOYMENT}/chat/completions")
    msgs = [{"role": "system", "content": f"{settings.CHATBOT_SYSTEM_PROMPT} The user's role is {role}."}]
    msgs += [t.model_dump() for t in history[-10:]]
    msgs.append({"role": "user", "content": message})
    body = {"messages": msgs, "max_completion_tokens": settings.CHATBOT_MAX_TOKENS}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(url, params={"api-version": settings.AZURE_OPENAI_API_VERSION},
                                  headers={"api-key": settings.AZURE_OPENAI_API_KEY}, json=body)
    except httpx.HTTPError as exc:
        _log.error("chatbot request failed: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="Chatbot provider unreachable")
    if r.status_code != 200:
        _log.error("chatbot provider status=%s", r.status_code)
        raise HTTPException(status_code=502, detail=f"Chatbot provider error ({r.status_code})")
    try:
        return r.json()["choices"][0]["message"]["content"] or "(empty reply)"
    except (KeyError, IndexError, ValueError):
        raise HTTPException(status_code=502, detail="Unexpected chatbot response")
