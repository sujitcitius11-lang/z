"""Appointment booking with slot validation."""
import uuid
from datetime import date, datetime, time, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Appointment, AppointmentStatus, Doctor, Patient, Role, User
from app.schemas.appointment import AppointmentCreate, AppointmentUpdate
from app.services import audit_service, doctor_service
from app.services.common import apply_sort, doctor_of, get_or_404, patient_of
from app.utils.notifications import notify
from app.utils.slots import slots_for

SORT = {"appointment_date": Appointment.appointment_date, "status": Appointment.status}


def _validate_slot(db: Session, doctor: Doctor, when: datetime, exclude_id: uuid.UUID | None = None) -> None:
    if when < datetime.now():
        raise HTTPException(status_code=422, detail="Appointment time is in the past")
    hhmm = when.strftime("%H:%M")
    if hhmm not in slots_for(doctor.availability, when.date()):
        raise HTTPException(status_code=422, detail="Time is outside the doctor's availability")
    if hhmm in doctor_service.booked_slots(db, doctor.doctor_id, when.date(), exclude_id):
        raise HTTPException(status_code=409, detail="Slot already booked")


def _check_access(db: Session, appt: Appointment, user: User) -> None:
    if user.role == Role.patient and appt.patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    if user.role == Role.doctor and appt.doctor.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")


def list_appointments(db: Session, user: User, skip: int, limit: int, status: AppointmentStatus | None,
                      doctor_id: uuid.UUID | None, patient_id: uuid.UUID | None,
                      date_from: date | None, date_to: date | None, sort: str) -> list[Appointment]:
    """Role-scoped, filtered appointments."""
    stmt = select(Appointment)
    if user.role == Role.patient:
        stmt = stmt.where(Appointment.patient_id == patient_of(db, user).patient_id)
    elif user.role == Role.doctor:
        stmt = stmt.where(Appointment.doctor_id == doctor_of(db, user).doctor_id)
    if status:
        stmt = stmt.where(Appointment.status == status)
    if doctor_id:
        stmt = stmt.where(Appointment.doctor_id == doctor_id)
    if patient_id:
        stmt = stmt.where(Appointment.patient_id == patient_id)
    if date_from:
        stmt = stmt.where(Appointment.appointment_date >= datetime.combine(date_from, time.min))
    if date_to:
        stmt = stmt.where(Appointment.appointment_date < datetime.combine(date_to + timedelta(days=1), time.min))
    return list(db.scalars(apply_sort(stmt, sort, SORT, "appointment_date").offset(skip).limit(limit)).unique())


def create(db: Session, data: AppointmentCreate, user: User, ip: str) -> Appointment:
    """Book an appointment (no double booking)."""
    if user.role == Role.patient:
        patient_id = patient_of(db, user).patient_id
    elif data.patient_id is None:
        raise HTTPException(status_code=422, detail="patient_id is required")
    else:
        patient_id = get_or_404(db, Patient, data.patient_id, "Patient").patient_id
    doctor = get_or_404(db, Doctor, data.doctor_id, "Doctor")
    _validate_slot(db, doctor, data.appointment_date)
    appt = Appointment(patient_id=patient_id, doctor_id=doctor.doctor_id,
                       appointment_date=data.appointment_date, notes=data.notes)
    db.add(appt)
    db.commit()
    db.refresh(appt)
    when = f"{appt.appointment_date:%Y-%m-%d %H:%M}"
    notify(doctor.user_id, f"New appointment at {when}")
    notify(appt.patient.user_id, f"Appointment booked for {when}")
    audit_service.log(db, user.user_id, "CREATE", "appointments", appt.appointment_id, ip)
    return appt


def update(db: Session, appt_id: uuid.UUID, data: AppointmentUpdate, user: User, ip: str) -> Appointment:
    """Reschedule (patient/receptionist), complete or annotate (doctor/receptionist)."""
    appt = get_or_404(db, Appointment, appt_id, "Appointment")
    _check_access(db, appt, user)
    d = data.model_dump(exclude_unset=True)
    if "appointment_date" in d and d["appointment_date"] is not None:
        if user.role == Role.doctor:
            raise HTTPException(status_code=403, detail="Doctors cannot reschedule")
        _validate_slot(db, appt.doctor, d["appointment_date"], appt.appointment_id)
        appt.appointment_date = d["appointment_date"]
    if d.get("status") is not None:
        if user.role == Role.patient and d["status"] != AppointmentStatus.Cancelled:
            raise HTTPException(status_code=403, detail="Patients can only cancel")
        appt.status = d["status"]
    if "notes" in d:
        if user.role == Role.patient:
            raise HTTPException(status_code=403, detail="Patients cannot edit notes")
        appt.notes = d["notes"]
    db.commit()
    audit_service.log(db, user.user_id, "UPDATE", "appointments", appt.appointment_id, ip)
    return appt


def cancel(db: Session, appt_id: uuid.UUID, user: User, ip: str) -> Appointment:
    """Cancel a scheduled appointment."""
    appt = get_or_404(db, Appointment, appt_id, "Appointment")
    _check_access(db, appt, user)
    if appt.status != AppointmentStatus.Scheduled:
        raise HTTPException(status_code=409, detail="Only scheduled appointments can be cancelled")
    appt.status = AppointmentStatus.Cancelled
    db.commit()
    notify(appt.doctor.user_id, "An appointment was cancelled")
    notify(appt.patient.user_id, "Your appointment was cancelled")
    audit_service.log(db, user.user_id, "UPDATE", "appointments", appt.appointment_id, ip)
    return appt
