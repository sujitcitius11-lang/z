"""Audit logging."""
import uuid

from sqlalchemy.orm import Session

from app.models import AuditLog


def log(db: Session, user_id: uuid.UUID | None, action: str, entity: str,
        entity_id: uuid.UUID | None = None, ip: str | None = None) -> None:
    """Persist an audit record (CREATE/UPDATE/DELETE/LOGIN/VIEW)."""
    db.add(AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id, ip_address=ip))
    db.commit()
