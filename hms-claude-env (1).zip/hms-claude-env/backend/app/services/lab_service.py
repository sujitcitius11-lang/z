"""Lab reports with validated file upload."""
import uuid
from pathlib import Path

from fastapi import HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import LabReport, Patient, Role, User
from app.services import audit_service
from app.services.common import get_or_404, patient_of

ALLOWED_EXT = {".pdf", ".png", ".jpg", ".jpeg"}
MAGIC = {b"%PDF": {".pdf"}, b"\x89PNG": {".png"}, b"\xff\xd8\xff": {".jpg", ".jpeg"}}


def _validate_file(filename: str, data: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(status_code=422, detail="Only PDF, PNG or JPG files are allowed")
    if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File larger than {settings.MAX_UPLOAD_MB} MB")
    if not any(data.startswith(sig) and ext in exts for sig, exts in MAGIC.items()):
        raise HTTPException(status_code=422, detail="File content does not match its extension")
    return ext


def create(db: Session, user: User, patient_id: uuid.UUID, test_name: str, summary: str | None,
           filename: str | None, data: bytes | None, ip: str) -> LabReport:
    """Store a lab result and optional file."""
    get_or_404(db, Patient, patient_id, "Patient")
    stored = None
    if filename and data:
        ext = _validate_file(filename, data)
        folder = Path(settings.UPLOAD_DIR)
        folder.mkdir(parents=True, exist_ok=True)
        stored = f"{uuid.uuid4().hex}{ext}"
        (folder / stored).write_bytes(data)
    rep = LabReport(patient_id=patient_id, test_name=test_name, result_summary=summary,
                    report_file=stored, created_by=user.user_id)
    db.add(rep)
    db.commit()
    audit_service.log(db, user.user_id, "CREATE", "lab_reports", rep.report_id, ip)
    return rep


def list_reports(db: Session, user: User, skip: int, limit: int, patient_id: uuid.UUID | None) -> list[LabReport]:
    """Role-scoped reports (patients: own only)."""
    stmt = select(LabReport).order_by(LabReport.created_at.desc())
    if user.role == Role.patient:
        stmt = stmt.where(LabReport.patient_id == patient_of(db, user).patient_id)
    elif patient_id:
        stmt = stmt.where(LabReport.patient_id == patient_id)
    return list(db.scalars(stmt.offset(skip).limit(limit)).unique())


def download(db: Session, report_id: uuid.UUID, user: User, ip: str) -> FileResponse:
    """Stream the stored file (patients: own only)."""
    rep = get_or_404(db, LabReport, report_id, "Report")
    if user.role == Role.patient and rep.patient.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    path = Path(settings.UPLOAD_DIR) / (rep.report_file or "")
    if not rep.report_file or not path.is_file():
        raise HTTPException(status_code=404, detail="No file for this report")
    audit_service.log(db, user.user_id, "VIEW", "lab_reports", rep.report_id, ip)
    return FileResponse(path, filename=f"{rep.test_name}{path.suffix}")
