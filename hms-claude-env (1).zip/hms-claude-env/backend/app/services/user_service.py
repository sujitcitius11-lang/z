"""User administration."""
import uuid

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import Role, User
from app.schemas.user import UserCreate, UserUpdate
from app.services import audit_service
from app.services.common import apply_sort, get_or_404

SORT = {"created_at": User.created_at, "name": User.name, "email": User.email, "role": User.role}


def list_users(db: Session, skip: int, limit: int, q: str | None, role: Role | None,
               status: bool | None, sort: str) -> list[User]:
    """Filtered, sorted, paginated users."""
    stmt = select(User)
    if q:
        stmt = stmt.where(or_(User.name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%")))
    if role:
        stmt = stmt.where(User.role == role)
    if status is not None:
        stmt = stmt.where(User.status == status)
    stmt = apply_sort(stmt, sort, SORT, "created_at").offset(skip).limit(limit)
    return list(db.scalars(stmt))


def create_user(db: Session, data: UserCreate, actor: User, ip: str) -> User:
    """Create a user."""
    email = data.email.lower()
    if db.scalar(select(User.user_id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=data.name, email=email, password_hash=hash_password(data.password),
                role=data.role, contact_number=data.contact_number, status=True)
    db.add(user)
    db.commit()
    audit_service.log(db, actor.user_id, "CREATE", "users", user.user_id, ip)
    return user


def update_user(db: Session, user_id: uuid.UUID, data: UserUpdate, actor: User, ip: str) -> User:
    """Update a user."""
    user = get_or_404(db, User, user_id, "User")
    d = data.model_dump(exclude_unset=True)
    if "password" in d:
        user.password_hash = hash_password(d.pop("password"))
    for k, v in d.items():
        setattr(user, k, v)
    db.commit()
    audit_service.log(db, actor.user_id, "UPDATE", "users", user.user_id, ip)
    return user


def deactivate_user(db: Session, user_id: uuid.UUID, actor: User, ip: str) -> None:
    """Soft-delete (status=False) so history stays intact."""
    user = get_or_404(db, User, user_id, "User")
    if user.user_id == actor.user_id:
        raise HTTPException(status_code=409, detail="You cannot deactivate yourself")
    user.status = False
    db.commit()
    audit_service.log(db, actor.user_id, "DELETE", "users", user.user_id, ip)
