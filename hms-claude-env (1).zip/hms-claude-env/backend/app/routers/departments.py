"""Department endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, get_db, require_roles
from app.models import Role, User
from app.schemas.doctor import DepartmentIn, DepartmentOut
from app.services import department_service
from app.services.common import client_ip

router = APIRouter(prefix="/departments", tags=["departments"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[DepartmentOut])
def list_departments(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
                     db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    """List departments (any authenticated user)."""
    return department_service.list_departments(db, skip, limit)


@router.post("", response_model=DepartmentOut, status_code=201)
def create(data: DepartmentIn, request: Request, db: Session = Depends(get_db), actor: User = Depends(admin)):
    """Create a department."""
    return department_service.create(db, data, actor, client_ip(request))


@router.put("/{dept_id}", response_model=DepartmentOut)
def update(dept_id: uuid.UUID, data: DepartmentIn, request: Request, db: Session = Depends(get_db),
           actor: User = Depends(admin)):
    """Update a department."""
    return department_service.update(db, dept_id, data, actor, client_ip(request))


@router.delete("/{dept_id}", status_code=204)
def delete(dept_id: uuid.UUID, request: Request, db: Session = Depends(get_db), actor: User = Depends(admin)):
    """Delete a department."""
    department_service.delete(db, dept_id, actor, client_ip(request))
