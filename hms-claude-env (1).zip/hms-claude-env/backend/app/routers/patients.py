"""Patient endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Gender, Role, User
from app.schemas.patient import PatientCreate, PatientOut, PatientUpdate
from app.services import patient_service
from app.services.common import client_ip

router = APIRouter(prefix="/patients", tags=["patients"])
staff_or_self = require_roles(Role.admin, Role.receptionist, Role.patient)
staff = require_roles(Role.admin, Role.receptionist)
lookup = require_roles(Role.admin, Role.receptionist, Role.patient, Role.lab_technician)


@router.get("", response_model=list[PatientOut])
def list_patients(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), q: str | None = None,
                  gender: Gender | None = None, sort: str = "name", db: Session = Depends(get_db),
                  user: User = Depends(lookup)):
    """List patients (patients see only themselves; lab technicians can look up)."""
    return patient_service.list_patients(db, user, skip, limit, q, gender, sort)


@router.post("", response_model=PatientOut, status_code=201)
def create(data: PatientCreate, request: Request, db: Session = Depends(get_db), actor: User = Depends(staff)):
    """Register a patient."""
    return patient_service.create(db, data, actor, client_ip(request))


@router.get("/{patient_id}", response_model=PatientOut)
def get(patient_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(staff_or_self)):
    """Get a patient."""
    return patient_service.get(db, patient_id, user, client_ip(request))


@router.put("/{patient_id}", response_model=PatientOut)
def update(patient_id: uuid.UUID, data: PatientUpdate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(staff_or_self)):
    """Update a patient."""
    return patient_service.update(db, patient_id, data, user, client_ip(request))
