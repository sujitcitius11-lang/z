"""Pharmacy endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.schemas.pharmacy import DispenseIn, DispenseOut, MedicineIn, MedicineOut
from app.services import pharmacy_service
from app.services.common import client_ip

router = APIRouter(tags=["pharmacy"])
staff = require_roles(Role.pharmacist, Role.admin)


@router.get("/medicines", response_model=list[MedicineOut])
def list_medicines(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), q: str | None = None,
                   low_stock: bool = False, near_expiry: bool = False, db: Session = Depends(get_db),
                   _: User = Depends(staff)):
    """Stock list; use low_stock / near_expiry for alerts."""
    return pharmacy_service.list_medicines(db, skip, limit, q, low_stock, near_expiry)


@router.post("/medicines", response_model=MedicineOut, status_code=201)
def create(data: MedicineIn, request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    """Add stock item."""
    return pharmacy_service.create(db, data, user, client_ip(request))


@router.put("/medicines/{medicine_id}", response_model=MedicineOut)
def update(medicine_id: uuid.UUID, data: MedicineIn, request: Request, db: Session = Depends(get_db),
           user: User = Depends(staff)):
    """Update stock item."""
    return pharmacy_service.update(db, medicine_id, data, user, client_ip(request))


@router.post("/pharmacy/dispense", response_model=DispenseOut)
def dispense(data: DispenseIn, request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    """Dispense a prescription."""
    return pharmacy_service.dispense(db, data.prescription_id, user, client_ip(request))
