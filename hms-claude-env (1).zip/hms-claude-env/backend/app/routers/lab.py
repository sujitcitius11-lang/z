"""Lab report endpoints."""
import uuid

from fastapi import APIRouter, Depends, File, Form, Query, Request, UploadFile
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.schemas.lab import LabReportOut
from app.services import lab_service
from app.services.common import client_ip

router = APIRouter(prefix="/lab-reports", tags=["lab"])
readers = require_roles(Role.lab_technician, Role.doctor, Role.patient)


@router.post("", response_model=LabReportOut, status_code=201)
async def create(request: Request, patient_id: uuid.UUID = Form(...), test_name: str = Form(..., max_length=120),
                 result_summary: str | None = Form(None), file: UploadFile | None = File(None),
                 db: Session = Depends(get_db), user: User = Depends(require_roles(Role.lab_technician))):
    """Upload a lab result (multipart); file optional (pdf/png/jpg)."""
    data = await file.read(settings.MAX_UPLOAD_MB * 1024 * 1024 + 1) if file else None
    return lab_service.create(db, user, patient_id, test_name, result_summary,
                              file.filename if file else None, data, client_ip(request))


@router.get("", response_model=list[LabReportOut])
def list_reports(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), patient_id: uuid.UUID | None = None,
                 db: Session = Depends(get_db), user: User = Depends(readers)):
    """List lab reports."""
    return lab_service.list_reports(db, user, skip, limit, patient_id)


@router.get("/{report_id}/download")
def download(report_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(readers)):
    """Download the report file."""
    return lab_service.download(db, report_id, user, client_ip(request))
