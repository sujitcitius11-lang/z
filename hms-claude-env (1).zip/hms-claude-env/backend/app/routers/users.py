"""User admin endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.schemas.user import UserCreate, UserOut, UserUpdate
from app.services import user_service
from app.services.common import client_ip

router = APIRouter(prefix="/users", tags=["users"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[UserOut])
def list_users(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), q: str | None = None,
               role: Role | None = None, status: bool | None = None, sort: str = "-created_at",
               db: Session = Depends(get_db), _: User = Depends(admin)):
    """List users."""
    return user_service.list_users(db, skip, limit, q, role, status, sort)


@router.post("", response_model=UserOut, status_code=201)
def create_user(data: UserCreate, request: Request, db: Session = Depends(get_db), actor: User = Depends(admin)):
    """Create a user."""
    return user_service.create_user(db, data, actor, client_ip(request))


@router.put("/{user_id}", response_model=UserOut)
def update_user(user_id: uuid.UUID, data: UserUpdate, request: Request, db: Session = Depends(get_db),
                actor: User = Depends(admin)):
    """Update a user."""
    return user_service.update_user(db, user_id, data, actor, client_ip(request))


@router.delete("/{user_id}", status_code=204)
def delete_user(user_id: uuid.UUID, request: Request, db: Session = Depends(get_db), actor: User = Depends(admin)):
    """Deactivate a user."""
    user_service.deactivate_user(db, user_id, actor, client_ip(request))
