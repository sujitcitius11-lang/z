"""Auth endpoints."""
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.core import ratelimit
from app.core.config import settings
from app.core.deps import get_current_user, get_db
from app.models import User
from app.schemas.user import LoginIn, RegisterIn, TokenOut, UserOut
from app.services import auth_service
from app.services.common import client_ip

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=UserOut, status_code=201)
def register(data: RegisterIn, request: Request, db: Session = Depends(get_db)):
    """Patient self-registration."""
    return auth_service.register(db, data, client_ip(request))


@router.post("/login", response_model=TokenOut)
def login(data: LoginIn, request: Request, db: Session = Depends(get_db)):
    """Login (rate limited per IP)."""
    ip = client_ip(request)
    ratelimit.check(f"login:{ip}", settings.LOGIN_RATE_LIMIT)
    return auth_service.login(db, data, ip)


@router.post("/logout", status_code=204)
def logout(user: User = Depends(get_current_user)):
    """Stateless logout; the client discards the token."""
    return None


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    """Current user."""
    return user
