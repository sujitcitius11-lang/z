"""Report endpoints."""
from datetime import date

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.services import report_service

router = APIRouter(prefix="/reports", tags=["reports"])
admin = require_roles(Role.admin)


@router.get("/revenue")
def revenue(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
            _: User = Depends(admin)):
    """Daily revenue."""
    return report_service.revenue(db, date_from, date_to)


@router.get("/patients-seen")
def patients_seen(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                  _: User = Depends(admin)):
    """Patients seen per day."""
    return report_service.patients_seen(db, date_from, date_to)


@router.get("/top-departments")
def top_departments(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                    _: User = Depends(admin)):
    """Busiest departments."""
    return report_service.top_departments(db, date_from, date_to)


@router.get("/export")
def export(fmt: str = Query("csv", alias="format", pattern="^(csv|pdf)$"),
           report: str = Query("revenue", pattern="^(revenue|patients-seen|top-departments)$"),
           date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
           _: User = Depends(admin)):
    """Export a report as CSV or PDF."""
    content, media, name = report_service.export(db, report, fmt, date_from, date_to)
    return Response(content, media_type=media, headers={"Content-Disposition": f'attachment; filename="{name}"'})
