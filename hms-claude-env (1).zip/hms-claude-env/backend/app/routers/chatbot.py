"""Chatbot endpoint (any authenticated user)."""
from fastapi import APIRouter, Depends

from app.core import ratelimit
from app.core.config import settings
from app.core.deps import get_current_user
from app.models import User
from app.schemas.chatbot import ChatIn, ChatOut
from app.services import chatbot_service

router = APIRouter(prefix="/chatbot", tags=["chatbot"])


@router.post("", response_model=ChatOut)
async def chat(data: ChatIn, user: User = Depends(get_current_user)):
    """Ask the HMS assistant (Azure AI Foundry / Azure OpenAI)."""
    ratelimit.check(f"chat:{user.user_id}", settings.CHATBOT_RATE_LIMIT)
    reply = await chatbot_service.ask(data.message, data.history, user.role.value)
    return ChatOut(reply=reply)
