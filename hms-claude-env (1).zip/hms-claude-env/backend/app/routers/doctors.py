"""Doctor endpoints."""
import uuid
from datetime import date

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, get_db, require_roles
from app.models import Role, User
from app.schemas.doctor import DoctorCreate, DoctorOut, DoctorUpdate
from app.services import doctor_service
from app.services.common import client_ip

router = APIRouter(prefix="/doctors", tags=["doctors"])
admin = require_roles(Role.admin)


@router.get("", response_model=list[DoctorOut])
def list_doctors(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), department_id: uuid.UUID | None = None,
                 q: str | None = None, sort: str = "name", db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    """List doctors (any authenticated user)."""
    return doctor_service.list_doctors(db, skip, limit, department_id, q, sort)


@router.post("", response_model=DoctorOut, status_code=201)
def create(data: DoctorCreate, request: Request, db: Session = Depends(get_db), actor: User = Depends(admin)):
    """Add a doctor."""
    return doctor_service.create(db, data, actor, client_ip(request))


@router.put("/{doctor_id}", response_model=DoctorOut)
def update(doctor_id: uuid.UUID, data: DoctorUpdate, request: Request, db: Session = Depends(get_db),
           actor: User = Depends(admin)):
    """Update a doctor."""
    return doctor_service.update(db, doctor_id, data, actor, client_ip(request))


@router.get("/{doctor_id}/availability")
def availability(doctor_id: uuid.UUID, date: date | None = None, db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    """Weekly availability and, when `date` is given, free HH:MM slots."""
    return doctor_service.availability(db, doctor_id, date)
