"""Prescription endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.schemas.appointment import PrescriptionCreate, PrescriptionOut
from app.services import prescription_service
from app.services.common import client_ip

router = APIRouter(tags=["prescriptions"])
readers = require_roles(Role.doctor, Role.patient, Role.pharmacist)


@router.post("/prescriptions", response_model=PrescriptionOut, status_code=201)
def create(data: PrescriptionCreate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(require_roles(Role.doctor))):
    """Doctor issues a prescription."""
    return prescription_service.create(db, data, user, client_ip(request))


@router.get("/prescriptions/{prescription_id}", response_model=PrescriptionOut)
def get(prescription_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(readers)):
    """Read a prescription."""
    return prescription_service.get(db, prescription_id, user, client_ip(request))


@router.get("/patients/{patient_id}/prescriptions", response_model=list[PrescriptionOut])
def for_patient(patient_id: uuid.UUID, skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
                db: Session = Depends(get_db), user: User = Depends(readers)):
    """Prescriptions of a patient."""
    return prescription_service.list_for_patient(db, patient_id, user, skip, limit)
