"""Appointment endpoints."""
import uuid
from datetime import date

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import AppointmentStatus, Role, User
from app.schemas.appointment import AppointmentCreate, AppointmentOut, AppointmentUpdate
from app.services import appointment_service
from app.services.common import client_ip

router = APIRouter(prefix="/appointments", tags=["appointments"])
allowed = require_roles(Role.patient, Role.receptionist, Role.doctor)


@router.get("", response_model=list[AppointmentOut])
def list_appointments(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
                      status: AppointmentStatus | None = None, doctor_id: uuid.UUID | None = None,
                      patient_id: uuid.UUID | None = None, date_from: date | None = None,
                      date_to: date | None = None, sort: str = "-appointment_date",
                      db: Session = Depends(get_db), user: User = Depends(allowed)):
    """List appointments scoped by role."""
    return appointment_service.list_appointments(db, user, skip, limit, status, doctor_id, patient_id,
                                                 date_from, date_to, sort)


@router.post("", response_model=AppointmentOut, status_code=201)
def create(data: AppointmentCreate, request: Request, db: Session = Depends(get_db), user: User = Depends(allowed)):
    """Book an appointment."""
    return appointment_service.create(db, data, user, client_ip(request))


@router.put("/{appointment_id}", response_model=AppointmentOut)
def update(appointment_id: uuid.UUID, data: AppointmentUpdate, request: Request, db: Session = Depends(get_db),
           user: User = Depends(allowed)):
    """Reschedule / complete / annotate."""
    return appointment_service.update(db, appointment_id, data, user, client_ip(request))


@router.patch("/{appointment_id}/cancel", response_model=AppointmentOut)
def cancel(appointment_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(allowed)):
    """Cancel an appointment."""
    return appointment_service.cancel(db, appointment_id, user, client_ip(request))
