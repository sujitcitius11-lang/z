"""Billing endpoints."""
import uuid

from fastapi import APIRouter, Depends, Query, Request, Response
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_roles
from app.models import Role, User
from app.schemas.billing import BillCreate, BillOut, PaymentUpdate
from app.services import billing_service
from app.services.common import client_ip
from app.utils.pdf import invoice_pdf

router = APIRouter(prefix="/billing", tags=["billing"])
staff = require_roles(Role.receptionist)
staff_or_patient = require_roles(Role.receptionist, Role.patient)


@router.post("", response_model=BillOut, status_code=201)
def create(data: BillCreate, request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    """Create a bill."""
    return billing_service.create(db, data, user, client_ip(request))


@router.get("", response_model=list[BillOut])
def list_bills(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), patient_id: uuid.UUID | None = None,
               db: Session = Depends(get_db), user: User = Depends(staff_or_patient)):
    """List bills (patients: own)."""
    return billing_service.list_bills(db, user, skip, limit, patient_id)


@router.get("/{bill_id}", response_model=BillOut)
def get(bill_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(staff_or_patient)):
    """Get a bill."""
    return billing_service.get(db, bill_id, user, client_ip(request))


@router.patch("/{bill_id}/payment", response_model=BillOut)
def payment(bill_id: uuid.UUID, data: PaymentUpdate, request: Request, db: Session = Depends(get_db),
            user: User = Depends(staff)):
    """Mark payment."""
    return billing_service.set_payment(db, bill_id, data, user, client_ip(request))


@router.get("/{bill_id}/invoice.pdf")
def invoice(bill_id: uuid.UUID, request: Request, db: Session = Depends(get_db), user: User = Depends(staff_or_patient)):
    """Invoice PDF."""
    bill = billing_service.get(db, bill_id, user, client_ip(request))
    return Response(invoice_pdf(bill), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="invoice-{bill.bill_id}.pdf"'})
