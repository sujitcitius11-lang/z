"""Declarative base and column helpers."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import Enum as SAEnum
from sqlalchemy import Uuid
from sqlalchemy.orm import DeclarativeBase, mapped_column


class Base(DeclarativeBase):
    """Base class for all models."""


def utcnow() -> datetime:
    """Naive UTC now (consistent across SQLite/PostgreSQL)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def pk():
    """UUID primary key column."""
    return mapped_column(Uuid, primary_key=True, default=uuid.uuid4)


def enum_col(e):
    """Portable enum column storing the enum values as strings."""
    return SAEnum(e, native_enum=False, length=30, values_callable=lambda x: [m.value for m in x])
