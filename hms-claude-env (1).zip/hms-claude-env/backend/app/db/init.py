"""Demo data for local development (SEED_DEMO_DATA=true)."""
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import Department, Doctor, Gender, Medicine, Patient, Role, User

DEMO_PASSWORD = "Hms@12345"


def seed_demo(db: Session) -> None:
    """Create demo users/department/doctor/patient/medicines once."""
    if db.scalar(select(User.user_id).limit(1)):
        return
    accounts = [
        ("Super Admin", "superadmin@hms.com", Role.super_admin),
        ("Admin", "admin@hms.com", Role.admin),
        ("Dr. Asha Rao", "doctor@hms.com", Role.doctor),
        ("Riya Reception", "reception@hms.com", Role.receptionist),
        ("Pooja Patil", "patient@hms.com", Role.patient),
        ("Lab Tech", "lab@hms.com", Role.lab_technician),
        ("Pharma Cist", "pharmacist@hms.com", Role.pharmacist),
    ]
    users = {}
    for name, email, role in accounts:
        users[role] = User(name=name, email=email, role=role, status=True,
                           password_hash=hash_password(DEMO_PASSWORD), contact_number="9999999999")
        db.add(users[role])
    dept = Department(name="General Medicine", description="Primary care")
    db.add(dept)
    db.add(Department(name="Cardiology", description="Heart care"))
    db.flush()
    avail = {d: "10-2" for d in ("Mon", "Tue", "Wed", "Thu", "Fri")}
    db.add(Doctor(user_id=users[Role.doctor].user_id, department_id=dept.department_id,
                  qualification="MBBS, MD", availability=avail))
    db.add(Patient(user_id=users[Role.patient].user_id, gender=Gender.Female, dob=date(1992, 5, 17),
                   blood_group="O+", address="Mumbai", emergency_contact="8888888888"))
    soon = date.today() + timedelta(days=365)
    for n, q, p in [("Paracetamol", 100, "2.50"), ("Amoxicillin", 50, "8.00"), ("Cetirizine", 5, "1.50")]:
        db.add(Medicine(name=n, quantity_available=q, expiry_date=soon, unit_price=p))
    db.commit()
