"""Auth and health tests."""
from tests.conftest import API


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_register_login_me(client):
    body = {"name": "Neha Shah", "email": "neha@t.com", "password": "Passw0rd!"}
    assert client.post(f"{API}/auth/register", json=body).status_code == 201
    r = client.post(f"{API}/auth/login", json={"email": "neha@t.com", "password": "Passw0rd!"})
    assert r.status_code == 200 and r.json()["role"] == "patient"
    me = client.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {r.json()['access_token']}"})
    assert me.json()["email"] == "neha@t.com"


def test_duplicate_email_conflict(client):
    body = {"name": "Neha Shah", "email": "neha@t.com", "password": "Passw0rd!"}
    client.post(f"{API}/auth/register", json=body)
    assert client.post(f"{API}/auth/register", json=body).status_code == 409


def test_bad_password_and_validation(client):
    client.post(f"{API}/auth/register", json={"name": "Neha", "email": "n@t.com", "password": "Passw0rd!"})
    assert client.post(f"{API}/auth/login", json={"email": "n@t.com", "password": "wrong"}).status_code == 401
    assert client.post(f"{API}/auth/register", json={"name": "N", "email": "bad", "password": "x"}).status_code == 422


def test_no_token_is_401(client):
    assert client.get(f"{API}/auth/me").status_code == 401
    assert client.get(f"{API}/patients").status_code == 401


def test_login_rate_limit(client):
    for _ in range(10):
        client.post(f"{API}/auth/login", json={"email": "x@t.com", "password": "bad"})
    assert client.post(f"{API}/auth/login", json={"email": "x@t.com", "password": "bad"}).status_code == 429
