"""Patients, doctors, departments, lab uploads, users."""
from app.models import Role
from tests.conftest import API

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 32


def test_patient_sees_only_self(client, make_user, patient):
    p, ph = patient
    make_user(Role.admin)
    other = client.post(f"{API}/patients", headers=make_user(Role.receptionist, "rec2@t.com")[1], json={
        "name": "Other Person", "email": "other@t.com", "password": "Passw0rd!"}).json()
    rows = client.get(f"{API}/patients", headers=ph).json()
    assert [r["patient_id"] for r in rows] == [str(p.patient_id)]
    assert client.get(f"{API}/patients/{other['patient_id']}", headers=ph).status_code == 403


def test_patient_validation(client, make_user):
    _, rh = make_user(Role.receptionist)
    bad = {"name": "A B", "email": "a@t.com", "password": "Passw0rd!", "contact_number": "abc"}
    assert client.post(f"{API}/patients", headers=rh, json=bad).status_code == 422
    assert client.get(f"{API}/patients/00000000-0000-0000-0000-000000000000", headers=rh).status_code == 404


def test_department_and_doctor_admin_flow(client, make_user):
    _, ah = make_user(Role.admin)
    dept = client.post(f"{API}/departments", headers=ah, json={"name": "Neurology"}).json()
    assert client.post(f"{API}/departments", headers=ah, json={"name": "Neurology"}).status_code == 409
    doc = client.post(f"{API}/doctors", headers=ah, json={
        "name": "Dr Strange", "email": "strange@t.com", "password": "Passw0rd!",
        "department_id": dept["department_id"], "availability": {"Mon": "10-2"}})
    assert doc.status_code == 201 and doc.json()["department_name"] == "Neurology"
    bad = {"name": "Dr X", "email": "x@t.com", "password": "Passw0rd!", "department_id": dept["department_id"],
           "availability": {"Funday": "10-2"}}
    assert client.post(f"{API}/doctors", headers=ah, json=bad).status_code == 422
    assert client.delete(f"{API}/departments/{dept['department_id']}", headers=ah).status_code == 409


def test_lab_upload_validation_and_download(client, make_user, patient, tmp_path, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, "UPLOAD_DIR", str(tmp_path))
    p, ph = patient
    _, lh = make_user(Role.lab_technician)
    data = {"patient_id": str(p.patient_id), "test_name": "X-ray"}
    ok = client.post(f"{API}/lab-reports", headers=lh, data=data, files={"file": ("x.png", PNG, "image/png")})
    assert ok.status_code == 201 and ok.json()["has_file"] is True
    rid = ok.json()["report_id"]
    assert client.get(f"{API}/lab-reports/{rid}/download", headers=ph).content == PNG
    bad = client.post(f"{API}/lab-reports", headers=lh, data=data, files={"file": ("x.exe", b"MZ", "application/octet-stream")})
    assert bad.status_code == 422
    fake = client.post(f"{API}/lab-reports", headers=lh, data=data, files={"file": ("x.pdf", b"not a pdf", "application/pdf")})
    assert fake.status_code == 422


def test_admin_deactivates_user_who_then_cannot_login(client, make_user):
    _, ah = make_user(Role.admin)
    client.post(f"{API}/auth/register", json={"name": "Temp User", "email": "tmp@t.com", "password": "Passw0rd!"})
    uid = next(u["user_id"] for u in client.get(f"{API}/users?q=tmp", headers=ah).json())
    assert client.delete(f"{API}/users/{uid}", headers=ah).status_code == 204
    assert client.post(f"{API}/auth/login", json={"email": "tmp@t.com", "password": "Passw0rd!"}).status_code == 401
