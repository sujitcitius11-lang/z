"""Chatbot endpoint: auth, config guard, happy path with a stubbed provider."""
from app.core.config import settings
from app.models import Role
from app.services import chatbot_service
from tests.conftest import API


def test_requires_auth(client):
    assert client.post(f"{API}/chatbot", json={"message": "hi"}).status_code == 401


def test_503_when_not_configured(client, make_user, monkeypatch):
    monkeypatch.setattr(settings, "AZURE_OPENAI_API_KEY", "")
    _, h = make_user(Role.patient)
    assert client.post(f"{API}/chatbot", json={"message": "hi"}, headers=h).status_code == 503


def test_reply_and_validation(client, make_user, monkeypatch):
    async def fake(message, history, role):
        return f"[{role}] echo: {message}"
    monkeypatch.setattr(chatbot_service, "ask", fake)
    _, h = make_user(Role.doctor)
    r = client.post(f"{API}/chatbot", json={"message": "hello"}, headers=h)
    assert r.json() == {"reply": "[doctor] echo: hello"}
    assert client.post(f"{API}/chatbot", json={"message": ""}, headers=h).status_code == 422
    assert client.post(f"{API}/chatbot", json={"message": "x" * 1001}, headers=h).status_code == 422
