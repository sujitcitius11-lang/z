"""Integration: appointment -> prescription -> billing -> pharmacy dispense -> reports."""
from datetime import date, timedelta

from app.models import Role
from tests.conftest import API


def test_full_patient_journey(client, make_user, patient, doctor, slot_dt):
    p, ph = patient
    d, dh = doctor
    _, rh = make_user(Role.receptionist)
    _, pharm_h = make_user(Role.pharmacist)
    _, admin_h = make_user(Role.admin)

    appt = client.post(f"{API}/appointments", headers=rh, json={
        "patient_id": str(p.patient_id), "doctor_id": str(d.doctor_id), "appointment_date": slot_dt("10:00")}).json()

    rx = client.post(f"{API}/prescriptions", headers=dh, json={
        "appointment_id": appt["appointment_id"], "diagnosis": "Viral fever",
        "medicines": [{"name": "Paracetamol", "dosage": "1-0-1", "quantity": 2}]})
    assert rx.status_code == 201
    rx = rx.json()
    done = client.get(f"{API}/appointments", headers=dh).json()[0]
    assert done["status"] == "Completed"
    assert client.get(f"{API}/prescriptions/{rx['prescription_id']}", headers=ph).status_code == 200

    bill = client.post(f"{API}/billing", headers=rh, json={
        "patient_id": str(p.patient_id), "services": [{"name": "Consultation", "amount": 500}, {"name": "CBC", "amount": 250.5}]})
    assert bill.status_code == 201 and bill.json()["total_amount"] == 750.5
    bid = bill.json()["bill_id"]
    assert client.patch(f"{API}/billing/{bid}/payment", headers=rh, json={"payment_status": "Paid"}).status_code == 422
    paid = client.patch(f"{API}/billing/{bid}/payment", headers=rh, json={"payment_status": "Paid", "payment_mode": "Cash"})
    assert paid.json()["payment_status"] == "Paid"
    inv = client.get(f"{API}/billing/{bid}/invoice.pdf", headers=ph)
    assert inv.status_code == 200 and inv.content.startswith(b"%PDF")

    stock = {"name": "Paracetamol", "quantity_available": 5, "expiry_date": str(date.today() + timedelta(days=200)), "unit_price": 2.5}
    assert client.post(f"{API}/medicines", headers=pharm_h, json=stock).status_code == 201
    out = client.post(f"{API}/pharmacy/dispense", headers=pharm_h, json={"prescription_id": rx["prescription_id"]})
    assert out.status_code == 200 and out.json()["total"] == 5.0
    assert client.post(f"{API}/pharmacy/dispense", headers=pharm_h, json={"prescription_id": rx["prescription_id"]}).status_code == 409
    assert client.get(f"{API}/medicines", headers=pharm_h).json()[0]["quantity_available"] == 3

    assert client.get(f"{API}/reports/revenue", headers=admin_h).json()[0]["revenue"] == 750.5
    assert client.get(f"{API}/reports/export?format=csv&report=top-departments", headers=admin_h).status_code == 200


def test_dispense_fails_when_stock_short(client, make_user, patient, doctor, slot_dt):
    p, _ = patient
    d, dh = doctor
    _, rh = make_user(Role.receptionist)
    _, pharm_h = make_user(Role.pharmacist)
    appt = client.post(f"{API}/appointments", headers=rh, json={
        "patient_id": str(p.patient_id), "doctor_id": str(d.doctor_id), "appointment_date": slot_dt("11:00")}).json()
    rx = client.post(f"{API}/prescriptions", headers=dh, json={
        "appointment_id": appt["appointment_id"], "diagnosis": "Cold",
        "medicines": [{"name": "Unobtainium", "dosage": "1-1-1"}]}).json()
    assert client.post(f"{API}/pharmacy/dispense", headers=pharm_h, json={"prescription_id": rx["prescription_id"]}).status_code == 409
