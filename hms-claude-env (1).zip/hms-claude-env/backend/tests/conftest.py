"""Shared fixtures: in-memory SQLite, API client, user factory."""
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core import ratelimit
from app.core.deps import get_db
from app.core.security import create_access_token, hash_password
from app.db.base import Base
from app.main import app
from app.models import Department, Doctor, Patient, Role, User

API = "/api/v1"
ALL_DAYS = {d: "9-12" for d in ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")}


@pytest.fixture()
def db():
    """Fresh in-memory database per test."""
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)() as session:
        yield session


@pytest.fixture()
def client(db):
    """TestClient wired to the test DB."""
    app.dependency_overrides[get_db] = lambda: db
    ratelimit.reset()
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture()
def make_user(db):
    """Factory -> (User, auth_headers)."""
    def _make(role: Role, email: str | None = None):
        user = User(name=f"{role.value} user", email=email or f"{role.value}@t.com", role=role, status=True,
                    password_hash=hash_password("Passw0rd!"), contact_number="9999999999")
        db.add(user)
        db.commit()
        token = create_access_token(str(user.user_id), role.value)
        return user, {"Authorization": f"Bearer {token}"}
    return _make


@pytest.fixture()
def patient(db, make_user):
    """(Patient, headers) for a patient user."""
    user, headers = make_user(Role.patient)
    p = Patient(user_id=user.user_id)
    db.add(p)
    db.commit()
    return p, headers


@pytest.fixture()
def doctor(db, make_user):
    """(Doctor, headers) available 09:00-12:00 every day."""
    user, headers = make_user(Role.doctor)
    dept = Department(name="Cardiology")
    db.add(dept)
    db.flush()
    d = Doctor(user_id=user.user_id, department_id=dept.department_id, availability=ALL_DAYS)
    db.add(d)
    db.commit()
    return d, headers


@pytest.fixture()
def slot_dt():
    """Future date string builder: slot_dt('10:00') -> ISO datetime 7 days ahead."""
    day = date.today() + timedelta(days=7)
    return lambda hhmm: f"{day.isoformat()}T{hhmm}:00"
