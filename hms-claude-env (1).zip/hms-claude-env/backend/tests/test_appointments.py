"""Booking rules: availability, double booking, cancel, access scope."""
from tests.conftest import API


def _book(client, headers, doctor_id, when, patient_id=None):
    body = {"doctor_id": str(doctor_id), "appointment_date": when}
    if patient_id:
        body["patient_id"] = str(patient_id)
    return client.post(f"{API}/appointments", json=body, headers=headers)


def test_patient_books_and_double_booking_blocked(client, patient, doctor, slot_dt):
    p, ph = patient
    d, _ = doctor
    assert _book(client, ph, d.doctor_id, slot_dt("10:00")).status_code == 201
    assert _book(client, ph, d.doctor_id, slot_dt("10:00")).status_code == 409


def test_outside_availability_and_past_rejected(client, patient, doctor, slot_dt):
    _, ph = patient
    d, _ = doctor
    assert _book(client, ph, d.doctor_id, slot_dt("15:00")).status_code == 422
    assert _book(client, ph, d.doctor_id, "2020-01-01T10:00:00").status_code == 422


def test_free_slots_shrink_after_booking(client, patient, doctor, slot_dt):
    _, ph = patient
    d, _ = doctor
    day = slot_dt("10:00")[:10]
    url = f"{API}/doctors/{d.doctor_id}/availability?date={day}"
    before = client.get(url, headers=ph).json()["slots"]
    _book(client, ph, d.doctor_id, slot_dt("10:00"))
    after = client.get(url, headers=ph).json()["slots"]
    assert "10:00" in before and "10:00" not in after


def test_cancel_frees_slot_and_blocks_second_cancel(client, patient, doctor, slot_dt):
    _, ph = patient
    d, _ = doctor
    appt = _book(client, ph, d.doctor_id, slot_dt("09:30")).json()
    assert client.patch(f"{API}/appointments/{appt['appointment_id']}/cancel", headers=ph).json()["status"] == "Cancelled"
    assert client.patch(f"{API}/appointments/{appt['appointment_id']}/cancel", headers=ph).status_code == 409
    assert _book(client, ph, d.doctor_id, slot_dt("09:30")).status_code == 201


def test_receptionist_needs_patient_id(client, make_user, doctor, slot_dt):
    d, _ = doctor
    _, rh = make_user(__import__("app.models", fromlist=["Role"]).Role.receptionist)
    assert _book(client, rh, d.doctor_id, slot_dt("10:00")).status_code == 422
