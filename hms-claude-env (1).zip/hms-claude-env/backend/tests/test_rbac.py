"""Role matrix: every listed endpoint is 403 for denied roles and not 401/403 for allowed ones."""
import uuid

import pytest

from app.models import Role
from tests.conftest import API

A, D, R, P, L, PH, SA = (Role.admin, Role.doctor, Role.receptionist, Role.patient,
                         Role.lab_technician, Role.pharmacist, Role.super_admin)
RULES = [
    ("GET", "/users", {A}),
    ("POST", "/users", {A}),
    ("POST", "/departments", {A}),
    ("POST", "/doctors", {A}),
    ("GET", "/patients", {A, R, P, L}),
    ("POST", "/patients", {A, R}),
    ("GET", "/appointments", {P, R, D}),
    ("POST", "/prescriptions", {D}),
    ("POST", "/lab-reports", {L}),
    ("GET", "/lab-reports", {L, D, P}),
    ("POST", "/billing", {R}),
    ("GET", "/medicines", {PH, A}),
    ("POST", "/pharmacy/dispense", {PH, A}),
    ("GET", "/reports/revenue", {A}),
    ("GET", f"/prescriptions/{uuid.uuid4()}", {D, P, PH}),
]


@pytest.mark.parametrize("method,path,allowed", RULES)
@pytest.mark.parametrize("role", list(Role))
def test_role_matrix(client, make_user, role, method, path, allowed):
    _, headers = make_user(role)
    effective = set(allowed) | ({SA} if A in allowed else set())
    status = client.request(method, API + path, headers=headers).status_code
    if role in effective:
        assert status not in (401, 403), f"{role} should be allowed, got {status}"
    else:
        assert status == 403, f"{role} should be denied, got {status}"
