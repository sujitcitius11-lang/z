# HMS - Hospital Management System (FastAPI + Streamlit)

## Run (Windows)
```
scripts\setup.bat        # venv + deps + creates .env   (once)
scripts\run_all.bat      # API http://localhost:8000/docs + UI http://localhost:8501
```
Separately: `scripts\run_backend.bat` (FastAPI) and `scripts\run_frontend.bat` (Streamlit).
Mac/Linux: same names with `.sh`. Docker: `docker compose up --build`.

## Demo logins (SEED_DEMO_DATA=true) - password `Hms@12345`
superadmin@ / admin@ / doctor@ / reception@ / patient@ / lab@ / pharmacist@ `hms.com`

## Chatbot - where to put API keys
Open **`.env`** (project root, copied from `.env.example`) and fill:
```
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com
AZURE_OPENAI_API_KEY=<key from Azure portal -> Keys and Endpoint>
AZURE_OPENAI_DEPLOYMENT=<deployment name, e.g. gpt-4o-mini>
AZURE_OPENAI_API_VERSION=2024-10-21
```
Restart the backend. Keys live only on the backend; Streamlit calls `POST /api/v1/chatbot`.
Not configured -> the 💬 Chatbot button shows "Chatbot is not configured".
Cost guards: 1000-char message, last 10 turns, `CHATBOT_MAX_TOKENS`, `CHATBOT_RATE_LIMIT` per user/min.

## Test
`cd backend && pytest -q --cov=app` (SQLite in memory, no setup needed)

## Notes
- Appointment slots are 30 min. Availability format: `{"Mon": "10-2", "Tue": "2-6"}` (hours).
- DELETE /users deactivates (history preserved). Notifications are logged (stub).
- Production: set `SEED_DEMO_DATA=false`, a long `SECRET_KEY`, and use Postgres (compose does).
