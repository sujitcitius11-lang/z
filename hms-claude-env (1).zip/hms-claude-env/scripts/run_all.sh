#!/usr/bin/env bash
D="$(dirname "$0")"
trap 'kill 0' EXIT
bash "$D/run_backend.sh" & sleep 4
bash "$D/run_frontend.sh" &
echo "API: http://localhost:8000/docs   UI: http://localhost:8501"
wait
