@echo off
start "HMS API" cmd /k "%~dp0run_backend.bat"
timeout /t 4 >nul
start "HMS UI" cmd /k "%~dp0run_frontend.bat"
echo API: http://localhost:8000/docs   UI: http://localhost:8501
