#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r backend/requirements.txt -r frontend/requirements.txt
[ -f .env ] || cp .env.example .env
echo "Setup done. Edit .env to add Azure chatbot keys, then run scripts/run_all.sh"
