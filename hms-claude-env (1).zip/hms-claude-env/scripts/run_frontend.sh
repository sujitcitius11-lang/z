#!/usr/bin/env bash
cd "$(dirname "$0")/.." && . .venv/bin/activate && cd frontend
exec streamlit run app.py --server.port 8501
