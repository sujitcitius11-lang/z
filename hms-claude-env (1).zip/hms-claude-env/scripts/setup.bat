@echo off
cd /d "%~dp0.."
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r backend\requirements.txt -r frontend\requirements.txt
if not exist .env copy .env.example .env
echo.
echo Setup done. Edit .env to add Azure chatbot keys, then run scripts\run_all.bat
