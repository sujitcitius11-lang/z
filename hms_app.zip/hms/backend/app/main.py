"""FastAPI application entrypoint."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.db.session import SessionLocal
from app.routers import (
    appointments,
    auth,
    billing,
    chat,
    departments,
    doctors,
    lab,
    notifications,
    patients,
    pharmacy,
    prescriptions,
    reports,
    users,
)
from app.services.seed import seed_demo, seed_super_admin


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Seed data on startup (schema is managed by Alembic)."""
    with SessionLocal() as db:
        seed_super_admin(db)
        if get_settings().seed_demo_data:
            seed_demo(db)
    yield


app = FastAPI(title="HMS API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[get_settings().frontend_origin], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

for r in (auth, users, patients, doctors, departments, appointments, prescriptions, lab, billing, pharmacy,
          reports, chat, notifications):
    app.include_router(r.router, prefix="/api/v1")


@app.get("/health")
def health():
    """Public liveness probe."""
    return {"status": "ok"}
