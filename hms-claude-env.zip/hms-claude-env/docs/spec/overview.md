# HMS Overview
Stack: Python 3.10+, FastAPI+Uvicorn, Streamlit, SQLAlchemy 2.x, Alembic, Pydantic v2, PyJWT + passlib(bcrypt), PostgreSQL (prod) / SQLite (dev+tests), pandas (CSV), ReportLab (PDF), Plotly, httpx/requests, pytest.
Roles: admin, doctor, receptionist, patient, lab_technician, pharmacist, super_admin (super_admin = admin + analytics).
Flow: Streamlit -> HTTPS/JSON -> FastAPI -> SQLAlchemy -> DB. Side: file storage (lab reports, local/S3), audit_logs table, email/SMS (optional).
- Streamlit never touches DB. JWT kept in st.session_state, sent as `Authorization: Bearer`.
- RBAC enforced in Streamlit (UX) and FastAPI deps (security). Backend is source of truth.

## Structure
hms/
  backend/app/{main.py, core/(config,security,deps), db/(base,session), models/, schemas/, routers/, services/, utils/(pdf,csv,notifications)}
  backend/{alembic/, tests/, requirements.txt, Dockerfile}
  frontend/{app.py, api_client.py, auth_utils.py, pages/(1_Patients..9_Admin).py, requirements.txt, Dockerfile}
  docker-compose.yml, .env.example, README.md
Routers: auth, users, patients, doctors, departments, appointments, prescriptions, lab, billing, pharmacy, reports.
