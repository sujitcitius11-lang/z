# Security, Testing, DevOps
## Security
JWT access token (refresh optional); bcrypt via passlib (pin passlib==1.7.4, bcrypt==4.0.1); RBAC via deps; audit logs; ORM only (no raw SQL); Pydantic validation; upload validation (type, size); secrets via env (.env never committed); login rate limit; TLS in transit; HIPAA/GDPR-aware handling.
## Testing
pytest + httpx TestClient, SQLite test DB. Per module: happy path, 404/422, RBAC matrix (allowed->2xx, denied->403, via parametrize). Integration: appointments -> prescriptions -> billing. Coverage >= 80% (pytest-cov). Lint: ruff. Locust/Playwright out of scope for the pipeline.
## DevOps
Separate Dockerfiles (backend: uvicorn; frontend: streamlit). docker-compose: backend, frontend, postgres, healthchecks, restart policy. .env.example. CI (GitHub Actions): lint -> test -> build image. Alembic migrations run on backend start. README short.
