# Data Model (all PKs UUID; use sqlalchemy.Uuid + JSON for SQLite/Postgres portability)
users: user_id, name, email(unique), password_hash, role(enum 7 roles), contact_number, status(bool), created_at
patients: patient_id, user_id FK, gender(Male|Female|Other), dob(date), blood_group, address, emergency_contact, allergies(text, comma-sep)
doctors: doctor_id, user_id FK, department_id FK, qualification, availability(JSON e.g. {"Mon":"10-2","Tue":"2-6"})
departments: department_id, name, description
appointments: appointment_id, patient_id FK, doctor_id FK, appointment_date(datetime), status(Scheduled|Completed|Cancelled), notes
prescriptions: prescription_id, appointment_id FK, diagnosis, medicines(JSON [{"name","dosage"}]), created_by FK(doctor)
lab_reports: report_id, patient_id FK, test_name, result_summary, report_file(path/URL), created_by FK(technician), created_at
billing: bill_id, patient_id FK, services(JSON list of {name,amount}), total_amount(Decimal), payment_status(Paid|Unpaid|Partially Paid), payment_mode(Cash|Card|Online), created_at
medicines: medicine_id, name, quantity_available(int), expiry_date(date), unit_price(Decimal)
audit_logs: log_id, user_id FK, action(CREATE|UPDATE|DELETE|LOGIN|VIEW), entity, entity_id, timestamp, ip_address
