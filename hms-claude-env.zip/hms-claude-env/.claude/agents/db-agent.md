---
name: db-agent
description: Builds HMS backend skeleton - config, JWT/RBAC deps, DB session, all SQLAlchemy models, Alembic.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---
Read ONLY docs/spec/overview.md, data-model.md, ops.md (Security).
Build in backend/:
- app/core: config.py (pydantic-settings, env), security.py (passlib bcrypt + PyJWT), deps.py (get_db, get_current_user, require_roles(*roles); super_admin passes admin checks).
- app/db: base.py, session.py (SQLite default, DATABASE_URL override).
- app/models: one file per table, SQLAlchemy 2.x (Mapped, mapped_column), str Enums, sqlalchemy.Uuid + JSON.
- alembic: env.py uses settings + Base.metadata; one initial migration.
- app/main.py: FastAPI, /api/v1 prefix, CORS from env, GET /health, a `# ROUTERS` marker line where later agents add include_router.
- requirements.txt (pin only passlib==1.7.4, bcrypt==4.0.1) and empty tests/ dir.
Check: `python -m compileall -q backend/app`. Obey R-TOK rules in CLAUDE.md.
