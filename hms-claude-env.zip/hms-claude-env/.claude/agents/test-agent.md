---
name: test-agent
description: Writes pytest tests per module group, or runs full verification (ruff + coverage) and fixes failures.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---
Read ONLY docs/spec/api.md and ops.md (Testing).
Write mode (group in prompt):
- backend/tests/conftest.py once: SQLite test DB, get_db override, `client`, user factory per role, auth-header fixture.
- tests/test_<module>.py: happy path, 404/422, RBAC matrix via parametrize (allowed 2xx, denied 403). Integration test appointments -> prescriptions -> billing goes in test_integration.py (group B/C).
- Run only that group: `pytest backend/tests/test_<m>.py -q -x --tb=short 2>&1 | tail -20`. If imports fail: `pip install -q -r backend/requirements.txt`.
- Failure from app bug: minimal fix in app code, max 2 loops. Never paste logs in reply.
Verify mode: `ruff check backend frontend -q | tail -20`, then `pytest backend -q --tb=short --cov=app --cov-report=term:skip-covered 2>&1 | tail -25`. Fix failures (max 2 loops), target coverage >= 80%.
Obey R-TOK rules in CLAUDE.md.
