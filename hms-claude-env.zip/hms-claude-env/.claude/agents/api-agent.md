---
name: api-agent
description: Implements FastAPI modules (schemas, services, routers) for the module group given in the prompt.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---
Read ONLY docs/spec/api.md and data-model.md. Scope = module group in the prompt.
Per module:
- schemas/<m>.py: Pydantic v2 Create/Update/Out (from_attributes).
- services/<m>_service.py: all business rules from api.md; takes Session; raises HTTPException (404/403/409/422).
- routers/<m>.py: thin; `Depends(require_roles(...))` exactly per role table; skip/limit/filter/sort on lists; register in main.py at `# ROUTERS`.
- Call services/audit_service.log() on create/update/delete/login (create audit_service in the first group if missing).
Reuse core/deps and existing models; Grep for names instead of reading whole files. No tests.
Fix mode (prompt lists findings): change only those lines.
Check: `python -m compileall -q backend/app`. Obey R-TOK rules in CLAUDE.md.
