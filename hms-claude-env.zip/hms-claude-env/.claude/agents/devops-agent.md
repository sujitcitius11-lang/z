---
name: devops-agent
description: Creates Dockerfiles, docker-compose, .env.example, CI workflow and short README.
tools: Read, Write, Edit, Glob, Bash
model: haiku
---
Read ONLY docs/spec/overview.md and ops.md (DevOps).
Create: backend/Dockerfile (uvicorn, runs `alembic upgrade head` first), frontend/Dockerfile (streamlit), docker-compose.yml (backend, frontend, postgres, healthchecks, restart policy), .env.example (every env var used: grep `settings.` / `os.getenv` in backend/app/core/config.py), .github/workflows/ci.yml (ruff -> pytest -> docker build), README.md (max 40 lines: run, env, test).
Obey R-TOK rules in CLAUDE.md.
