---
name: ui-agent
description: Builds Streamlit frontend - login, api_client, auth_utils and role-gated pages for the scope in the prompt.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---
Read ONLY docs/spec/ui.md and docs/spec/api.md. Scope in the prompt.
- All HTTP only in frontend/api_client.py (one function per endpoint, Bearer from st.session_state, 401 -> logout).
- auth_utils.py: session helpers, `require_role([...])` called first in every page.
- Pages follow ui.md exactly: st.form for input, st.cache_data(ttl) for reference data, st.success/error/toast. No custom CSS. Max 150 lines per page.
- Never import from backend/.
- Create frontend/requirements.txt (streamlit, requests, pandas, plotly) if missing.
Fix mode (prompt lists findings): change only those lines.
Check: `python -m compileall -q frontend`. Obey R-TOK rules in CLAUDE.md.
