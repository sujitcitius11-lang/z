"""UserPromptSubmit guardrail: block clearly off-topic prompts before any tokens are spent."""
import json
import sys

BLOCK_MSG = "I can't answer this question"
DENY = ["movie", "song", "celebrity", "astrology", "politics", "cricket",
        "football", "stock tips", "recipe", "travel plan", "horoscope", "lyrics"]
ALLOW = ["hms", "hospital", "patient", "doctor", "fastapi", "streamlit", "python",
         "api", "test", "endpoint", "router", "service", "model", "schema", "jwt",
         "billing", "pharmacy", "lab", "appointment", "docker", "agent", "pipeline",
         "bug", "error", "fix", "code", "review"]


def main() -> None:
    try:
        prompt = json.load(sys.stdin).get("prompt", "")
    except Exception:
        return
    p = prompt.strip().lower()
    if p.startswith("/"):
        return
    if any(d in p for d in DENY) and not any(a in p for a in ALLOW):
        print(json.dumps({"decision": "block", "reason": BLOCK_MSG}))


if __name__ == "__main__":
    main()
