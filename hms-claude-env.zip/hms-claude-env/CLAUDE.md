# HMS - Hospital Management System (FastAPI + Streamlit)
Spec (source of truth): docs/spec/*.md. NEVER read docs/BRD.txt.
Build everything with `/build-agent-api`. Do not hand-run agents.

## Rules
- R-ARCH-01 Router -> Service -> Model. Routers thin, logic in services.
- R-API-01 Pydantic v2 schemas for all I/O. Never return ORM objects.
- R-SEC-01 `require_roles` on every non-public endpoint. Backend is authoritative.
- R-SEC-02 bcrypt hashes. Secrets from env only.
- R-UI-01 Streamlit talks to API only via frontend/api_client.py. Never touches DB.
- R-AUD-01 Audit-log create/update/delete/login.
- R-DOC-01 One-line docstring per public func/class. No other comments.

## Token rules (every agent)
- R-TOK-01 Read only the spec files named in your agent file.
- R-TOK-02 Don't re-read files you just wrote. No repo-wide ls/tree. Narrow Grep/Glob. Read with limit on big files.
- R-TOK-03 Write files directly. Never echo code, specs or logs in replies.
- R-TOK-04 Quiet commands: `-q` flags, pipe output through `| tail -20`.
- R-TOK-05 Final reply max 5 lines: `S<stage> OK|FAIL | files:<n> | <=15 words`.
- R-GRD-01 Off-topic request -> reply exactly: I can't answer this question
